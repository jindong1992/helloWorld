#ifndef DBG_TRACE_ISA
#   define DBG_TRACE_ISA
/*===========================================================================*/
/**
 * @file dbg_trace_isa.h
 *
 *   Maps the BASA dbg_trace API to the ISA debugtrace API.
 *
 * %full_filespec:dbg_trace_isa.h~kok_basa#5:incl:kok_aud#1 %
 * @version %version:kok_basa#5 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Mon Nov  7 11:46:07 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - EM - Error Management
 *   - TR - TRace
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_10016705_BASA_dbg_trace.doc
 *
 *   - Requirements Document(s):
 *     - BASA_SRS_Error_Management_1.2.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup dbg_trace_client
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "debugtrace.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/**
 * NOTE: The following is only for use internally; it is not part of the
 * outside "API". It converts the module id into a mask, which is used in
 * the debugtrace API to specify the "group".
 */
#   define __TR_GET_MASK ((uint64_t)1<<(TR_FILE_ID>>EM_MOD_SHIFT_CNT))

#   if (TR_COMPILE_VERBOSITY == TR_COMPILE_DISABLED)
/*############################################################################
 *
 * TRACE DISABLED - No trace code is generated
 *
 *############################################################################*/

#      define Tr_Fault(msg)
#      define Tr_Fault_1(msg,a1)
#      define Tr_Fault_2(msg,a1,a2)
#      define Tr_Fault_3(msg,a1,a2,a3)
#      define Tr_Fault_4(msg,a1,a2,a3,a4)

#      define Tr_Warn(msg)
#      define Tr_Warn_1(msg,a1)
#      define Tr_Warn_2(msg,a1,a2)
#      define Tr_Warn_3(msg,a1,a2,a3)
#      define Tr_Warn_4(msg,a1,a2,a3,a4)

#      define Tr_Notify(msg)
#      define Tr_Notify_1(msg,a1)
#      define Tr_Notify_2(msg,a1,a2)
#      define Tr_Notify_3(msg,a1,a2,a3)
#      define Tr_Notify_4(msg,a1,a2,a3,a4)

#      define Tr_Info_Hi(msg)
#      define Tr_Info_Hi_1(msg,a1)
#      define Tr_Info_Hi_2(msg,a1,a2)
#      define Tr_Info_Hi_3(msg,a1,a2,a3)
#      define Tr_Info_Hi_4(msg,a1,a2,a3,a4)

#      define Tr_Info_Mid(msg)
#      define Tr_Info_Mid_1(msg,a1)
#      define Tr_Info_Mid_2(msg,a1,a2)
#      define Tr_Info_Mid_3(msg,a1,a2,a3)
#      define Tr_Info_Mid_4(msg,a1,a2,a3,a4)

#      define Tr_Info_Lo(msg)
#      define Tr_Info_Lo_1(msg,a1)
#      define Tr_Info_Lo_2(msg,a1,a2)
#      define Tr_Info_Lo_3(msg,a1,a2,a3)
#      define Tr_Info_Lo_4(msg,a1,a2,a3,a4)

#   elif (TR_COMPILE_VERBOSITY == TR_COMPILE_COMPACT)
/*############################################################################
 *
 * COMPACT TRACE - Minimal trace information is logged
 *
 *############################################################################*/

#      define Tr_Fault(msg) Tr_Err(msg)
#      define Tr_Fault_1(msg,a1) Tr_Err(msg,a1)
#      define Tr_Fault_2(msg,a1,a2) Tr_Err(msg,a1,a2)
#      define Tr_Fault_3(msg,a1,a2,a3) Tr_Err(msg,a1,a2,a3)
#      define Tr_Fault_4(msg,a1,a2,a3,a4) Tr_Err(msg,a1,a2,a3,a4)

#      define Tr_Warn(msg) Tr_Wrn(msg)
#      define Tr_Warn_1(msg,a1) Tr_Wrn(msg,a1)
#      define Tr_Warn_2(msg,a1,a2) Tr_Wrn(msg,a1,a2)
#      define Tr_Warn_3(msg,a1,a2,a3) Tr_Wrn(msg,a1,a2,a3)
#      define Tr_Warn_4(msg,a1,a2,a3,a4) Tr_Wrn(msg,a1,a2,a3,a4)

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_NOTIFY)

#         define Tr_Notify(msg)
#         define Tr_Notify_1(msg,a1)
#         define Tr_Notify_2(msg,a1,a2)
#         define Tr_Notify_3(msg,a1,a2,a3)
#         define Tr_Notify_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Notify(msg) Tr_Inf(__TR_GET_MASK,msg)
#         define Tr_Notify_1(msg,a1) Tr_Inf(__TR_GET_MASK,msg,a1)
#         define Tr_Notify_2(msg,a1,a2) Tr_Inf(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Notify_3(msg,a1,a2,a3) Tr_Inf(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Notify_4(msg,a1,a2,a3,a4) Tr_Inf(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI)

#         define Tr_Info_Hi(msg)
#         define Tr_Info_Hi_1(msg,a1)
#         define Tr_Info_Hi_2(msg,a1,a2)
#         define Tr_Info_Hi_3(msg,a1,a2,a3)
#         define Tr_Info_Hi_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Hi(msg) Tr_Dbg_At1(__TR_GET_MASK,msg)
#         define Tr_Info_Hi_1(msg,a1) Tr_Dbg_At1(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Hi_2(msg,a1,a2) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Hi_3(msg,a1,a2,a3) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Hi_4(msg,a1,a2,a3,a4) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_MID)

#         define Tr_Info_Mid(msg)
#         define Tr_Info_Mid_1(msg,a1)
#         define Tr_Info_Mid_2(msg,a1,a2)
#         define Tr_Info_Mid_3(msg,a1,a2,a3)
#         define Tr_Info_Mid_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Mid(msg) Tr_Dbg_At2(__TR_GET_MASK,msg)
#         define Tr_Info_Mid_1(msg,a1) Tr_Dbg_At2(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Mid_2(msg,a1,a2) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Mid_3(msg,a1,a2,a3) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Mid_4(msg,a1,a2,a3,a4) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_MID */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_LO)

#         define Tr_Info_Lo(msg)
#         define Tr_Info_Lo_1(msg,a1)
#         define Tr_Info_Lo_2(msg,a1,a2)
#         define Tr_Info_Lo_3(msg,a1,a2,a3)
#         define Tr_Info_Lo_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Lo(msg) Tr_Dbg_At3(__TR_GET_MASK,msg)
#         define Tr_Info_Lo_1(msg,a1) Tr_Dbg_At3(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Lo_2(msg,a1,a2) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Lo_3(msg,a1,a2,a3) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Lo_4(msg,a1,a2,a3,a4) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_LO */

#   elif (TR_COMPILE_VERBOSITY == TR_COMPILE_VERBOSE)
/*############################################################################
 *
 * VERBOSE TRACE - all trace information is logged
 *
 *############################################################################*/

#      define Tr_Fault(msg) Tr_Err(msg)
#      define Tr_Fault_1(msg,a1) Tr_Err(msg,a1)
#      define Tr_Fault_2(msg,a1,a2) Tr_Err(msg,a1,a2)
#      define Tr_Fault_3(msg,a1,a2,a3) Tr_Err(msg,a1,a2,a3)
#      define Tr_Fault_4(msg,a1,a2,a3,a4) Tr_Err(msg,a1,a2,a3,a4)

#      define Tr_Warn(msg) Tr_Wrn(msg)
#      define Tr_Warn_1(msg,a1) Tr_Wrn(msg,a1)
#      define Tr_Warn_2(msg,a1,a2) Tr_Wrn(msg,a1,a2)
#      define Tr_Warn_3(msg,a1,a2,a3) Tr_Wrn(msg,a1,a2,a3)
#      define Tr_Warn_4(msg,a1,a2,a3,a4) Tr_Wrn(msg,a1,a2,a3,a4)

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_NOTIFY)

#         define Tr_Notify(msg)
#         define Tr_Notify_1(msg,a1)
#         define Tr_Notify_2(msg,a1,a2)
#         define Tr_Notify_3(msg,a1,a2,a3)
#         define Tr_Notify_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Notify(msg) Tr_Inf(__TR_GET_MASK,msg)
#         define Tr_Notify_1(msg,a1) Tr_Inf(__TR_GET_MASK,msg,a1)
#         define Tr_Notify_2(msg,a1,a2) Tr_Inf(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Notify_3(msg,a1,a2,a3) Tr_Inf(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Notify_4(msg,a1,a2,a3,a4) Tr_Inf(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI)

#         define Tr_Info_Hi(msg)
#         define Tr_Info_Hi_1(msg,a1)
#         define Tr_Info_Hi_2(msg,a1,a2)
#         define Tr_Info_Hi_3(msg,a1,a2,a3)
#         define Tr_Info_Hi_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Hi(msg) Tr_Dbg_At1(__TR_GET_MASK,msg)
#         define Tr_Info_Hi_1(msg,a1) Tr_Dbg_At1(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Hi_2(msg,a1,a2) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Hi_3(msg,a1,a2,a3) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Hi_4(msg,a1,a2,a3,a4) Tr_Dbg_At1(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_HI */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_MID)

#         define Tr_Info_Mid(msg)
#         define Tr_Info_Mid_1(msg,a1)
#         define Tr_Info_Mid_2(msg,a1,a2)
#         define Tr_Info_Mid_3(msg,a1,a2,a3)
#         define Tr_Info_Mid_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Mid(msg) Tr_Dbg_At2(__TR_GET_MASK,msg)
#         define Tr_Info_Mid_1(msg,a1) Tr_Dbg_At2(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Mid_2(msg,a1,a2) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Mid_3(msg,a1,a2,a3) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Mid_4(msg,a1,a2,a3,a4) Tr_Dbg_At2(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_MID */

#      if (TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_LO)

#         define Tr_Info_Lo(msg)
#         define Tr_Info_Lo_1(msg,a1)
#         define Tr_Info_Lo_2(msg,a1,a2)
#         define Tr_Info_Lo_3(msg,a1,a2,a3)
#         define Tr_Info_Lo_4(msg,a1,a2,a3,a4)

#      else

#         define Tr_Info_Lo(msg) Tr_Dbg_At3(__TR_GET_MASK,msg)
#         define Tr_Info_Lo_1(msg,a1) Tr_Dbg_At3(__TR_GET_MASK,msg,a1)
#         define Tr_Info_Lo_2(msg,a1,a2) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2)
#         define Tr_Info_Lo_3(msg,a1,a2,a3) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2,a3)
#         define Tr_Info_Lo_4(msg,a1,a2,a3,a4) Tr_Dbg_At3(__TR_GET_MASK,msg,a1,a2,a3,a4)

#      endif                    /* TR_COMPILE_INFO_LEVEL < TR_LVL_INFO_LO */

#   else

#      error TR_COMPILE_VERBOSITY is not set to a supported value.

#   endif                       /* if (TR_COMPILE_VERBOSITY == TR_COMPILE_DISABLED) */

#   define Tr_Get_Module_Info_Trace_Level(module_id) Dt_Get_Level()

#   define Tr_Set_Info_Trace_Level(lvl) Tr_Set_Level(lvl)

#   define Tr_Set_Module_Info_Trace_Level(module_id,lvl) Tr_Set_Level(lvl)

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */

/*===========================================================================*/
/*!
 * @file dbg_trace_isa.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 04-Nov-2011 kirk bailey
 *   - Added NOTIFY level.
*
 * - 23-feb-2009 kirk bailey
 *   - Changed __TR_GET_MASK to work with module ids > 31.
 *   - Added mappings for Tr_Get_Module_Info_Trace_Level and Tr_Set*.
 *
 * - 12-feb-2009 kirk bailey
 *   - Converted API to map to ISA debugtrace API.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* DBG_TRACE_ISA */
