#ifndef DBG_TRACE_CBK_H
#   define DBG_TRACE_CBK_H
/*===========================================================================*/
/**
 * @file dbg_trace_cbk.h
 *
 * Defines the callout interface for the debug trace module.
 *
 * %full_filespec:dbg_trace_cbk.h~kok_basa#5:incl:kok_aud#1 %
 * @version %version:kok_basa#5 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Thu May 10 08:25:46 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @addtogroup dbg_trace
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include <stdarg.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/**
 * Structure holding trace event information to log. 
 */
typedef struct Tr_Compact_Data_Tag
{
  uint16_t trace_level; /**< The level of the trace (TR_LVL_FAULT, etc.) */
  uint16_t file_id;     /**< A numeric id for the file with the trace statement. */
  uint16_t line_num;    /**< The source code line number of the trace statement. */
  uint16_t num_args;    /**< The actual # of arguments in the args array(compact mode only). */
  uint32_t args[4];     /**< Trace-specific numeric data (compact mode only). */
  uint32_t timestamp;   /**< Time of occurrence (if not TR_STAND_ALONE). */
  uint32_t app_id;      /**< Application causing trace event (if not TR_STAND_ALONE). */
  uint32_t thread_id;   /**< Thread causing trace event (if not TR_STAND_ALONE). */
  uint32_t thr_cpu_time_ms; /**< Thread CPU time (if available). */
}
Tr_Compact_Data_T;

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
/**
 * Logs a pre-formatted message to all of the outputs of Debug Trace.
 *
 * @note Do NOT call directly.
 *
 * @param [in] trace_output Character string to output to all of the Debug Trace sinks
 *
 */
void Tr_Log(char_t * trace_output);

/**
 * Outputs a Call Stack backtrace from the location where this function was
 * executed. This will list all of the functions that have been called to get
 * to this point of execution.
 *
 * @note This Call Stack backtrace will be output regardless of the Trace Level
 * for the executing module. The caller of this function is responsible for
 * only calling this function when the Trace Level is appropriate (if desired).
 *
 * @note Currently only supported on a Linux C99 platform.
 */
void Tr_Print_Stack_Backtrace(void);

/**
 * This callout allows the system to customize its treatment of compact trace
 * data; it can simply be "printed out" or it can be logged to a file system.
 *
 * @param tr_data [in] The compact data captured by the trace statement.
 */
void Tr_Store_Compact_Data(Tr_Compact_Data_T const *tr_data);

/**
 * This callout allows the system to customize its treatment of verbose trace
 * data; it can simply be "printed out" or it can be logged to a file system.
 *
 * @param tr_data [in] The compact data captured by the trace statement.
 * @param f_name [in] The name of the file containing the trace statement.
 * @param msg [in] The printf-like format string for the trace statement.
 * @param arg [in] Any variable-argument parameters needed by the format string.
 */
void Tr_Store_Verbose_Data(Tr_Compact_Data_T const *tr_data,
                           char_t const *f_name, char_t const *msg, va_list arg);

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#
/*===========================================================================*/
/*!
 * @file dbg_trace_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 10-May-2012 kirk bailey Rev. 5
 *   - Added thread CPU time.
 *
 * - 07-may-2011 Kris Boultbee
 *   Task kok_basa#30663 Revision 4
 *   - Added function Tr_Log() used to log a pre-formatted string to Debug Trace.
 *
 * - 11-Dec-2010 kirk bailey Rev. 3
 *   - Task 17813 - Added XSAL app id to trace output.
 *
 * - 08-aug-2008 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* DBG_TRACE_CBK_H */
