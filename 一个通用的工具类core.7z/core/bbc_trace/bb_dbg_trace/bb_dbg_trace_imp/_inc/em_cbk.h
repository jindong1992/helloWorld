#ifndef EM_CBK_H
#   define EM_CBK_H
/*===========================================================================*/
/**
 * @file em_cbk.h
 *
 * Defines the callout API for the EM  Asserts
 *
 * %full_filespec:em_cbk.h~kok_basa#4:incl:kok_aud#4 %
 * @version %version:kok_basa#4 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Tue Jul 12 12:55:39 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - EM = Error Management
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_BASA_Error_Management.doc (version 0.7)
 *
 *   - Requirements Document(s):
 *     BASA_SRS_Error_Management_1.2.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @addtogroup em
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * This callout is made when an EM assert occurs; it should implement
 * whatever system action is appropriate for a system fault. Keep in mind that
 * a basic assumption of assert-based logic is that this call NEVER returns.
 */
void EM_Assert(void);

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */

/*===========================================================================*/
/*!
 * @file em_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 12-Jun-2011 Kirk Bailey Rev. 4
 *   - Eliminated configurable assert types; replaced with a single callout.
 *
 * - 06-aug-2008 kirk bailey
 *   - Added EM_Restart() and EM_Bench() callouts
 *
 * - 05-oct-2007 kirk bailey
 *   - Updated Doxygen comments to new version 1.5.3 conventions
 *
 * - 05-Sept-2007 Dan Carman
 *   - Added callout to save trace message and trace data block
 *
 * - 04-apr-2007 kirk bailey
 *   - Created initial file
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* EM_ICBK_H */
