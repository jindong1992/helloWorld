/*===========================================================================*/
/**
 * @file dbg_trace_verbose.c
 *
 *   Implements the output of verbose dbg_trace data.
 *
 * %full_filespec: dbg_trace_verbose.c~kok_basa#3:csrc:kok_aud#1 %
 * @version %version: kok_basa#3 %
 * @author  %derived_by: dzq92s %
 * @date    %date_modified: Thu May 10 08:25:48 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - TR = TRace
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "dbg_trace_cbk.h"
#include "dbg_trace_cfg.h"
#include "dbg_trace_imp.h"
#include <stdarg.h>
#if defined(DBG_USE_THREAD_CPU_TIME) && (DBG_USE_THREAD_CPU_TIME==true)
#   include <time.h>
#endif

#if (TR_STAND_ALONE)

#   define SAL_Get_Thread_Id() 1
#   define SAL_Clock()         0
#   define SAL_Get_App_Id()    0

#else

#   include "xsal.h"

#endif /* if (TR_STAND_ALONE) */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 *
 * Please refer to the detailed description in dbg_trace.h
 *
 *===========================================================================*/
void Tr_Trace_Verbose(Tr_Trace_Level_T lvl, uint16_t f_num, char_t const *f_name,
                      uint16_t line_num, char_t const *msg, ...)
{
   if (tr_Is_Trace_Level_Enabled(f_num, lvl))
   {
      va_list arg_ptr;
      Tr_Compact_Data_T tr_data;
#if defined(DBG_USE_THREAD_CPU_TIME) && (DBG_USE_THREAD_CPU_TIME==true)
      struct timespec thr_time;

      clock_gettime(CLOCK_THREAD_CPUTIME_ID, &thr_time);
#endif
      tr_data.trace_level = lvl;
      tr_data.file_id     = f_num;
      tr_data.line_num    = line_num;
      tr_data.timestamp   = SAL_Clock();
      tr_data.thread_id   = SAL_Get_Thread_Id();
      tr_data.app_id      = SAL_Get_App_Id();
#if defined(DBG_USE_THREAD_CPU_TIME) && (DBG_USE_THREAD_CPU_TIME==true)
      tr_data.thr_cpu_time_ms = (thr_time.tv_sec * 1000) + (thr_time.tv_nsec / 1000000);
#else
      tr_data.thr_cpu_time_ms = 0;
#endif
      va_start(arg_ptr, msg);
      Tr_Store_Verbose_Data(&tr_data, f_name, msg, arg_ptr);
      va_end(arg_ptr);
   }
}

/*===========================================================================*/
/*!
 * @file dbg_trace_verbose.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 10-May-2012 kirk bailey Rev. 3
 *   - Added option for CPU thread time.
 *
 * - 11-Dec-2010 kirk bailey Rev. 2
 *   - Task 17813 - Added XSAL app id to trace output.
 *
 * - 11-jun-2008 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
