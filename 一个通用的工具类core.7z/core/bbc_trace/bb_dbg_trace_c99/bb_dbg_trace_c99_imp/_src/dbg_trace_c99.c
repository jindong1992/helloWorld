/*===========================================================================*/
/**
 * @file dbg_trace_c99.c
 *
 *   Implements utility functions for translating dbg_trace data into
 *   strings using C99 extensions to the C standard library.
 *
 * %full_filespec:dbg_trace_c99.c~kok_basa#11:csrc:kok_aud#1 %
 * @version %version:kok_basa#11 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Thu May 10 08:25:49 2012 %
 *
 *----------------------------------------------------------------------------
 *
 * Copyright 2010-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *----------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "dbg_trace_c99.h"
#include "dbg_trace_cfg.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#ifndef DBG_TRACE_PATH_SEPARATOR
#   define DBG_TRACE_PATH_SEPARATOR '/'
#endif

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * Table used to translate Tr_Trace_Level_T values to strings.
 */
static char_t const *Trace_Levels[] = {
   "FAULT",
   "WARN",
   "NOTIFY",
   "INFO_HI",
   "INFO_MID",
   "INFO_LO"
};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 *
 * Please refer to the detailed description in dbg_trace_c99.h
 *
 *===========================================================================*/
int32_t Tr_Snprintf_Compact(char_t * buf, size_t buf_size, Tr_Compact_Data_T const *tr_data)
{
   ssize_t num_written;
   ssize_t total_num_written = 0;
   char_t const *tr_descr = "?";
   ssize_t num_left = buf_size;

   if ((NULL == buf) || (NULL == tr_data))
   {
      /*******/
      return 0;
      /*******/
   }

   if (tr_data->trace_level <= TR_LVL_INFO_LO)
   {
      tr_descr = Trace_Levels[tr_data->trace_level];
   }

   num_written =
#if defined(DBG_USE_THREAD_CPU_TIME) && (DBG_USE_THREAD_CPU_TIME==true)
      snprintf(buf + total_num_written, num_left, "[%u:%u] %u:%u; %#x:%u; %s",
               (unsigned)tr_data->timestamp, (unsigned)tr_data->thr_cpu_time_ms,
               (unsigned)tr_data->app_id,    (unsigned)tr_data->thread_id,
               (unsigned)tr_data->file_id,   (unsigned)tr_data->line_num, tr_descr);
#else
      snprintf(buf + total_num_written, num_left,
               "[%u] %u:%u; %#x:%u; %s",   (unsigned)tr_data->timestamp,
               (unsigned)tr_data->app_id,  (unsigned)tr_data->thread_id,
               (unsigned)tr_data->file_id, (unsigned)tr_data->line_num, tr_descr);
#endif
   if (num_written < 0)
   {
      total_num_written = num_written;
   }
   else if (num_written >= num_left)
   {
      total_num_written += num_written;
   }
   else
   {
      total_num_written += num_written;
      num_left -= num_written;

      if (tr_data->num_args > 0)
      {
         num_written = snprintf(buf + total_num_written, num_left, " -");

         if (num_written < 0)
         {
            total_num_written = num_written;
         }
         else if (num_written >= num_left)
         {
            total_num_written += num_written;
         }
         else
         {
            int32_t i;

            total_num_written += num_written;
            num_left -= num_written;

            for (i = 0; i < tr_data->num_args; i++)
            {
               num_written = snprintf(buf + total_num_written, num_left, " %#x", (unsigned)tr_data->args[i]);

               if (num_written < 0)
               {
                  total_num_written = num_written;
                  break;
               }
               else if (num_written >= num_left)
               {
                  total_num_written += num_written;
                  break;
               }
               else
               {
                  total_num_written += num_written;
                  num_left -= num_written;
               }
            }
         }
      }
   }
   if (buf_size > 0)
   {
      buf[buf_size-1] = '\0'; /* Make sure to NUL terminate a truncated string */
   }
   return total_num_written;    /* WARNING: Multiple returns in function body. */
}

/*===========================================================================*
 *
 * Please refer to the detailed description in dbg_trace_c99.h
 *
 *===========================================================================*/
int32_t Tr_Snprintf_Verbose(char_t * buf, size_t buf_size,
                            Tr_Compact_Data_T const *tr_data, char_t const *f_name, char_t const *msg, va_list arg_ptr)
{
   char_t const *short_f_name = "?";
   ssize_t num_written;
   ssize_t total_num_written = 0;
   char_t const *tr_descr = "?";
   ssize_t num_left = buf_size;

   if ((NULL == buf) || (NULL == tr_data))
   {
      /*******/
      return 0;
      /*******/
   }

   if (f_name != NULL)
   {
      short_f_name = strrchr(f_name, DBG_TRACE_PATH_SEPARATOR);
      if (NULL == short_f_name)
      {
         short_f_name = f_name;
      }
      else
      {
         short_f_name++;
      }
   }                            /* if (f_name != NULL) */

   if (tr_data->trace_level <= TR_LVL_INFO_LO)
   {
      tr_descr = Trace_Levels[tr_data->trace_level];
   }
#if defined(DBG_USE_THREAD_CPU_TIME) && (DBG_USE_THREAD_CPU_TIME==true)
   num_written = snprintf(buf + total_num_written, num_left, "[%u:%u] %u:%u; %s:%u; %s - ",
                          (unsigned)tr_data->timestamp, (unsigned)tr_data->thr_cpu_time_ms,
                          (unsigned)tr_data->app_id,    (unsigned)tr_data->thread_id,
                          short_f_name, (unsigned)tr_data->line_num, tr_descr);
#else
   num_written = snprintf(buf + total_num_written, num_left, "[%u] %u:%u; %s:%u; %s - ",
                          (unsigned)tr_data->timestamp,
                          (unsigned)tr_data->app_id, (unsigned)tr_data->thread_id,
                          short_f_name, (unsigned)tr_data->line_num, tr_descr);
#endif
   if (num_written < 0)
   {
      total_num_written = num_written;
   }
   else if (num_written >= num_left)
   {
      total_num_written += num_written;
   }
   else if (msg != NULL)
   {
      total_num_written += num_written;
      num_left -= num_written;

      num_written = vsnprintf(buf + total_num_written, num_left, msg, arg_ptr);

      if (num_written < 0)
      {
         total_num_written = num_written;
      }
      else
      {
         total_num_written += num_written;
      }
   }
   if (buf_size > 0)
   {
      buf[buf_size-1] = '\0'; /* Make sure to NUL terminate a truncated string */
   }
   return total_num_written;    /* WARNING: Multiple returns in function body. */
}

/*===========================================================================*/
/*!
 * @file dbg_trace_c99.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 10-May-2012 kirk bailey Rev. 11
 *   - Added option for thread CPU time.
 *
 * - 04-Nov-2011 Kirk Bailey Rev. 10
 *   - Added NOTIFY level.
 *
 * - 11-Dec-2010 kirk bailey Rev. 9
 *   - Task 17813 - Added XSAL app id to trace output.
 *
 * - 11-oct-2010 kirk bailey
 *   - SCR 3638 - Changed timestamp formatting to unsigned.
 *
 * - 08-oct-2010 kirk bailey
 *   - SCR 3632 - Guarantee a terminated string has a NUL character on the end.
 *
 * - 06-oct-2010 kirk bailey
 *   - SCR 3429 - Fixed signed/unsigned mismatch warning for Visual Studio compiler.
 *
 * - 07-jul-2009 kirk bailey
 *   - Removed unnecessary information from the verbose output.
 *
 * - 02-dec-2008 kirk bailey
 *   - Replaced '/' with DBG_TRACE_PATH_SEPARATOR, which can be overridden, so
 *     that both DOS and UNIX file separators can be supported.
 *
 * - 11-jun-2008 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
