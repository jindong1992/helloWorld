/*===========================================================================*/
/**
 * @file dbg_call_stack_backtrace_c99.c
 *
 * Displays the current call stack backtrace.
 *
 * %full_filespec:dbg_call_stack_backtrace_c99.c~6:csrc:kok_basa#1 %
 * @version %version:6 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Tue Jan 10 19:31:49 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Displays the current call stack backtrace if call stack backtrace
 * is available on the platform. If call stack backtrace is not available
 * nothing will be printed.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PbC Programming by Contract
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "dbg_trace.h"
#include "dbg_trace_cbk.h"
#include "dbg_trace_cfg.h"

#if (TR_STAND_ALONE)

#   define SAL_Get_Thread_Id() 1
#   define SAL_Clock()         0
#   define SAL_Get_App_Id()    0

#else

#   include "xsal.h"

#endif /* TR_STAND_ALONE */

#ifdef DBG_ENABLE_STACK_BACKTRACE
#   if (DBG_ENABLE_STACK_BACKTRACE == true)
#      ifdef LINUX
#         include <execinfo.h>
#      endif /* ifdef LINUX */
#   include <stdlib.h>
#   include <stdio.h>
#   include <string.h>
#   include <syslog.h>
#   include <unistd.h>
#   endif /* (DBG_ENABLE_STACK_BACKTRACE == true) */
#endif    /* DBG_ENABLE_STACK_BACKTRACE */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#ifndef DBG_MAX_CALL_DEPTH
/**
 * Maximum stack callback depth to track/log.
 */
#   define DBG_MAX_CALL_DEPTH 32
#endif

#ifndef DBG_BT_LOG_BUF_SZ
/**
 * Size of output buffer to use for forming log messages.
 */
#   define DBG_BT_LOG_BUF_SZ 512
#endif

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/* ========================================================================
 *
 * Please refer to dbg_trace_cbk.h for more details.
 *
 * ========================================================================*/
void Tr_Print_Stack_Backtrace(void)
{
#if defined(DBG_ENABLE_STACK_BACKTRACE) && (DBG_ENABLE_STACK_BACKTRACE == true) && defined(LINUX)
   size_t buf_ofst = 0;
   int num_addrs;
   char sigbuf[DBG_BT_LOG_BUF_SZ];
   void *bt_addrs[DBG_MAX_CALL_DEPTH];

   num_addrs = backtrace(bt_addrs, Num_Elems(bt_addrs));

   if (num_addrs <= 0)
   {
      snprintf(sigbuf + buf_ofst, sizeof(sigbuf) - buf_ofst,
         "[%u] %d:%d; dbg_call_stack_backtrace_c99.c:%u; FAULT - No stack backtrace data available (stack corrupted?)", (unsigned) SAL_Clock(),
         (int) SAL_Get_App_Id(), (int) SAL_Get_Thread_Id(), (unsigned) __LINE__);
   }
   else
   {
      int i;
      size_t new_ofst;

      new_ofst = snprintf(sigbuf + buf_ofst, sizeof(sigbuf) - buf_ofst, "[%u] %d:%d; dbg_call_stack_backtrace_c99.c:%u; FAULT - Stack backtrace:",
         (unsigned) SAL_Clock(), (int) SAL_Get_App_Id(), (int) SAL_Get_Thread_Id(), (unsigned) __LINE__);

      if (new_ofst >= 0)
      {
         buf_ofst += new_ofst;
      }

      for (i = 1; i < num_addrs && buf_ofst < sizeof(sigbuf); i++)
      {
         new_ofst = snprintf(sigbuf + buf_ofst, sizeof(sigbuf) - buf_ofst, " %p", bt_addrs[i]);
         if (new_ofst >= 0)
         {
            buf_ofst += new_ofst;
         }
      }
   }

   syslog(LOG_MAKEPRI(LOG_USER, LOG_DEBUG), "%s", sigbuf);
   printf("%s\n", sigbuf);
#endif
}

/*===========================================================================*/
/*!
 * @file dbg_call_stack_backtrace_c99.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 10-Jan-2012 Kirk Bailey Rev. 5
 *   - Simplified backtrace and separated from regular trace output.
 *
 * - 03-Nov-2011 Kirk Bailey Rev. 4
 *   - Fixed logic to work even when backtrace data is not available.
 *
 * - 17-may-2011 Kirk Bailey Rev. 2
 *   - Re-did logic to use addr2line to extract symbol information.
 *
 * - 03-may-2011 Kris Boultbee
 *   Task kok_basa#30663 Revision 1
 *   - Created initial file.
 */
/*===========================================================================*/
