/*===========================================================================*/
/**
 * @file ps_nor_data_set.cpp
 *
 * Implement persistent data set storage to NOR device
 *
 * %full_filespec:ps_nor_data_set.cpp~ctc_ec#12:c++:kok_basa#1 %
 * @version %version:ctc_ec#12 %
 * @author  %derived_by:hzm7yk %
 * @date    %date_modified:Sat Apr 18 14:25:35 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011, 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implement persistent data set storage to NOR device
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include "bdb_lite.h"
#include "pbc_trace.h"
#include "ps_data_set.h"
#include "ps_data_set_cfg.h"
#include "utilities.h"
#include "reuse.h"
#include "xsal.h"
#include <errno.h>
#include <fcntl.h>
#include <map>
#include <cstring>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <mtd/mtd-user.h>

using namespace std;

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#undef EM_F_ID
#define EM_F_ID EM_FILE_ID(PERSISTENT_STORAGE_MODULE_ID, 8) /**< Identifies file for PbC/trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/**
 * Number pf areas (max 8) within each sector
 */
#ifndef PS_NOR_AREAS_PER_SECTOR
#  define PS_NOR_AREAS_PER_SECTOR   (2)
#endif

#ifndef PS_NOR_INIT_BUF_LENGTH
#define PS_NOR_INIT_BUF_LENGTH      256
#endif

#ifndef PS_MAX_RECORD_SIZE
#define PS_MAX_RECORD_SIZE          1024
#endif

#define PS_MIN_RECORD_SIZE          8

#define CHECKSUM_OFFSET             (0x5555)

#define PS_ERASED                   ((uint16_t) 0xFFFF)

#define PS_STARTED                  ((uint16_t) 0x7EE7)
#define PS_VALID                    ((uint16_t) 0x5AA5)

#define PS_ERASE_STARTED            ((uint16_t) 0xE7E7)
#define PS_ERASE_COMPLETE           ((uint16_t) 0xA5A5)

/*
 * Invalid file position
 */
#define M_POSITION_INVALID          -2

/**
 * size of one data block
 *   All data is repeated each block
 */
#define PS_NOR_AREA_SIZE  (PS_NOR_SECTOR_SIZE / PS_NOR_AREAS_PER_SECTOR)

/**
 *  Number of areas
 */
#define PS_NOR_NUM_AREAS   (2 *  PS_NOR_AREAS_PER_SECTOR)

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/** data storage */
typedef map<string, string> PS_Map;
typedef PS_Map::iterator PS_Iterator;

typedef struct Sector_Header_Tag
{
      uint16_t sector_valid; /**< DEFAULT - Empty, Partial - Partial data set written, KEY - sector has valid data */
      uint16_t sector_full; /**< KEY - sector is full */
      uint16_t erase_status; /**< Partial erase started on other sector, KEY erase finished on other sector */
      uint16_t area_flags; /**< two bits per area, 11b - empty, 01b - full data set written, 10b - area bad, 00 - area full */
} Sector_Header_T;

typedef enum Area_Flags_Tag
{
   AF_FULL = 0, AF_BAD = 1, AF_INIT = 2, AF_EMPTY = 3,
} Area_Flags_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

#define Get_Sector_Valid(sector)    Read_Header(sector, offsetof(Sector_Header_T, sector_valid))
#define Set_Sector_Inuse(sector)    Write_Header(sector, offsetof(Sector_Header_T, sector_valid), PS_STARTED)
#define Set_Sector_Initialized()    Write_Header(Area_to_Sector(m_area), offsetof(Sector_Header_T, sector_valid), PS_VALID)

#define Is_Sector_Full(sector)      (PS_VALID == Read_Header(sector, offsetof(Sector_Header_T, sector_full)))
#define Set_Sector_Full(sector)     Write_Header(sector, offsetof(Sector_Header_T, sector_full), PS_VALID)

#define Get_Erase_Status(sector)    Read_Header(sector, offsetof(Sector_Header_T, erase_status))
#define Set_Erase_Started()         Write_Header(Area_to_Sector(m_area), offsetof(Sector_Header_T, erase_status), PS_ERASE_STARTED)
#define Set_Erase_Complete()        Write_Header(Area_to_Sector(m_area), offsetof(Sector_Header_T, erase_status), PS_ERASE_COMPLETE)

#define Get_Sector_Area_Flags(sector) Read_Header(sector, offsetof(Sector_Header_T, area_flags))
#define Set_Sector_Area_Flags(sector, flags) Write_Header(sector, offsetof(Sector_Header_T, area_flags), flags)
#define Set_Area_Full(area)         Set_Area_Flags(area, AF_FULL)
#define Set_Area_Initialized(area)  Set_Area_Flags(area, AF_INIT)
#define Set_Area_Bad(area)          Set_Area_Flags(area, AF_BAD)

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
#define INITIALIZER_LIST \
   /*                 member type member name member initializer   */ \
   INITIALIZED_MEMBER(off_t,      m_position, M_POSITION_INVALID) AND \
   INITIALIZED_MEMBER(int,        m_fid,      0                 ) AND \
   INITIALIZED_MEMBER(int,        m_area,     -1                )

/**
 * Persistent data set abstract declaration
 */
class Persistent_NOR_Data_Set: public PS::Persistent_Data_Set
{
   public:

      Persistent_NOR_Data_Set(const char *device);

      virtual ~ Persistent_NOR_Data_Set();

      /**
       * Read a data item from data set
       *    Only callable from persistent data set control thread
       *
       * @return true if successful; false otherwise,
       *
       * @param [in] key Name associated with data to be read.
       * @param [in,out] data_dest buffer into which the data is to be read.
       * @param [in] size_dest Size of destination buffer.
       */
      virtual bool_t Read_Data(const char *key, char *data_dest, ssize_t size_dest);

      /**
       * Write an item to data set
       *    Only callable from persistent data set control thread
       *
       * @param [in] key Name for data item to write
       * @param [in] data string data to write
       */
      virtual void Write_Data(const char *key, const char *data);

      /**
       * Returns if data set has unsaved changes
       *
       * @return true if data set is dirty, false if no unsaved changes
       */
      virtual bool_t Is_Dirty(void);

      /**
       *  Save data set to non-volatile storage
       *    Only callable from persistent data set control thread
       */
      virtual bool_t Save(void);

      /**
       * Erase saved data
       */
      virtual void Erase(void);

      /**
       * Dump data set
       */
      virtual void Dump(const char * output);

      /**
      * Set PS as read only
      */
      virtual void Configure_PS_As_ReadOnly(void);

      /**
      * Set PS as writable
      */
      virtual void Configure_PS_As_Writable(void);

   private:
      /**********************************************************************
       * Members initialized by the constructor initializer list
       **********************************************************************/
#undef AND
#define AND
#undef INITIALIZED_MEMBER
#define INITIALIZED_MEMBER(type, name, initializer) type name;

      PS_Map m_data;    /**< All persistent data */
      PS_Map m_pending; /**< Data pending write to NOR */
      string m_device;  /**< device name */
      INITIALIZER_LIST

      /**********************************************************************
       * Members initialized in the constructor body
       **********************************************************************/
      BDB_T m_buffer; /**< read / write data buffer */

      /**
       * Initialize data set from stored data
       */
      void load(void);

      /**
       *  Write all data set to non-volatile storage
       */
      virtual void Save_All(void);

      /** write a data entry to NOR */
      int Write_Data(PS_Iterator i);

      /**
       * DETERMINES IF ENOUGH SPACE IS AVAILABE IN CURRENT AREA FOR NEXT WRITE
       */
      bool_t Space_Available(size_t write_size);

      /**
       * return the record size for given item
       */
      size_t Write_Size(PS_Iterator i);

      /**
       * Write one data record to NOR at present location
       */
      bool_t Write_Record(PS_Iterator i, ssize_t write_size);

      /**
       * Read one key value pair to NOR
       *
       * @return false if end of data
       */
      bool_t Read_Record(void);

      /**
       * Erase one sector from MTD
       */
      int Erase_Sector(int sector);

      void Init_Area_Number(void);

      void Write_Header(size_t sector, size_t offset, uint16_t value);
      uint16_t Read_Header(size_t sector, size_t offset);

      Area_Flags_T Get_Area_Flags(int area);
      void Set_Area_Flags(int area, Area_Flags_T area_flags);

      void Seek_Next_Area(void);
      size_t Area_Start(int area);
      size_t Area_to_Sector(int area);
      size_t Area_to_Other_Sector(int area);
      size_t Get_Area_Number(size_t sector);
      void Load_Partial(int area);

      void Open(void);
      void Close(void);
};

/* Create initializer list for constructor */
#undef AND
#define AND ,
#undef INITIALIZED_MEMBER
#define INITIALIZED_MEMBER(type, name, initializer) name( initializer )

/* ==========================================================================*
 * Persistent_Client::Persistent_NOR_Data_Set
 * ==========================================================================*/
Persistent_NOR_Data_Set::Persistent_NOR_Data_Set(const char *device)
                        :m_data(),
                         m_pending(),
                         m_device(device),
                         INITIALIZER_LIST
{
   BDB_Init(&m_buffer, PS_NOR_INIT_BUF_LENGTH);

   Init_Area_Number();
   load();

   /**
    * if previous erase was not finished, then re-erase sector
    */
   if (PS_ERASE_STARTED == Get_Erase_Status(Area_to_Sector(m_area)))
   {
      int ret;

      ret = Erase_Sector(Area_to_Other_Sector(m_area));

      if (0 == ret)
      {
         Set_Erase_Complete();
      }
      else
      {
         Tr_Fault_2("Erase of sector %u failed for reason %d", Area_to_Other_Sector(m_area), ret);
      }
   }
}

/* ==========================================================================*
 * Persistent_Client::~Persistent_NOR_Data_Set
 * ==========================================================================*/
Persistent_NOR_Data_Set::~Persistent_NOR_Data_Set()
{
   /* ensure all data has been written to NOR */
   while (Is_Dirty())
   {
      Save();
   }
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Read_Data
 * ==========================================================================*/
bool_t Persistent_NOR_Data_Set::Read_Data(const char *key, char *data_dest, ssize_t size_dest)
{
   bool_t valid = false;
   ssize_t stored_size = m_data[key].length();
   bool_t ok = false;

   /* copy data only if positive dest_size matches stored sized exactly or the absolute
    value of a negative desc_size is greater or equal to stored data size*/
   if (size_dest >= 0)
   {
      ok = size_dest == stored_size;
   }
   else
   {
      ok = (-size_dest) >= stored_size;
   }

   if (ok)
   {
      Safe_Strncpy(data_dest, m_data[key].c_str(), abs(size_dest)+1);
      valid = true;
   }
   else
   {
      if (0 != stored_size)
      {
         Tr_Warn_3("PS Item: %s Size Requested: %d doesn't match Size Stored: %d", key, size_dest, stored_size);
      }
   }
   return valid;
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Write_Data - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Write_Data(const char *key, const char *data)
{
   m_data[key] = data;
   m_pending[key] = data;
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Is_Dirty - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_NOR_Data_Set::Is_Dirty(void)
{
   return !m_pending.empty();
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Save - Writes deltas to NOR area
 * ==========================================================================*/
bool_t Persistent_NOR_Data_Set::Save(void)
{
   size_t rec_size;
   PS_Iterator i;
   size_t num_items;
   int status;
   uint32_t mem_contents;

   Tr_Info_Mid_2("Saving deltas data set to %s at 0x%06X", m_device.c_str(), (unsigned int)m_position);

   Open();

   PBC_Require_2(0 == (m_position % 2), "m_position is not on an even byte boundary, m_position=0x%06X in %s", (unsigned int)m_position, m_device.c_str());
   PBC_Require_1(m_position != M_POSITION_INVALID, "m_position has not been set in %s", m_device.c_str());

   /* Test to see that we are in erased memory */
   status = lseek(m_fid, m_position, SEEK_SET);
   if(-1 == status)
   {
      Tr_Fault_3("lseek failed with status %s, m_position=0x%06X in %s", strerror(errno), (unsigned int)m_position, m_device.c_str());
   }
   PBC_Ensure_3((m_position == status), "lseek failed to seek to desired position in %s: requested=0x%06X, actual=0x%06X", m_device.c_str(), (unsigned int) m_position, status);

   rec_size = read(m_fid, &mem_contents, 2);
   PBC_Ensure_1((2 == rec_size), "read verification failed to read 2 bytes, actual=%d", rec_size);
   PBC_Ensure_3((0xFF == ((mem_contents >> 8) & 0xFF)), "memory not erased, read=%u m_position=0x%06X in %s", ((mem_contents >> 8) & 0xFF), (unsigned int)(m_position + 1), m_device.c_str());
   PBC_Ensure_3((0xFF == (mem_contents & 0xFF)), "memory not erased, read=%u m_position=0x%06X in %s", (mem_contents & 0xFF), (unsigned int)m_position, m_device.c_str());

   /* Now reposition the cursor to write */
   status = lseek(m_fid, -2, SEEK_CUR);
   if(-1 == status)
   {
      Tr_Fault_1("lseek failed with status %s", strerror(errno));
   }
   PBC_Ensure_2((m_position == status), "lseek failed to seek to desired position: requested=0x%06X, actual=%d", (unsigned int) m_position, status);

   i = m_pending.begin();

   for (num_items = m_pending.size(); num_items > 0; num_items--)
   {
      rec_size = Write_Size(i);

      if (Space_Available(rec_size))
      {
         if (Write_Record(i, rec_size))
         {
            PS_Iterator last = i;
            ++i;
            m_pending.erase(last); /* remove from pending list */
         }
         else
         {
            Tr_Fault_2("Error writing PS Data %s to %s", i->first.c_str(), m_device.c_str());
            ++i;
         }
      }
      else
      {
         Set_Area_Full(m_area);
         Save_All();
         break;
      }
   }

   Close();

   return true;
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Erase - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Erase(void)
{
   Erase_Sector(0);
   Erase_Sector(1);
   m_pending.clear();
   m_data.clear();
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Dump - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Dump(const char * output)
{
   int fid;
   ssize_t write_ret = 0;

   Tr_Info_Mid_1("Dumping data set to %s", output);

   fid = open(output, O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

   if (fid >= 0)
   {
      for (PS_Iterator i = m_data.begin(); i != m_data.end(); ++i)
      {
         write_ret = write(fid, i->first.c_str(), i->first.length());
         write_ret += write(fid, ",'", 2);
         write_ret += write(fid, i->second.c_str(), (i->second.length() > 2) ? (i->second.length() - 2) : (i->second.length()));
         write_ret += write(fid, "\n", 1);
      }

      close(fid);
   }
}

/** return the sector for a specific area */
size_t Persistent_NOR_Data_Set::Area_to_Sector(int area)
{
   return (int) (area >= PS_NOR_AREAS_PER_SECTOR);
}

/** return the sector mot used by a specific area */
size_t Persistent_NOR_Data_Set::Area_to_Other_Sector(int area)
{
   return (int) (area < PS_NOR_AREAS_PER_SECTOR);
}

/* size is BDB String of key + BDB string of data, + 2 bytes checksum + 1 byte newline */
size_t Persistent_NOR_Data_Set::Write_Size(PS_Iterator i)
{
   size_t size = (1 + i->first.length()) + (1 + i->second.length()) + 2 + 1;

   /* round up to 16 bit alignment */
   size = (size + 1) & ~1;

   return size;
}

/**
 * Write to record to NOR at current position
 *    Record definition
 *       16 bit size of record
 *       BDB Buffer with
 *          Key String
 *          Data String
 *          16 bit checksum
 *          8 bit new line (\n)
 */
bool_t Persistent_NOR_Data_Set::Write_Record(PS_Iterator rec, ssize_t write_size)
{
   int write_ret = -1;
   uint16_t checksum;
   uint8_t const * sptr;
   uint8_t * dptr;

   PBC_Require_1(write_size > 0, "Invalid Write Size %d", write_size);
   PBC_Require(m_position != M_POSITION_INVALID, "m_position has not been set");

   if (write_size < PS_MAX_RECORD_SIZE)
   {
      BDB_Guarantee_Min_Buffer_Length(&m_buffer, write_size + 2);

      /** compute checksum of data and write data to buffer */

      dptr = (uint8_t *) BDB_Get_Buffer(&m_buffer);
      checksum = CHECKSUM_OFFSET;

      /* record size */
      *dptr = (write_size & 0xFF);
      checksum += *dptr++;
      *dptr = ((write_size >> 8) & 0xFF);
      checksum += *dptr++;

      /** key  */
      sptr = (uint8_t const *) rec->first.c_str();
      while (0 != *sptr)
      {
         *dptr++ = *sptr;
         checksum += *sptr++;
      }
      *dptr++ = 0;

      /* data */
      sptr = (uint8_t const *) rec->second.c_str();
      while (0 != *sptr)
      {
         *dptr++ = *sptr;
         checksum += *sptr++;
      }
      *dptr++ = 0;

      /* write checksum */
      *dptr++ = (checksum & 0xFF);
      *dptr++ = ((checksum >> 8) & 0xFF);

      /* write new line (plus an extra incase we are rounding the length up) for display */
      *dptr++ = '\n';
      *dptr = '\n';

      write_size += 2; /* add 2 for record size */

      Tr_Info_Hi_4("Writing %s at 0x%06X Len: %d - %s", rec->first.c_str(), (unsigned int) m_position, (int) write_size, rec->second.c_str());

      write_ret = write(m_fid, BDB_Get_Buffer(&m_buffer), write_size);

      if (write_ret != write_size)
      {
         Tr_Fault_2("Write size %d doesn't match desired size %d", write_ret, write_size);
      }

      m_position += write_size;
   }
   else
   {
      Tr_Fault_2("Data size %d is too large. Dropping key %s", write_size, rec->first.c_str());
   }

   return (write_ret == write_size);
}

/**
 * Read one key value pair to NOR
 *
 * @return false if end of data
 */
bool_t Persistent_NOR_Data_Set::Read_Record(void)
{
   int16_t rec_size = -1;
   size_t read_size;
   bool_t valid;

   PBC_Require(m_position != M_POSITION_INVALID, "m_position has not been set");

   read_size = read(m_fid, &rec_size, 2);

   valid = (2 == read_size) && (rec_size > 0); /* Is there data here (end of NOR should be 0xFFFF) */

   if (valid)
   {
      if ((rec_size > PS_MIN_RECORD_SIZE) && (rec_size < PS_MAX_RECORD_SIZE)) /* is the record size reasonable ? */
      {
         BDB_Guarantee_Min_Buffer_Length(&m_buffer, rec_size); /* ensure buffer is big enough for entire record */
         read_size = read(m_fid, (void *) BDB_Get_Buffer(&m_buffer), rec_size); /* read record from NOR */

         if (read_size == (uint16_t) rec_size) /** did we successfully read the record, verify data */
         {
            uint8_t const * sptr = (uint8_t const *) BDB_Get_Buffer(&m_buffer);

            if ('\n' == *(sptr + (rec_size - 1))) /* if last byte new line, then verify checksum */
            {
               char const * key = (char const *) sptr;
               char const * data;
               uint16_t checksum;
               uint16_t read_checksum;

               checksum = CHECKSUM_OFFSET + (rec_size & 0xFF);
               checksum += (rec_size >> 8) & 0xFf;

               /* read key */
               while (0 != *sptr)
               {
                  checksum += *sptr++;
               }
               sptr++; /* pass null character */

               /* read data */
               data = (char const *) sptr;
               while (0 != *sptr)
               {
                  checksum += *sptr++;
               }
               sptr++; /* pass null character */

               read_checksum = *sptr++;
               read_checksum += (*sptr << 8);
               sptr++; /* should be pointing to new line */

               Tr_Info_Lo_3("Read %s at 0x%06X : %s", key, (unsigned int) m_position, data);

               if ((checksum == read_checksum) && (*sptr == '\n'))
               {
                  m_data[key] = data; /* update map with read data */
               }
               else
               {
                  Tr_Fault_2("Checksum error Read %d Computed %d", read_checksum, checksum);
               }
            }
         }
         else
         {
            Tr_Fault_2("NOR Read failed Record Size %d Read Size %d", rec_size, read_size);
         }

         m_position += rec_size + 2;
      }
      else
      {
         uint8_t ch;
         ssize_t bytes_read;

         Tr_Fault_1("Invalid record size %d", rec_size);

         m_position += 2;

         do
         {
            ch = 0xFF;
            bytes_read = read(m_fid, &ch, 1);
            m_position++;
         } while ((ch != '\n') && (ch != 0xFF) && (1 == bytes_read));
         m_position = (m_position + 1) & ~1;
      }
   }

   return (rec_size > 0) && Space_Available(0); /* rec_size should be FFFF at end of data */
}

/**
 * Determines if there is enough space in the current area to complete write
 */
bool_t Persistent_NOR_Data_Set::Space_Available(size_t write_size)
{
   int area;

   PBC_Require(m_position != M_POSITION_INVALID, "m_position has not been set");

   area = ((m_position + write_size + 2) / PS_NOR_AREA_SIZE);

   return (m_area == area);
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Save_All - Writes all parameters to NOR area
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Save_All(void)
{
   size_t rec_size = 0;

   Open();

   Seek_Next_Area();

   Tr_Info_Mid_2("Saving all data to %s Area %d", m_device.c_str(), m_area);

   m_pending.clear();

   for (PS_Iterator i = m_data.begin(); i != m_data.end(); ++i)
   {
      rec_size = Write_Size(i);

      if (Space_Available(rec_size))
      {
         if (!Write_Record(i, rec_size))
         {
            Tr_Fault_2("Error writing PS Data %s to %s", i->first.c_str(), m_device.c_str());
         }
      }
      else
      {
         Tr_Fault_1("Data Set is bigger than area - losing Data %s", i->first.c_str());
      }
   }

   /* Mark area as initialized */
   Set_Sector_Initialized();
   Set_Area_Initialized(m_area);

#if (PS_NOR_AREAS_PER_SECTOR > 1)
   if (1 == (m_area % PS_NOR_AREAS_PER_SECTOR)) /* if second area within sector, then erase other sector */
#endif 
   {
      int ret;

      Set_Erase_Started();

      ret = Erase_Sector(Area_to_Other_Sector(m_area));

      if (0 == ret)
      {
         Set_Erase_Complete();
      }
      else
      {
         Tr_Fault_2("Erase of sector %u failed for reason %d", Area_to_Other_Sector(m_area), ret);
      }
   }

   Close();
}

/**
 * Erase one sector from MTD
 *
 * Returns 0 on success, a negative number of failure.  The error code is a
 * standard UNIX error code, likely errors include, but are not limited to:
 *   -EPERM, lack of permissions, no erase was done
 *   -EINVAL, invalid arguments, again not erase
 *   -EIO, I/O error in erase operation, maybe something was erased
 */
int Persistent_NOR_Data_Set::Erase_Sector(int sector)
{
   mtd_info_t meminfo;
   erase_info_t erase;
   int res;

   /* Make sure device is opened */
   Open();

   Tr_Info_Hi_2("Erasing sector %d on %s", sector, m_device.c_str());

   /**
    * Check if erasesize and PS_NOR_SECTOR_SIZE actually match.  The erase will
    * still work if PS_NOR_SECTOR_SIZE is a multiple of the erasesize, even if
    * they aren't the same.  So we go ahead and try even if they sizes don't
    * match.  The MEMERASE ioctl will fail with EINVAL if the start and length
    * aren't valid (multiple of the erasesize is the normal constraint for NOR
    * flash).  */
   res = ioctl(m_fid, MEMGETINFO, &meminfo);
   if (res != -1)
   {
      if (meminfo.erasesize != PS_NOR_SECTOR_SIZE)
      {
         Tr_Warn_3("Erase size of '%s' doesn't match, got 0x%x wanted 0x%x",
            m_device.c_str(), meminfo.erasesize, PS_NOR_SECTOR_SIZE);
      }
   }
   else
   {
      Tr_Fault_3("ioctl(MEMGETINFO) failed on '%s' with error %d '%s'",
         m_device.c_str(), res, strerror(res));
   }

   /* Actual erase call.  Typically will return -EINVAL if the size or length
    * won't work.  */
   erase.start = sector * PS_NOR_SECTOR_SIZE;
   erase.length = PS_NOR_SECTOR_SIZE;
   return ioctl(m_fid, MEMERASE, &erase);
}

size_t Persistent_NOR_Data_Set::Get_Area_Number(size_t sector)
{
   uint16_t flags;
   int_fast8_t i;
   size_t area = 0;
   Area_Flags_T area_status;
   bool_t found = false;

   flags = Get_Sector_Area_Flags(sector);

   for (i = 0; (i < PS_NOR_AREAS_PER_SECTOR) && !found; i++)
   {
      area_status = (Area_Flags_T) (flags & 0x03);
      flags >>= 2;

      switch (area_status)
      {
         case AF_INIT:
            area = i + (sector * PS_NOR_AREAS_PER_SECTOR);
            found = true;
            break;
         case AF_EMPTY:
            area = i + (sector * PS_NOR_AREAS_PER_SECTOR);
            Load_Partial(area);
            found = true;
            break;
         default: /* either full or BAD */
            break;
      }
   }

   if (!found) /* all area were either full or bad */
   {
      area = (PS_NOR_AREAS_PER_SECTOR - 1) + (sector * PS_NOR_AREAS_PER_SECTOR);
   }

   return (area);
}

/**
 * Handles case where full data set was NOT completely written to area
 *    Load full data from last area
 *    Load partial data from this area
 *    Save results to a different area
 *
 * We most likely got there because one area was full, which caused the next area
 * was being written with a new copy of the data, but the write was interrupted
 * (battery disconnect, app crash, SOH reset), so the write didn't finish.
 * To minimize the data loss, the data list is rebuilt first from the old data,
 * then overwritten with any data that would be in the new data. This will update
 * any "pending" data that was written to the new area. Any "pending" data that
 * was not yet written is lost. Once the list is built and is complete as it can
 * be, then the data will be written to a new area. Where that data is written
 * depends on how many areas are available.
 */
void Persistent_NOR_Data_Set::Load_Partial(int area)
{
   int previous_area;

   PBC_Require_1(area < PS_NOR_NUM_AREAS, "Area is invalid, area=%d", area);

   previous_area = (area > 0) ? (area - 1) : (PS_NOR_NUM_AREAS - 1);

   m_area = previous_area;
   load(); /* load complete data from last area */

   m_area = area;
   load(); /* load partial data from new area */

   /* At this point, we have a list of the most current data available. What
    * we do next is dependent of how many NOR areas we have defined */
#if (PS_NOR_AREAS_PER_SECTOR > 1)
#error function not defined
#else
   {
      /* Since we only have 2 areas, we have old one that is valid and full, and
       * the new one that is partially written. What we do not have is an empty
       * area to store the data. Since the last record that was partially written
       * (and not added to the list because of a corrupt checksum) may be a new
       * version and have 0's where 1's used to be, we cannot overwrite the old
       * data on top of it. The only choice is to erase the new data and attempt
       * to rewrite the whole list. There is a risk that if the second attempt
       * to write the new data fails again, we will have lost data. Oh well,
       * "stuff" happens.
       */
      Erase_Sector(Area_to_Sector(area)); /* erase the new area with the partial data */
      m_area = previous_area; /* Set the area to the last good area */
   }
#endif
   Save_All(); /* write all data to new area */
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Init_Area_Number - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Init_Area_Number(void)
{
   uint16_t sector_status[2] =
   { 0xFFFF, 0xFFFF };

   sector_status[0] = Get_Sector_Valid(0);
   sector_status[1] = Get_Sector_Valid(1);

   Tr_Info_Lo_2("Sector Statuses 0x%04X 0x%04X", sector_status[0], sector_status[1]);

   /** Are both sectors valid */
   if ((sector_status[0] == PS_VALID) && (sector_status[1] == PS_VALID))
   {
      if (Is_Sector_Full(0))
      {
         m_area = Get_Area_Number(1);
      }
      else
      {
         m_area = Get_Area_Number(0);
      }
   }
   else if (sector_status[0] == PS_VALID) /* is first sector valid */
   {
      if (Is_Sector_Full(0) && (PS_STARTED == sector_status[1])) /* did we get interrupted on going to next sector */
      {
         Load_Partial(PS_NOR_AREAS_PER_SECTOR);
      }
      else
      {
         m_area = Get_Area_Number(0);
      }
   }
   else if (sector_status[1] == PS_VALID) /* Is second sector valid */
   {
      if (Is_Sector_Full(1) && (PS_STARTED == sector_status[0])) /* did we get interrupted on next area */
      {
         Load_Partial(0);
      }
      else
      {
         m_area = Get_Area_Number(1);
      }
   }
   /* Is blank device */
   else if ((sector_status[0] == PS_ERASED) && (sector_status[1] == PS_ERASED))
   {
      Tr_Info_Mid("Blank device");

      m_area = PS_NOR_NUM_AREAS; /* use first area by forcing wrap */
      Save_All();
   }
   else /* invalid settings, so erase and start over */
   {
      Tr_Fault_2("NOR Data is invalid. Status %04X %04X. Wiping all data.", sector_status[0], sector_status[1]);
      Erase();
      m_area = PS_NOR_NUM_AREAS; /* use first area by forcing wrap */
      Save_All();
   }

   Tr_Info_Mid_1("Set area to %d", m_area);
}

/**
 * returns start position for area
 */
size_t Persistent_NOR_Data_Set::Area_Start(int area)
{
   size_t start;

   PBC_Require_1(area < PS_NOR_NUM_AREAS, "Invalid Area %d", area);

   start = area * PS_NOR_AREA_SIZE;

   if (0 == (area % PS_NOR_AREAS_PER_SECTOR)) /* if first area within sector, leave room for sector header */
   {
      start += sizeof(Sector_Header_T);
   }
   return start;
}

/**
 * Determines next Area to save data to
 *    if we change sectors, set old sector full and mark the new sector inuse
 *    Sets position to start of data in new area
 */
void Persistent_NOR_Data_Set::Seek_Next_Area(void)
{
   m_area++;

   if (m_area >= PS_NOR_NUM_AREAS)
   {
      m_area = 0;
      if (PS_VALID == Get_Sector_Valid(1))
      {
         Set_Sector_Full(1);
      }
      Set_Sector_Inuse(0);
   }
   else if (m_area == PS_NOR_AREAS_PER_SECTOR)
   {
      if (PS_VALID == Get_Sector_Valid(0))
      {
         Set_Sector_Full(0);
      }
      Set_Sector_Inuse(1);
   }
   else
   {
   }

   m_position = Area_Start(m_area);

   lseek(m_fid, m_position, SEEK_SET);
}

/*==========================================================================*
 * Persistent_NOR_Data_Set::Save - refer to description in class declaration
 *==========================================================================*/
void Persistent_NOR_Data_Set::load(void)
{
   int status;

   Tr_Info_Mid_2("Loading partition %s Area %d", m_device.c_str(), m_area);

   Open();

   /** go start of area */
   m_position = Area_Start(m_area);
   status = lseek(m_fid, m_position, SEEK_SET);
   if(-1 == status)
   {
      Tr_Fault_1("lseek failed with status %s", strerror(errno));
   }
   PBC_Ensure_2((m_position == status), "lseek failed to seek to desired position: requested=%u, actual=%d", (unsigned int) m_position, status);

   Tr_Info_Mid_2("Reading data from area %d at 0x%06X", m_area, (unsigned int) m_position);

   while (Read_Record())
   {
      /* empty loop */
   }

   Close();
}

/**
 * Open a handle to NOR if necessary
 */
void Persistent_NOR_Data_Set::Open(void)
{
   if (m_fid <= 0)
   {
      m_fid = open(m_device.c_str(), O_RDWR);

      if (m_fid <= 0)
      {
         Tr_Fault_2("Error %d opening NOR device %s", errno, m_device.c_str());
      }
   }
}

/**
 * close handle to NOR
 */
void Persistent_NOR_Data_Set::Close(void)
{
   if (m_fid > 0)
   {
      close(m_fid);
      m_fid = 0;
    }
}

void Persistent_NOR_Data_Set::Write_Header(size_t sector, size_t offset, uint16_t value)
{
   ssize_t bytes_written;
   int status;

   Open();

   status = lseek(m_fid, (sector * PS_NOR_SECTOR_SIZE) + offset, SEEK_SET);
   if(-1 == status)
   {
      Tr_Fault_1("lseek failed with status %s", strerror(errno));
   }
   PBC_Ensure_2(((int)((sector * PS_NOR_SECTOR_SIZE) + offset) == status), "lseek failed to seek to desired position requested=%u, actual=%d", (unsigned int) m_position, status);

   bytes_written = write(m_fid, &value, 2);
   if (2 != bytes_written)
   {
      Tr_Fault("Write failed");
   }

   if(m_position != M_POSITION_INVALID)
   {
      status = lseek(m_fid, m_position, SEEK_SET);
      if(-1 == status)
      {
         Tr_Fault_1("lseek failed with status %s", strerror(errno));
      }
      PBC_Ensure_2((m_position == status), "lseek failed to seek to desired position: requested=%u, actual=%d", (unsigned int) m_position, status);
   }
}

uint16_t Persistent_NOR_Data_Set::Read_Header(size_t sector, size_t offset)
{
   uint16_t value = 0xFFFF;
   int status;

   ssize_t bytes_read;

   Open();

   status = lseek(m_fid, (sector * PS_NOR_SECTOR_SIZE) + offset, SEEK_SET);
   if(-1 == status)
   {
      Tr_Fault_1("lseek failed with status %s", strerror(errno));
   }
   PBC_Ensure_2(((int)((sector * PS_NOR_SECTOR_SIZE) + offset) == status), "lseek failed to seek to desired position requested=%u, actual=%d", (unsigned int) m_position, status);

   bytes_read = read(m_fid, &value, 2);
   if (2 != bytes_read)
   {
      Tr_Fault_2("Read failed Sector: %d Offset: %d", sector, offset);
   }

   if(m_position != M_POSITION_INVALID)
   {
      status = lseek(m_fid, m_position, SEEK_SET);
      if(-1 == status)
      {
         Tr_Fault_1("lseek failed with status %s", strerror(errno));
      }
      PBC_Ensure_2((m_position == status), "lseek failed to seek to desired position requested=%u, actual=%d", (unsigned int) m_position, status);
   }

   return value;
}

Area_Flags_T Persistent_NOR_Data_Set::Get_Area_Flags(int area)
{
   uint16_t flags;

   flags = Read_Header(Area_to_Sector(area), offsetof(Sector_Header_T, area_flags));

   return (Area_Flags_T) ((flags >> (area * 2)) & 0x03);
}

void Persistent_NOR_Data_Set::Set_Area_Flags(int area, Area_Flags_T area_flags)
{
   uint16_t flags;
   uint16_t shift;
   size_t sector;

   if (area < PS_NOR_AREAS_PER_SECTOR)
   {
      shift = area * 2;
      sector = 0;
   }
   else
   {
      shift = (area - PS_NOR_AREAS_PER_SECTOR) * 2;
      sector = 1;
   }

   flags = Get_Sector_Area_Flags(sector);

   flags &= ~(0x03U << shift);
   flags |= (uint16_t) area_flags << shift;

   Set_Sector_Area_Flags(sector, flags);
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Configure_PS_As_ReadOnly - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Configure_PS_As_ReadOnly(void)
{
   /* Do nothing as of now */
}

/* ==========================================================================*
 * Persistent_NOR_Data_Set::Configure_PS_As_Writable - refer to description in class declaration
 * ==========================================================================*/
void Persistent_NOR_Data_Set::Configure_PS_As_Writable(void)
{
   /* Do nothing as of now */
}

/**
 * Returns a reference to a concrete persistent data object based on address
 */
PS::Persistent_Data_Set * PS::Get_Data_Set(const char * device_name)
{
   Persistent_NOR_Data_Set *ds = new Persistent_NOR_Data_Set(device_name);

   PBC_Ensure_1(ds != NULL, "Failed to create data set object %s", device_name);

   return ds;
}

/*===========================================================================*/
/*!
 * @file ps_nor_data_set.cpp
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 16-Jul-2012 Larry Piekarski Rev 11
 *   - Task 108903: Add additional trace to persistent storage
 *
 * - 13-Jul-2012 Larry Piekarski Rev 10
 *   - Task 108387: Initialized uninitialized variables.
 *
 * - 12-Jul-2012 Larry Piekarski Rev 9
 *   - Task 108250: Fixed issue where load_partial did not properly retore an
 *     image if only one area per sector is used.
 *
 * - 10-Jul-2012 Larry Piekarski Rev 8
 *   - Task 107843: Added PBC checks to lseek commands. While this is just good 
 *     programming practice, we are specifically looking for a problem and this
 *     will show us when and where a specific corruption is occuring.
 *
 * - 08-jun-2012 Kris Boultbee
 *   Task kok_basa#101950 Revision 6
 *   - Addressed the following defect in Persistent_NOR_Data_Set::Save() reported by Klocwork:
 *     Iterator 'i' is dereferenced at line 430 when it can be equal to value returned by call
 *     to [r]end().
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * - 1-Aug-2011 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
