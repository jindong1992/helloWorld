/*===========================================================================*/
/**
 * @file ps_file_data_set.cpp
 *
 * Implement persistent data set storage to a file
 *
 * %full_filespec:ps_file_data_set.cpp~ctc_ec#31.1.2:c++:kok_basa#1 %
 * @version %version:ctc_ec#31.1.2 %
 * @author  %derived_by:hzs8nb %
 * @date    %date_modified:Thu Jul  9 14:32:25 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implement persistent data set storage to a file
 *
 * @section ABBR ABBREVIATIONS:
 *   - PS - Persistent Storage
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - Add check values to data file, and load backup if error reading main file
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "ps_data_set.h"
#include "ps_data_set_cfg.h"
#include "reuse.h"
#include "utilities.h"
#include "xsal.h"
#include <errno.h>
#include <fcntl.h>
#include <map>
#include <cstring>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#undef EM_F_ID
#define EM_F_ID EM_FILE_ID(PERSISTENT_STORAGE_MODULE_ID, 1) /**< Identifies file for PbC/trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/** define maximum length for path and file name */
#ifndef PS_MAX_PATH
#   define PS_MAX_PATH 64
#endif

/**
 * Use to define temp buffer for reading key from file
 */
#ifndef PS_MAX_KEY_LENGTH
#   define PS_MAX_KEY_LENGTH 128
#endif

/**
 * Use to define temp buffer for reading data from file
 */
#ifndef PS_MAX_DAT_LENGTH
#   define PS_MAX_DAT_LENGTH 1300
#endif

/**
 * Limit number of parameters that can be read from file
 */
#define PS_BEYOND_MAX_PARAMS     (2000)

/**
 * Define the range of file numbers used
 */
#define FILE_NUMBER_BITS   (7)

/**
 * Define maximum file number, should not be edited
 */
#define MAX_FILE_NUMBER    ((1 << FILE_NUMBER_BITS) - 1)

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/** data storage */
typedef map<string, string> PS_Map;
typedef PS_Map::iterator PS_Iterator;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/**
 * Persistent data set abstract declaration
 */
class Persistent_File_Data_Set: public PS::Persistent_Data_Set
{
   public:

      Persistent_File_Data_Set(const char *path, const char *name);

      virtual ~ Persistent_File_Data_Set();

      /**
       * Read a data item from data set
       *    Only callable from persistent data set control thread
       *
       * @return true if successful; false otherwise,
       *
       * @param [in] key Name associated with data to be read.
       * @param [in,out] data_dest buffer into which the data is to be read.
       * @param [in] size_dest Size of destination buffer.
       */
      virtual bool_t Read_Data(const char *key, char *data_dest, ssize_t size_dest);

      /**
       * Write an item to data set
       *    Only callable from persistent data set control thread
       *
       * @param [in] key Name for data item to write
       * @param [in] data string data to write
       */
      virtual void Write_Data(const char *key, const char *data);

      /**
       * Returns if data set has unsaved changes
       *
       * @return true if data set is dirty, false if no unsaved changes
       */
      virtual bool_t Is_Dirty(void);

      /**
       *  Save data set to non-volatile storage
       *    Only callable from persistent data set control thread
       */
      virtual bool_t Save(void);

      /**
       * Erase saved data
       */
      virtual void Erase(void);

      /**
       * Dump data set
       */
      virtual void Dump(const char * output);

      /**
      * Set PS as read only
      */
      virtual void Configure_PS_As_ReadOnly(void);

      /**
      * Set PS as writable
      */
      virtual void Configure_PS_As_Writable(void);

   private:
      PS_Map m_data;
      string m_pathroot;
      string m_name;
      uint8_t m_file_number;
      bool_t m_dirty;
      bool_t m_ps_readonly; /* Indicates if PS is read only or not */

      char m_path[PS_MAX_PATH];

      /**
       * Builds a file name for the daa set given and index numbeer
       *    Updates m_path
       *
       * @param fn file index (0..n)
       *
       */
      void filename(int fn);

      /**
       * File exists
       *
       * @param fn file index (0..n)
       *
       * @return true if file exists
       */
      bool_t file_exists(int fn);

      /**
       * Determene iniital file number
       */
      void init_file_number(void);

      /**
       * Determine valid existing file and initialize data set
       */
      void load(void);

      /**
       * Determine if PS is read only
       */
      bool_t is_ps_read_only(void);
};

/* ==========================================================================*
 * Persistent_Client::Persistent_File_Data_Set
 * ==========================================================================*/
Persistent_File_Data_Set::Persistent_File_Data_Set(const char * path, const char *name) :
   m_data(), m_pathroot(path), m_name(name), m_dirty(false), m_ps_readonly(false)
{
   struct stat sb;
   int status;

   status = stat(m_pathroot.c_str(), &sb);

   if (status != 0)
   {
      status = mkdir(m_pathroot.c_str(), (S_IRWXU | S_IRWXG | S_IRWXO));

      if (status != 0)
      {
         Tr_Warn_2("Error %d creating folder %s", status, m_pathroot.c_str());
      }
   }

   init_file_number();
   load();
}

/* ==========================================================================*
 * Persistent_Client::~Persistent_File_Data_Set
 * ==========================================================================*/
Persistent_File_Data_Set::~Persistent_File_Data_Set()
{
   /*
    Delete strings from map?
    */
}

/* ==========================================================================*
 * Persistent_File_Data_Set::onCreatingMessageQueue - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_File_Data_Set::Read_Data(const char *key, char *data_dest, ssize_t size_dest)
{
   bool_t valid = false;
   ssize_t stored_size = m_data[key].length();
   bool_t ok = false;

   /*copy data only if positive dest_size matches stored sized exactly or the absolute
    value of a negative desc_size is greater or equal to stored data size*/
   if (size_dest >= 0)
   {
      ok = size_dest == stored_size;
   }
   else
   {
      ok = (stored_size > 0) && ((-size_dest) >= stored_size);
   }

   if (ok)
   {
      Safe_Strncpy(data_dest, m_data[key].c_str(), abs(size_dest)+1);
      valid = true;
   }
   else
   {
      if (0 != stored_size)
      {
         Tr_Warn_3("PS Item: %s Size Requested: %d doesn't match Size Stored: %d", key, size_dest, stored_size);
      }
   }
   return valid;
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Write_Data - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::Write_Data(const char *key, const char *data)
{
   m_data[key] = data;
   m_dirty = true;
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Is_Dirty - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_File_Data_Set::Is_Dirty(void)
{
   return m_dirty;
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Save - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_File_Data_Set::Save(void)
{
   bool_t b_save_success  = true; /*true: success, false: failed*/
   
   /* If PS is writable, then proceed */
   if (!is_ps_read_only())
   {
      int fid;
      const char nl = '\n';
      ssize_t write_ret = 0;

      /* advance to next file in sequence */
      m_file_number = (m_file_number + 1) & MAX_FILE_NUMBER;
      filename(m_file_number);

      Tr_Info_Mid_1("Saving data set to %s", m_path);

      fid = open(m_path, O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

      if (fid >= 0)
      {
         for (PS_Iterator i = m_data.begin(); i != m_data.end(); ++i)
         {
            write_ret = write(fid, i->first.c_str(), i->first.length());
            write_ret += write(fid, &nl, 1);
            write_ret += write(fid, i->second.c_str(), i->second.length());
            write_ret += write(fid, &nl, 1);

            /* Check, whether write()s were successful */
            if (write_ret != ((ssize_t) (i->first.length() + 1 + i->second.length() + 1)))
            {
               Tr_Fault_2("Error: %d while writing file %s", errno, m_path);
               b_save_success  = false; ;
               break;
            }
         }
         fsync(fid);
         close(fid);
	 
      }
      else
      {
         Tr_Fault_2("Error %d opening file %s for writing", errno, m_path);

         /* Decrement file number since new one was not created */
         m_file_number = (m_file_number - 1) & MAX_FILE_NUMBER;
         b_save_success  = false; 
      }

      /* delete the previous backup */

      if (file_exists(m_file_number - 2))
      {
         filename(m_file_number - 2);
         if (remove(m_path) == -1)
         {
            perror("Error deleting file");
            Tr_Warn_2("Failed to remove old file %s with error %d", m_path, errno);
         }
      }

      m_dirty = false;
   }
   else
   {
      b_save_success  = false; 
   }
   
   return b_save_success;
}

/* ==========================================================================*
 * Persistent_File_Data_Set::filename - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_File_Data_Set::file_exists(int fn)
{
   struct stat sb;
   int status;

   filename(fn);

   status = stat(m_path, &sb);

   return (0 == status);

}

/* ==========================================================================*
 * Persistent_File_Data_Set::filename - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::filename(int fn)
{
   snprintf(m_path, PS_MAX_PATH, "%s%s_%1d.ps", m_pathroot.c_str(), m_name.c_str(), (fn & MAX_FILE_NUMBER));
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Erase - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::Erase(void)
{
   uint8_t i;

   for (i = 0; i <= MAX_FILE_NUMBER; i++)
   {
      if (file_exists(i))
      {
         filename(i);
         remove(m_path);
      }
   }

   m_data.clear();
   sync();
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Dump - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::Dump(const char * output)
{
   int fid;
   ssize_t write_ret = 0;

   Tr_Info_Mid_1("Dumping data set to %s", output);

   fid = open(output, O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

   if (fid >= 0)
   {
      for (PS_Iterator i = m_data.begin(); i != m_data.end(); ++i)
      {
         write_ret = write(fid, i->first.c_str(), i->first.length());
         write_ret += write(fid, ",'", 2);
         write_ret += write(fid, i->second.c_str(), (i->second.length() > 2) ? (i->second.length() - 2) : (i->second.length()));
         write_ret += write(fid, "\n", 1);
      }

      close(fid);
   }
}

/* ==========================================================================*
 * Persistent_File_Data_Set::init_file_number - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::init_file_number(void)
{
   uint8_t i;
   int num_files = 0;
   bool_t exists[MAX_FILE_NUMBER + 1];
   bool_t file_number_selected = false;
   int status;

   m_file_number = 0;

   /*
    get list of available  files

    determine valid file
    if none, then don't load
    if one, load that one
    if two take second (e.g., if 1,2 take 2, if 0,3 take 0)
    if more than two files, take middle (i.e., 1,2,3 take 2)
    */

   for (i = 0; i <= MAX_FILE_NUMBER; i++)
   {
      exists[i] = file_exists(i);
      if (exists[i])
      {
         num_files++;
      }
   }

   switch (num_files)
   {
      case 0:
         m_file_number = 0;
         file_number_selected = true;
         break;
      case 1:
         for (i = 0; i <= MAX_FILE_NUMBER; i++)
         {
            if (exists[i])
            {
               m_file_number = i;
               file_number_selected = true;
            }
         }
         break;
      case 2:
         for (i = 0; i <= MAX_FILE_NUMBER; i++)
         {
            if (exists[i])
            {
               if (!exists[(i + 1) & MAX_FILE_NUMBER])
               {
                  m_file_number = i;
                  file_number_selected = true;
               }
            }
         }
         break;
      default: /* Last file was not completely written */
         for (i = 0; i <= MAX_FILE_NUMBER; i++)
         {
            if (exists[i])
            {
               if (exists[(i - 1) & MAX_FILE_NUMBER] && exists[(i + 1) & MAX_FILE_NUMBER])
               {
                  m_file_number = i;
                  file_number_selected = true;
               }
            }
         }
         break;
   }

   if (!file_number_selected) /* An error in the file numbering exists */
   {
      /* It is impossible to know which file is the most recent, so
       * select the file with the largest number.  It is most likely
       * to be the most recent, but not guaranteed.
       */
      for (i = 0; i <= MAX_FILE_NUMBER; i++)
      {
         if (exists[i])
         {
            /* Remove unused files for cleanup */
            if (exists[m_file_number])
            {
               status = system("mount -o remount,rw /factory_data");
               Tr_Info_Lo_1("'mount -o remount,rw /factory_data' returned status=%d", status);
               filename(m_file_number);
               remove(m_path);
               status = system("mount -o remount,ro /factory_data");
               Tr_Info_Lo_1("'mount -o remount,ro /factory_data' returned status=%d", status);
            }

            m_file_number = i;
            file_number_selected = true;
         }
      }
   }
}

/*==========================================================================*
 * Persistent_File_Data_Set::Save - refer to description in class declaration
 *==========================================================================*/
void Persistent_File_Data_Set::load(void)
{
   FILE *fp;
   char *key;
   char *dat;
   int key_length;
   int reads = 0;

   filename(m_file_number);
   fp = fopen(m_path, "r");

   if (NULL != fp)
   {
      Tr_Info_Mid_1("Loading file %s", m_path);

      /* allocate temp buf to read in data */
      key = (char *) SAL_Alloc(PS_MAX_KEY_LENGTH);
      if (NULL != key)
      {
         dat = (char *) SAL_Alloc(PS_MAX_DAT_LENGTH);
         if (NULL!=dat)
         {
            /* PrFILE sometimes gets stuck and does not set eof, so limit number of read attempts */
            while (!feof(fp) && (reads < PS_BEYOND_MAX_PARAMS))
            {
               if ((NULL != fgets(key, PS_MAX_KEY_LENGTH, fp)) && (NULL != fgets(dat, PS_MAX_DAT_LENGTH, fp)))
               {
                  key_length = strlen(key);

                  if (key_length > 2)
                  {
                     /* get rid of \n */
                     key[key_length - 1] = '\0';
                     dat[strlen(dat) - 1] = '\0';

                     m_data[key] = dat;
                  }
               }
               reads++;
            }
            SAL_Free(dat);
         }
         SAL_Free(key);
      }

      fclose(fp);
   }
   else
   {
      Tr_Fault_2("Error: %d while opening file %s", errno, m_path);
   }
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Configure_PS_As_ReadOnly - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::Configure_PS_As_ReadOnly(void)
{
   Tr_Fault("\nConfigure_PS_As_ReadOnly\n");
   m_ps_readonly = true;
}

/* ==========================================================================*
 * Persistent_File_Data_Set::Configure_PS_As_Writable - refer to description in class declaration
 * ==========================================================================*/
void Persistent_File_Data_Set::Configure_PS_As_Writable(void)
{
   m_ps_readonly = false;
}
/* ==========================================================================*
 * Persistent_File_Data_Set::is_ps_read_only - refer to description in class declaration
 * ==========================================================================*/
bool_t Persistent_File_Data_Set::is_ps_read_only(void)
{
   return m_ps_readonly;
}

PS::Persistent_Data_Set * PS::Get_Data_Set(const char *path, const char *name)
{
   Persistent_File_Data_Set *ds = new Persistent_File_Data_Set(path, name);

   PBC_Ensure_1(ds != NULL, "Failed to create data set object %s", name);

   return ds;
}

/*===========================================================================*/
/*!
 * @file ps_file_data_set.cpp
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 10-Jul-2012 Larry Piekarski Rev 30
 *   - Task 107843: Fixed warnings for gcc 4.6.3
 *
 *   06-Jul-2012 Keerthika Pandiselvan Rev 29
 *   Task kok_basa#107329 NULL Dereference fix and indentation check
 *
 *   05-Jul-2012 Keerthika Pandiselvan Rev 28
 *   Task kok_basa#107124 NULL Dereference fix
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * 11Jan12  David Origer (hz1941)  Rev 24
 * SCR kok_basa#20342 : Corrected problems that were causing persistent storage
 *    files to be misnumbered and misused.
 *
 * - 11-Feb-2011 Vijayalakshmi KR
 *   - Add variable length support for PS_Read
 *
 * 24Jan11  David Origer  Rev 12
 * SCR kok_basa#5672 : Add back final changes to move persistent
 *    storage to NAND.  Use sync to force changes into HW to avoid
 *    corruption when battery is pulled.  Increased file number maximum
 *    to avoid conflicts when trying to create recently deleted files.
 *    This also led to removing several magic nubers throughout the code.
 *
 * 18Jan11  David Origer  Rev 11
 * SCR kok_basa#5462 : Temporarily remove changes to reduce risk for DIT
 *    DIT delivery.
 *
 * 13Jan11  David Origer  Rev 8
 * SCR kok_basa#5462 : Ensure file system changes are written to hardware
 *    storage.
 *
 * - 28-Nov-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
