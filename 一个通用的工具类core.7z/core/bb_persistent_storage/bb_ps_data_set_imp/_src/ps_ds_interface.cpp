/*===========================================================================*/
/**
 * @file ps_ds_interface.cpp
 *
 * Converts between persistent data blocks and checksum strings used by the database
 *
 * %full_filespec:ps_ds_interface.cpp~ctc_ec#30.2.5:c++:kok_aud#1 %
 * @version %version:ctc_ec#30.2.5 %
 * @author  %derived_by:pz6vcp %
 * @date    %date_modified:Thu Oct  6 21:42:27 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module converts persistent data between binary form and null terminated hex string form
 *    String inclues one byte two complement checksum of binary data
 *    and passes the strings to the database interface.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - Have not implemented persistent ojbect registry and the Reset / Reload data by section
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "bdb_lite.h"
#include "hex_string.h"
#include "pbc_trace.h"
#include "persistent_storage.h"
#include "ps_ds_cbk.h"
#include "ps_ds_friend.h"
#include "state_of_health.h"
#include "ps_data_set.h"
#include "ps_data_set_cfg.h"
#include "reuse.h"
#include "xsal.h"
#include "xsal_thread_priority.h"
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#undef EM_F_ID
#define EM_F_ID EM_FILE_ID(PERSISTENT_STORAGE_MODULE_ID, 0) /**< Identifies file for PbC/trace */

/*
 * If project has not defined a maximum variable size then use default size
 */
#ifndef PS_INITIAL_BUF_SIZE
#   define PS_INITIAL_BUF_SIZE 256
#endif

#ifndef PS_MAX_READ_REQUESTS
#   define PS_MAX_READ_REQUESTS 5
#endif

#ifndef PS_READ_TIMEOUT_MS
#   define PS_READ_TIMEOUT_MS 1000
#endif

#ifndef PS_READ_DONE_TIMEOUT_MS
#    define PS_READ_DONE_TIMEOUT_MS 10000
#endif

#ifndef PS_SEND_TIMEOUT_MS
#   define PS_SEND_TIMEOUT_MS 1000
#endif

#ifndef PS_READ_LOCK_TIMEOUT_MS
#   define PS_READ_LOCK_TIMEOUT_MS 2000
#endif

#ifndef PS_WRITE_DELAY_MS
#   define PS_WRITE_DELAY_MS 500
#endif

#ifndef PS_WRITE_TIMEOUT_MS
#   define PS_WRITE_TIMEOUT_MS 3000
#endif

#ifndef PS_DS_MSG_SIZE
#   define PS_DS_MSG_SIZE 64
#endif

#ifndef PS_MSG_TIMEOUT_MS
#   define PS_MSG_TIMEOUT_MS 2000
#endif

#ifndef PS_BACKGROUND_PRIORITY
#define PS_BACKGROUND_PRIORITY  SAL_LOW_PRIORITY
#endif

#ifndef PS_BACKGROUND_DELAY_MS
#define PS_BACKGROUND_DELAY_MS   30000
#endif

#ifndef PS_SOH_TIMEOUT_MS
#   define PS_SOH_TIMEOUT_MS SOH_DEFAULT_TIMEOUT_MS
#endif

#define NOT_OWNED ((SAL_Thread_Id_T) 0)

/**
 * Size of header on Read Status message before data
 */
#define READ_HEADER_SIZE (1 + 4)

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/**
 * Read Request Structure
 */
typedef struct PS_Read_Tag
{
      SAL_Thread_Id_T owner; /**< thread read request is for, 0 is unused */
      Persistent_Section_ID_T section;
      const char *name;
      void *data_dest;
      ssize_t size_dest;
      bool_t read_succesful;
      SAL_Semaphore_T read_done;
} PS_Read_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

#undef PS_SECTION
#define PS_SECTION(label, path, name)  name,

/**
 * Defines table names for each data set
 */
static const char * const Data_Set_Names[PERSISTENT_NUMBER_OF_SECTIONS] =
{ PS_SECTIONS};

#undef PS_SECTION
#define PS_SECTION(label, path, name)  path,

/**
 * Defines path names for each data set
 */
static const char * const Data_Set_Paths[PERSISTENT_NUMBER_OF_SECTIONS] =
{ PS_SECTIONS};

/**
 * Persistent_Data_Set object for each section
 */
static PS::Persistent_Data_Set * PS_Data[PERSISTENT_NUMBER_OF_SECTIONS];

/**
 * lock for read requests
 */
static SAL_Mutex_T PS_Read_Lock;

/** Delay without updates before saving */
static SAL_Timer_Id_T Write_Delay;

/** Maximum time before saving */
static SAL_Timer_Id_T Write_Timeout;

/** conversion buffer */
static bdb_t PS_Hex_Buf;

/** Tmp buffer for inter-process reads */
static bdb_t PS_Read_Buf;

/** continue persistent control thread */
static bool_t PS_Continue;

/** Limit on pending read/write messages to persistent storage thread */
SAL_Semaphore_T PS_Send_Sem;

/** Controls allocation of read requests */
static SAL_Semaphore_T Read_Requests;

/** pool of read requests */
PS_Read_T PS_Read_Pool[PS_MAX_READ_REQUESTS];

static bool_t ps_ready_flag = false;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
extern "C" void PS_Control_Thread(void *param);
static void Do_Write(bdb_t * pbdb);
static ssize_t Do_Read(Persistent_Section_ID_T section, const char *name, void *data_dest, ssize_t size_dest);
static void Do_Pool_Read(uint8_t indx);
static void Do_Msg_Read(SAL_Message_T const * msg);
static void Process_Msg(const SAL_Message_T * msg);
static void Load_Section(Persistent_Section_ID_T section);
static void Init_Data_Sets(void);
static void Destroy_Data_Sets(void);
static void PS_Send(SAL_Event_Id_T event_id, const void *data, size_t data_size);
static int8_t Get_Read_Request(Persistent_Section_ID_T section, const char *name, void *data_dest, ssize_t size_dest);
static void Return_Read_Request(int8_t indx);
static void Save_Data_Sets(void);
static void Load_Defaults(Persistent_Section_ID_T section);
static void Delete_Data_Sets(void);
void PS_Read_Data(const SAL_Message_T * msg);
static void Free_Read_Request(int8_t read_index);
static void Set_PS_ReadOnly(bool_t read_only);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/**
 *  Send a message to persistent thread
 *    Use a semaphore to keep from overflowing persistent message queue
 *
 * @param event_id - event id to send
 * @param data - pointer to message data
 * @param data_size - size of message data
 */
static void PS_Send(SAL_Event_Id_T event_id, const void *data, size_t data_size)
{
   if (SAL_Wait_Semaphore_Timeout(&PS_Send_Sem, PS_SEND_TIMEOUT_MS))
   {
      SAL_Send(PS_APP_ID, PS_THREAD_ID, event_id, data, data_size);
   }
   else
   {
      Tr_Fault_1("Dropped message %d to Persistent Storage", (int)event_id);
   }
}

/*===========================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/
void PS_Write(Persistent_Section_ID_T section, const char *name, const void *data_src, size_t size_src)
{
   bdb_t bdb;
   int bdb_result;
   size_t msg_len;

   PBC_Require_1(section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section index %d", (int)section);
   PBC_Require(name != NULL, "NULL persistent storage key");
   PBC_Require(name[0] != '\0', "Empty persistent storage key");
   PBC_Require(data_src != NULL, "NULL persistent storage data ptr");
   PBC_Require(size_src > 0, "No persistent storage data");

   Tr_Info_Lo_3("Request Write PS Section: %d Name: %s size: %d", (int)section, name, (int)size_src);

   /*
    * Calculate the exact message length so that there is no wasted space or
    * need for reallocation. Note that BDB sends an int32_t length and NUL
    * terminator with each string. We will also send an int32_t length for the
    * binary data.
    */
   msg_len = sizeof(Persistent_Section_ID_T) + strlen(name) + size_src + 2 * sizeof(int32_t) + 1;
   bdb_result = BDB_Init(&bdb, msg_len);
   PBC_Require(0 == bdb_result, "BDB unable to create buffer");

   BDB_Write_Bytes(&bdb, (int8_t const *) &section, sizeof(Persistent_Section_ID_T));
   BDB_Write_String(&bdb, name);
   BDB_Write_U32(&bdb, size_src);
   BDB_Write_Bytes(&bdb, (int8_t const *) data_src, size_src);

   PBC_Internal_2(BDB_Get_Data_Length(&bdb) == msg_len,
      "Error in initial size allocated for BDB buffer: %d, not %d",
      (int)msg_len, (int)BDB_Get_Data_Length(&bdb));
  
   PS_Send(PS_EV_WRITE, BDB_Get_Buffer(&bdb), msg_len);

   BDB_Destroy(&bdb);
}

/**
 * Get read request from pool
 *    Wait for available slot
 *    Find unused slot in request array
 *    Mark slot used and fill in request data
 *    return slot id
 */
static int8_t Get_Read_Request(Persistent_Section_ID_T section, const char *name, void *data_dest, ssize_t size_dest)
{
   int8_t indx = -1;

   if (SAL_Wait_Semaphore_Timeout(&Read_Requests, PS_READ_TIMEOUT_MS))
   {
      if (SAL_Lock_Mutex_Timeout(&PS_Read_Lock, PS_READ_TIMEOUT_MS))
      {
         for (int i = 0; (indx < 0) && (i < PS_MAX_READ_REQUESTS); i++)
         {
            if (NOT_OWNED == PS_Read_Pool[i].owner)
            {
               indx = i;
               PS_Read_Pool[i].owner = SAL_Get_Thread_Id();
               PS_Read_Pool[i].section = section;
               PS_Read_Pool[i].name = name;
               PS_Read_Pool[i].data_dest = data_dest;
               PS_Read_Pool[i].size_dest = size_dest;
               PS_Read_Pool[i].read_succesful = false;
            }
         }
         SAL_Unlock_Mutex(&PS_Read_Lock);
      }
      else
      {
         Tr_Fault("Unable to access PS_Read_Pool");
         SAL_Signal_Semaphore(&Read_Requests);
      }
   }
   else
   {
      Tr_Fault("Failed to allocate Read Request Semaphore");
   }

   return indx;
}

/**
 * Used to free read request if it times out
 */
static void Free_Read_Request(int8_t read_index)
{
   if (SAL_Lock_Mutex_Timeout(&PS_Read_Lock, PS_READ_TIMEOUT_MS))
   {
      if (SAL_Get_Thread_Id() == PS_Read_Pool[read_index].owner)
      {
         PS_Read_Pool[read_index].owner = NOT_OWNED;
         SAL_Signal_Semaphore(&PS_Read_Pool[read_index].read_done);
      }
      SAL_Unlock_Mutex(&PS_Read_Lock);
   }
   SAL_Signal_Semaphore(&Read_Requests);
}

/**
 *  Return a read request to the pool
 *    Mark request as unowned (0)
 *    Increment number of requests available
 *
 * @param indx - request to return to pool
 */
static void Return_Read_Request(int8_t indx)
{
   if (SAL_Lock_Mutex_Timeout(&PS_Read_Lock, PS_READ_TIMEOUT_MS))
   {
      PS_Read_Pool[indx].owner = NOT_OWNED;

      SAL_Unlock_Mutex(&PS_Read_Lock);
   }

   SAL_Signal_Semaphore(&Read_Requests);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/
bool_t PS_Read(Persistent_Section_ID_T section, const char *name, void *data_dest, ssize_t size_dest)
{
   bool_t read_successful = false;
   int8_t read_index;

   PBC_Require_1(section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section index %d", (int)section);
   PBC_Require(name != NULL, "NULL persistent storage key");
   PBC_Require(data_dest != NULL, "NULL persistent storage data ptr");
   PBC_Require(size_dest != 0, "No persistent storage data");

   read_index = Get_Read_Request(section, name, data_dest, size_dest);

   if ((read_index >= 0) && (read_index < PS_MAX_READ_REQUESTS))
   {
      PS_Send(PS_EV_READ, &read_index, 1);

      if (SAL_Wait_Semaphore_Timeout(&PS_Read_Pool[read_index].read_done, PS_READ_DONE_TIMEOUT_MS))
      {
         if (SAL_Get_Thread_Id() == PS_Read_Pool[read_index].owner)
         {
            read_successful = PS_Read_Pool[read_index].read_succesful;
            Return_Read_Request(read_index);
         }
         else
         {
            Tr_Fault_1("Wrong PS Read Pool Owner %d", PS_Read_Pool[read_index].owner);
         }
      }
      else
      {
         Tr_Fault_2("***** PS_Read %s with section id %d Failed *****", name, section);
         Free_Read_Request(read_index);
         /*PBC_Failed("PS Thread failed to do read");*/
      }
   }
   else
   {
      Tr_Fault("Failed to allocate a PS Read Request");
   }

   return read_successful;
}

extern "C" void PS_Reset(Persistent_Section_ID_T section)
{
   /* delete data files and then data set */
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_ERASE, &section, sizeof(section));
}

extern "C" void PS_Save_Now(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_SAVE, NULL, 0);
}

extern "C" void PS_Shutdown(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_QUIT, NULL, 0);
}

extern "C" void PS_Reload(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_RELOAD, NULL, 0);
}
extern "C" void PS_Get_PS_Ready_Status(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_PS_READY, NULL, 0);
}
/**
 * Start persistent storage thread
 */
extern "C" void PS_Initialize(void)
{
   SAL_Thread_Attr_T attr;
   SAL_Thread_Id_T tid;

   PS_Data_Set_Get_Thread_Attr(&attr);

   tid = SAL_Create_Thread(PS_Control_Thread, NULL, &attr);
   PBC_Ensure_1(PS_THREAD_ID == tid, "Wrong thread id %d", (int)tid);
}

/**
 * Perform actual write request
 *
 * @param pbdb  BDB buffer with write request and data
 */
static void Do_Write(bdb_t * pbdb)
{
   Persistent_Section_ID_T section;
   char const *key;
   size_t size_src;
   size_t hex_sz;
   char *hex_data;

   BDB_Read_Bytes(pbdb, (int8_t *) &section, sizeof(Persistent_Section_ID_T));
   key = BDB_Read_P_String(pbdb);
   size_src = (size_t) BDB_Read_U32(pbdb);
   hex_sz = Hex_String_Size(size_src);

   PBC_Require_1(section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section index %d", (int)section);
   PBC_Require(key != NULL, "NULL persistent storage key");
   PBC_Require(size_src > 0, "No persistent storage data");
   
     

   if (NULL == PS_Data[section])
   {
      Load_Section(section);
   }
   
   SAL_Start_Timer(Write_Delay, PS_WRITE_DELAY_MS, false);

   if (!PS_Data[section]->Is_Dirty())
   {
      SAL_Start_Timer(Write_Timeout, PS_WRITE_TIMEOUT_MS, false);
   }

   /*
    * Convert the binary data to a hex string in m_write_bdb, which will be
    * dynamically sized to hold the largest encountered string.
    */
   BDB_Erase(&PS_Hex_Buf);
   BDB_Guarantee_Min_Buffer_Length(&PS_Hex_Buf, hex_sz);
   hex_data = (char *) BDB_Get_Buffer(&PS_Hex_Buf);

   Bin_To_Hex_String((const uint8_t *) BDB_Get_Buffer(pbdb) + BDB_Tell(pbdb), (Hex_Byte_T *) hex_data, size_src);

   Tr_Info_Lo_4("Writing PS Section: %d Key: %s size:%d Data: %s", (int)section, key, size_src, (const char *)PS_Hex_Buf.mBuffer);

   PS_Data[section]->Write_Data(key, hex_data);
}

/**
 * perform read operation

 * @return Number of bytes read
 */
static ssize_t Do_Read(Persistent_Section_ID_T section, const char *name, void *data_dest, ssize_t size_dest)
{
   size_t read_size = 0;
   ssize_t hex_sz; /* size of hex string */

   PBC_Internal_1(section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section %d", (int) section);
   PBC_Internal(name != NULL, "NULL persistent storage key.");
   PBC_Internal(data_dest != NULL, "NULL dest pointer.");
   PBC_Internal(size_dest != 0, "Size can not be 0");

   if (NULL == PS_Data[section])
   {
      Tr_Info_Lo_1("Load_Section %d", (int) section);
      Load_Section(section);
   }

   /*
    * Use temp buffer to hold hex string
    *   Make sure it is big enough to hold string
    */
   BDB_Erase(&PS_Hex_Buf);
   hex_sz = Hex_String_Int_Size(size_dest);
   BDB_Guarantee_Min_Buffer_Length(&PS_Hex_Buf, abs(hex_sz));

   Tr_Info_Lo_3("Reading PS Section: %d Key: %s size: %d", (int)section, name, size_dest);

   if (PS_Data[section]->Read_Data(name, (char *) BDB_Get_Buffer(&PS_Hex_Buf), hex_sz))
   {

      if (Hex_String_To_Bin((Hex_Byte_T *) BDB_Get_Buffer(&PS_Hex_Buf), (uint8_t *) data_dest, size_dest, &read_size))
      {
         Tr_Info_Lo_1("Persistent Data read successful and size of data read is %d",read_size);
      }
      else
      {
         Tr_Warn_4("Persistent Data is corrupt. Section: %d Key: %s Size: %d Hex Data: %s",
            (int)section, name, size_dest, (char *)BDB_Get_Buffer(&PS_Hex_Buf));
      }
   }
   else
   {
      Tr_Info_Hi_3("Persistent Data not present. Section:%d Key: %s Hex Size: %d", (int)section, name,hex_sz);
   }

   return read_size;
}

/**
 * Read requested data item from pool request (local process)
 *
 * @param indx read request index
 */
static void Do_Pool_Read(uint8_t indx)
{
   PS_Read_T *request = &PS_Read_Pool[indx];
   ssize_t read_size;
   SAL_Thread_Id_T owner = NOT_OWNED;

   PBC_Require_1(indx < PS_MAX_READ_REQUESTS, "Invalid read index %u", indx);

   if (SAL_Lock_Mutex_Timeout(&PS_Read_Lock, PS_READ_TIMEOUT_MS))
   {
      owner = request->owner;
      SAL_Unlock_Mutex(&PS_Read_Lock);
   }

   if (NOT_OWNED != owner)
   {
      PBC_Require_2(request->section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section %d. Read Index %d", (int)request->section, indx);
      PBC_Require_1(request->name != NULL, "NULL persistent storage key. Index %d", indx);
      PBC_Require_1(request->data_dest != NULL, "NULL dest pointer. Index %d", indx);
      PBC_Require_1(request->size_dest != 0, "No persistent storage data. Index %d", indx);

      read_size = Do_Read(request->section, request->name, request->data_dest, request->size_dest);
      request->read_succesful = (read_size > 0);

      SAL_Signal_Semaphore(&request->read_done);
   }
}

/**
 * Process a Persistent read request from another process
 *    @param msg Message with read request
 */
static void Do_Msg_Read(SAL_Message_T const * msg)
{
   bdb_t bdb; /**< hold request information */
   Persistent_Section_ID_T section;
   char const * name;
   ssize_t size_dest;
   size_t read_size;

   /* get request information */
   BDB_Populate(&bdb, (int8_t *) msg->data, msg->data_size);

   BDB_Read_Bytes(&bdb, (int8_t *) &section, sizeof(Persistent_Section_ID_T));
   name = BDB_Read_P_String(&bdb);
   size_dest = BDB_Read_I32(&bdb);

   /* Ensure local read buffer is sufficiently large to hold read data before forwarding */
   BDB_Guarantee_Min_Buffer_Length(&PS_Read_Buf, (abs(size_dest) + 5));

   /* do read into local Read buffer */
   read_size = Do_Read(section, (const char *) name, (char *) BDB_Get_Buffer(&PS_Read_Buf) + READ_HEADER_SIZE, size_dest);

   if (read_size > 0)
   {
      BDB_Rewind(&PS_Read_Buf);
      BDB_Write_Bool(&PS_Read_Buf, true);
      BDB_Write_U32(&PS_Read_Buf, read_size);

      PBC_Ensure_1(READ_HEADER_SIZE == BDB_Tell(&PS_Read_Buf),"Mismatch on header size %d", BDB_Tell(&PS_Read_Buf));

      SAL_Send(msg->sender_app_id, msg->sender_thread_id, PS_EV_READ_STATUS, BDB_Get_Buffer(&PS_Read_Buf), READ_HEADER_SIZE
         + read_size);
   }
   else /* read failed */
   {
      BDB_Erase(&PS_Read_Buf);
      BDB_Write_Bool(&PS_Read_Buf, false); /* signal read failed and no data */
      BDB_Write_U32(&PS_Read_Buf, 0);

      SAL_Send(msg->sender_app_id, msg->sender_thread_id, PS_EV_READ_STATUS, BDB_Get_Buffer(&PS_Read_Buf), BDB_Get_Data_Length(
         &PS_Read_Buf));
   }
}

/**
 * Save all dirty data sets
 */
static void Save_Data_Sets(void)
{
   int i;

   SAL_Stop_Timer(Write_Delay);
   SAL_Stop_Timer(Write_Timeout);

   for (i = 0; i < PERSISTENT_NUMBER_OF_SECTIONS; i++)
   {
      if ((NULL != PS_Data[i]) && PS_Data[i]->Is_Dirty())
      {
         PS_Data[i]->Save();
      }
   }
 
}

/**
 * Deletes all in memory and file based data for section
 *
 * @param section section to wipe out so defaults will be loaded
 */
static void Load_Defaults(Persistent_Section_ID_T section)
{
   if (NULL == PS_Data[section])
   {
      Load_Section(section);
   }

   PS_Data[section]->Erase();
}

/**
 * Delete in memory data
 *    Data will actually be loaded on next read / write
 */
static void Delete_Data_Sets(void)
{
   int i;

   for (i = 0; i < PERSISTENT_NUMBER_OF_SECTIONS; i++)
   {
      if (NULL != PS_Data[i])
      {
         delete PS_Data[i];
         PS_Data[i] = NULL;
      }
   }
}

/**
 * Set PS as read only or writable depending on "read_only"
 */
static void Set_PS_ReadOnly(bool_t read_only)
{
   int i;

   for (i = 0; (i < PERSISTENT_NUMBER_OF_SECTIONS) && (NULL != PS_Data[i]); i++)
   {
      if (read_only)
      {
         PS_Data[i]->Configure_PS_As_ReadOnly();
      }
      else
      {
         PS_Data[i]->Configure_PS_As_Writable();
      }
   }
}

/**
 * process incoming persistent storage request
 */
static void Process_Msg(const SAL_Message_T * msg)
{
   bdb_t bdb;

   switch (msg->event_id)
   {
      case PS_EV_WRITE:
         BDB_Populate(&bdb, (int8_t *) msg->data, msg->data_size);
         Do_Write(&bdb);
         break;
      case PS_EV_READ:
         PBC_Ensure_2(PS_APP_ID == msg->sender_app_id, "Local Read Request from non-local process %u:%u", msg->sender_app_id, msg->sender_thread_id)
         ;
         Do_Pool_Read(*((uint8_t *) msg->data));
         break;
      case PS_EV_SAVE:
         Save_Data_Sets();
         break;
      case PS_EV_ERASE:
         Load_Defaults(*((Persistent_Section_ID_T *) msg->data));
         break;
      case PS_EV_QUIT:
         PS_Continue = false;
         break;
      case PS_EV_RELOAD:
         Delete_Data_Sets();
         break;
      case PS_EV_BCK_END_READ:
         Do_Msg_Read(msg);
         break;
      case PS_EV_GO_BACKGROUND:
         SAL_Set_Thread_Priority(SAL_Get_Thread_Id(), PS_BACKGROUND_PRIORITY);
         break;
      case PS_EV_SET_AS_READONLY:
      {
         if (NULL != msg->data)
         {
            Set_PS_ReadOnly(*((bool_t *) msg->data));
         }
         break;
      }

      case PS_EV_PS_READY:
      {
    	   Tr_Notify("ODCP PS_EVG_READY_1");
    	   SAL_Publish(PS_EVG_READY, NULL, 0);
         break;
      }

      default:
         Tr_Warn_1("Unknown message %d", (int)msg->event_id);
         break;
   }

   if ((PS_APP_ID == msg->sender_app_id) && ((PS_EV_WRITE == msg->event_id) || (PS_EV_READ == msg->event_id)))
   {
      SAL_Signal_Semaphore(&PS_Send_Sem);
   }
}

/**
 * Create objects for each data set
 */
static void Load_Section(Persistent_Section_ID_T section)
{
   int status;
#ifdef PS_NOR_IS
   if (NULL == Data_Set_Names[section])
   {
      Tr_Info_Lo_2("Loading Data set %d Device: %s", section, Data_Set_Paths[section]);
      PS_Data[section] = PS::Get_Data_Set(Data_Set_Paths[section]);
   }
   else
#endif
   /* create data sets */
     /*20131129,fuxiang*/
   Tr_Notify("Load ps section, it will mount factory into ro");
   if(section == PS_SECTION_PARTNUM )
   {
      status = system("mount -o remount,rw /factory_data");
      Tr_Info_Lo_1("'mount -o remount,rw /factory_data' returned status=%d", status);
   }
   /*20131129,fuxiang*/   
 
   {
      Tr_Info_Lo_2("Loading Data set %d Name: %s", section, Data_Set_Names[section]);
      PS_Data[section] = PS::Get_Data_Set(Data_Set_Paths[section], Data_Set_Names[section]);
   }
    /*20131129,fuxiang*/
   if(section == PS_SECTION_PARTNUM )
   {
      status = system("mount -o remount,ro /factory_data");
      Tr_Info_Lo_1("'mount -o remount,ro /factory_data' returned status=%d", status);
   }
   /*20131129,fuxiang*/   
}

/**
 * init data sets as not loaded
 */
static void Init_Data_Sets(void)
{
   int i;
   SAL_Mutex_Attr_T mutex_attr;
   SAL_Semaphore_Attr_T sema_attr;

   SAL_Init_Mutex_Attr(&mutex_attr);

   SAL_Create_Mutex(&PS_Read_Lock, &mutex_attr);

   for (i = 0; i < PERSISTENT_NUMBER_OF_SECTIONS; i++)
   {
      PS_Data[i] = NULL;
   }

   SAL_Init_Semaphore_Attr(&sema_attr);
   for (i = 0; i < PS_MAX_READ_REQUESTS; i++)
   {
      PS_Read_Pool[i].owner = NOT_OWNED;
      SAL_Create_Semaphore(&PS_Read_Pool[i].read_done, &sema_attr);
   }

   sema_attr.initial_value = PS_MAX_READ_REQUESTS;
   SAL_Create_Semaphore(&Read_Requests, &sema_attr);
}

/**
 * Destory each data set
 */
static void Destroy_Data_Sets(void)
{
   int i;

   /* first ensure all data has been saved */
   Save_Data_Sets();

   Delete_Data_Sets();

   for (i = 0; i < PS_MAX_READ_REQUESTS; i++)
   {
      PS_Read_Pool[i].owner = NOT_OWNED;
      SAL_Destroy_Semaphore(&PS_Read_Pool[i].read_done);
   }

   SAL_Destroy_Mutex(&PS_Read_Lock);
   SAL_Destroy_Semaphore(&Read_Requests);
   
   sync();
}

static void PS_Thread_init(void)
{
   SAL_Semaphore_Attr_T attr;

   BDB_Init(&PS_Hex_Buf, PS_INITIAL_BUF_SIZE);
   BDB_Init(&PS_Read_Buf, PS_INITIAL_BUF_SIZE);

   Init_Data_Sets();

   SAL_Create_Timer(PS_EV_SAVE, &Write_Delay);
   SAL_Create_Timer(PS_EV_SAVE, &Write_Timeout);

   /* Limit number of local read  / write requests to help avoid queue overflow */
   SAL_Init_Semaphore_Attr(&attr);
   attr.initial_value = (PS_Data_Set_Queue_Size * 3) / 4;
   SAL_Create_Semaphore(&PS_Send_Sem, &attr);

   SAL_Create_Queue(PS_Data_Set_Queue_Size, PS_DS_MSG_SIZE, SAL_Alloc, SAL_Free);

   SAL_Signal_Ready();

   PS_Continue = true;
}

/**
 * Thread to serialize all persistent data reads and write
 *
 * @param param NOT USED
 */
extern "C" void PS_Control_Thread(void *param)
{
   SAL_Timer_Id_T Go_Background_Timer;
   uint32_t i;

   (void) param;
   Tr_Info_Lo("  \n\n\n==> Running PS_Control thread ....\n");

   PS_Thread_init();

   Tr_Notify("Start Load Section.....");
 
   for (i = 0; i < PERSISTENT_NUMBER_OF_SECTIONS; i++)
   {
      if (NULL == PS_Data[i])
      {
         Load_Section((Persistent_Section_ID_T) i);
      }
   }
 
   Tr_Notify("End Load Section.....");

   #if 0
   /* don't report ready until atleast one section is read */
   if (NULL == PS_Data[0])
   {
      Load_Section((Persistent_Section_ID_T) 0);
   }
   #endif

   SAL_Create_Timer(PS_EV_GO_BACKGROUND, &Go_Background_Timer);
   SAL_Start_Timer(Go_Background_Timer, PS_BACKGROUND_DELAY_MS, false);

   PS_Activated();

   /* Start state of health monitoring */
   SOH_Register(PS_SOH_TIMEOUT_MS);
   /* Notify other threads about persistence ready */
   SAL_Publish(PS_EVG_READY, NULL, 0);
     ps_ready_flag = true;
   while (PS_Continue)
   {
      SAL_Message_T const * msg;

      msg = SAL_Receive_Timeout(PS_MSG_TIMEOUT_MS);
      if (NULL != msg)
      {
         Process_Msg(msg);
      }
      SOH_Alive(PS_SOH_TIMEOUT_MS);
   }

   Destroy_Data_Sets();
   SAL_Destroy_Timer(Write_Delay);
   SAL_Destroy_Timer(Write_Timeout);
   BDB_Destroy(&PS_Hex_Buf);
   BDB_Destroy(&PS_Read_Buf);

   SOH_Dormant();

   PS_Terminated(); /* notify system of shutdown */
}

/*===========================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/
void PS_Set_As_ReadOnly(bool_t readonly)
{
   Tr_Fault_1("\nPS_Set_As_ReadOnly: readonly = %d\n", readonly);
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_SET_AS_READONLY, &readonly, sizeof(readonly));
}

/*===========================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file ps_ds_interface.cpp
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  07 OCt 2016 - ctc_ec#163686
 *  PS ready events added
 *
 * - 11-Apr-2016 Nikhil Thorat
 *  - ctc_ec#149603 : Added persistence ready event notification - PS_EVG_READY.
 *
 * - 29-Nove-2013  fu xiang
 *   - set factory_data partition to RW when need write it.
 *     
 * - 22-July-2013  Jiang Tao
 *   - It is observed that sometimes the PS_Read() from ps_proxy will SAL_Util_Req_And_Rcv timeout when startup.
 *      The timeout is defined as 30 seconds, which will cuase the thread calling  PS_Read() fail to report SOH status, then
 *      cause system reset. Here, load all PS sections when initilization. And this loading all sections cost no less than 10ms.   
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * - 16-Apr-2012 Vijayalakshmi KR
 *   - SOH timeout changed to SOH_DEFAULT_TIMEOUT_MS.
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 11-Feb-2011 Vijayalakshmi KR
 *   - Add variable length support for PS_Read
 *
 * - 24 Dec-2010 Vijayalakshmi KR rev 20
 *   - task 18633: Standalone proxy for PS_Read().
 *
 * - 24-Nov-2009 Dan Carman
 *   - Initial version
 */
/*===========================================================================*/
