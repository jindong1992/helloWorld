#ifndef PS_EVENT_ID_H
#   define PS_EVENT_ID_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file ps_event_id.h
 *
 *    Defines XSAL events for the state-of-health manager.
 *
 * %full_filespec: ps_event_id.h~ctc_ec#12:incl:kok_aud#1 %
 * @version %version: ctc_ec#12 %
 * @author  %derived_by: pz6vcp %
 * @date    %date_modified: Thu Oct  6 21:42:22 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   These declarations are included into the xsal_event_id module to be
 *   assigned unique values within the systems event space.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PS = Persistent Storage
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

#  define PS_PUBLISHED_EVENTS \
   SAL_PUBLIC_EVENT(PS_EVG_DIAG_CHANGED_PS_DATA, "PS Data Changed by Diagnostic")\
   SAL_PUBLISHED_EVENT(PS_EVG_READY, "Persistence Ready Event")\

#  define PS_PUBLIC_EVENTS\
   SAL_PUBLIC_EVENT(PS_EV_BCK_END_READ, "Read from backend")\
   SAL_PUBLIC_EVENT(PS_EV_READ_STATUS, "Read successful from backend")\
   SAL_PUBLIC_EVENT(PS_EV_WRITE,"PS Write Data")\

#  define PS_PRIVATE_EVENTS\
   SAL_PRIVATE_EVENT(PS_EV_READ, "PS Read Data")\
   SAL_PRIVATE_EVENT(PS_EV_SAVE, "PS Save Data Sets")\
   SAL_PRIVATE_EVENT(PS_EV_ERASE,"PS Erase data section")\
   SAL_PRIVATE_EVENT(PS_EV_QUIT, "PS Shutdown")\
   SAL_PRIVATE_EVENT(PS_EV_RELOAD, "PS Reload data from files")\
   SAL_PRIVATE_EVENT(PS_EV_GO_BACKGROUND, "PS Switch to background priority")\
   SAL_PRIVATE_EVENT(PS_EV_SET_AS_READONLY, "Make PS as Read Only or Writable")\
   SAL_PRIVATE_EVENT(PS_EV_PS_READY, "Read PS READY Status")\

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file ps_event_id.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  07 OCt 2016 - ctc_ec#163686
 *  PS ready events added
 *
 * - 11-Apr-2016 Nikhil Thorat
 *  - ctc_ec#149603 : Added persistence ready event notification - PS_EVG_READY.
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 09-Feb-2011 Vijayalakshmi KR
 *   - PS write and read changes.
 *
 * - 24 Dec-2010 Vijayalakshmi KR rev 20
 *   - task 18633: Standalone proxy for PS_Read().
 *
 * - 25-Nov-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PS_EVENT_ID_H */
