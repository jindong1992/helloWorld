#ifndef PS_DS_CBK_H
#   define PS_DS_CBK_H
/*===========================================================================*/
/**
 * @file ps_ds_cbk.h
 *
 * Defines the implementation-specific callouts and constants that must be
 * provided by another module in the system
 *
 * %full_filespec:ps_ds_cbk.h~kok_basa#6:incl:kok_aud#1 %
 * @version %version:kok_basa#6 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Wed Mar  7 15:07:46 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Isolates the implementation-specific constants and callouts so that the
 * remainder of the module can be reused without modification.
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @addtogroup ps_ds
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "xsal.h"

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Exported Constants for Callouts
 *===========================================================================*/
/**
 * Number of entries allocated to persistent storage client message queue.
 */
extern const size_t PS_Data_Set_Queue_Size;

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * Returns the thread configuration for Embedded DBA Client Listener thread.
 *
 * @param [out] attr Points to the caller-supplied thread attribute that
 *                   will be filled in with the attributes of the thread
 *                   for this system.
 *
 * @pre
 *    attr != NULL
 *
 * @post
 *    attr->id == thread ID
 */
void PS_Data_Set_Get_Thread_Attr(SAL_Thread_Attr_T * attr);

/** 
 *  Callout on start of PS application
 */
void PS_Activated(void);

/** 
 *  Callout on end of PS application
 */
void PS_Terminated(void);

/*===========================================================================*/
/*!
 * @file ps_ds_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 09-Feb-2011 Vijayalakshmi KR
 *   - PS write and read changes.
 *
 * - 24-Dec-2010 Vijayalakshmi KR
 *   - Stand alone proxy for PS_Write().
 *
 * - 43-Nov-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
} /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PS_DS_CBK_H */
