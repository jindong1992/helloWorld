#ifndef PS_DATA_SET_H
#   define PS_DATA_SET_H
/*===========================================================================*/
/**
 * @file ps_data_set.h
 *
 * Persistent Data Set API
 *
 * %full_filespec:ps_data_set.h~ctc_ec#11:incl:kok_aud#1 %
 * @version %version:ctc_ec#11 %
 * @author  %derived_by:hzm7yk %
 * @date    %date_modified:Sat Apr 18 14:25:14 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This class represents a persistent data set of string tuples
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup ps_data_set_storage Template Class to create ps_data_set objects
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"

#   define EM_F_ID EM_FILE_ID(PERSISTENT_STORAGE_MODULE_ID, 5)

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

namespace PS
{

   /**
    * Persistent data set abstract declaration
    */
   class Persistent_Data_Set
   {
      public:

      virtual ~Persistent_Data_Set()
      {
      }

      /**
       * Read a data item from data set
       *    Only callable from persistent data set control thread
       *
       * @return true if successful; false otherwise,
       *
       * @param [in] key Name associated with data to be read.
       * @param [in,out] data_dest buffer into which the data is to be read.
       * @param [in] size_dest Size of destination buffer.Positive length values
       * means that we need exactly that much data(more or less is invalid).
       * Negative length values means that the absolute value is the maximum
       * acceptable length (e.g., -10 would mean that any data size from 0 to 10 would
       * be acceptable.Data longer than that would be considered invalid.
       */
      virtual bool_t Read_Data(const char *key, char *data_dest, ssize_t size_dest) = 0;

      /**
       * Write an item to data set
       *    Only callable from persistent data set control thread
       *
       * @param [in] key Name for data item to write
       * @param [in] data string data to write
       */
      virtual void Write_Data(const char *key, const char *data) = 0;

      /**
       * Returns if data set has unsaved changes
       *
       * @return true if data set is dirty, false if no unsaved changes
       */
      virtual bool_t Is_Dirty(void) = 0;

      /**
       *  Save data set to non-volatile storage (if it has changed)
       */
      virtual bool_t Save(void) = 0;

      /**
       * Erase saved data
       */
      virtual void Erase(void) = 0;

      /**
       * Dump data set to output path
       */
      virtual void Dump(const char * output) = 0;

      /**
      * Set PS as read only
      */
      virtual void Configure_PS_As_ReadOnly(void) = 0;

      /**
      * Set PS as writable
      */
      virtual void Configure_PS_As_Writable(void) = 0;
   };

   /**
    * Returns a reference to a concrete persistent data object based on file name
    */
   Persistent_Data_Set *Get_Data_Set(const char *path, const char *name);

   /**
    * Returns a reference to a concrete persistent data object based on mtd device name
    */
   Persistent_Data_Set *Get_Data_Set(const char * device_name);

   /*===========================================================================*
    * Exported Const Object Declarations
    *===========================================================================*/

   /*===========================================================================*
    * Exported Function Prototypes
    *===========================================================================*/

   /*===========================================================================*
    * Exported Inline Function Definitions and #define Function-Like Macros
    *===========================================================================*/

}

#   undef  EM_F_ID

/*===========================================================================*/
/*!
 * @file ps_data_set.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * - 11-Feb-2011 Vijayalakshmi KR
 *   - Add variable length support for PS_Read
 *
 * - 24-Nov-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PS_DATA_SET_H */
