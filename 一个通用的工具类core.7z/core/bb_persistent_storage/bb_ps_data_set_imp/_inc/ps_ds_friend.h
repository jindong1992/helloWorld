#ifndef PS_DS_FRIEND_H
#   define PS_DS_FRIEND_H
/*===========================================================================*/
/**
 * @file ps_ds_friend.h
 *
 * Defines the implementation-specific APIs available to other modules
 *
 * %full_filespec:ps_ds_friend.h~kok_basa#6:incl:kok_aud#1 %
 * @version %version:kok_basa#6 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Wed Mar  7 15:07:46 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Isolates the implementation-specific constants and callouts so that the
 * remainder of the module can be reused without modification.
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @addtogroup ps_ds
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "persistent_storage.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/**
 * Erases all persistent data in section.
 *    Defaults should be loaded on future reads
 *
 * @param section Section ID to erase 
 *
 */
void PS_Reset(Persistent_Section_ID_T section);

/**
 *  Force data files to be updated now
 */
void PS_Save_Now(void);

/**
 * Delete in memory data and reload from files
 */
void PS_Reload(void);

#   ifdef __cplusplus
} /* extern "C" */
#   endif                       /* __cplusplus */

/*===========================================================================*/
/*!
 * @file ps_ds_friend.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 43-Nov-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* PS_DS_FRIEND_H */
