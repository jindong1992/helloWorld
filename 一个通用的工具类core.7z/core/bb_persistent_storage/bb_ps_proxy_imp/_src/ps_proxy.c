/*===========================================================================*/
/**
 * @file ps_proxy.c
 *
 * Converts between persistent data blocks and checksum strings used by the database
 *
 * %full_filespec:ps_proxy.c~ctc_ec#10:csrc:kok_basa#1 %
 * @version %version:ctc_ec#10 %
 * @author  %derived_by:pz6vcp %
 * @date    %date_modified:Fri Oct  7 13:56:00 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module converts persistent data between binary form and null terminated hex string form
 *    String inclues one byte two complement checksum of binary data
 *    and passes the strings to the database interface. 
 * Variable length data:  positive length values means that we need exactly that much data 
 * (more or less is invalid).Negative length values means that the absolute value is the 
 * maximum acceptable length (e.g., -10 would mean that any data size from 0 to 10 would 
 * be acceptable.  Data longer than that would be considered invalid. 
 * 
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - Have not implemented persistent ojbect registry and the Reset / Reload data by section
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "reuse.h"
#include "pbc_trace.h"
#include "bdb_lite.h"
#include "xsal_util.h"
#include "persistent_storage.h"
#include "xsal.h"
#include <string.h>
#include <stdlib.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PERSISTENT_STORAGE_MODULE_ID, 0); /* Identifies file for PbC/trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

#ifndef PS_DATA_REQUEST_TIMEOUT_MS
#define PS_DATA_REQUEST_TIMEOUT_MS 10000
#endif

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
/*============================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/
void PS_Write(Persistent_Section_ID_T PS_Section, const char *name, const void *data_src, size_t size_src)
{
   bdb_t bdb;
   int bdb_result;
   size_t msg_len;

   PBC_Require_1(PS_Section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section index %d", (int)PS_Section);
   PBC_Require(name != NULL, "NULL persistent storage key");
   PBC_Require(name[0] != '\0', "Empty persistent storage key");
   PBC_Require(data_src != NULL, "NULL persistent storage data ptr");
   PBC_Require(size_src > 0, "No persistent storage data");

   Tr_Info_Lo_3("Request Write PS Section: %d Name: %s size: %d", (int)PS_Section, name, (int)size_src);

   /*
    * Calculate the exact message length so that there is no wasted space or
    * need for reallocation. Note that BDB sends an int32_t length and NUL
    * terminator with each string. We will also send an int32_t length for the
    * binary data.
    */
   msg_len = sizeof(Persistent_Section_ID_T) + strlen(name) + size_src + 2 * sizeof(int32_t) + 1;
   bdb_result = BDB_Init(&bdb, msg_len);
   PBC_Require(0 == bdb_result, "BDB unable to create buffer");

   BDB_Write_Bytes(&bdb, (int8_t const *) &PS_Section, sizeof(Persistent_Section_ID_T));
   BDB_Write_String(&bdb, name);
   BDB_Write_U32(&bdb, size_src);
   BDB_Write_Bytes(&bdb, (int8_t const *) data_src, size_src);

   PBC_Internal_2(BDB_Get_Data_Length(&bdb) == msg_len,
      "Error in initial size allocated for BDB buffer: %d, not %d",
      (int)msg_len, (int)BDB_Get_Data_Length(&bdb));

   Tr_Info_Lo("Send PS_EV_WRITE to persistent backend thread");

   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_WRITE, BDB_Get_Buffer(&bdb), msg_len);

   BDB_Destroy(&bdb);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in persistent_storage.h.
 *
 *===========================================================================*/
bool PS_Read(Persistent_Section_ID_T PS_Section, const char *name, void *data_dest, ssize_t size_dest)
{
   bool read_successful = false;
   bdb_t bdb;
   int bdb_result;
   size_t msg_len;
   const SAL_Message_T* msg;
   SAL_Util_Send_Rcv_T srs;
   bdb_t pbdb;
   size_t read_size;

   Tr_Info_Lo_3("Request Read PS Section: %d Name: %s size: %d", (int)PS_Section, name, (int)size_dest);

   PBC_Require_1(PS_Section < PERSISTENT_NUMBER_OF_SECTIONS, "Invalid section index %d", (int)PS_Section);
   PBC_Require(name != NULL, "NULL persistent storage key");
   PBC_Require(data_dest != NULL, "NULL persistent storage data ptr");
   PBC_Require(size_dest != 0, "No persistent storage data");

   msg_len = sizeof(Persistent_Section_ID_T) + strlen(name) + sizeof(ssize_t) + sizeof(int32_t) + 1;
   bdb_result = BDB_Init(&bdb, msg_len);
   PBC_Require(0 == bdb_result, "BDB unable to create buffer");

   BDB_Write_Bytes(&bdb, (int8_t const *) &PS_Section, sizeof(Persistent_Section_ID_T));
   BDB_Write_String(&bdb, name);
   BDB_Write_I32(&bdb, size_dest);

   PBC_Internal_2(BDB_Get_Data_Length(&bdb) == msg_len,
      "Error in initial size allocated for BDB buffer: %d, not %d",
      (int)msg_len, (int)BDB_Get_Data_Length(&bdb));

   srs.app_id = PS_APP_ID;
   srs.thread_id = PS_THREAD_ID;
   srs.send_id = PS_EV_BCK_END_READ;
   srs.send_data = (char *) BDB_Get_Buffer(&bdb);
   srs.send_data_sz = (int) BDB_Get_Data_Length(&bdb);
   srs.reply_id = PS_EV_READ_STATUS;
   srs.max_tries = 3; /* ctc_ec#14713, Radio reboot, chang 1 -> 3 by zengliangqian  */
   srs.timeout_ms = PS_DATA_REQUEST_TIMEOUT_MS;

   Tr_Info_Lo("Send PS_EV_BCK_END_READ to persistent backend thread");

   msg = SAL_Util_Req_And_Rcv(&srs);

   PBC_Require(NULL != msg, "SAL_Util_Req_And_Rcv() failed");
   PBC_Require(msg->event_id == PS_EV_READ_STATUS, "Incorrect event received");

   if (NULL != msg->data)
   {
      bool_t size_ok = false;

      BDB_Populate(&pbdb, (int8_t *) msg->data, msg->data_size);
      read_successful = BDB_Read_Bool(&pbdb);
      if (read_successful)
      {
         read_size = BDB_Read_U32(&pbdb);
         PBC_Require_1(read_size > 0, "Invalid read size %d returned", read_size);

         Tr_Info_Lo_1("Verifying the size of read data after read success %d",read_size);

         if (size_dest > 0)
         {
            size_ok = (read_size == size_dest);
         }
         else
         {
            size_ok = (read_size <= abs(size_dest));
         }

         if (size_ok)
         {
            Tr_Info_Lo("Copying read data to destination buffer");
            BDB_Read_Bytes(&pbdb, data_dest, read_size);
         }
         else
         {
            read_successful = false;
         }
      }
   }
   BDB_Destroy(&bdb);

   return read_successful;
}

void PS_Reset(Persistent_Section_ID_T section)
{
   /* delete data files and then data set */
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_ERASE, &section, sizeof(section));
}

void PS_Save_Now(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_SAVE, NULL, 0);
}

void PS_Shutdown(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_QUIT, NULL, 0);
}

void PS_Reload(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_RELOAD, NULL, 0);
}
void PS_Get_PS_Ready_Status(void)
{
   SAL_Send(PS_APP_ID, PS_THREAD_ID, PS_EV_PS_READY, NULL, 0);
}

/*===========================================================================*/
/*!
 * @file ps_proxy.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  07 OCt 2016 - ctc_ec#163686
 *  PS ready events added
 *
 * - 03-June-2011 Vijayalakshmi KR
 *   - Change PS_DATA_REQUEST_TIMEOUT_MS.
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 11-Feb-2011 Vijayalakshmi KR
 *   - Add variable length support for PS_Read
 *
 * - 09-Feb-2011 Vijayalakshmi KR
 *   - PS write and read changes.
 *
 * - 24 Dec-2010 Vijayalakshmi KR rev 20
 *   - task 18633: Standalone proxy for PS_Read().
 *
 * - 24 Dec-2010 Vijayalakshmi KR rev 20
 *   - task 18632: Standalone proxy for PS_Write().
 *
 * - 06 Dec-2010 Vijayalakshmi KR rev 19
 *   - task 17296: Temporary changed:Disable Write/Read of PS EDB.
 *
 * - 16-Oct-2009 Bob Lemcke rev 16
 *   - task 58340: Temporary changed: Disable Write/Read of PS.
 *
 * - 24-Sep-2009 Kirk Bailey rev 15
 *   - task 57480: Changed interface to PS_EDB_Read/Write
 *
 * - 26-March-2009 Dan Carman
 *   - reimplemented block split into mutliple c files
 */
/*===========================================================================*/

