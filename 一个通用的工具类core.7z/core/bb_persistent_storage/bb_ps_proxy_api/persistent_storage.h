#ifndef PERSISTENT_STORAGE_H
#   define PERSISTENT_STORAGE_H
/*===========================================================================*/
/**
 * @file persistent_storage.h
 *
 * API to read / write persistent data from non-volatile storage
 *
 * %full_filespec:persistent_storage.h~ctc_ec#4.2.1:incl:kok_basa#9 %
 * @version %version:ctc_ec#4.2.1 %
 * @author  %derived_by:pz6vcp %
 * @date    %date_modified:Thu Oct  6 21:42:32 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * It is not recommended that data handlers directly use the PS_Read / PS_Write interface
 *  but instead use the persistent class interface.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PS - Persistent Storage
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @defgroup  p_storage API to read / write data block from/to non-volatile storage
 * @ingroup persistent_storage
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include "persistent_storage_acfg.h"

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/**
 * Stores data into the persistent storage.
 * Persistent storage memory is devided into different sections.
 * In the case of database, each section may be in seperate files.
 * Each of the section is then divided into different blocks
 * Each block can hold multiple data entries
 * PS_Section:   Persistent storage section in which the data will be stored.
 * name:         name of persistent variable to write
 * data_src:     pointer to the runtime memory location where
 *               the source of the data is.
 * size_src:     size of the data to be stored
 */
void PS_Write(Persistent_Section_ID_T PS_Section, const char *name, const void *data_src, size_t size_src);

/**
 * Reads data from the persistent storage.
 * Persistent storage memory is devided into different sections.
 * In the case of database, each section may be in seperate files.
 * Each of the section is then divided into different blocks
 * Each block can hold multiple data entries
 * PS_Section:   Persistent storage section in which the data will be stored.
 * name:         name of perisistent variable to read
 * data_dest:    pointer to the runtime memory location
 *               where the retrieved data is to be stored
 * size_src:     size of the data to be read.
 * Variable length data:  positive length values means that we need exactly that much data
 * (more or less is invalid).Negative length values means that the absolute value is the
 * maximum acceptable length (e.g., -10 would mean that any data size from 0 to 10 would
 * be acceptable.  Data longer than that would be considered invalid.
 *
 * return:       true = successful
 */
bool_t PS_Read(Persistent_Section_ID_T PS_Section, const char *name, void *data_dest, ssize_t size_dest);

/**
 * Start the persistent storage server task
 */
void PS_Initialize(void);

/**
 * Shutdown the persistent storage server task
 */
void PS_Shutdown(void);

/**
 * Using PITS message, the PS files can be removed. To avoid new writes of PS objects,
 * this API is used to make PS as Read Only till reset happens. Post startup,
 * PS is again writable.
 *
 * readonly: true - set as readonly. false - set as writable.
 */
void PS_Set_As_ReadOnly(bool_t readonly);

void PS_Get_PS_Ready_Status(void);

/*===========================================================================*/
/*!
 * @file persistent_storage.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 07 OCt 2016 - ctc_ec#163686
 * PS ready events added
 *
 * 17 May 2012 Pramod N K
 * Set the PS as read only when PITS command to remove PS files is received.
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 11-Feb-2011 Vijayalakshmi KR
 *   - Add variable lenth support for PS_Read
 *
 * - 09-Feb-2011 Vijayalakshmi KR
 *   - PS write and read changes.
 *
 * 18-March 2009 Dan Carman
 *   - Changed APIs to use variable name instead of block index
 *
 * task 37919: 15-09-2008
 * Use void pointer instead of type casting.
 * task38774
 * make API configurable
 *
 * task 42155: 17-11-2008
 * simplified PERSISTENT_SECTION_ID_T enum
 * implementation moved to _cfg.h
 *
 * task 45219: 30-01-2009
 * Added PS_Reset_Parm
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
} /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PS_PROXY_H */
