/**
 * @file ps_proxy.h
 *
 * This is deprecated header file, please use persistetn_storage.h
 *
 * %full_filespec:persistent_storage.h~2:incl:kok_basa#9 %
 * @version %version:2 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Tue Mar 22 07:52:16 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 */

#include "persistent_storage.h"

/*===========================================================================*/
/*!
 * @file ps_proxy.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 22-March-2011 Dan Carman
 *   - Implement to restore old API file 
 */
/*===========================================================================*/
