#ifndef PERSISTENT_H
#   define PERSISTENT_H
/*===========================================================================*/
/**
 * @file persistent.h
 *
 * Template class for persistent storage
 *
 * %full_filespec:persistent.h~ctc_ec#7.1.1:incl:kok_basa#6 %
 * @version %version:ctc_ec#7.1.1 %
 * @author  %derived_by:xzhgs6 %
 * @date    %date_modified:Fri Jan 30 13:06:25 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009-2013 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This template class defines behaviors to make Persistent variables.
 *    Behaviors include:
 *     Local cached copy of data for quick read / write access
 *       Cache is loaded from back-end storage on first get 
 *       Back-end storage is only updated when cache changes
 *     Default value when variable is not in non-volatile storage
 *     Abitily to force to default
 *     Ability to force reload from back-end storage
 *
 * @section ABBR ABBREVIATIONS:
 *   - PS - Persistent Storage
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @defgroup persistent_storage Template Class to create persistent objects 
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include <cstring>
#   include <string>
#   include "reuse.h"
#   include "persistent_storage.h"
#   include "pbc_trace.h"
#   include "xsal.h"

#   define EM_F_ID EM_FILE_ID(PERSISTENT_STORAGE_MODULE_ID, 2)

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/**
 * This template class is to create dynamic persistent objects
 */
template < class T > class Persistent
{
   T cache; /**< local storage */
   const T *def_value; /**< Default value */
   std::string name; /**< name of variable in database */
   bool valid; /**< indicates if data loaded from database */
   Persistent_Section_ID_T section; /**< identifies table / section of persistent storage in database */

   public:
   /** construct persistent object with a pointer to default value */
   Persistent(Persistent_Section_ID_T sect, const char *nam, const T * def);

   /** construct persistent object with a specific default value */
   Persistent(Persistent_Section_ID_T sect, const char *nam, T def);

   virtual ~ Persistent();

   /** update cache and queue save to database */
   void Put(T);

   /** update cache and queue save to database */
   void Put(const T *);

   /** return current value (cached) */
   T Get();

   /** return current value (uncached) */
   T Read();

   /** return default value */
   T Get_Default();

   /** set value to default */
   virtual void Default();

   /** Invalidate cache and force data reload on next get */
   void Reload();

   /** Diagnostic Read. Does not use cache */
   T Diag_Read();

   /** Diagnostic Write. Does not use cache. */
   void Diag_Write(T);

   /**<doesnot update cache and queue save to database */
   void Diag_Write(const T *);

};

template < class T > Persistent < T >::Persistent(Persistent_Section_ID_T sect, const char *nam, const T * def)
{
   valid = false;
   name = nam;
   section = sect;
   def_value = def;
}

template < class T > Persistent < T >::Persistent(Persistent_Section_ID_T sect, const char *nam, T def)
{
   valid = false;
   name = nam;
   section = sect;
   def_value = new T(def);
}

template < class T > Persistent < T >::~Persistent()
{
   valid = false;
}

template < class T > void Persistent < T >::Put(T nv)
{
   if ((!valid) || (0 != std::memcmp(&cache, &nv, sizeof(T))))
   {
      cache = nv;
      valid = true;
      PS_Write(section, name.c_str(), &cache, sizeof(T)); /* write to presistent storage */
   }
}

template < class T > void Persistent < T >::Put(const T * nv)
{
   if ((!valid) || (0 != std::memcmp(&cache, nv, sizeof(T))))
   {
      cache = *nv;
      valid = true;
      PS_Write(section, name.c_str(), &cache, sizeof(T)); /* write to presistent storage */
   }
}

template < class T > void Persistent < T >::Default()
{
   valid = false; /* force update to database */
   Put(def_value);
}

template < class T > void Persistent < T >::Reload()
{
   valid = false; /* invalidate cache to force database read on next get */
}

template < class T > T Persistent < T >::Get_Default()
{
   return *def_value;
}

template < class T > T Persistent < T >::Get()
{
   if (!valid)
   {
      Tr_Info_Lo_1("Reading %s from persistent storage", name.c_str());
      valid = PS_Read(section, name.c_str(), &cache, sizeof(T));
      if (!valid)
      {
         Tr_Warn_1("%s was not in persistent storage, using default", name.c_str());
         Default();
      }
   }
   return cache;
}

template < class T > T Persistent < T >::Read()
{
   Tr_Info_Lo_1("Reading %s from persistent storage", name.c_str());
   valid = PS_Read(section, name.c_str(), &cache, sizeof(T));
   if (!valid)
   {
      Tr_Warn_1("%s was not in persistent storage, using default", name.c_str());
      Default();
   }

   return cache;
}

template < class T > T Persistent < T >::Diag_Read()
{
   T temp;
   Tr_Info_Lo_1("Diagnostic Reading %s from persistent storage", name.c_str());

   if (!PS_Read(section, name.c_str(), &temp, sizeof(T)))
   {
      Tr_Warn_1("%s was not in persistent storage, using default", name.c_str());
      temp = *def_value;
    }

   return temp;
}

template < class T > void Persistent < T >::Diag_Write(T nv)
{
      Diag_Write(&nv);
}

template < class T > void Persistent < T >::Diag_Write(const T * nv)
{
   Tr_Info_Lo_1("Diagnostic Writing %s to persistent storage", name.c_str());

   PS_Write(section, name.c_str(), nv, sizeof(T)); /* always write to persistent storage */
   valid = false;
   SAL_Publish(PS_EVG_DIAG_CHANGED_PS_DATA, NULL, 0);
}

#   undef  EM_F_ID

/*===========================================================================*/
/*!
 * @file persistent.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 31-Jan-2012 Dan Carman
 *   Added Diagnostic Read / Write Methods
 *   Removed template for Persistent Reader
 *
 * - 29-Feb-2012 Mark Elkins Rev 4
 *   - Task 79563: Persistent Storage:  Add Get_Default() method to return the default value of a persistent object
 *
 * - 03-March-2011 Vijayalakshmi KR
 *   - Implement review comments.
 *
 * - 20-may-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PERSISTENT_H */
