/*===========================================================================*/
/**
 * @file xml_property.cpp
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:xml_property.cpp~4:c++:kok_basa#1 %
 * @version %version:4 %
 * @author  %derived_by:kzyqkh %
 * @date    %date_modified:Tue Jul 26 03:39:07 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * @todo Add full description here
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include "reuse.h"
#include <stdio.h>
#include <string.h>

#include "string_res.h"

#include "xml_parser_cfg.h"
#include "xml_property.h"

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Class Definitions
\*===========================================================================*/

void XmlProperty::setProperty(const char* name, const char* data)
{
   if (name != NULL)
   {
      if (mName != NULL)
      {
         delete [] mName;
      }
      
      mName = new char[strlen(name) + 1];
      Safe_Strncpy(mName, name, strlen(name) + 1);
   }
   
   if (data != NULL)
   {
      if (mData != NULL)
      {
         delete [] mData;
      }
      
      mData = new char[strlen(data) + 1];
      Safe_Strncpy(mData, data, strlen(data) + 1);
   }
}

XmlProperty::~XmlProperty()
{
   if (mName != NULL)
   {
      delete [] mName;
      mName = NULL;
   }
   
   if (mData != NULL)
   {
      delete [] mData;
      mData = NULL;
   }
}

size_t XmlProperty::writeXmlFile(FILE* handle)
{
   char str[XML_MAX_TAG_NAME_LEN + XML_MAX_TAG_DATA_LEN + 10];

   if (NULL == handle)
   {
      return 0;
   }
   
   if (NULL != mData)
   {
      snprintf(str, sizeof(str), " %s=\"%s\"", mName, mData);
   }
   else
   {
      snprintf(str, sizeof(str), "%s", mName);
   }
   
   return fwrite(str, sizeof(str[0]), strlen(str), handle);
}

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * 07-sep-2010 <name>
 * + Created initial file.
 *
\*===========================================================================*/
