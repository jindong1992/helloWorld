/*===========================================================================*/
/**
 * @file xml_parser.cpp
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:xml_parser.cpp~11:c++:kok_basa#3 %
 * @version %version:11 %
 * @author  %derived_by:hz1941 %
 * @date    %date_modified:Thu Feb  7 13:57:10 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * @todo Add full description here
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include "reuse.h"
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/stat.h>

#include "string_res.h"

#include "xml_parser.h"
#include "xml_parser_cfg.h"

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/
enum XmlToken
{
   NO_TOKEN = -1,
   START_TAG_TOKEN,
   END_TAG_TOKEN,
   LETTER_TOKEN,
   EQUAL_TOKEN,
   QUOTE_TOKEN,
   SLASH_TOKEN,
   COMMENTS_TOKEN,
   INFO_TOKEN
};

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Class Definitions
\*===========================================================================*/

XmlParser::XmlParser() :
#ifndef CFG_USE_CACHE
   mHandle(NULL),
#else
   mcFileBuff(NULL),
   mpFileCursor(NULL),
   mpEOF(NULL),
   mFileSize(0),
#endif
   mLineNumber(1),
   mFName(NULL)
{
}

XmlParser::~XmlParser()
{
   clean();
}

void XmlParser::clean()
{
   while (!mTags.empty())
   {
      delete mTags.back();
      mTags.pop_back();
   }

   if (NULL != mcFileBuff)
   {
      delete [] mcFileBuff;
      mcFileBuff = NULL;
   }

}

int XmlParser::removeTag(const XmlTag* aTag)
{
   XmlTag* tag = NULL;   
   std::vector<XmlTag*>::iterator it;
   
   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      if (*it == aTag)
      {
         mTags.erase(it);
         delete aTag;
         
         return 0;
      }
   }    
   
   /* There is no such tag in the parser's container
      try to find it in the embedded tags */
   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      tag = *it;
      
      if (tag->removeTag(aTag) == 0)
      {
         return 0;
      }
   }    
      
   return -1;
}

XmlTag* XmlParser::findTag(const char* tagName, const char* propName, 
   const char* propData)
{
   XmlTag* retTag = NULL;
   XmlTag* tag = NULL;
   std::vector<XmlTag*>::iterator it;

   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      tag = *it;
      
      if ((retTag = tag->findTag(tagName, propName, propData)) != NULL)
      {
         return retTag;
      }
   }     
   
   return NULL;
}

int XmlParser::parseXmlFile(const char* fname)
{
   int token;
   XmlTag* tag;
   
   mFName = fname;

#ifdef CFG_USE_CACHE
   FILE* mHandle = NULL;
#endif

   mHandle = fopen(mFName, "r");
   
   if (NULL == mHandle)
   {
      return -1;
   }

#ifdef CFG_USE_CACHE
   if (0 != fseek(mHandle, 0, SEEK_END))
   {
      fclose(mHandle);
      return -1;
   }
   
   mFileSize = ftell(mHandle);
   mcFileBuff = new char[mFileSize];

   if (0 != fseek(mHandle, 0, SEEK_SET))
   {
      fclose(mHandle);
      return -1;
   }

   if (0 >= fread(mcFileBuff, sizeof(mcFileBuff[0]), mFileSize, mHandle))
   {
      fclose(mHandle);
      return -1;
   }

   mpFileCursor = &mcFileBuff[0];
   mpEOF = mcFileBuff + mFileSize;
#endif   

   while ((token = getToken()) != NO_TOKEN)
   {
      switch(token)
      {
         /* New tag */
         case START_TAG_TOKEN:
         {
            tag = getXmlTag();
            
            if (tag != NULL)
            {
               mTags.push_back(tag);
            }
            break;
         }
         default:
         {
#ifndef CFG_USE_CACHE
            /* Step forward one byte */
            if (0 != fseek(mHandle, 1, SEEK_CUR))
            {
               fclose(mHandle);
               return -1;
            }
#else
            mpFileCursor++;
#endif
            break;
         }
      }
   }
   
   fclose(mHandle);

#ifdef CFG_USE_CACHE
   delete [] mcFileBuff;
   mcFileBuff = NULL;
#endif

   return 0;
}

void XmlParser::skipSpaces()
{
   char buff;
#ifndef CFG_USE_CACHE
   while (0 >= fread(&buff, sizeof(buff), 1, mHandle) > 0)
   {
#else
   while (mpFileCursor < mpEOF)
   {
      buff = *mpFileCursor;
      mpFileCursor++;
#endif
      if ((char) buff == '\n')
      {
         mLineNumber++;
         continue;
      }
      if ((char)buff == ' ') continue;
      if ((char)buff == '\t') continue;
      if ((char)buff == '\r') continue;

#ifndef CFG_USE_CACHE
      /* Step back one byte */
      fseek(mHandle, -1, SEEK_CUR);
#else
      mpFileCursor--;
#endif
      return;
   }
}

int XmlParser::getToken()
{
   char buff;
   int token = NO_TOKEN;
   skipSpaces();
   
#ifndef CFG_USE_CACHE
   if (0 >= fread(&buff, sizeof(buff), 1, mHandle) > 0)
   {
#else
   if (mpFileCursor < mpEOF)
   {
      buff = *mpFileCursor;
      mpFileCursor++;
#endif
      switch (buff)
      {
         case '<': 
            token = START_TAG_TOKEN;
            break;
         case '>': 
            token = END_TAG_TOKEN;
            break;
         case '=': 
            token = EQUAL_TOKEN;
            break;
         case '\"':
            token = QUOTE_TOKEN;
            break;
         case '!':
            token = COMMENTS_TOKEN;
            
            /* Skip Comments */
            gotoEndOfTag();
            return getToken();
         case '?':
            token = INFO_TOKEN;
//            gotoEndOfTag();
//            return getToken();
            break;
         case '/':
            token = SLASH_TOKEN;
            break;
         default :
            token = LETTER_TOKEN;
#ifndef CFG_USE_CACHE
            fseek(mHandle, -1, SEEK_CUR);
#else
            mpFileCursor--;
#endif
      }
   }   
   
   return token;
}

int XmlParser::getString(char *str, int aEol, bool_t is_tag_value)
{
   char buff;
#ifndef CFG_USE_CACHE
   while (0 >= fread(&buff, sizeof(buff), 1, mHandle) > 0)
   {
#else
   while (mpFileCursor < mpEOF)
   {
      buff = *mpFileCursor;
      mpFileCursor++;
#endif
      if (buff == '\n')
      {
         mLineNumber++;
      }

      /* aEol is the end of line character */
      if (aEol != 0)
      {
         if (buff == aEol)
         {
            *str = 0;
            return 0;
         }
         else
         {
            *str = buff;
            str++;
         }
      }
      else
      { 
         /* If no eol is defined then string is [a..z][A..Z][0..9] */
         if (buff == '\"')
         {
            continue;
         }

         if ((isalnum(buff) != 0) ||
            ((unsigned char) buff > 127) ||
            (buff == '-' ) ||
            (buff == '+' ) ||
            (buff == '*' ) ||
            (buff == '^' ) ||
            (buff == '%' ) ||
            (buff == '@' ) ||
            (buff == ':' ) ||
            (buff == ';' ) ||
            (buff == '|' ) ||
            (buff == '`' ) ||
            (buff == '~' ) ||
            (buff == '_' ) ||
            (buff == ',' ) ||
            (buff == '&' ) ||
            (buff == '$' ) ||
            (buff == '#' ) ||
            (buff == '\\' ) ||
            (buff == '\'' ) ||
            (buff == '[' ) ||
            (buff == ']' ) ||
            (buff == '(' ) ||
            (buff == ')' ) ||
            (buff == '{' ) ||
            (buff == '}' ) ||
            ((buff == ' ' ) && is_tag_value) ||
            ((buff == '?' ) && is_tag_value) ||
            ((buff == '!' ) && is_tag_value) ||
            (buff == '.' ))
         {
            *str = buff;
            str++;
         }
         else
         {
#ifndef CFG_USE_CACHE
            /* Step back one byte */
            fseek(mHandle, -1, SEEK_CUR);
#else
            mpFileCursor --;
#endif
            *str = 0;            
            return 0;
         }
      }
   }
   
   return -1;
}

void XmlParser::gotoEndOfTag()
{
   char buff;
   int tagCount = 1;
#ifndef CFG_USE_CACHE
   while (0 >= fread(&buff, sizeof(buff), 1, mHandle) > 0)
   {
#else
   while (mpFileCursor < mpEOF)
   {
      buff = *mpFileCursor;
      mpFileCursor++;
#endif
      if (buff == '>')
      {
         tagCount--;
      }
      
      if (buff == '<')
      {
         tagCount++;
      }
      
      if (tagCount == 0)
      {
         return;
      }
      
      if (buff == '\n')
      {
         mLineNumber++;
         continue;
      }
   }
}

/* Get the XML tag in format
 * <name [property]... />
 * or
 * <name [property]... > [<tag>]... </name>
 */
XmlTag* XmlParser::getXmlTag()
{
   XmlTag* tag = NULL;
   int token;
   int prevToken = NO_TOKEN;
   char name[XML_MAX_TAG_NAME_LEN];
   XmlProperty* property;
   
   /* First get name of the tag */
   switch (getToken())
   {
      case INFO_TOKEN:
      {
         gotoEndOfTag();
         return NULL;
      }
      case COMMENTS_TOKEN:
      {
         break;
      }
      case START_TAG_TOKEN:
      {
         return getXmlTag();
      }
      case LETTER_TOKEN:
      {
         if (getString(name, 0, false) == -1)
         {
            return NULL;
         }
         
         tag = new XmlTag(name);
         break;
      }
      default:
      {
         return NULL;
      }
   }

   /* Now lets get the properties and embedded tags */
   while ((token = getToken()) != NO_TOKEN)
   {            
      switch (token)
      {
         case SLASH_TOKEN:
         {             
            if (prevToken == END_TAG_TOKEN)
            {           
               mpFileCursor--;              

               property = getXmlProperty();
               if (property != NULL)
               {
                  tag->addProperty(property);
               }

               break;
            }
            else
            {
               gotoEndOfTag();
               return tag;
            }
         }
         case QUOTE_TOKEN:
         {             
            if (prevToken == END_TAG_TOKEN)
            {
               mpFileCursor--;              

               property = getXmlProperty();
               if (property != NULL)
               {
                  tag->addProperty(property);
               }

               break;
            }           
         }
         case COMMENTS_TOKEN:
         {          
            break;
         }
         case END_TAG_TOKEN:
         {         
            break;
         }
         case LETTER_TOKEN:
         {
            property = getXmlProperty();
            if (property != NULL)
            {
               tag->addProperty(property);
            }

            break;
         }
         case START_TAG_TOKEN:
         {
            if (getToken() == SLASH_TOKEN)
            {
               gotoEndOfTag();
               return tag;
            }
            else
            {
               XmlTag* newtag = getXmlTag();
               
               if (newtag != NULL)
               {
                  tag->addTag(newtag);
               }
            }
            break;
         }
         default:
         {
            break;
         }
      }

      prevToken = token;
   }
   return tag;
}

void XmlParser::copyUntilEndOfTag(char* str)
{
   char buff;

#ifndef CFG_USE_CACHE
   /* Step back one byte */
   fseek(mHandle, -1, SEEK_CUR);
#else
   mpFileCursor--;
#endif

#ifndef CFG_USE_CACHE
   while (0 >= fread(&buff, sizeof(buff), 1, mHandle) > 0)
   {
#else
   while (mpFileCursor < mpEOF)
   {
      buff = *mpFileCursor;
      mpFileCursor++;
#endif
      if (buff == '<')
      {
#ifndef CFG_USE_CACHE
         /* Step back one byte */
         fseek(mHandle, -1, SEEK_CUR);
#else
         mpFileCursor--;
#endif
         *str++ = 0;
         return;
      }
      
      if (buff == '\n')
      {
         mLineNumber++;
         continue;
      }
      
      *str++ = buff;
   }
    
   *str++ = 0;
}

/* Get the XML property in format name = "data" */
XmlProperty* XmlParser::getXmlProperty()
{
   XmlProperty* prop = NULL;
   char name[XML_MAX_TAG_NAME_LEN];
   char data[XML_MAX_TAG_DATA_LEN];
   char str[XML_MAX_TAG_DATA_LEN];

   memset(name, 0, sizeof(name));
   memset(data, 0, sizeof(data));
   memset(str, 0, sizeof(str));

   int token;
   
   /* First get name of the property */
   token = getToken();

   if (token != LETTER_TOKEN && token != SLASH_TOKEN && token != QUOTE_TOKEN)
   {
      return NULL;
   }

   if (token == SLASH_TOKEN)
   {
      name[0] = '/';
   }

   if (token == QUOTE_TOKEN)
   {
      name[0] = '\"';
   }
   
   if (getString(str, 0, true) != 0)
   {
      return NULL;
   }

   strncat(name, str, XML_MAX_TAG_NAME_LEN - 1);
   memset(str, 0, sizeof(str));
   
   /* Get '=' */
   token = getToken();
   
   if (token == EQUAL_TOKEN)
   {
      /* Handle the case when property has data like <tag name="data" /> */

      /* Ignore " */
      if (getToken() == QUOTE_TOKEN)
      {
      }
      
      if ((token = getToken()) == QUOTE_TOKEN)
      {
         Safe_Strncpy(data, "", 2);
      }
      else
      {
         if ((token = getToken()) != LETTER_TOKEN)
         {
            return NULL;
         }
         
         if (getString(data, '\"', false) != 0)
         {
            return NULL;
         }
      }
      
      prop = new XmlProperty(name, data);
   }
   else
   {
      /* Handle the case when property has no data like:
         <tag>name</tag> */

/*
      if (token == LETTER_TOKEN)
      {
#ifndef CFG_USE_CACHE
            lseek(mHandle, 1, SEEK_CUR); // Step back one byte
#else
            mpFileCursor ++;
#endif
      }
*/      
      copyUntilEndOfTag(str);
      strncat(name, str, XML_MAX_TAG_NAME_LEN - 1);
      prop = new XmlProperty(name, NULL);
   }
   
   return prop;
}

int XmlParser::writeXmlFile(const char* fname, const char* additionalTags)
{
   FILE* fpHandle = fopen(fname, "w"); 
   char sInfo[64];

   if (NULL == fpHandle)
   {
      return -1;  /* Multiple returns */
   }
   else
   {
      if (additionalTags != NULL)
      {
         snprintf(sInfo, sizeof(sInfo), "<?xml version=\"%s\" encoding=\"UTF-8\"?>\n%s\n", XML_VERSION, additionalTags);
      }
      else
      {
         snprintf(sInfo, sizeof(sInfo), "<?xml version=\"%s\" encoding=\"UTF-8\"?>\n", XML_VERSION);
      }

      if (0 == fwrite(sInfo, sizeof(sInfo[0]), strlen(sInfo), fpHandle))
      {
         fclose(fpHandle);
         return -1;  /* Multiple returns */
      }

      XmlTag* tag = NULL;   
      std::vector<XmlTag*>::iterator it;
      
      for (it = mTags.begin(); it < mTags.end(); it++)
      {
         tag = *it;
         
         if (NULL != tag)
         {
            int res = tag->writeXmlFile(fpHandle, 0);

            if (res != 0)
            {
               fclose(fpHandle);
               return -1;  /* Multiple returns */
            }
         }      
      }    
         
      fclose(fpHandle);
   }
   
   return 0;   /* Multiple returns */
}

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * SCR kok_basa#38182 : Fixed Klocwork issues:
 *    - Check for file open success.
 *
 * 07-sep-2010 <name>
 * + Created initial file.
 *
\*===========================================================================*/
