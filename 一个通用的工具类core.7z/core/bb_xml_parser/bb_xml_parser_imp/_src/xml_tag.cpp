/*===========================================================================*/
/**
 * @file xml_tag.cpp
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:xml_tag.cpp~7:c++:kok_basa#1 %
 * @version %version:7 %
 * @author  %derived_by:kzyqkh %
 * @date    %date_modified:Wed Jun 13 07:06:09 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * @todo Add full description here
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include "reuse.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "string_res.h"

#include "xml_property.h"
#include "xml_tag.h"
#include "xml_parser_cfg.h"

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Class Definitions
\*===========================================================================*/

XmlTag::XmlTag(const char* name)
{
   mName = NULL;
   
   if (name)
   {
      mName = new char[strlen(name) + 1];
      Safe_Strncpy(mName, name, strlen(name) + 1);
   }
}

XmlTag::~XmlTag()
{
   clean();
}

void XmlTag::setName(const char* name)
{
   if (name)
   {
      if (mName != NULL)
      {
         delete [] mName;
      }
      
      mName = new char[strlen(name) + 1];
      Safe_Strncpy(mName, name, strlen(name) + 1);
   }
}

void XmlTag::clean()
{
   if (mName != NULL)
   {
      delete [] mName;
      mName = NULL;
   }
   
   while (!mProperties.empty())
   {
      delete mProperties.back();
      mProperties.pop_back();
   }

   while (!mTags.empty())
   {
      delete mTags.back();
      mTags.pop_back();
   }
}

int XmlTag::removeTag(const XmlTag* aTag)
{
   XmlTag* tag = NULL;   
   std::vector<XmlTag*>::iterator it;
   
   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      if (*it == aTag)
      {
         mTags.erase(it);
         delete aTag;
         return 0;
      }
   }     

   /* There is no such tag in the container try to find it in the embedded tags */
   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      tag = *it;
      
      if (tag->removeTag(aTag) == 0)
      {
         return 0;
      }
   }      
   
   return -1;
}

const char* XmlTag::getTagValue()
{
   XmlProperty* prop = NULL;
   
   if (!mProperties.empty()) 
   {
      prop = mProperties.back();
   }

   if (NULL == prop)
   {
      return NULL;
   }

   return prop->getName();
}

void XmlTag::setTagValue(char* name)
{
   XmlProperty* prop = new XmlProperty(name, NULL);

   if (NULL != prop)
   {
      mProperties.insert(mProperties.begin(), prop);

      if (mProperties.size() > 1)
      {
         prop = *(mProperties.begin() + 1);

         if (prop->getData() == NULL)
         {
            mProperties.erase(mProperties.begin() + 1);
         }
      }
   }
}

XmlTag* XmlTag::findNextTag(const char* tagName, const char* propName)
{
   XmlTag* keyTag = NULL;
   std::vector<XmlTag*>::iterator it;
   
   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      keyTag = *it;
      
      if (0 == strcmp(tagName, keyTag->getName()))
      {
         XmlProperty* prop = (XmlProperty*) keyTag->findProperty(propName);

         if (NULL != prop)
         {
            return *(it + 1);
         }
      }
   }     

   return NULL;
}

XmlTag* XmlTag::findTag(const char* tagName, const char* propName, const char* propData)
{
   if ((NULL != mName) && (strcmp(mName, tagName) == 0))
   {
      if ((propName == NULL) || (propData == NULL))
      {
         return this;
      }

      XmlProperty* prop = NULL;      
      std::vector<XmlProperty*>::iterator it;
      
      for (it = mProperties.begin(); it < mProperties.end(); it++)
      {
         prop = *it;
         
         if ((strcmp(prop->getName(), propName) == 0) &&
               (strcmp(prop->getData(), propData) == 0))
         {
            return this;
         }         
      }            
   }

   XmlTag* retTag = NULL;
   XmlTag* tag = NULL;
   std::vector<XmlTag*>::iterator it;

   for (it = mTags.begin(); it < mTags.end(); it++)
   {
      tag = *it;
      
      if ((retTag = tag->findTag(tagName, propName, propData)) != NULL)
      {
         return retTag;
      }
   }      
   
   return NULL;
}

XmlProperty* XmlTag::findProperty(const char* name)
{
   XmlProperty* prop = NULL;
   std::vector<XmlProperty*>::iterator it;
   
   for (it = mProperties.begin(); it < mProperties.end(); it++)
   {
      prop = *it;
      
      if (strcmp(prop->getName(), name) == 0)
      {
         return prop;
      }
   }         
   
   return NULL;
}

void XmlTag::updateProperty(const char* name, const char* data)
{
   XmlProperty* prop = findProperty(name);
   
   if (NULL != prop)
   {
      if (NULL != data)
      {
         prop->setProperty(NULL, data);
         return;
      }
   }
/*
   XmlProperty* prop = NULL;
   std::vector<XmlProperty*>::iterator it;
   
   for (it = mProperties.begin(); it < mProperties.end(); it++)
   {
      prop = *it;
      
      if (strcmp(prop->getName(), name) == 0)
      {
         if (NULL != data)
         {
             prop->setProperty(NULL, data);
            return;
         }
      }
   }
 */
   
   /* If no such property, add new one */   
   mProperties.push_back(new XmlProperty(name, data));
}

int XmlTag::writeXmlFile(FILE* handle, int spaces)
{
   char str[XML_MAX_TAG_DATA_LEN * 2 + 10];
   char tSpaces[1024];
   int i;
   int return_val = 0;

   if (NULL == handle)
   {
      return -1;
   }

   if (NULL == mName)
   {
      return -1;
   }

   for (i = 0; i < spaces; i++)
   {
      tSpaces[i] = ' ';
   }
   
   tSpaces[i] = 0;

   /* If tag has embedded tags */
   if (!mTags.empty())
   {
      snprintf(str, sizeof(str), "%s<%s", tSpaces, mName);            

      if (fwrite(str, sizeof(str[0]), strlen(str), handle))
      {
         XmlProperty* prop = NULL;
         std::vector<XmlProperty*>::iterator it;
   
         for (it = mProperties.begin(); it < mProperties.end(); it++)
         {
            prop = *it;            

            if ((prop->getName() != NULL) && (prop->getData() != NULL))
            {
               prop->writeXmlFile(handle);
            }
         }
            
         snprintf(str, sizeof(str), ">\n");

         if (fwrite(str, sizeof(str[0]), strlen(str), handle))
         {
            XmlTag* tag = NULL;
            std::vector<XmlTag*>::iterator itt;
   
            for (itt = mTags.begin(); itt < mTags.end(); itt++)
            {
               tag = *itt;
               tag->writeXmlFile(handle, spaces + XML_SPACE_DELTA);
            }
            
            snprintf(str, sizeof(str), "%s</%s>\n", tSpaces, mName);

            if (0 == fwrite(str, sizeof(str[0]), strlen(str), handle))
            {
               return_val = -1;
            }
         }
         else
         {
            return_val = -1;
         }
      }
      else
      {
         return_val = -1;
      }
   }
   else /* If tag has only properties, and no embedded tags */
   {
      if (mProperties.size() > 1)
      {
         snprintf(str, sizeof(str), "%s<%s", tSpaces, mName);

         if (fwrite(str, sizeof(str[0]), strlen(str), handle))
         {         
            XmlProperty* prop = NULL;
            std::vector<XmlProperty*>::iterator it;
            bool flag = false;
   
            for (it = mProperties.begin(); it < mProperties.end(); it++)
            {
               prop = *it;

               if (it == mProperties.begin())
               {
                  if (prop->getData() != NULL)
                  {
                     prop->writeXmlFile(handle);
                  }
                  else
                  {
                     /* This is TAG value, not property */
                     flag = true;
                  }
               }
               else
               {   
                  if ((prop->getName() != NULL) && (prop->getData() != NULL))
                  {
                     prop->writeXmlFile(handle);
                  }
               }
            }                  

            if (flag)
            {
               prop = *(mProperties.begin());

               if (prop->getName() != NULL)
               {
                  snprintf(str, sizeof(str), ">%s</%s>\n", prop->getName(), mName);
               }
            }
            else
            {
               snprintf(str, sizeof(str), "/>\n");
            }        
         }
         else 
         {
            return_val = -1;
         }

         if (0 == fwrite(str, sizeof(str[0]), strlen(str), handle))
         {
            return_val = -1;
         }
      }
      else if (mProperties.size() == 1)
      {
         snprintf(str, sizeof(str), "%s<%s", tSpaces, mName);

         if (fwrite(str, sizeof(str[0]), strlen(str), handle))
         {        
            XmlProperty* prop = NULL;
            std::vector<XmlProperty*>::iterator it;
            
            it = mProperties.begin();            
            prop = *it;

            if (prop->getData() != NULL)
            {
               prop->writeXmlFile(handle);
               snprintf(str, sizeof(str), "/>\n");
            }
            else
            {
               snprintf(str, sizeof(str), ">%s</%s>\n", prop->getName(), mName);
            }            
         }
         else
         {
            return_val = -1;
         }

         if (0 == fwrite(str, sizeof(str[0]), strlen(str), handle))
         {
            return_val = -1;
         }         
      }
      else
      {
         snprintf(str, sizeof(str), "%s<%s/>\n", tSpaces, mName);

         if (0 == fwrite(str, sizeof(str[0]), strlen(str), handle))
         {
            return_val = -1;
         } 
      }
   }

   return return_val;
}

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * 07-sep-2010 <name>
 * + Created initial file.
 *
\*===========================================================================*/
