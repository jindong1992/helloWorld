#ifndef XMLPARSER_H
#   define XMLPARSER_H
/*===========================================================================*/
/**
 * @file xml_parser.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:xml_parser.h~4:incl:kok_basa#3 %
 * @version %version:4 %
 * @author  %derived_by:hz1941 %
 * @date    %date_modified:Thu Feb  7 13:45:12 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * @todo Add full description here
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup xml_parser Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#   include <vector>
#   include "xml_property.h"
#   include "xml_tag.h"

/*===========================================================================*\
 * Exported Preprocessor #define Constants
\*===========================================================================*/
#define CFG_USE_CACHE (1)

/*===========================================================================*\
 * Exported Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Exported Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Exported Inline Function Definitions and #define Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Exported Class Definitions
\*===========================================================================*/

class XmlParser
{
   public:
     
      XmlParser();
      virtual ~XmlParser();

      /* Read the XML file and create the tree of the XML tags */
      int parseXmlFile(const char* fname);

      /* Write tags in to a file in XML format */
      int writeXmlFile(const char* fname, const char* additionalTags = NULL);

      const std::vector<XmlTag*>* getTags() { return &mTags; }

      /* Remove all the tags and release memory */
      void clean();

      /* Add tag */
      void addTag(XmlTag* tag) { mTags.push_back(tag); }

      /* Remove the tag from the container and release memory */
      int removeTag(const XmlTag* tag);

      /* Find the tag with the name, and given property */
      XmlTag* findTag(const char* tagName, const char* propName, const char* propData);

      enum
      {
         BEFORE_TAG,
         START_TAG,
         BODY_TAG,
         END_TAG
      };
         
   private:

      int getToken();
      int getString(char* str, int aEol, bool_t is_tag_value);
      XmlProperty* getXmlProperty();
      XmlTag* getXmlTag();
      void skipSpaces();
      void gotoEndOfTag();
      void copyUntilEndOfTag(char* str);
      XmlParser&  operator = (const XmlParser& other) { /* Do not allow copying */ return *this; }
      XmlParser(const XmlParser& other) { /* Do not allow copying */ }


#ifndef CFG_USE_CACHE
      FILE* mHandle;
#else
      char* mcFileBuff;
      char* mpFileCursor;
      char* mpEOF;
      long mFileSize;
#endif

      int mLineNumber;      
      const char* mFName;
      std::vector<XmlTag*> mTags;     
};

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * 7Feb13  David Origer
 * SCR kok_basa#38182 : Fixed Klocwork issues:
 *    - Create private copy constructor and operator= functions.
 *
 * 07-sep-2010 <name>
 * + Created initial file.
 *
\*===========================================================================*/
/** @} doxygen end group */
#endif /* XMLPARSER_H */
