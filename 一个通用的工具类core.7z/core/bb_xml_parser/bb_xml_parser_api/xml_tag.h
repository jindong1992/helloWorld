#ifndef XMLTAG_H
#   define XMLTAG_H
/*===========================================================================*/
/**
 * @file xml_tag.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:xml_tag.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:hz1941 %
 * @date    %date_modified:Thu Feb  7 13:45:15 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * @todo Add full description here
 *
 * ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#   include <vector>
#   include <stdio.h>

/*===========================================================================*\
 * Exported Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Exported Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Exported Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Exported Inline Function Definitions and #define Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Exported Class Definitions
\*===========================================================================*/

class XmlTag
{
   public:

      explicit XmlTag(const char* name = NULL);
      virtual ~XmlTag();

      void setName(const char* name);
      
      const char* getName() { return mName; }
      
      std::vector<XmlTag*>* getTags() { return &mTags; }
      std::vector<XmlProperty*>* getProperties() { return &mProperties; }
      void addTag(XmlTag* tag) { mTags.push_back(tag); }
      
      void clean();
      int removeTag(const XmlTag* tag);      
      void updateProperty(const char* name, const char* data = NULL);

      void updateProperty(XmlProperty* property)
      {
         updateProperty(property->getName(), property->getData());
      }

      void addProperty(const char* name, const char* data = NULL)
      {
         mProperties.push_back(new XmlProperty(name, data));
      }

      void addProperty(XmlProperty* property)
      {
         mProperties.push_back(property);
      }
      
      int writeXmlFile(FILE* handle, int spaces);
      XmlTag* findTag(const char* tagName, const char* propName, const char* propData);        
      XmlTag* findNextTag(const char* tagName, const char* propName);      
      XmlProperty* findProperty(const char* name);
      const char* getTagValue();
      void setTagValue(char* name);

   private:
      XmlTag&  operator = (const XmlTag& other) { /* Do not allow copying */ return *this; }
      XmlTag(const XmlTag& other) { /* Do not allow copying */ }
   
      char* mName;
      std::vector<XmlProperty*> mProperties;
      std::vector<XmlTag*> mTags;
};

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * SCR kok_basa#38182 : Fixed Klocwork issues:
 *    - Create private copy constructor and operator= functions.
 *
 * 07-sep-2010 <name>
 * + Created initial file.
 *
\*===========================================================================*/
/** @} doxygen end group */
#endif /* XMLTAG_H */
