#ifndef SIGNAL_DBG_H
#   define SIGNAL_DBG_H
/*===========================================================================*/
/**
 * @file signal_dbg.h
 *
 *   Supports debugging of signals (like SIGSEGV) thrown during code
 *   execution.
 *
 * %full_filespec:signal_dbg.h~3:incl:kok_basa#1 %
 * @version %version:3 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Sun Jan  8 16:57:38 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   This block provides an interface that can be used by a process to
 *   intercept signals and log information about them when they occur.
 *   This allows, for example, the code that caused a SIGSEGV to be
 *   identified.
 *
 * @section ABBR ABBREVIATIONS:
 *   - SIGDBG = SIGnal DeBuG
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @defgroup signal_dbg Debug process signals (like SIGSEGV)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/**
 * Type for optional callback function.
 */
typedef void (*SIGDBG_Callback_T)(int32_t signum);

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/**
 * This is called by a process to have this module substitute its signal
 * handlers for the defaults.
 *
 * @param callback Optional callback function (can be NULL) that will be called
 *                 by the signal handler just prior to re-raising the signal
 *                 (after logging information about the signal).
 * @param signal_ids Pointer to list of signal ids to be intercepted; the end
 *                   of the list must be designated by an entry with the value
 *                   of zero.
 */
void SIGDBG_Intercept_Signals(SIGDBG_Callback_T callback, int32_t const *signal_ids);

/**
 * This is called by a process to restore the signal handlers to their
 * defaults.
 */
void SIGDBG_Restore_Handlers(void);


/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file signal_dbg.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 08-jan-2012 Kirk Bailey
 *   - Made signal list an argument instead of a configuration so that each
 *     process could have a different list.
 *
 * - 05-jan-2012 Kirk Bailey
 *   - Added callback.
 *
 * - 05-jan-2012 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SIGNAL_DBG_H */
