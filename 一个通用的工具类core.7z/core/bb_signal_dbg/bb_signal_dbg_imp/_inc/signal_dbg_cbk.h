#ifndef SIGNAL_DBG_CBK_H
#   define SIGNAL_DBG_CBK_H
/*===========================================================================*/
/**
 * @file signal_dbg_cbk.h
 *
 * Defines the implementation-specific callouts and constants that must be
 * provided by another module in the system
 *
 * %full_filespec: signal_dbg_cbk.h~2:incl:kok_basa#1 %
 * @version %version: 2 %
 * @author  %derived_by: bzt837 %
 * @date    %date_modified: Mon Feb 25 12:39:19 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Isolates the implementation-specific constants and callouts so that the
 * remainder of the module can be reused without modification.
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @addtogroup signal_dbg
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <signal.h>

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*
 * Constant Objects that Must be Provided by the Application
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * Dump system/process information when terminating due to a signal.
 */
void SIGDBG_Dump(siginfo_t *info);

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file signal_dbg_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 25-Feb-2013 Chris Edgington Rev 2
 *   - Task 141682: Move SIGDBG_Dump call location and change its parameters to include signal info.
 *
 * - 10-Jul-2012 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SIGNAL_DBG_CBK_H */
