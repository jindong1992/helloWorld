/*===========================================================================*/
/**
 * @file signal_dbg.c
 *
 *   Implement logic to log signals from the OS.
 *
 * %full_filespec:signal_dbg.c~9:csrc:kok_basa#1 %
 * @version %version:9 %
 * @author  %derived_by:bzt837 %
 * @date    %date_modified:Mon Feb 25 12:39:18 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *
 * @section ABBR ABBREVIATIONS:
 *   - SIGDBG = SIGnal DeBuG
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "dbg_trace_cbk.h"
#include <errno.h>
#include "pbc_trace.h"
#include <signal.h>
#include "signal_dbg.h"
#include "signal_dbg_cbk.h"
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include "xsal.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(SIGDBG_MODULE_ID, 0); /* Identifies file for PbC/trace */

/**
 * Size of output buffer to use for forming log messages.
 */
#define SIGDBG_LOG_BUF_SZ 512

/**
 * Maximum stack callback depth to track/log.
 */
#define SIGDBG_MAX_CALL_DEPTH 32

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * Callback function called at the end of the signal handler (can be NULL).
 */
static SIGDBG_Callback_T Sig_Callback;

/**
 * Dynamically allocated list of signals intercepted by this module; will
 * be freed by a call to SIGDBG_Restore_Handlers.
 */
static int32_t *Signal_List;

/**
 * Number of signal ids in Signal_List.
 */
static size_t Num_Signals;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static char const *Get_Signal_Code_Descriptor(int signum, int code);
static void Log_Signal_Data(int signo, int code, void *bad_addr, void *instr_addr, char const *short_name);
static void Log_Signal_Info(int signal_id, siginfo_t *info, void *context);
static void Signal_Handler(int signal_id, siginfo_t *info, void *context);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/**
 * Translates a signal number and code into a description for logging.
 *
 * @return A string describing the signal/code for logging.
 *
 * @param signum The signal number.
 * @param code   The signal code that accompanied the signal.
 */
static char const *Get_Signal_Code_Descriptor(int signum, int code)
{
   char const *descr;

   switch (signum)
   {
      case SIGBUS:
         switch (code)
         {
            case BUS_ADRALN   : descr = "invalid address alignment";             break;
            case BUS_ADRERR   : descr = "nonexistent physical address";          break;
            case BUS_OBJERR   : descr = "object-specific hardware error";        break;
            default           : descr = "other";                                 break;
         }
         break;
      case SIGCHLD:
         switch (code)
         {
            case CLD_CONTINUED: descr = "stopped child has continued";           break;
            case CLD_DUMPED   : descr = "child terminated abnormally";           break;
            case CLD_EXITED   : descr = "child has exited";                      break;
            case CLD_KILLED   : descr = "child was killed";                      break;
            case CLD_STOPPED  : descr = "child has stopped";                     break;
            case CLD_TRAPPED  : descr = "traced child has trapped";              break;
            default           : descr = "other";                                 break;
         }
         break;
      case SIGFPE:
         switch (code)
         {
            case FPE_FLTDIV   : descr = "floating-point divide by zero";         break;
            case FPE_FLTINV   : descr = "floating-point invalid operation";      break;
            case FPE_FLTOVF   : descr = "floating-point overflow";               break;
            case FPE_FLTRES   : descr = "floating-point inexact result";         break;
            case FPE_FLTSUB   : descr = "subscript out of range";                break;
            case FPE_FLTUND   : descr = "floating-point underflow";              break;
            case FPE_INTDIV   : descr = "integer divide by zero";                break;
            case FPE_INTOVF   : descr = "integer overflow";                      break;
            default           : descr = "other";                                 break;
         }
         break;
      case SIGILL:
         switch (code)
         {
            case ILL_BADSTK   : descr = "internal stack error";                  break;
            case ILL_COPROC   : descr = "coprocessor error";                     break;
            case ILL_ILLADR   : descr = "illegal addressing mode";               break;
            case ILL_ILLOPC   : descr = "illegal opcode";                        break;
            case ILL_ILLOPN   : descr = "illegal operand";                       break;
            case ILL_ILLTRP   : descr = "illegal trap";                          break;
            case ILL_PRVOPC   : descr = "privileged opcode";                     break;
            case ILL_PRVREG   : descr = "privileged register";                   break;
            default           : descr = "other";                                 break;
         }
         break;
#if defined(LINUX)
      case SIGPOLL:
         switch (code)
         {
            case POLL_ERR     : descr = "i/o error";                             break;
            case POLL_HUP     : descr = "device disconnected";                   break;
            case POLL_IN      : descr = "data input available";                  break;
            case POLL_MSG     : descr = "input message available";               break;
            case POLL_OUT     : descr = "output buffers available";              break;
            case POLL_PRI     : descr = "high priority input available";         break;
            default           : descr = "other";                                 break;
         }
         break;
 #endif /* !define(WIN32) */
     case SIGSEGV:
         switch (code)
         {
            case SEGV_ACCERR  : descr = "invalid permissions for mapped object"; break;
            case SEGV_MAPERR  : descr = "address not mapped to object";          break;
            default           : descr = "other";                                 break;
         }

         break;
#if !defined(WIN32)
      case SIGTRAP:
         switch (code)
         {
            case TRAP_BRKPT   : descr = "process breakpoint";                    break;
            case TRAP_TRACE   : descr = "process trace trap";                    break;
            default           : descr = "other";                                 break;
         }
         break;
#endif /* !define(WIN32) */
       default:
         switch (code)
         {
            case SI_ASYNCIO   : descr = "AIO completed";                         break;
#if !defined(QNX_NTO)
            case SI_KERNEL    : descr = "Sent by the kernel";                    break;
#endif /* !defined(QNX_NTO) */
            case SI_MESGQ     : descr = "POSIX message queue state changed";     break;
            case SI_QUEUE     : descr = "sigqueue(2)";                           break;
#if defined(LINUX)
            case SI_SIGIO     : descr = "queued SIGIO";                          break;
#endif /* !define(WIN32) */
            case SI_TIMER     : descr = "POSIX timer expired";                   break;
#if defined(LINUX)
            case SI_TKILL     : descr = "tkill(2) or tgkill(2)";                 break;
#endif /* !define(WIN32) */
            case SI_USER      : descr = "kill(2) or raise(3)";                   break;
            default           : descr = "other";                                 break;
         }
         break;
   }

   return descr;
}

/**
 * Logs information information about which signal occurred and what the
 * instruction address was. This is available for all signals.
 *
 * @param signal_id The signal that occurred.
 * @param short_name The short version of this source file name.
 * @param instr_addr The address at which the signal occurred.
 */
static void Log_Signal_Data(int signo, int code, void *bad_addr, void *instr_addr, char const *short_name)
{
   char sigbuf[SIGDBG_LOG_BUF_SZ];

   snprintf(sigbuf, sizeof(sigbuf), "[%u] %d:%d; %s:%u; FAULT - SIGNAL #%d. Offending address: %p accessed by %p. Code %d - %s",
      (unsigned) SAL_Clock(), (int) SAL_Get_App_Id(), (int) SAL_Get_Thread_Id(), short_name, (unsigned) __LINE__,
      signo, bad_addr, instr_addr, code, Get_Signal_Code_Descriptor(signo, code));

   syslog(LOG_MAKEPRI(LOG_USER, LOG_DEBUG), "%s", sigbuf);
   printf("%s\n", sigbuf);
}

/**
 * Logs information about the signal to both syslog and the console. This
 * includes the address where the signal occurred along with a stack
 * backtrace (assuming the stack has not been corrupted).
 *
 * @param signal_id The signal that occurred.
 * @param info The signinfo_t structure from the OS containing generic
 *             signal information.
 * @param context The ucontext_t structure containing micro-specific
 *                information about the signal.
 */
static void Log_Signal_Info(int signal_id, siginfo_t *info, void *context)
{
   void *bad_addr;
   char const *fname = __FILE__;
   void *instr_addr;
   char const *short_name;
#if !defined(WIN32)
   ucontext_t *ucontext = (ucontext_t*) context;
#endif /* !defined(WIN32) */

   short_name = strrchr(fname, '/');
   if (NULL == short_name)
   {
      short_name = fname;
   }
   else
   {
      short_name++; /* skip '/' */
   }
#if   defined(WIN32)
   bad_addr   = NULL;
   instr_addr = NULL; /* Not available from Cygwin? */
#elif defined(__i386__)
   bad_addr   = info->si_addr;
   instr_addr = (void*) ucontext->uc_mcontext.gregs[REG_EIP];
#elif defined(__arm__)
   bad_addr   = info->si_addr;
#if defined(QNX_NTO)
   instr_addr = (void *) ucontext;  /* Not available from QNX ? */
#else
   instr_addr = (void*)ucontext->uc_mcontext.arm_pc;
#endif
#else
#   error need architecture support
#endif

   Log_Signal_Data(info->si_signo, info->si_code, bad_addr, instr_addr, short_name);

   Tr_Print_Stack_Backtrace();

   SIGDBG_Dump(info);
}

/**
 * This function is used as the signal handler by this module. The OS will
 * transfer control to this function when one of the signals monitored by
 * this block occurs.
 *
 * @param signal_id The signal that occurred.
 * @param info The signinfo_t structure from the OS containing generic
 *             signal information.
 * @param context The ucontext_t structure containing micro-specific
 *                information about the signal.
 */
static void Signal_Handler(int signal_id, siginfo_t *info, void *context)
{
   SIGDBG_Callback_T callback;
   /*
    * Log it.
    */
   Log_Signal_Info(signal_id, info, context);

   callback = Sig_Callback;

   if (callback != NULL)
   {
      callback(signal_id);
   }
   /*
    * Restore default signal handler and re-raise it to terminate process.
    */
   signal(signal_id, SIG_DFL);
   raise(signal_id);
}

/* =========================================================================
 *
 * Please refer to signal_dbg.h for a complete description of this function.
 *
 * ========================================================================= */
void SIGDBG_Intercept_Signals(SIGDBG_Callback_T callback, int32_t const *signal_ids)
{
   if ((Num_Signals != 0) && (signal_ids != NULL))
   {
      Tr_Fault("Attempt to intercept new signals without first restoring signal handlers");
   }
   else
   {
      /*
       * Can change just the callback on the fly by passing NULL for the signal_ids.
       */
      Sig_Callback = callback;

      if (signal_ids != NULL)
      {
         int err;
         struct sigaction new_action = { { 0 } };
         size_t signal_count = 0;
         /*
          * Count signals passed in and malloc an array to keep a copy.
          */
         while (signal_ids[signal_count] != 0)
         {
            signal_count++;
         }

         Num_Signals = signal_count;

         if (0 == signal_count)
         {
            Tr_Fault("Empty list of signals ignored.");
         }
         else
         {
            Signal_List = SAL_Alloc(signal_count * sizeof(*Signal_List));

            if (NULL == Signal_List)
            {
               Tr_Fault("Unable to allocate memory for signal list.");
               Num_Signals = 0;
            }
            else
            {
               /*
                * Copy the list and replace default signal handlers with our own.
                */
#if defined(QNX_NTO)
              new_action.sa_flags = SA_SIGINFO;
#else
              new_action.sa_flags = SA_RESTART | SA_SIGINFO;
#endif
               new_action.sa_sigaction = Signal_Handler;

               for (signal_count = 0; signal_count < Num_Signals; signal_count++)
               {
                  int32_t signum = signal_ids[signal_count];

                  Signal_List[signal_count] = signum;

                  err = sigaction(signum, &new_action, NULL);
                  if (err != 0)
                  {
                     Tr_Fault_2("sigaction failed for signal %d: %s", signum, strerror(errno));
                  }
               }
            } /* if (NULL == Signal_List) */
         } /* if (0 == signal_count) */
      }  /* if (signal_ids != NULL) */
   }
}

/* =========================================================================
 *
 * Please refer to signal_dbg.h for a complete description of this function.
 *
 * ========================================================================= */
void SIGDBG_Restore_Handlers(void)
{
   size_t i;

   Sig_Callback = NULL;

   for (i = 0; i < Num_Signals; i++)
   {
      int signum = Signal_List[i];

      signal(signum, SIG_DFL);
   }

   SAL_Free(Signal_List);
   Signal_List = NULL;
   Num_Signals = 0;
}

/*===========================================================================*/
/*!
 * @file signal_dbg.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 25-Feb-2013 Chris Edgington
 *   - Task 141682: Move SIGDBG_Dump call location and change its parameters to include signal info.
 *
 * - 06-Jun-2012 Kirk Bailey
 *   - Fixed Klockwork errors.
 *
 * - 08-jan-2012 Kirk Bailey
 *   - Refactored and added signal-specific information.
 *   - Made signal list an argument, not a configuration.
 *
 * - 05-jan-2012 Kirk Bailey
 *   - Added callback.
 *
 * - 05-jan-2012 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
