#ifndef VIRTUAL_OPERATOR_H
#   define VIRTUAL_OPERATOR_H
/*===========================================================================*/
/**
 * @file virtual_operator.h
 *
 * The virtual operator is a testing mechanism that allows simulating the
 * inputs of an operator of the radio via a scripting interface.
 *
 * %full_filespec:virtual_operator.h~kok_basa#3:incl:kok_aud#1 %
 * @version %version:kok_basa#3 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Thu Jan 28 07:49:36 2010 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   Note that the public interface defined for this module does not constrain
 *   the behavior of the implementation very much; it simple provides a means
 *   to initialize, shutdown, start, and stop the module. Refer to the
 *   implemenation for a detailed description of the behavior.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VO = Virtual Operator
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @defgroup virtual_operator Simulate Radio Operator Input
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "virtual_operator_acfg.h"
#   if !VO_HAS_ITS_OWN_THREAD /* declared in virtual_operator_acfg.h */
#      include "xsal.h"
#   endif /* VO_HAS_ITS_OWN_THREAD */

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/**
 * This function initializes the virtual operator and must be called before
 * any of its other functions are available.
 */
void VO_Initialize(void);

/*
 * If VO is not configured to have a thread, then this function must be part of
 * its public API in order to be called by the message thread that runs VO;
 * otherwise, this function is "private", meaning it is only for use inside
 * the VO logic.
 */
#if !VO_HAS_ITS_OWN_THREAD
/**
 * Process received SAL messages. This logic is broken out to facilitate C-Unit
 * testing. In this way, this function can be called directly from the test
 * suites.
 *
 * @param [in] msg Pointer to received XSAL message.
 */
void VO_Process_SAL_Message(const SAL_Message_T * msg);
#endif /* VO_HAS_ITS_OWN_THREAD */

/**
 * This function shuts down the virtual operator; after it is called, the
 * virtual operator is not available for use.
 */
void VO_Shutdown(void);

/**
 * If the virtual operator is not configured to "auto start", then this call
 * can be used to programatically start it. It can subsequently be stopped
 * via VO_Stop().
 */
void VO_Start(void);

/**
 * This call will stop the virtual operator executing commands; it can later
 * be re-started via VO_Start().
 */
void VO_Stop(void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file virtual_operator.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 27-jan-2010 Kirk Bailey
 *   - Task kok_basa 5520 - Added option for VO to not have a thread.
 *
 * - 24-jul-2009 Kirk Bailey
 *   - Task kok_aud 54853 - Added VO_Start, VO_Stop.
 *
 * - 12-jul-2009 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* VIRTUAL_OPERATOR_H */
