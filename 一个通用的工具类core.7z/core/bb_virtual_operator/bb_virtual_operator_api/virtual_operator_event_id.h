#ifndef VIRTUAL_OPERATOR_EVENT_ID_H
#   define VIRTUAL_OPERATOR_EVENT_ID_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file virtual_operator_event_id.h
 *
 *    Defines XSAL events for the virtual operator.
 *
 * %full_filespec: virtual_operator_event_id.h~3:incl:kok_aud#1 %
 * @version %version: 3 %
 * @author  %derived_by: dzq92s %
 * @date    %date_modified: Fri Jul 24 12:35:34 2009 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   These declarations must included into the xsal_event_id module to be
 *   assigned unique values within the system's event space.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VO = Virtual Operator
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup virtual_operator
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

#   define VIRTUAL_OPERATOR_PUBLISHED_EVENTS\
   SAL_PUBLISHED_EVENT(VO_EVG_STARTED, "Virtual Operator started executing script")\
   SAL_PUBLISHED_EVENT(VO_EVG_STOPPED, "Virtual Operator stopped executing script")

#   define VIRTUAL_OPERATOR_PUBLIC_EVENTS

#   define VIRTUAL_OPERATOR_PRIVATE_EVENTS\
   SAL_PRIVATE_EVENT(VO_EV_ERROR,         "Error detected during Virtual Operator execution")\
   SAL_PRIVATE_EVENT(VO_EV_NO_SCRIPT,     "Virtual Operator detected removal of script")\
   SAL_PRIVATE_EVENT(VO_EV_SCRIPT_DONE,   "Virtual Operator command script finished")\
   SAL_PRIVATE_EVENT(VO_EV_SCRIPT_FOUND,  "Virtual Operator command script found")\
   SAL_PRIVATE_EVENT(VO_EV_SHUTDOWN,      "Terminate the Virtual Operator service")\
   SAL_PRIVATE_EVENT(VO_EV_START,         "Start executing the Virtual Operator script")\
   SAL_PRIVATE_EVENT(VO_EV_STOP,          "Stop executing the Virtual Operator script")\
   SAL_PRIVATE_EVENT(VO_EV_TIMER_EXPIRED, "Virtual Operator timer event")

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
 
/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file virtual_operator_event_id.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 15-jul-2009 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIRTUAL_OPERATOR_EVENT_ID_H */
