#ifndef VIRTUAL_OPERATOR_CBK_H
#   define VIRTUAL_OPERATOR_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file virtual_operator_cbk.h
 *
 *   This file declares the callouts that are used by the Virtual Operator and
 *   which must be implemented by the system using this module.
 *
 * %full_filespec:virtual_operator_cbk.h~4:incl:kok_aud#1 %
 * @version %version:4 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Fri Jul 24 09:28:12 2009 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   Callouts are used to map the module's behavior into the desired action
 *   in the system. This provides flexibility that allows the core module to
 *   be used "as is" while customizing its use in programs.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VO = Virtual Operator
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup virtual_operator
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include "virtual_operator_cfg.h"
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

#   undef VO_KEY
#   define VO_KEY(tag,name) tag,

/**
 * Assigns numeric values to the keys in the system based on the
 * configuration's VO_KEYS X MACRO declaration.
 */
typedef enum VO_Key_Id_Tag
{
   VO_KEYS
   VO_NUMBER_OF_KEYS
}
VO_Key_Id_T;

#   undef VO_KNOB
#   define VO_KNOB(tag,name) tag,

/**
 * Assigns numeric values to the knobs in the system based on the
 * configuration's VO_KNOBS X MACRO declaration.
 */
typedef enum VO_Knob_Id_Tag
{
   VO_KNOBS
   VO_NUMBER_OF_KNOBS
}
VO_Knob_Id_T;
               
/*===========================================================================*
 * Exported const object prototypes that must be defined by the system
 *===========================================================================*/

/**
 * Provides an optional pointer to an internal script. If not used, the value
 * will be NULL. If non-NULL, it must point to a NULL terminated sequence of
 * const pointers to const char. Each of these strings define a command to
 * be executed.
 */
extern char const * const * const VO_Internal_Script;

/**
 * The SAL queue size for the Virtual Operator thread. This constant must
 * be configured by the system using the module.
 */
extern const size_t VO_Msg_Thread_Queue_Size;

               
/*===========================================================================*
 * Exported function prototypes that must be defined by the system
 *===========================================================================*/

/**
 * Signal to the system that the Virual Operator is operational.
 */
void VO_Activated(void);

/**
 * Obtain the attributes to be used for the Virtual Operator's thread.
 *
 * @param [out] thread_attr pointer to the location into which the
 *                          thread attribute is to be placed.
 */
void VO_Get_Msg_Thread_Attr(SAL_Thread_Attr_T *thread_attr);

/**
 * Simulate the pressing of a hard key. 
 *
 * @param [in] key_id Identifies which key is pressed.
 */
void VO_Press_Key(VO_Key_Id_T key_id);

/**
 * Simulate the releasing of a hard key. 
 *
 * @param [in] key_id Identifies which key is released.
 */
void VO_Release_Key(VO_Key_Id_T key_id);

/**
 * Signal that the Virual Operator task is terminating.
 */
void VO_Terminated(void);

/**
 * Simulate the touch of the screen at coordinates (x, y); negative values for
 * either coordinate indicate a "release" of the screen. 
 *
 * @param [in] x - x coordinate of touch (number of pixels from left)
 * @param [in] y - y coordinate of touch (number of pixels from top)
 */
void VO_Touch_Screen(int16_t x, int16_t y);

/**
 * Simulate the turning of a knob.
 *
 * @param [in] knob_id Identifies which knob is turned.
 * @param [in] clicks Magnitude and direction of turn; positive values are
 *                    clockwise, negative values are counterclockwise.
 */
void VO_Turn_Knob(VO_Knob_Id_T knob_id, int16_t clicks);

/*===========================================================================*/
/*!
 * @file virtual_operator_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 24-jul-2009 Kirk Bailey
 *   - Task kok_aud 54853 - Updated comments.
 *
 * - 12-jul-2009 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIRTUAL_OPERATOR_CBK_H */
