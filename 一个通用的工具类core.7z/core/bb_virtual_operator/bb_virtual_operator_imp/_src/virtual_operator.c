/*===========================================================================*/
/**
 * @file virtual_operator.c
 *
 *   This file implements the message thread for the virtual operator.
 *
 * %full_filespec:virtual_operator.c~kok_basa#10:csrc:kok_aud#1 %
 * @version %version:kok_basa#10 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Mon Jul 26 10:08:28 2010 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   For a description of the behavior of the Virtual Operator, please refer to
 *   virtual_operator_hsm.c.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VO = Virtual Operator
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup virtual_operator
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "virtual_operator.h"
#include "virtual_operator_cbk.h"
#include "virtual_operator_private.h"
#include "xsal_util.h"

#if VO_HAS_ITS_OWN_THREAD /* Only use SOH if VO has a thread */
#   include "state_of_health.h"
#endif /* VO_HAS_ITS_OWN_THREAD */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#undef EM_F_ID
#define EM_F_ID EM_FILE_ID(VO_MODULE_ID, 0) /**< Identifies file for PbC/trace */

#if VO_HAS_ITS_OWN_THREAD /* The following only apply if VO has a thread */
/*vvvvvvvvvvvvvvvvvvvvvvvvvvvvv*/

/** Maximum received data size */
#   define VO_MSG_DATA_SIZE  4

/** Maximum time between SOH calls before triggering a fault */
#   define VO_SOH_TIMEOUT_MS (3*VO_WAIT_TIME_MS)

/** Timeout waiting for a message. */
#   define VO_WAIT_TIME_MS 1000

/*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/
#endif /* VO_HAS_ITS_OWN_THREAD */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/**
 * Performs the VO initialization logic that is common to both the threaded
 * and non-threaded builds of VO.
 */
static void Do_Init(void)
{
   vo_Start_HSM(); /* Start statemachine, transition to first state. */
   VO_Activated(); /* Let the system know that VO is now operational */
}

/**
 * Performs the VO shutdown logic that is common to both the threaded
 * and non-threaded builds of VO.
 */
static void Do_Shutdown(void)
{
   vo_Shutdown_HSM(); /* Perform any shutdown cleanup */
   VO_Terminated();   /* Let the system know that VO is terminating */
}

#if VO_HAS_ITS_OWN_THREAD
/**
 * This is the message loop for the virtual operator.
 *
 * @param [in] arg  Not used
 */
static void Virtual_Operator_Msg_Thread(void *arg)
{
   bool_t is_ok;
   bool_t perform_shutdown = false;

   Tr_Info_Lo("Virtual Operator Message Thread: started");

   is_ok = SAL_Create_Queue(VO_Msg_Thread_Queue_Size, VO_MSG_DATA_SIZE, SAL_Alloc, SAL_Free);
   PBC_Ensure(is_ok, "SAL_Create_Queue() failed");

   Do_Init();

   SAL_Signal_Ready();
   SOH_Register(VO_SOH_TIMEOUT_MS);

   while (!perform_shutdown)
   {
      SAL_Message_T const *msg;

      msg = SAL_Receive_Timeout(VO_WAIT_TIME_MS);

      if (msg != NULL) /* not a timeout */
      {
         if (VO_EV_SHUTDOWN == msg->event_id)
         {
            perform_shutdown = true;
         }
         else
         {
            VO_Process_SAL_Message(msg);
         }
      }

      SOH_Alive(VO_SOH_TIMEOUT_MS);

   } /* while (!perform_shutdown) */

   SOH_Dormant();
   Do_Shutdown();
   Tr_Info_Lo("Virtual Operator Message Thread: exiting");
}
#endif /* VO_HAS_ITS_OWN_THREAD */

/* =========================================================================
 * 
 * Please refer to the description in virtual_operator.h.
 *
 * =========================================================================*/
void VO_Initialize(void)
{
#if VO_HAS_ITS_OWN_THREAD
   SAL_Thread_Attr_T thread_attributes;
   SAL_Thread_Id_T thread_id;

   VO_Get_Msg_Thread_Attr(&thread_attributes);

   thread_id = SAL_Create_Thread(Virtual_Operator_Msg_Thread, NULL, &thread_attributes);
   PBC_Ensure_1((VO_MSG_THREAD_ID == thread_id), "SAL_Create_Thread() failed: %d", (int)thread_id);
#else
   Do_Init();
#endif /* VO_HAS_ITS_OWN_THREAD */
}

/* =========================================================================
 * 
 * Please refer to the description in virtual_operator.h.
 *
 * =========================================================================*/
void VO_Shutdown(void)
{
#if VO_HAS_ITS_OWN_THREAD
   SAL_Send(VO_APP_ID, VO_MSG_THREAD_ID, VO_EV_SHUTDOWN, NULL, 0); 
#else
   Do_Shutdown();
#endif /* VO_HAS_ITS_OWN_THREAD */
}

/*===========================================================================*/
/*!
 * @file virtual_operator.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 26-Jul-2010 Kirk Bailey Rev 10
 *   - Replaced "bool" with "bool_t".
 *
 * - 27-jan-2010 Kirk Bailey
 *   - Task kok_basa 8083 - Removed SAL_End_Thread() during IT33 tip off.
 *
 * - 27-jan-2010 Kirk Bailey
 *   - Task kok_basa 5520 - Added option for VO to not have a thread.
 *
 * - 11-jan-2010 Kirk Bailey
 *   - Task kok_basa 4904 - Added shutdown call to destroy HSM's timer.
 *
 * - 30-sep-2009 Kirk Bailey
 *   - Task kok_aud 57700 - Added SAL_End_Thread() call.
 *
 * - 17-aug-2009 Kirk Bailey
 *   - Task kok_aud 55616 - Fixed SOH at shutdown.
 *
 * - 24-jul-2009 Kirk Bailey
 *   - Task kok_aud 54853 - Updated comments.
 *
 * - 12-jul-2009 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
