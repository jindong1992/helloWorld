#ifndef VIRTUAL_OPERATOR_PRIVATE_H
#   define VIRTUAL_OPERATOR_PRIVATE_H
/*===========================================================================*/
/**
 * @file virtual_operator_private.h
 *
 *   Declares types and functions shared between the multiple files that
 *   implement the Virtual Operator.
 *
 * %full_filespec:virtual_operator_private.h~kok_basa#6:incl:kok_aud#1 %
 * @version %version:kok_basa#6 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Mon Jul 26 10:10:15 2010 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @section ABBR ABBREVIATIONS:
 *   - VO = Virtual Operator
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup virtual_operator
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include "hsm_engine.h"
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/**
 * Maximum length of a command line that is supported from a script file.
 */
#   define VO_MAX_LINE_LENGTH 128

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/**
 * This declares the data structure that contains all of the data associated
 * with an instance of a Virtual Operator.
 */
typedef struct VO_Data_Tag
{
   size_t command_index;   /**< index of next command to execute */
   long int file_offset;   /**< offset into command file of next place to read */
   HSM_Statechart_T hsm;   /**< statechart that controls the object */
   size_t repeat_index;    /**< index of command at which to begin repeat sequence */
   long int repeat_offset; /**< file offset of first command in repeat sequence */
   bool_t running_internal_script; /**< true if an internal script is running. */
   SAL_Timer_Id_T timer_id;      /**< ID of XSAL timer used for VO delay events */
   char buf[VO_MAX_LINE_LENGTH]; /**< buffer used to read commands from a file */
}
VO_Data_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*
 * If VO is not configured to have a thread, then this function must be part of
 * its public API in order to be called by the message thread that runs VO;
 * otherwise, this function is "private", meaning it is only for use inside
 * the VO logic.
 */
#if VO_HAS_ITS_OWN_THREAD
/**
 * Process received SAL messages. This logic is broken out to facilitate C-Unit
 * testing. In this way, this function can be called directly from the test
 * suites.
 *
 * @param [in] msg Pointer to received XSAL message.
 */
void VO_Process_SAL_Message(const SAL_Message_T * msg);
#endif /* !VO_HAS_ITS_OWN_THREAD */

/**
 * Perform any shutdown required for the Virtual Operator HSM.
 */
void vo_Shutdown_HSM(void);

/**
 * Initialize the Virtual Operator object and launch its statechart.
 */
void vo_Start_HSM(void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file virtual_operator_private.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 26-Jul-2010 Kirk Bailey Rev 6
 *   - Replaced "bool" with "bool_t".
 *
 * - 27-jan-2010 Kirk Bailey
 *   - Task kok_basa 5520 - Added option for VO to not have a thread.
 *
 * - 11-jan-2010 Kirk Bailey
 *   - Task kok_basa 4904 - Added shutdown call to destroy HSM's timer.
 *
 * - 24-jul-2009 Kirk Bailey
 *   - Task kok_aud 54853 - Updated comments.
 *
 * - 12-jul-2009 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* VIRTUAL_OPERATOR_PRIVATE_H */
