#ifndef PITS_PROCESSING_AUDIO_H
#   define PITS_PROCESSING_AUDIO_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_processing_audio.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_processing_audio.h~1:incl:ctc_ec#23 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:36 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_processing_audio Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_audio_set_fade_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_balance_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_tone_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_mute_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_volume_diag_req(const PITS_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Process_Set_Fade
 *===========================================================================*
 * @brief Set Fade values to linear position
 *
 * @returns process_data
 *
 * @param [in] data
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Process_Set_Fade(uint8_t  data);

/*===========================================================================*
 * FUNCTION: PITS_Process_Set_Balance
 *===========================================================================*
 * @brief Set Balance values to linear position
 *
 * @returns process_data
 *
 * @param [in] data
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Process_Set_Balance(uint8_t  data);
/*===========================================================================*/
/*!
 * @file pits_processing_audio.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 5
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 4
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 1-May-2012 Darinka Lopez  Rev 3
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 29 Mar 2012 Miguel Garcia Rev 2
 * Include Pits process set Fade, Balance
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_PROCESSING_AUDIO_H */
