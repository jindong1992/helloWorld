#ifndef PITS_PROCESSING_WIFI_H
#   define PITS_PROCESSING_WIFI_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_processing_wifi.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_processing_wifi.h~2:incl:ctc_ec#20 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Thu Jun 23 17:09:26 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_processing_wifi Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <sys/stat.h>
#include "pits_wifi_services.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
/* sys/stat.h */
#ifdef __ARMCC_VERSION
typedef long  off_t;
typedef unsigned long int dev_t;
typedef unsigned long int ino_t;
typedef unsigned int      mode_t;
typedef unsigned int      nlink_t;
typedef unsigned int      uid_t;
typedef unsigned int      gid_t;
typedef long int          blkcnt_t;
typedef long int          blksize_t;

struct stat {
    dev_t     st_dev;
    ino_t     st_ino;
    mode_t    st_mode;
    nlink_t   st_nlink;
    uid_t     st_uid;
    gid_t     st_gid;
    dev_t     st_rdev;
    off_t     st_size;
    blksize_t st_blksize;
    blkcnt_t  st_blocks;
    time_t    st_atime;
    time_t    st_mtime;
    time_t    st_ctime;
};

#else
struct stat;
#endif

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Begin_Wifi_Test_In_Processing
 *===========================================================================*
 * @brief set begin wifi test status in processing
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Test_In_Processing(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Begin_Wifi_Test_Status
 *===========================================================================*
 * @brief return begin wifi test status
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
PITS_WIFI_STATUS_ENUM_T PITS_Get_Wifi_Test_Status(void);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Set_Mac_Addr
 *===========================================================================*
 * @brief set wifi mac address to client
 *
 * @returns void
 *
 * @param [in] Mac address
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
bool_t PITS_WIFI_Set_Mac_Addr(uint8_t *mac);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Get_Mac_Addr
 *===========================================================================*
 * @brief return wifi mac address
 *
 * @returns success or fail
 *
 * @param [in] mac address
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
bool PITS_WIFI_Get_Mac_Addr(uint8_t * mac);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Get_Coex_Pin_Status
 *===========================================================================*
 * @brief return wifi coex pin status
 *
 * @returns success or fail
 *
 * @param [in] mac address
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
bool PITS_WIFI_Get_Coex_Pin_Status(uint8_t * Pin_status);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Save_Carrier_Channel
 *===========================================================================*
 * @brief Save Carrier Channel
 *
 * @returns void
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_WIFI_Save_Carrier_Channel(uint16_t Carrier_Channel);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Get_Carrier_Channel
 *===========================================================================*
 * @brief return Carrier Channel
 *
 * @returns Wifi Carrier Channel
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
uint16_t PITS_WIFI_Get_Carrier_Channel(void);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Save_Final_XtalTrim
 *===========================================================================*
 * @brief save wifi Final Xtal Trim value
 *
 * @returns void
 *
 * @param [in] Wifi xtal trim
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
bool PITS_WIFI_Save_Final_XtalTrim(uint8_t Final_XtalTrim);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Save_XtalTrim
 *===========================================================================*
 * @brief save wifi Xtal Trim value
 *
 * @returns void
 *
 * @param [in] Wifi xtal trim
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_WIFI_Save_XtalTrim(uint8_t XtalTrim);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Connect_In_Processing
 *===========================================================================*
 * @brief set wifi connect status in processing
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Connect_In_Processing(void);

/*===========================================================================*
 * FUNCTION: PITS_WIFI_Get_XtalTrim
 *===========================================================================*
 * @brief return wifi Xtal Trim value
 *
 * @returns Wifi xtal trim
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
uint16_t PITS_WIFI_Get_XtalTrim(void);

bool PITS_WIFI_Get_Final_XtalTrim(uint8_t * Final_XtalTrim);

/*===========================================================================*
 * FUNCTION: PITS_Get_Wifi_Connect_Status
 *===========================================================================*
 * @brief return wifi connect status
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
PITS_WIFI_CONN_STATUS_ENUM_T PITS_Get_Wifi_Connect_Status(void);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Current_Level
 *===========================================================================*
 * @brief return current wifi signal level
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern int16_t PITS_Wifi_Get_Current_Level(void);

/*===========================================================================*
 * FUNCTION: PTIS_Wifi_Save_Signal_info
 *===========================================================================*
 * @brief Save WIFI Signal information
 *
 * @returns void
 *
 * @param [in] data, length
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PTIS_Wifi_Save_Signal_info(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Current_PER
 *===========================================================================*
 * @brief return wifi current PER
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern float PITS_Wifi_Get_Current_PER(void);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Average_PER
 *===========================================================================*
 * @brief return wifi average PER
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern float PITS_Wifi_Get_Average_PER(void);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Clear_Current_Packet_Number
 *===========================================================================*
 * @brief calculate current wifi signal total bad packet number
 *
 * @returns void
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Clear_Current_Packet_Number(void);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Current_Packet_Number
 *===========================================================================*
 * @brief return current wifi signal total packet number
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
uint32_t PITS_Wifi_Get_Current_Packet_Number(void);

/*===========================================================================*
 * FUNCTION: PITS_Begin_Wifi_Test_Success
 *===========================================================================*
 * @brief set begin wifi test status success
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Begin_Wifi_Test_Success(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Test_Failure
 *===========================================================================*
 * @brief set begin wifi test status failure
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Test_Failure(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Stop_Wifi_Test_Success
 *===========================================================================*
 * @brief set stop wifi test status success
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Stop_Wifi_Test_Success(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Connect_Success
 *===========================================================================*
 * @brief set wifi connect status success
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Connect_Success(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Connect_Failure
 *===========================================================================*
 * @brief set wifi connect status failure
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Connect_Failure(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Disconnect_Success
 *===========================================================================*
 * @brief set wifi disconnect status success
 *
 * @returns process_data
 *
 * @param [in] void
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Wifi_Disconnect_Success(const uint8_t * data, size_t length);



/*===========================================================================*/
/*!
 * @file pits_processing_wifi.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 2
 * ctc_ec#156415: Remove build warnings.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_PROCESSING_WIFI_H */
