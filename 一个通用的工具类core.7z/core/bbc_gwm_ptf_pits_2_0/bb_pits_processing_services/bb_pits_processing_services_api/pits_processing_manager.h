#ifndef PITS_PROCESSING_MANAGER_H
#   define PITS_PROCESSING_MANAGER_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_processing_manager.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_processing_manager.h~1:incl:ctc_ec#23 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:59 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_processing_manager Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/**
 * PITS_Get_Partition_Status - Gets Current Partition Status.
 *
 * @param partition
 *
 * @return uint8_t   status
 */
extern uint8_t PITS_Get_Partition_Status(uint8_t partition);

/**
 * PITS_Set_Partition_Status - Sets Partition status.
 *
 * @param partition and status
 *
 * @return none
 */
extern void PITS_Set_Partition_Status(uint8_t partition, uint8_t enable);

/*===========================================================================*/
/*!
 * @file pits_processing_manager.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 04-Jul-2012   Oscar Vega Rev 2
 * Task kok_basa#106084: 2_0 - MID 1E/1F - Request/Report  to Unlock and Lock Data Partition
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_PROCESSING_MANAGER_H */
