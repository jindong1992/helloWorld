#ifndef PITS_PROCESSING_FILESYS_H
#   define PITS_PROCESSING_FILESYS_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_processing_filesys.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_processing_filesys.h~1:incl:ctc_ec#23 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:52 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_processing_filesys Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_filesys_services.h"
#include "source_manager.h"
#include "playback_plugin_engine_event_types.h"
#include "playback_plugin_engine_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern  SSM_Source_T pits_source;
extern PPE_Instance_Id_T pits_instanced_id;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: Pits_Msd_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Msd_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Mtp_Connected_Status
 *===========================================================================*
* @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Mtp_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Ipod_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Ipod_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Filesys_Get_Elapsed_Time
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Elapsed Time
 *
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Filesys_Get_Elapsed_Time (const uint8_t * data, uint16_t length);
extern void Pits_Get_File_Track_Info (const uint8_t * data, size_t length);
extern bool_t Pits_Filesys_Get_Authentication_Status (uint8_t device);
extern void Pits_Set_Ipod_Aut_Failure (const uint8_t * data, size_t length);
extern void Pits_Unsupported_Device_Inserted (const uint8_t * data, size_t length);
extern void pits_filesys_process_status_req(void);
extern uint8_t pits_filesys_process_get_device_type (void);
extern uint8_t pits_filesys_process_get_device_connected (void);
extern void pits_filesys_process_get_position_req (PITS_FILESYS_Pos_T * pit_get_position);
extern Done_Or_Not_Done_T pits_filesys_set_diag_position_req(const PITS_Message_T * message);
/*===========================================================================*/
/*!
 * @file pits_processing_filesys.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 4
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Jul-2012 Miguel Garcia  Rev 3
 * Task kok_basa#112058: PITS: Update Pits filesys services
 * Update PITS_FILESYS_Pos_T
 *
 * 11 Jun 2012 Miguel Garcia Rev 2
 * Include ICR filsys functions in processing services
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_PROCESSING_FILESYS_H */
