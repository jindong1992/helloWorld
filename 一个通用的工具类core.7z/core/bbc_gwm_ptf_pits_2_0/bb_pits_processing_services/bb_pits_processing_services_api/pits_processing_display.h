#ifndef PITS_PROCESSING_DISPLAY_H
#   define PITS_PROCESSING_DISPLAY_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_processing_display.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_processing_display.h~1:incl:ctc_ec#23 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:47 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_processing_display Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
 #if defined FORD_C490
/*===========================================================================*
 * FUNCTION: PITS_Get_Screen_Check_Override_Status
 *===========================================================================*
 * @brief get display override status from screen check module 
 * @returns none
 * @param [in] 
 */
/*===========================================================================*/
uint8_t PITS_Get_Screen_Check_Override_Status (void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Screen_Check_Pattern_Status
 *===========================================================================*
 * @brief get display pattern status from screen check module 
 * @returns none
 * @param [in] 
 */
/*===========================================================================*/
uint8_t PITS_Get_Screen_Check_Pattern_Status (void);

/*===========================================================================*
 * FUNCTION: PITS_Wait_Screen_Check_replay
 *===========================================================================*
 * @brief send change pic request and return status from screen check module 
 * @returns none
 * @param [in] 
 */
/*===========================================================================*/
bool PITS_Wait_Screen_Check_replay (uint8_t Req);
#endif

#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
uint8_t PITS_Disp_Get_Faceplat_Dim();
#endif

/*===========================================================================*/
/*!
 * @file pits_processing_display.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_PROCESSING_DISPLAY_H */
