/*===========================================================================*/
/**
 * @file pits_processing_filesys.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_filesys.c~2:csrc:ctc_ec#22 %
 * @version %version:2 %
 * @author  %derived_by:rznbk1 %
 * @date    %date_modified: Thu Jun 23 09:30:03 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "app_header.h"
#include "em.h"
#include "pits_filesys_services.h"
#include "pits_filesys_services_cbk.h"
#include "pits_processing_filesys.h"
#include "playback_plugin_engine_types.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"


EM_FILENUM(PITS_MODULE_ID_5, 34);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MAX_CD_ELAPSED_TIME_SECONDS    5999

#define PIT_MTP_MSD_DETECTED 1
#define PIT_IPOD_DETECTED 2
#define PIT_SD_DETECTED 3
#define PIT_SD_USB_DETECTED 4
#define PIT_SD_IPOD_DETECTED 5
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
static void pits_filesys_process_compose_header(uint8_t mid, uint8_t size);

static uint8_t filesysp_tx_bus_id;
static PITS_Message_T filesysp_message;
static uint8_t filesysp_tx_data[PITS_MAX_MESSAGE_SIZE];
static PITS_DEVICE_ID_T pits_devices_status = PITS_UNUSED;
static bool_t pits_enable_msd = false;
static bool_t pits_enable_mtp = false;
static bool_t pits_enable_ipod = false;
static bool_t pits_enable_sd = false;
static bool_t pits_usb_connected = false;
static bool_t pits_ipod_connected = false;
static bool_t pits_sd_connected = false;
static uint8_t pit_time_filesys[16];
static bool_t pits_device_present = false;
static bool_t pits_autentification_msd = false;
static bool_t pits_autentification_mtp = false;
static bool_t pits_autentification_ipod = false;
static bool_t pits_autentification_sd = false;
static uint8_t pits_title_length = 0;
static char pits_title[120];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
 SSM_Source_T pits_source;
PPE_Instance_Id_T pits_instanced_id;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
static void pits_filesys_process_compose_header(uint8_t mid, uint8_t size)
{
   filesysp_message.bus = filesysp_tx_bus_id;
   filesysp_message.data = filesysp_tx_data;
   filesysp_message.MSID = MSID_FILESYS_SERVICES;
   filesysp_message.MID = mid;
   filesysp_message.data_size = size;
   memset(filesysp_tx_data, 0x00, size);
}

void pits_filesys_process_status_req(void)
{

    if (pits_usb_connected)
    {
        pits_devices_status = PITS_USB_DEVICE;
       if((pits_usb_connected)&&(pits_sd_connected))
       {
           pits_devices_status = PITS_SD_USB_DEVICE;
       } 
    }
   else if (pits_ipod_connected)
    {
        pits_devices_status = PITS_IPOD_DEVICE;
        if((pits_ipod_connected)&&(pits_sd_connected))
        {
           pits_devices_status = PITS_SD_IPOD_DEVICE;
        }
     }
    else if(pits_sd_connected)
    {
         pits_devices_status = PITS_SD_DEVICE;
    }
    else
      {
       pits_devices_status  =PITS_UNUSED;

      }
}

uint8_t pits_filesys_process_get_device_type (void)
{
   return (pits_devices_status);
}

uint8_t pits_filesys_process_get_device_connected (void)
{

   return (pits_device_present);
}
void pits_filesys_process_get_position_req (PITS_FILESYS_Pos_T * pit_get_position)
{
   uint32_t new_time_elap = 0;
   uint32_t  pit_seconds;
   uint8_t   pit_minutes;
   uint8_t   pit_out_sec;
   uint32_t   pit_time_rpt12 = pit_time_filesys[12];
   uint32_t   pit_time_rpt13 = pit_time_filesys[13];
   uint32_t   pit_time_rpt14 = pit_time_filesys[14];
   uint32_t   pit_time_rpt15 = pit_time_filesys[15];

   new_time_elap = pit_time_rpt12 + ((pit_time_rpt13 & 0x000000FF)<<8) + ((pit_time_rpt14 & 0x000000FF)<<16) + ((pit_time_rpt15 & 0x000000FF)<<24);
   pit_seconds = new_time_elap / 0x3E8;
   pit_out_sec = pit_seconds % 60;
   pit_minutes = (pit_seconds / 60) % 60;

   if (pits_device_present)
   {
   
      pit_get_position->minutes = (uint8_t) Hex_To_BCD(pit_minutes, 2);
      pit_get_position->seconds = (uint8_t) Hex_To_BCD(pit_out_sec, 2);
      pit_get_position->name_length = pits_title_length;
      memcpy(&pit_get_position->title_name[0], &pits_title[0],pits_title_length);
      
   }

}

Done_Or_Not_Done_T pits_filesys_set_diag_position_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      filesysp_tx_bus_id = message->bus;
      pits_filesys_process_compose_header(MID_FILESYS_MEDIA_POSITION_SET_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         filesysp_tx_data[0] = (uint8_t) SUCCESS;
         filesysp_tx_data[1] = 1;
         filesysp_tx_data[2] = pits_title_length; /* title length*/
         filesysp_message.data_size = 3 + pits_title_length;
         memcpy(&filesysp_tx_data[3], &pits_title[0],pits_title_length);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&filesysp_message);                      
      }
   }

   return (pits_status);

}
void Pits_Msd_Connected_Status(const uint8_t * data, size_t length)
{
   pits_enable_msd = data[0];
   pits_usb_connected = false;
   pits_ipod_connected = false;
   pits_autentification_mtp = false;
   pits_autentification_ipod = false;
   if (pits_enable_msd)
   {
      pits_usb_connected = true;
      pits_device_present = true;
      pits_autentification_msd = true;
   }
   else
   {
      pits_device_present = false;
      pits_autentification_msd = false;
   }
}
void Pits_Sd_Connected_Status(const uint8_t * data, size_t length)
{
   pits_enable_sd = data[0];
   pits_sd_connected = false;
   pits_autentification_sd = false;
   if (pits_enable_sd)
   {
      pits_sd_connected = true;
      pits_device_present = true;
      pits_autentification_sd = true;
      
   }
   else
   {
      pits_device_present = false;
      pits_autentification_sd = false;
   }
}

void Pits_Mtp_Connected_Status(const uint8_t * data, size_t length)
{
   pits_enable_mtp = data[0];
   pits_usb_connected = false;
   pits_ipod_connected = false;
   pits_autentification_msd = false;
   pits_autentification_ipod = false;
   if (pits_enable_mtp)
   {
      pits_usb_connected = true;
      pits_device_present = true;
      pits_autentification_mtp = true;
   }
   else
   {
      pits_device_present = false;
      pits_autentification_mtp = false;
   }
}

void Pits_Ipod_Connected_Status(const uint8_t * data, size_t length)
{
   pits_enable_ipod = data[0];
   pits_ipod_connected = false;
   pits_usb_connected = false;
   pits_autentification_msd = false;
   pits_autentification_mtp = false;
   if (pits_enable_ipod)
   {
       pits_ipod_connected = true;
      pits_device_present = true;
      pits_autentification_ipod = true;
   }
   else
   {
      pits_device_present = false;
      pits_autentification_ipod = false;
   }
}

extern bool_t Pits_Filesys_Get_Authentication_Status (uint8_t device)
   {
      bool_t status = false;
   
      if (device == 1)
      {
         if ((pits_autentification_msd)||(pits_autentification_mtp))
         {
            status = pits_autentification_msd;
         }
      }
      if (device == 2)
      {
         status = pits_autentification_ipod;
      }
      if (device == 3)
      {
         status = pits_autentification_sd;
      }
      return (status);
   }

void Pits_Set_Ipod_Aut_Failure (const uint8_t * data, size_t length)
{
   pits_autentification_ipod = false;
}

void Pits_Unsupported_Device_Inserted (const uint8_t * data, size_t length)
{
   pits_autentification_ipod = false;
   pits_autentification_msd = false;
   pits_autentification_mtp = false;
}

void Pits_Filesys_Get_Elapsed_Time(const uint8_t * data, uint16_t length)
{
   memcpy(&pit_time_filesys[0],&data[0],16);
}

extern void Pits_Get_File_Track_Info (const uint8_t * data, size_t length)
{
   BDB_T bdb;
   SSM_Source_T source;
   PPE_Instance_Id_T instance_id;
   char const* title = NULL;
   char const* artist;
   PPE_File_Type_T file_type;


   if (NULL  != (data))
   {
      BDB_Populate(&bdb, data, length);
      BDB_Read_Bytes(&bdb, &source, sizeof(source));
      instance_id = BDB_Read_U32(&bdb);
      title = BDB_Read_P_String(&bdb);
      if (title)
      {
         artist = BDB_Read_P_String(&bdb);
         (void) BDB_Read_P_String(&bdb); /* Album */
         (void) BDB_Read_U32(&bdb);  /* total time */
         file_type = (PPE_File_Type_T) BDB_Read_U32(&bdb);
         UNUSED_PARAM(instance_id);
         UNUSED_PARAM(artist);
         UNUSED_PARAM(file_type);
      }
   }

   if (title)
   {
      pits_title_length = strlen(title);
      Safe_Strncpy(&pits_title[0],title, sizeof(pits_title));      
   }
}

void Pits_USB_Device_Connected_Status(const uint8_t * data, size_t length)
{
   PPE_EVG_REPORT_PLAY_STATUS_T* ppe_data;
   ppe_data = (PPE_EVG_REPORT_PLAY_STATUS_T*)data;

   pits_source = ppe_data->source;
   pits_instanced_id = ppe_data->instance_id;

   switch (ppe_data->source.type)
   {
      /*USB*/
      case SSM_SRC_MSD:
	 pits_ipod_connected = false;
	 pits_autentification_ipod = false;

         pits_usb_connected = true;
         pits_device_present = true;
	 pits_autentification_msd = true;
         break;
      /*ipod*/
      case SSM_SRC_IPOD:
	 pits_usb_connected = false;
	 pits_autentification_msd = false;

	 pits_ipod_connected = true;
	 pits_device_present = true;
	 pits_autentification_ipod = true;
         break;
      /*SD*/
      case SSM_SRC_SD:
	  pits_sd_connected = true;
	  pits_device_present = true;
	  pits_autentification_sd = true;
         break;
      default:	
      break;
   }
}

void Pits_USB_Device_Remove(const uint8_t * data, size_t length)
{
   PPE_EVG_DEVICE_REMOVED_T* ppe_data;
   ppe_data = (PPE_EVG_DEVICE_REMOVED_T*)data;

   pits_source = ppe_data->source;

   switch (ppe_data->source.type)
   {
      /*USB*/
      case SSM_SRC_MSD:
	 pits_usb_connected = false;
         pits_device_present = false;
	 pits_autentification_msd = false;
         break;
      /*ipod*/
      case SSM_SRC_IPOD:
	 pits_ipod_connected = false;
	 pits_device_present = false;
	 pits_autentification_ipod = false;
         break;
      /*SD*/
      case SSM_SRC_SD:
	  pits_sd_connected = false;
	  pits_device_present = false;
	  pits_autentification_sd = false;
         break;
      default:	
      break;
   }

}

/*===========================================================================*/
/*!
 * @file pits_processing_filesys.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Pits_USB_Device_Connected_Status function:
 *  get message when USB device insert, parse message and set usb device connect
 *  status and authentification status.
 *
 *  06-Sep-2012 Darinka L�pez Rev 5
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Aug-2012 Darinka Lopez 4
 * Taks kok_basa#116889 - Change MID 30/32 - Set standarized Input
 * Fix Include issue. *_cbk.h should not be call in *.h files.
 *
 * 31-Jul-2012 Miguel Garcia  Rev 3
 * Task kok_basa#112058: PITS: Update Pits filesys services
 * Update PITS_FILESYS_Pos_T
 *
 * 11 Jun 2012 Miguel Garcia Rev 2
 * Move ICR filesys to processing services
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
