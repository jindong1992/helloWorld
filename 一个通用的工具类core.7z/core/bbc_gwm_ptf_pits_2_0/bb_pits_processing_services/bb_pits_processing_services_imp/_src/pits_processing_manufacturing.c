/*===========================================================================*/
/**
 * @file pits_processing_manufacturing.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_manufacturing.c~2:csrc:ctc_ec#22 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Wed Jun  8 11:00:41 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_processing_manufacturing.h"
#include "pits_programming_services.h"
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "xsal_util.h"
#include "bt_connection_manager.h"
#include "vip_proxy.h"
#include "allgo_gateway_diag_proxy.h"
#include "persistent_storage.h"
#include "metadata_storage_mgr.h"
#include "pits_misc_services_cbk.h"


EM_FILENUM(PITS_MODULE_ID_5, 44);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define PITS_REFLASH_CONFIG_OFFSET   16
#define PITS_MD5SUM_BYTES            32
#define MD5_CKSUM_OFFSET             64
#define AUX_JACK_CMD_NOT_SUPP         3

#define PITS_PS_MFG_CALS_ERASE_CMD        "/usr/local/bin/erase_mfg_cal.sh"
#define PITS_PS_NONVOL_ERASE_CMD          "/usr/local/bin/erase_ps.sh"

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct MD5_Convert_Tag{
  char     ascii_char;
  uint8_t  hex_char;
} MD5_Convert_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static uint8_t pits_man_map_ascii_to_hex_md5(uint8_t ascii_char);

static void pits_mfg_reset_radio(void);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static const MD5_Convert_T md5_compare_table[] =
{
   { '0',    0x00 },
   { '1',    0x01 },
   { '2',    0x02 },
   { '3',    0x03 },
   { '4',    0x04 },
   { '5',    0x05 },
   { '6',    0x06 },
   { '7',    0x07 },
   { '8',    0x08 },
   { '9',    0x09 },
   { 'A',    0x0A },
   { 'B',    0x0B },
   { 'C',    0x0C },
   { 'D',    0x0D },
   { 'E',    0x0E },
   { 'F',    0x0F },
   { 'a',    0x0A },
   { 'b',    0x0B },
   { 'c',    0x0C },
   { 'd',    0x0D },
   { 'e',    0x0E },
   { 'f',    0x0F },
}; 
   

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_man_map_ascii_to_hex_md5
 *===========================================================================*
 * @brief convert ascii to hex value
 *
 * @returns
 *    uint8_t = nex hex value
 *
 * @param [in] ascii_char = Ascii char received from the buffer.
 */
/*===========================================================================*/
uint8_t pits_man_map_ascii_to_hex_md5(uint8_t ascii_char)
{
  uint8_t pits_hexdata = 0;
  uint8_t pitstable_index;

  for (pitstable_index = 0; pitstable_index < Num_Elems(md5_compare_table); pitstable_index++)
  {
     if (ascii_char == md5_compare_table[pitstable_index].ascii_char)
     {
        pits_hexdata = md5_compare_table[pitstable_index].hex_char;
        break;
     }
  }

  if (pitstable_index >= sizeof(md5_compare_table))
  {
     pits_hexdata = 0;
  }
  
  return (pits_hexdata);
}


/*===========================================================================*
 * FUNCTION: PITS_Man_Load_MD5_Data
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Man_Load_MD5_Data(int8_t fd, uint8_t *tx_msg, uint16_t indx_offset)
{
   ssize_t bytes_read;
   char buffer[33];
   uint8_t pitbuffer_index;
   uint8_t pits_hexdata;
   uint16_t pits_man_md5_index = 0; 
   int8_t rc = 0;

    /*  skip first 16 bytes -> reflash configurations  */
    pits_man_md5_index = indx_offset * MD5_CKSUM_OFFSET;
    pits_man_md5_index += PITS_REFLASH_CONFIG_OFFSET;
    /*  move to md5sum of desire parition -> index  */
    rc = lseek(fd, pits_man_md5_index, SEEK_SET);

    if(0 > rc)
    {
       Tr_Warn("PITS file seek operation failed");
    }

    /*  obtain md5sum -> 32 bytes  */
    bytes_read = read(fd, buffer, PITS_MD5SUM_BYTES);

    if(PITS_MD5SUM_BYTES == bytes_read)
    {
       /*convert to hex*/
       for (pitbuffer_index = 0; pitbuffer_index < PITS_MD5SUM_BYTES; pitbuffer_index++)
       {

          pits_hexdata = pits_man_map_ascii_to_hex_md5(buffer[pitbuffer_index]);                  

          if((0 == pitbuffer_index%2))
          {
            (*tx_msg) = (pits_hexdata)<< 4;
          }
          else
          {
            (*tx_msg) += pits_hexdata;
            tx_msg ++;
          }  
       }
    }
   else
   {
      Tr_Warn_2("MD5 File: Only read %d bytes of %d", bytes_read, PITS_MD5SUM_BYTES);
   }
    
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Aux_Jack_Status
 *===========================================================================*
 *
 * @see the cbk for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_Aux_Jack_Status(void)
{
   uint8_t aux_jack_current_status = 0;
   SAL_Event_Id_T event_id_list[] = { EVG_AUX_JACK_STATUS };
   SAL_Message_T const *msg = NULL;

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      VIP_Request_Aux_Jack_Phy_State(); 
      msg = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 100);
      if (NULL != msg)
      { 
        if (EVG_AUX_JACK_STATUS == msg->event_id)
        {
           memcpy(&aux_jack_current_status, msg->data, sizeof(aux_jack_current_status));
           Tr_Info_Hi_1("AuxJack Status = %x", aux_jack_current_status);  
        }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
   else
   {
      Tr_Warn("SAL_Subscribe failed");
   }
   return aux_jack_current_status;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Session_Close_State
 *===========================================================================*
 *
 * @see the cbk for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Get_Session_Close_State(void)
{
  return (PITS_Get_PPS_Session() == SESSION_CLOSE);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_Load_Defaults
 *===========================================================================*
 *
 * @see the cbk for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Set_Load_Defaults (uint8_t default_option)
{
   uint8_t status_default = SUCCESS;
   int ret = 0;
   
   switch (default_option)
   {
      case PITS_RESET_ALL:
         #if PITS_BLUETOOTH_IS
         BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
         #endif
#if 0
         #if PITS_USB_IS
         DAG_Diag_Clear_Dev_List();
         #endif
         PS_Set_As_ReadOnly(true);

         /* Shutdown the QBA */
         qba_status = QBA_Shutdown();
         if (!qba_status)
         {       
            Tr_Warn_1("QBA shutdown failed in routine %s",__FUNCTION__);
         }
#endif
         ret = SAL_Run_Command_L(PITS_PS_MFG_CALS_ERASE_CMD, NULL);
         ret |= SAL_Run_Command_L(PITS_PS_NONVOL_ERASE_CMD, NULL);
         if (!SAL_Check_Return_Status_OK(ret, "Failed to erase something in PS (and to reboot)"))
         {
            status_default = FAIL;
         }
 
         sync();
         pits_mfg_reset_radio();
         break;
      case PITS_RESET_FACTORY_DATA:
         PS_Set_As_ReadOnly(true);
         ret = SAL_Run_Command_L(PITS_PS_MFG_CALS_ERASE_CMD, NULL);
         if (!SAL_Check_Return_Status_OK(ret, "Failed to erase something in PS (and to reboot)"))
         {
            status_default = FAIL;
         }
         sync();
         pits_mfg_reset_radio();
         break;
      case PITS_RESET_CUSTOMER_CALS:
         PS_Set_As_ReadOnly(true);
         pits_mfg_reset_radio();
         break;
      case PITS_RESET_NONVOL:
         #if PITS_BLUETOOTH_IS
         BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
         #endif
         PS_Set_As_ReadOnly(true);
#if 0		 
         /* Shutdown the QBA */
         qba_status = QBA_Shutdown();
         if (!qba_status)
         {
            Tr_Warn_1("QBA shutdown failed in routine %s",__FUNCTION__);
         }
#endif
         ret = SAL_Run_Command_L(PITS_PS_NONVOL_ERASE_CMD, NULL);
         if (!SAL_Check_Return_Status_OK(ret, "Failed to erase something in PS (and to reboot)"))
         {
            status_default = FAIL;
         }
         sync();
         pits_mfg_reset_radio();
		 
         break;
      #if PITS_USB_IS
      case PITS_RESET_USB_DATA:
         DAG_Diag_Clear_Dev_List();
         sync();
         break;
      case PITS_RESET_METADATA:
         MSM_Erase_Media();
         sync();
         break;
      #endif
      case PITS_RESET_TUNER_DATA:
         #if 0
         Tun_DSP_Load_Default();
         Tun_FE_Load_Default();
         #endif
         break;
      default:
         status_default = COMMAND_NOT_SUPPORTED;
         break;
   }
   return (status_default);
}

/* After the PS files are removed, cause radio reset. This allows the radio to
* load defaults on next startup.
*/
static void pits_mfg_reset_radio(void)
{
   Tr_Fault("PS Data has been removed. Resetting now...");
   SAL_Sleep(500);                                 /* Allow time for trace message to be printed */
   PITS_Module_Reset();
}

/**
 * @see the cbk for detail description of this function.
 */
uint8_t PITS_Get_Reflash_Status(void)
{
   return PITS_REFLASH_NOT_STARTED;
}

/**
 * @see the cbk for detail description of this function.
 */
bool_t PITS_Get_Reflash_Mode(void)
{
#if 0
   return Parts_PS_Get_Reflash_Mode();
#endif
   /*to do by tim*/
   return true;
}

/**
 * @see the cbk for detail description of this function.
 */
void PITS_Set_Reflash_Mode(void)
{
   /*to do by tim*/
#if 0
   if(!Parts_PS_Get_Reflash_Mode())
   {
      Parts_PS_Put_Reflash_Mode(true);
   }
#endif   
}

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Man_Map_Ascii_To_Hex_MD5
 *===========================================================================*
 * @brief convert ascii to hex value
 *
 * @returns
 *    uint8_t = nex hex value
 *
 * @param [in] ascii_char = Ascii char received from the buffer.
 */
/*===========================================================================*/
uint8_t PITS_Man_Map_Ascii_To_Hex_MD5(uint8_t ascii_char)
{
  uint8_t pits_hexdata = 0;
  uint8_t pitstable_index;

  for (pitstable_index = 0; pitstable_index < Num_Elems(md5_compare_table); pitstable_index++)
  {
     if (ascii_char == md5_compare_table[pitstable_index].ascii_char)
     {
        pits_hexdata = md5_compare_table[pitstable_index].hex_char;
        break;
     }
  }

  if (pitstable_index >= sizeof(md5_compare_table))
  {
     pits_hexdata = 0;
  }
  
  return (pits_hexdata);
}


/*===========================================================================*/
/*!
 * @file pits_processing_manufacturing.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Implemention PITS_Get_Aux_Jack_Status function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 4
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 27-Jun-2012 Darinka Lopez  Rev 3
 * Task kok_basa#105485: Implement Read of Parameter List 02
 *
 * 06-Jun-2012   Manuel Alejandro Robledo Rev 2
 * Task kok_basa#100574: Implement Test Man Front Aux Jack Present State -Pits 2.0
 *
 * 24-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19048: Implement MSID(10h)- Manufacturing Services Handler
 * Initial version.
 *
 */
/*===========================================================================*/
