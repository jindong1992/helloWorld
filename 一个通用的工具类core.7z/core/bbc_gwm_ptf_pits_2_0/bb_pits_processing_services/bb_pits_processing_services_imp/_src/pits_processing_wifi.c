/*===========================================================================*/
/**
 * @file pits_processing_wifi.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_wifi.c~4:csrc:ctc_ec#20 %
 * @version %version:4 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Wed Jul  6 17:26:48 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "em.h"
#include "pits_processing_wifi.h"
#include "string.h"
#include "utilities.h"
#include "xsal_util.h"
#include "wifi_mgr_event_types.h"
#include "wifi_proxy.h"

EM_FILENUM(PITS_MODULE_ID_5, 45);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_POS_XTRIM_OF_UFMIB                (36)
#define PITS_WIFI_UFMIB_PATH                        "/factory_data/ufmib.dat"

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static float Pits_Wifi_signal_Current_PER = 0;
static WIFI_Diagnose_Read_Data_T Pits_Wifi_signal = {0,0,0};
static uint32_t Pits_Wifi_clear_packet_number = 0;
static uint16_t Pits_Wifi_Carrier_Channel = 0;
static uint8_t Pits_Wifi_XtalTrim = 0;

static PITS_WIFI_STATUS_ENUM_T Pits_wifi_test_status = PITS_WIFI_STATUS_OFF;
static PITS_WIFI_CONN_STATUS_ENUM_T Pits_connect_status = PITS_WIFI_CONN_STATUS_OFF;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/**
 *  Wifi_Char_To_Hex
 *
 *  @param
 */
static uint8_t Wifi_Char_To_Hex(char schar)
{
   if (schar >= '0' && schar <= '9') return (schar - '0');
   else if (schar >= 'A' && schar <= 'F') return (schar - 'A' + 0x0A);
   else if (schar >= 'a' && schar <= 'f') return (schar - 'a' + 0x0A);
   else return 0;
}

/**
 *  Wifi_Find_Char_Pos
 *
 *  @param
 */
static uint16_t Wifi_Find_Char_Pos(char *sptr, char findchar, uint8_t numchar, uint16_t maxlen)
{
   uint16_t pos;
    
   if (maxlen == 0) return 0;
   pos = 0;
   for (;;) 
   {
      if (*sptr++ == findchar) 
      {
         if (numchar == 0) break;
         else numchar--;
      }
      maxlen--;
      pos++;
      if (maxlen == 0) break;
   }
   return pos;
}

/**
 *  Wifi_Get_Hex_Mac
 *
 *  @param
 */
static uint8_t Wifi_Get_Hex_Mac(char *item, uint8_t count)
{
   uint8_t mac = 0xff;

   if ((item == NULL) || (count == 0)) return 0xff;
   if (count == 2)
   {
      mac = Wifi_Char_To_Hex(item[0])<<4 | Wifi_Char_To_Hex(item[1]);
   }
   else if (count == 1)
   {
      mac = Wifi_Char_To_Hex(item[0]);
   }
   return mac;
}

/**
 *  Wifi_on
 *  Transfer "FF:FF:FF:FF:FF:FF" to 0xff,0xff,0xff,0xff,0xff,0xff
 *  @param
 */
static void Wifi_Mac_String_To_Hex(uint8_t *mac, char *mac_ascii)
{
   uint16_t pos_p, pos_n, i, item_count;
   char item[20];
    
   if ((mac == NULL) || (mac_ascii == NULL)) return;
   if (strlen(mac_ascii) != 17) return;
   for (i = 0; i < 6; i++)
   {
      if (i == 0)
      {
         pos_p = Wifi_Find_Char_Pos(mac_ascii, ':', i, strlen(mac_ascii));
         item_count = pos_p;
         memcpy(item, &mac_ascii[i], item_count);
         mac[i] = Wifi_Get_Hex_Mac(item, item_count);
      }
      else if (i == 5)
      {
         pos_p = Wifi_Find_Char_Pos(mac_ascii, ':', i - 1, strlen(mac_ascii));
         item_count = strlen(mac_ascii) - pos_p - 1;
         memcpy(item, &mac_ascii[pos_p + 1], item_count);
         mac[i] = Wifi_Get_Hex_Mac(item, item_count);
      }
      else
      {
         pos_p = Wifi_Find_Char_Pos(mac_ascii, ':', i - 1, strlen(mac_ascii));
         pos_n = Wifi_Find_Char_Pos(mac_ascii, ':', i, strlen(mac_ascii));

         if(1 < (pos_n - pos_p))
         {
            item_count = pos_n - pos_p - 1;
         }
         else
         {
            item_count = 0;
         }

         memcpy(item, &mac_ascii[pos_p + 1], item_count);
         mac[i] = Wifi_Get_Hex_Mac(item, item_count);
      }
   }
}


/*===========================================================================* 
 * FUNCTION: PTIS_Wifi_Save_Signal_info 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PTIS_Wifi_Save_Signal_info(const uint8_t * data, size_t length)
{
   WIFI_Diagnose_Read_Data_T Pits_Wifi_info;
   uint32_t Pits_Wifi_signal_Current_total = 0;
   uint32_t Pits_Wifi_signal_Current_totalGood = 0;
   memcpy(&Pits_Wifi_info, data, sizeof(Pits_Wifi_info));

   Pits_Wifi_signal_Current_total = Pits_Wifi_info.total - Pits_Wifi_signal.total;
   Pits_Wifi_signal_Current_totalGood = Pits_Wifi_info.totalGood - Pits_Wifi_signal.totalGood;
   
   Pits_Wifi_signal_Current_PER = (float)(Pits_Wifi_signal_Current_total - Pits_Wifi_signal_Current_totalGood)/(float)Pits_Wifi_signal_Current_total;
   
   memcpy(&Pits_Wifi_signal, &Pits_Wifi_info, sizeof(WIFI_Diagnose_Read_Data_T));
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_PER 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
float PITS_Wifi_Get_Current_PER(void)
{
   return Pits_Wifi_signal_Current_PER;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Average_PER 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
float PITS_Wifi_Get_Average_PER(void)
{
   float Pits_Wifi_signal_Average_PER = 0;
   
   Pits_Wifi_signal_Average_PER = (float)(Pits_Wifi_signal.total - Pits_Wifi_clear_packet_number - Pits_Wifi_signal.totalGood)/(float)Pits_Wifi_signal.total;
   
   return (Pits_Wifi_signal_Average_PER);
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
int16_t PITS_Wifi_Get_Current_Level(void)
{
   return (Pits_Wifi_signal.rssiAv);
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
uint32_t PITS_Wifi_Get_Current_Packet_Number(void)
{
   return (Pits_Wifi_signal.total);
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Clear_Current_Packet_Number 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Clear_Current_Packet_Number(void)
{
   Pits_Wifi_clear_packet_number = Pits_Wifi_signal.total - Pits_Wifi_signal.totalGood;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Begin_Wifi_Test_Success(const uint8_t * data, size_t length)
{
   Pits_wifi_test_status = PITS_WIFI_STATUS_ON;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Test_Failure(const uint8_t * data, size_t length)
{
   Pits_wifi_test_status = PITS_WIFI_STATUS_OPERATION_ERROR;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Test_In_Processing(void)
{
   Pits_wifi_test_status = PITS_WIFI_STATUS_IN_PROCESSING;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
PITS_WIFI_STATUS_ENUM_T PITS_Get_Wifi_Test_Status(void)
{
   return Pits_wifi_test_status;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Stop_Wifi_Test_Success(const uint8_t * data, size_t length)
{
   Pits_wifi_test_status = PITS_WIFI_STATUS_OFF;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Connect_Success(const uint8_t * data, size_t length)
{
   Pits_connect_status = PITS_WIFI_CONN_STATUS_ON;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Disconnect_Success(const uint8_t * data, size_t length)
{
   Pits_connect_status = PITS_WIFI_CONN_STATUS_OFF;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Connect_Failure(const uint8_t * data, size_t length)
{
   Pits_connect_status = PITS_WIFI_CONN_STATUS_OPERATION_ERROR;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_Wifi_Connect_In_Processing(void)
{
   Pits_connect_status = PITS_WIFI_CONN_STATUS_IN_PROCESSING;
}

/*===========================================================================* 
 * FUNCTION: PITS_Wifi_Get_Current_Level 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
PITS_WIFI_CONN_STATUS_ENUM_T PITS_Get_Wifi_Connect_Status(void)
{
   return Pits_connect_status;
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Set_Mac_Address 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool_t PITS_WIFI_Set_Mac_Addr(uint8_t *mac)
{ 
   struct stat buff;
   char command[256];
   int ret = 0;
   bool Retvalue = false;

   if (mac == NULL) return false;
   if (0 != stat(WIFI_MAC_ADDRESS_PATH, &buff))
   {

      ret = SAL_Run_Command_L("/bin/touch", WIFI_MAC_ADDRESS_PATH, NULL);
      if (SAL_Check_Return_Status_OK(ret, "/bin/touch"))
      {
         sync();
	      Tr_Notify("Wifi create mac.txt success !");
         Retvalue = true;
      }
      else
      {
         /* do nothing */
      }
   }
   
   memset(command, 0, sizeof(command));
   snprintf(command, sizeof(command), "/bin/echo %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x > %s" , mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], WIFI_MAC_ADDRESS_PATH);

   ret = SAL_Run_Command_L("sh", "-c", command,  NULL);
   if (SAL_Check_Return_Status_OK(ret, "/bin/echo"))
   {
      sync();
      Tr_Notify("Wifi set mac address to mac.txt success !");
      Retvalue = true;
   }
   else
   {
      /* do nothing */
   }

   return Retvalue;   
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Get_Mac_Addr 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool PITS_WIFI_Get_Mac_Addr(uint8_t * mac)
{
   FILE *fpipe;
   char command[256];
   char line[64];
   char *result = NULL;

   if (mac == NULL) return false;
   memset(command, 0, sizeof(command));
   snprintf(command, sizeof(command), "/bin/cat %s", WIFI_MAC_ADDRESS_PATH);
   if (!(fpipe = (FILE *)popen(command, "r")))
   {
      Tr_Warn("Wifi get mac address popen error");
      return false;
   }
   else
   {
      memset(line, 0, sizeof(line));
      if (fgets(line, sizeof(line), fpipe))
      {
         result = line;
         result = strsep(&result, "\n");
         if (strstr(result, "no") || strstr(result, "failed") || strstr(result, "Failed"))
         {
            Tr_Warn("Wifi get mac address error");
            pclose(fpipe);
            return false;
         }
         Wifi_Mac_String_To_Hex(mac, line);
      }
      pclose(fpipe);
   }
   return true;
   
#if 0   
   SAL_Message_T const  *msg                  = NULL;
   bool ret_value = false;
   SAL_Event_Id_T       subscribe_list[]      = {WIFI_MGR_PUBLISH_MAC_GET_SUCCESS};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Wifi_Proxy_Get_Mac_Address();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 100);

      if(NULL != msg)
      {
         if (WIFI_MGR_PUBLISH_MAC_GET_SUCCESS == msg->event_id)
         {
            ret_value = true;
            memcpy(pwifi_mac_addr, msg->data,6);
         }
         else
         {
            Tr_Warn_1("PITS Get WIFI Mac addr : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS Get WIFI Mac addr : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return (ret_value);
#endif   
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Get_Coex_Pin_Status 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool PITS_WIFI_Get_Coex_Pin_Status(uint8_t * Pin_status)
{
   SAL_Message_T const  *msg  = NULL;
   bool ret_value = false;
   SAL_Event_Id_T       subscribe_list[]      = {WIFI_MGR_PUBLISH_DIAG_GET_GPIO_SUCCESS,
                                                 WIFI_MGR_PUBLISH_DIAG_GET_GPIO_FAILED};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Wifi_Proxy_Diagnose_Get_Gpio_Status();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 100);

      if(NULL != msg)
      {
         if (WIFI_MGR_PUBLISH_DIAG_GET_GPIO_SUCCESS == msg->event_id)
         {
             ret_value = true;
             *Pin_status = *(uint8_t *)(msg->data);
         }
         else if (WIFI_MGR_PUBLISH_DIAG_GET_GPIO_FAILED == msg->event_id)
         {
            Tr_Warn_1("PITS WIFI : %s get coexistence failed", __FUNCTION__);
         }
         else 
         {
            Tr_Warn_1("PITS WIFI : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS WIFI : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return (ret_value);
}


/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Save_Carrier_Channel 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_WIFI_Save_Carrier_Channel(uint16_t Carrier_Channel)
{
   Pits_Wifi_Carrier_Channel = Carrier_Channel;
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Get_Carrier_Channel 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
uint16_t PITS_WIFI_Get_Carrier_Channel(void)
{
   return Pits_Wifi_Carrier_Channel;
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Save_XtalTrim 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
void PITS_WIFI_Save_XtalTrim(uint8_t XtalTrim)
{
   Pits_Wifi_XtalTrim = XtalTrim;
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Get_XtalTrim 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
uint16_t PITS_WIFI_Get_XtalTrim(void)
{
   return Pits_Wifi_XtalTrim;
}


/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Get_Final_XtalTrim 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool PITS_WIFI_Get_Final_XtalTrim(uint8_t * Final_XtalTrim)
{
#if 0
   FILE *uf_mib;
   unsigned int size;
   bool retvalue = true;

   if (Final_XtalTrim == NULL) 
   {
      retvalue = false;
   }
   else
   {
      uf_mib = fopen(PITS_WIFI_UFMIB_PATH, "rb");
      if (uf_mib == NULL)
      {
         Tr_Warn("PITS - Ufmib file open failed\n");
         retvalue = false;
      }
      else
      {
         fseek(uf_mib, PITS_POS_XTRIM_OF_UFMIB, SEEK_SET);
         size = fread(Final_XtalTrim, 1, 1, uf_mib);
         if (size != 1)
         {
            Tr_Warn("PITS - Final xtrim value get failed");
            retvalue = false;
         }
         fclose(uf_mib);
      }
   }

   return retvalue;
#endif

   SAL_Message_T const  *msg  = NULL;
   bool ret_value = false;
   SAL_Event_Id_T       subscribe_list[]      = {WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_SUCCESS,
                                                 WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_FAILED};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Wifi_Proxy_Diagnose_Get_Final_XtalTrim();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 500);

      if(NULL != msg)
      {
         if (WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_SUCCESS == msg->event_id)
         {
             ret_value = true;
             *Final_XtalTrim = *(uint8_t *)(msg->data);
         }
         else if (WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_FAILED == msg->event_id)
         {
            Tr_Warn_1("PITS WIFI : %s get final XtalTrim failed", __FUNCTION__);
         }
         else 
         {
            Tr_Warn_1("PITS WIFI : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS WIFI : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return (ret_value);
}

/*===========================================================================* 
 * FUNCTION: PITS_WIFI_Save_Final_XtalTrim 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool PITS_WIFI_Save_Final_XtalTrim(uint8_t Final_XtalTrim)
{
   FILE *uf_mib;
   unsigned int size;
   bool retvalue = true;
   int rc = 0;

   uf_mib = fopen(PITS_WIFI_UFMIB_PATH, "rb+");
   if (uf_mib == NULL)
   {
      Tr_Warn("PITS - Ufmib file open failed\n");
      retvalue = false;
   }
   else
   {
      rc = fseek(uf_mib, PITS_POS_XTRIM_OF_UFMIB, SEEK_SET);
      if(0 <= rc)
      {
         size = fwrite(&Final_XtalTrim, 1, 1, uf_mib);
         if (size != 1)
         {
            Tr_Warn("PITS - Final xtrim value set failed");
            retvalue = false;
         }
         if(0 != fclose(uf_mib))
         {
            Tr_Warn("PITS file close operation failed");
         }
         sync();
      }
      else
      {
         if(0 != fclose(uf_mib))
         {
            Tr_Warn("PITS file close operation failed");
         }
         retvalue = false;
      }

   }

   return retvalue;

}



/*===========================================================================*/
/*!
 * @file pits_processing_display.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06July2016 Rahul Chiryil (vzm576) Rev.4
 *  ctc_ec#157446: Coverity warning removal
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 3
 * ctc_ec#156415: Remove build warnings.
 *
 * 25-Jun-2014 Bao Qifan  Rev 12
 * Task ctc_ec#71800 [NGK PITS] add copy log file to usb and print trace code on UART function
 *
 * 11-Jun-2014 Bao Qifan  Rev 11
 * Task ctc_ec#70321 [NGK klocwork] fix klocwork warning
 *
 * 28 Mar 2014 Bao Qifan Rev 10
 * Task ctc_ec#68955. [NGK PITS] use SAL_Run_Command_L instead of system
 *
 * 28 Mar 2014 Bao Qifan Rev 9
 * Task ctc_ec#68919. [NGK PTIS] change wifi mac address and xtaltrim read and write function from wifi module to pits module
 *
 * 02-Mar-2014 Bao Qifan Rev 8
 * Task ctc_ec#63523 [NGK PITS] add wifi Xtal get function for parameter list
 *
 * 06 Mar 2014 Bao Qifan Rev 7
 * Task ctc_ec#60736. [NGK PITS] add bt and wifi coexistance function
 *
 * 12-Feb-2014 Bao Qifan Rev 6
 * Task ctc_ec#58862 [NGK PITS] add pits msg 12 7E save wifi alignment cal value function
 *
 * 12-Feb-2014 Bao Qifan Rev 5
 * Task ctc_ec#58837 [NGK PITS] add pits12 BA clear wifi packet number function
 *
 * 22-Jan-2014 Bao Qifan Rev 4
 * Task ctc_ec#58181 [NGK PITS] add pits wifi function 12 7C query alignment value
 *
 * 21-Jan-2014 Bao Qifan Rev 3
 * Task ctc_ec#58134 [NGK PITS] add wifi pits message
 *
 * 02-Sept-2013 Bao Qifan Rev 2
 * Task ctc_ec#43085 [NGK PITS] update wifi service connect and disconnect notify event
 *
 * 30-Augu-2013 Bao Qifan Rev 1
 * Task ctc_ec#43034 [NGK PITS]draf version for wif pits function
 *
 */
/*===========================================================================*/
