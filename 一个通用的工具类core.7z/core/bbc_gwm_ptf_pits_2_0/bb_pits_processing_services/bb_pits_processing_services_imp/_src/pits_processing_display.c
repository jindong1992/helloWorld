/*===========================================================================*/
/**
 * @file pits_processing_display.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_display.c~1:csrc:ctc_ec#22 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Mon May 23 14:13:50 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_display_services.h"
#include "pits_display_services_cbk.h"
#include "pits_processing_display.h"
#include "xsal_util.h"
#include "screen_check_proxy.h"
#include <string.h>
#include "pcan_appl_proxy.h"

EM_FILENUM(PITS_MODULE_ID_5, 33);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
 #if defined FORD_C490
/*===========================================================================* 
 * FUNCTION: PITS_Get_Screen_Check_Override_Status 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
uint8_t PITS_Get_Screen_Check_Override_Status (void)
{
   SAL_Message_T const  *msg                  = NULL;
   SCREEN_CHECK_STATUS_T  SC_Status = {0,0};
   SAL_Event_Id_T       subscribe_list[]      = {SCREEN_CHECK_EV_GET_STATUS_RPT};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Screen_Check_Get_Status_Request();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

      if(NULL != msg)
      {
         if (SCREEN_CHECK_EV_GET_STATUS_RPT == msg->event_id)
         {
            memcpy(&SC_Status, msg->data,sizeof(SCREEN_CHECK_STATUS_T));
         }
         else
         {
            Tr_Warn_1("PITS Display LCD : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS Display LCD : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return ((uint8_t)SC_Status.Is_enable_screen_check);
}

/*===========================================================================* 
 * FUNCTION: PITS_Get_Screen_Check_Pattern_Status 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
uint8_t PITS_Get_Screen_Check_Pattern_Status (void)
{
   SAL_Message_T const  *msg                  = NULL;
   SCREEN_CHECK_STATUS_T  SC_Status = {0,0};
   SAL_Event_Id_T       subscribe_list[]      = {SCREEN_CHECK_EV_GET_STATUS_RPT};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Screen_Check_Get_Status_Request();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

      if(NULL != msg)
      {
         if (SCREEN_CHECK_EV_GET_STATUS_RPT == msg->event_id)
         {
            memcpy(&SC_Status, msg->data,sizeof(SCREEN_CHECK_STATUS_T));
         }
         else
         {
            Tr_Warn_1("PITS Display LCD : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS Display LCD : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return ((uint8_t)SC_Status.Screen_Pattern);
}

/*===========================================================================* 
 * FUNCTION: PITS_Get_Screen_Check_Pattern_Status 
 *===========================================================================* 
 * 
 * @see the API for detail description of this function. 
 */ 
/*===========================================================================*/ 
bool PITS_Wait_Screen_Check_replay (uint8_t Req)
{
   SAL_Message_T const  *msg                  = NULL;
   bool Ret_Val = false;
   SAL_Event_Id_T       subscribe_list[]      = 
      {SCREEN_CHECK_EV_SUCCESS,
       SCREEN_CHECK_EV_FAIL};

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      Screen_Check_Apply_Pic_Request((SCREEN_CHECK_PIC_PATT_ENUM_T)Req);
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

      if(NULL != msg)
      {
         if (SCREEN_CHECK_EV_SUCCESS == msg->event_id)
         {
            Ret_Val = true;
         }
         else if (SCREEN_CHECK_EV_FAIL == msg->event_id)
         {
            Ret_Val = false;
         }
         else
         {
            Tr_Warn_1("PITS Display LCD : %s receive wrong event id", __FUNCTION__);
         }
      }
      else
      {
         Tr_Warn_1("PITS Display LCD : %s receive nothing event id", __FUNCTION__);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return (Ret_Val);
}
#endif
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
uint8_t PITS_Disp_Get_Faceplat_Dim()
{ 
   uint8_t illu_step = 0;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      PCAN_APPL_FACEPLATE_ILLUM_STEP,
   };

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      PCAN_Get_Faceplate_Ill_Step();
   
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      { 
         if (PCAN_APPL_FACEPLATE_ILLUM_STEP == response_message->event_id)
         {
            illu_step = ((uint8_t *)response_message->data)[0];
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   } 

   return (illu_step);
}
#endif

/*===========================================================================*/
/*!
 * @file pits_processing_display.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 2
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
