/*===========================================================================*/
/**
 * @file pits_processing_tuner.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_tuner.c~1:csrc:ctc_ec#22 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Mon May 23 14:14:32 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_tuner_services.h"
#include "pits_tuner_services_cbk.h"
#include "pits_gmdiag_services.h"
#include "pits_processing_tuner.h"
#include "xsal_util.h"


EM_FILENUM(PITS_MODULE_ID_5, 41);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define FM_CHANNEL_SPACE     (0xC8)
#define FM_BASE_CONST        (0x0A)
#define AM_CHANNEL_SPACE     (0x0A)
#define AM_LOW_FREC          (0x0212)
#define FM_LOW_FREC          (0x2242)
/*#define PITS_FREQ_CONVERSION (10)*/


/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static bool_t pits_tuner_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
SSM_Source_Type_T                 pits_tuner_source_type;
uint32_t                          pits_tuner_xm_frequency;
uint16_t                          pits_tuner_hd_current_subchannel;
uint8_t                           pits_tuner_quality;
uint8_t                           pits_tuner_xm_sid;
Tuner_Mgr_Station_Info_AMFM_T     pits_tuner_amfm_info;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Get_Current_Station_Info
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Get_Current_Station_Info(const uint8_t * data, size_t length)
{
   Tuner_Mgr_Station_Info_T          tuner_station_info;
   SSM_Source_T                      tuner_source;
   Tuner_Mgr_Station_Info_Content_T  tuner_content;
   Tuner_Mgr_Station_Info_AMFM_T     tuner_amfm_info;
   Tuner_Mgr_Station_Info_XM_T       tuner_xm_info;

   tuner_station_info     = *((Tuner_Mgr_Station_Info_T*)(data));
   tuner_source           = tuner_station_info.source;
   tuner_content          = tuner_station_info.content;
   tuner_amfm_info        = tuner_content.amfm_info;
   pits_tuner_amfm_info   = tuner_content.amfm_info;
   tuner_xm_info          = tuner_content.xm_info;

   pits_tuner_source_type           = tuner_source.type;
   pits_tuner_hd_current_subchannel = 0; /*todo when implemented tuner_amfm_info.hd_current_subchannel;*/
 /*  if(SSM_SRC_FM == tuner_source.type)
   {
      pits_tuner_amfm_info.frequency = pits_tuner_amfm_info.frequency/PITS_FREQ_CONVERSION;
   }*/
   if(SSM_SRC_XM == tuner_source.type)
   {
      pits_tuner_xm_frequency = tuner_xm_info.station;
      pits_tuner_xm_sid = tuner_xm_info.sid;
      pits_tuner_amfm_info.frequency = tuner_xm_info.station;

   }
   else if ((SSM_SRC_FM == tuner_source.type)||(SSM_SRC_AM == tuner_source.type))
   {
      pits_tuner_quality = tuner_amfm_info.quality;
      Pits_Set_Gmdiag_Quality (tuner_amfm_info.quality);
   }
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Source_Type
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_Tuner_Band_T PITS_Get_Tuner_Source_Type(void)
{
   return pits_tuner_source_type;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Frequency
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint32_t PITS_Get_AMFM_Tuner_Frequency(void)
{
   return pits_tuner_amfm_info.frequency;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_HD_Subchannel
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint16_t PITS_Get_Tuner_HD_Subchannel(void)
{
   return pits_tuner_hd_current_subchannel;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Quality
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_Tuner_Quality(void)
{
   return pits_tuner_amfm_info.quality;
}

/*===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
RDS_Pi_T PITS_Get_Tuner_User_PI_Code(void)
{
   return RD_PI();
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Received_PTY
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_Tuner_Received_PTY(void)
{
   return (0);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Received_PI
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
RDS_Pi_T PITS_Get_Tuner_Received_PI(void)
{
   return RDS_Get_Current_PI();
}

/*===========================================================================*
 * FUNCTION: PITS_Get_XM_Tuner_SID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_XM_Tuner_SID(void)
{
   return pits_tuner_xm_sid;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_XM_Tuner_Channel
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint32_t PITS_Get_XM_Tuner_Channel(void)
{
   return (pits_tuner_xm_frequency);	/*TODO*/
}

/*===========================================================================*
 * FUNCTION: PITS_Get_DAB_Tuner_Frequency
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_DAB_Tuner_Frequency(void)
{
   return 0x00;
}

/*===========================================================================*
 * FUNCTION: pits_tuner_amfm_channel_is_valid
 *===========================================================================*
 * @brief verify valid am/fm band
 *
 * @returns
 *    true = valid band limit
 *    false = No valid band.
 *
 * @param [in] band = FM/AM band
 * @param [in] channel = frequency value.

 */
/*===========================================================================*/
static bool_t pits_tuner_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel)
{
   uint16_t lower_band_limit = AM_FM_Drv_Get_Lower_Band_Limit(band);
   uint16_t upper_band_limit = AM_FM_Drv_Get_Upper_Band_Limit(band);
   uint16_t band_step_size = AM_FM_Drv_Get_Tune_Step_Size(band);

   return ( (upper_band_limit >= channel) &&
            (lower_band_limit <= channel) &&
            (((channel - lower_band_limit) % band_step_size) == 0) );
}

/*===========================================================================*
 * FUNCTION: PITS_Tuner_Set_FM_Value
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Tuner_Set_FM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2)
{
   uint8_t pit_channel = 0;
   uint32_t tune_band_adjust;
   bool_t valid_channel = false;

   pits_band_info->target_value= (uint32_t) (((uint16_t)(msg_data_1) << 8) + msg_data_2);
   pits_band_info->target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
   pits_band_info->target_subchannel = 0;
      
   pit_channel = (uint8_t)(((pits_band_info->target_value - FM_LOW_FREC)*FM_BASE_CONST)/FM_CHANNEL_SPACE);
   tune_band_adjust = ((FM_CHANNEL_SPACE * pit_channel)/FM_BASE_CONST)+ FM_LOW_FREC;
   pits_band_info->target_subchannel = (uint8_t) (pits_band_info->target_value - tune_band_adjust);
   pits_band_info->target_value = pits_band_info->target_value - pits_band_info->target_subchannel;
   if (pits_band_info->target_subchannel > 0)
   {
      pits_band_info->target_subchannel = pits_band_info->target_subchannel - 1;
   }
   valid_channel = pits_tuner_amfm_channel_is_valid(FM_BAND, pits_band_info->target_value);

   /*#if PITS_NEW_TUNER_IS
   pits_band_info->target_value = pits_band_info->target_value*PITS_FM_FREQ_CONVERSION;
   #endif  */

   return (valid_channel);
}

/*===========================================================================*
 * FUNCTION: PITS_Tuner_Set_AM_Value
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
 bool_t PITS_Tuner_Set_AM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2)
{
   bool_t valid_channel = false;

   pits_band_info->target_value= (uint32_t) (((uint16_t)(msg_data_1) << 8) + msg_data_2);
   pits_band_info->target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
   pits_band_info->target_subchannel = 0;

   valid_channel = pits_tuner_amfm_channel_is_valid(AM_BAND, pits_band_info->target_value);

   return (valid_channel);
}

/*===========================================================================*
 * FUNCTION: PITS_Tuner_Set_XM_Value
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
 bool_t PITS_Tuner_Set_XM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2)
{
    pits_band_info->target_type = TUNER_MGR_TARGET_TYPE_SERVICE_ID;
    pits_band_info->target_value = msg_data_1;
    pits_band_info->target_subchannel =  msg_data_2;
    return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Tuner_Set_DAB_Value
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
 bool_t PITS_Tuner_Set_DAB_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2)
{
    return(false);
}


/*===========================================================================*/
/*!
 * @file pits_processing_tuner.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 13
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 15 Aug 2012 Miguel Garcia
 * Include Pits Set Gmdiag quality
 *
 * 13 Aug 2012 Miguel Garcia
 * Include pits calls for different regions in dpid2 and dpid10
 *
 * 26 Jul 2012 Miguel Garcia 9
 * Fix subchannel selection for HD.
 *
 * 22-May-2012 Juan Carlos Castillo 8
 * Task kok_basa#98416 - gmsbx14_pits - Received PTY PITs
 *
 * 17-May-2012 Juan Carlos Castillo 7
 * Task kok_basa#96194 - gmsbx14_pits - Signal Strength and PI code Pit.
 *
 * 30-Mar-2012 Oscar Vega 6
 * Task kok_basa#86208 - Fix DAB message to use 1 byte to get frequency.
 *
 * 28-Mar-2012 Oscar Vega 5
 * Task kok_basa#85766 - 20 - Fix DAB message to use 1 byte.
 *
 * 21-Mar-2012 Darinka Lopez  Rev 4
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 27 Feb 2012 Miguel Garcia Rev 2
 * Fix XM setting with SID
 *
 * 30-Jan-2012 Oscar Vega  Rev 2
 * SCR kok_basa#21073: Implemente set/get Request Band and Frequency for DAB
 * Fix: Implement code to get and set frequency for DAB.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
