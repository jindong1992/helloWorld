/*===========================================================================*/
/**
 * @file pits_processing_misc.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_misc.c~3:csrc:ctc_ec#5 %
 * @version %version:3 %
 * @author  %derived_by:tzl4my %
 * @date    %date_modified: Fri Jan 13 14:07:07 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_configuration.h"
#include "pits_display_services.h"
#include "pits_misc_services.h"
#include "pits_misc_services_cbk.h"
#include "pits_processing_misc.h"
#include "utilities.h"
#include <string.h>
#include "xsal_util.h"
#include <stdlib.h>
#include "version_tracking.h"
#include "vip_desip.h"
#include "vip_proxy.h"
#include "pits_can.h"
#include "wifi_mgr_event_types.h"
#include "wifi_proxy.h"
#include "nav_gps_drv.h"
#include "nav_gps_proxy.h"
#include <unistd.h>
#include <errno.h>
#include "pcan_appl_proxy.h"
#include "can_btcs_msg_types.h"

EM_FILENUM(PITS_MODULE_ID_5, 37);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define LANGUAGE_ENGLISH  (0)
#define LANGUAGE_FRENCH  (1)
#define LANGUAGE_SPANISH  (2)

#define PITS_VR_SWID_SIZE (5)

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint8_t swid_speech_data_size = 0;
static uint8_t samantha_swid_speech_data_size = 0;
static uint8_t julie_swid_speech_data_size = 0;
static uint8_t paulina_swid_speech_data_size = 0;
static uint8_t english_swid_speech_data_size = 0;
static uint8_t french_swid_speech_data_size = 0;
static uint8_t mexican_swid_speech_data_size = 0;
static uint8_t speech_rec_data_size = 0;
static uint8_t PWM_Remote_Enabled = true;

static SIP_Power_Antenna_Status_T antenna_status = {0};

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*\
 * Misc Services
\*===========================================================================*/

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
void PITS_Module_Reset(void)
{
   PITS_Disconnect_Sources();
   Tr_Notify("PITS message: PITS_Module_Reset");
   SAL_Sleep(50);
   VIP_Send(VIPP_EV_COLD_START, NULL, 0);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
void PITS_Module_Enter_Sleep_Mode(void)
{
   Tr_Info_Lo("Enter sleep mode!");
   PITS_Disconnect_Sources();

   #if defined(GWM_CHK041_8AT) ||defined(GWM_CHK011_8AT)
   {
      SYS_POWER_MODE_T status = POWER_MODE_OFF;
      SAL_Publish(CAN_EVG_SYS_POWER_MODE, &status, sizeof(status));
      Tr_Notify("CAN_EVG_SYS_POWER_MODE sleep 10!");
      SAL_Sleep(10500);
   }
   #else
      SAL_Sleep(50);
   #endif

   VIP_AP_Immediate_Shutdown();
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */

void PITS_Exit_Manufacturing_Mode (void)
{
   Exit_Manufacturing_Mode();
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
uint8_t PITS_Misc_Get_RTD_SWID(uint8_t * data)
{
   uint8_t pits_response = (uint8_t) FAIL;

   #if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)/* add by zengliangqian for get display version */
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      EVG_RTD_VERSION,
   };

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Pits_Get_RTD_Version();
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
      if (NULL != response_message)
      {
         Tr_Info_Lo("RTD Swid Response Received!!\r\n");
         if (EVG_RTD_VERSION == response_message->event_id)
         {
            pits_response = (uint8_t) SUCCESS;
            memcpy(&data[0],response_message->data,response_message->data_size);
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
   #endif
   return (pits_response);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
uint8_t PITS_Misc_Get_RTD_Checksum(uint8_t * data)
{
   uint8_t pits_response = (uint8_t) FAIL;
#if 0
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      EVG_RTD_IMAGE_CHECKSUM_REP,
   };

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Pits_Get_RTD_Checksum();
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
      if (NULL != response_message)
      {
         Tr_Info_Lo("RTD Checksum Response Received!!\r\n");
         if (EVG_RTD_IMAGE_CHECKSUM_REP == response_message->event_id)
         {
            pits_response = (uint8_t) SUCCESS;
            memcpy(&data[0],response_message->data,response_message->data_size);
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
   #endif
   return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Boot_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_Boot_SWID(uint8_t * data, uint8_t *data_len)
{

  int8_t fp;
  int rc;
  char buffer[33];
  uint8_t pitsend_index = 0;
  /*Moved to pits gmdiag for reading boot swid before splash screens load*/
  system("dd if=/dev/mtdblock2 bs=1 skip=65542 count=8>/tmp/fbl_swid");


   /* open /tmp/swid temporal file */
   fp = open("/tmp/fbl_swid", O_RDONLY, 0);

   if(0 <= fp)
   {
      /*  obtain md5sum -> 32 bytes  */
     rc = read(fp, buffer, 8);

     if(0 != rc)
     {
         /*convert to hex*/
        for (pitsend_index = 0; pitsend_index < 8; pitsend_index++)
        {
           data[pitsend_index] = buffer[pitsend_index];
        }

        *data_len = 8;
     }
     close(fp);
  }

  return (SUCCESS);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VIP_Boot_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VIP_Boot_SWID(uint8_t * data, uint8_t *data_len)
{
   SIP_VIP_Swid_T  pits_K0R_swid_info = {0, 0, 0};
   uint8_t length = 0;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      EVG_VIP_BOOT_SWID,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      VIP_Send(VIPP_EV_BOOT_SWID_REQ, NULL, 0);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (EVG_VIP_BOOT_SWID == response_message->event_id)
         {
            memcpy(&pits_K0R_swid_info, response_message->data, sizeof(pits_K0R_swid_info));
            *data_len = sizeof(pits_K0R_swid_info);
            Tr_Info_Hi_3("Software version is %x %x %x", pits_K0R_swid_info.sw_id, pits_K0R_swid_info.sw_version, pits_K0R_swid_info.sw_subversion);
            pits_swid_results = SUCCESS;
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   /* Store swid information in response buffer */
   Util_Put_Big_Endian_U32(&data[length], pits_K0R_swid_info.sw_id);

   length += sizeof(pits_K0R_swid_info.sw_id);
   Util_Put_Big_Endian_U16(&data[length], pits_K0R_swid_info.sw_version);

   length += sizeof(pits_K0R_swid_info.sw_version);
   data[length] = (uint8_t)pits_K0R_swid_info.sw_subversion;

   return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VIP_Boot_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VIP_App_SWID(uint8_t * data, uint8_t *data_len)
{

   SIP_VIP_Swid_T  pits_K0R_swid_info = {0,0,0};
   uint8_t length = 0;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      EVG_VIP_SWID,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {

      VIP_Send(VIPP_EV_APP_SWID_REQ, NULL, 0);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
        if (EVG_VIP_SWID == response_message->event_id)
  	   {
           memcpy(&pits_K0R_swid_info, response_message->data, sizeof(pits_K0R_swid_info));
           Tr_Info_Hi_3("Software version is %x %x %x", pits_K0R_swid_info.sw_id, pits_K0R_swid_info.sw_version, pits_K0R_swid_info.sw_subversion);
           pits_swid_results = SUCCESS;
	      }
	    }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  /* Store swid information in response buffer */
  Util_Put_Big_Endian_U32(&data[length], pits_K0R_swid_info.sw_id);

  length += sizeof(pits_K0R_swid_info.sw_id);
  Util_Put_Big_Endian_U16(&data[length], pits_K0R_swid_info.sw_version);

  length += sizeof(pits_K0R_swid_info.sw_version);
  data[length] = (uint8_t)pits_K0R_swid_info.sw_subversion;
  *data_len = length + sizeof(pits_K0R_swid_info.sw_subversion);

  return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_ClkOut_Status
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_ClkOut_Status (void)
{
   return (0);
}

/*===========================================================================*
 * FUNCTION: PIT_Set_ClkOut
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/

void PIT_Set_ClkOut(uint8_t data)
{

}
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_App_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_App_SWID(uint8_t * data)
{
   Util_Put_Big_Endian_U32(&data[0], VT_SOFTWARE_ID);
   Util_Put_Big_Endian_U32(&data[NUM_BYTES_APP_SWID], VT_SOFTWARE_VERSION);
   return (SUCCESS);
}
#if PITS_WIFI_IS
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Build_ID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_WIFI_Build_ID(uint8_t * data, uint8_t * length)
{

   WIFI_Diagnose_Chip_Info_T pits_wifi_swid;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   uint8_t Length_item = 0;
   SAL_Event_Id_T event_id_list[] =
   {
      WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {

      Wifi_Proxy_Diagnose_Get_Chip_Info();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 20);
      if (NULL != response_message)
      {
        if (WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO == response_message->event_id)
  	   {

           memcpy(&pits_wifi_swid, response_message->data, sizeof(WIFI_Diagnose_Chip_Info_T));

           Length_item = sizeof(pits_wifi_swid.buildId);
           Util_Put_Big_Endian_U32(&data[0], pits_wifi_swid.buildId);
           *length = Length_item;

           pits_swid_results = SUCCESS;

	      }
	    }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Chip_ID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_WIFI_Chip_Rev(uint8_t * data, uint8_t * length)
{

   WIFI_Diagnose_Chip_Info_T pits_wifi_swid;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   uint8_t Length_item = 0;
   SAL_Event_Id_T event_id_list[] =
   {
      WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {

      Wifi_Proxy_Diagnose_Get_Chip_Info();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 20);
      if (NULL != response_message)
      {
        if (WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO == response_message->event_id)
  	   {

           memcpy(&pits_wifi_swid, response_message->data, sizeof(WIFI_Diagnose_Chip_Info_T));

           Length_item = Num_Elems(pits_wifi_swid.chipRev);
           memcpy(&data[0], &pits_wifi_swid.chipRev, Length_item);
           *length = Length_item;

           pits_swid_results = SUCCESS;

	      }
	    }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Rom_Name
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_WIFI_Rom_Name(uint8_t * data, uint8_t * length)
{

   WIFI_Diagnose_Chip_Info_T pits_wifi_swid;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   uint8_t Length_item = 0;
   SAL_Event_Id_T event_id_list[] =
   {
      WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {

      Wifi_Proxy_Diagnose_Get_Chip_Info();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 20);
      if (NULL != response_message)
      {
        if (WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO == response_message->event_id)
  	   {

           memcpy(&pits_wifi_swid, response_message->data, sizeof(WIFI_Diagnose_Chip_Info_T));

           Length_item = Num_Elems(pits_wifi_swid.romName);
           memcpy(&data[0], &pits_wifi_swid.romName, Length_item);
           *length = Length_item;

           pits_swid_results = SUCCESS;

	      }
	    }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Firmware_ID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_WIFI_Firmware_ID(uint8_t * data, uint8_t * length)
{

   WIFI_Diagnose_Chip_Info_T pits_wifi_swid;
   Success_Or_Fail_T pits_swid_results = FAIL;
   SAL_Message_T const *response_message = NULL;
   uint8_t Length_item = 0;
   SAL_Event_Id_T event_id_list[] =
   {
      WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {

      Wifi_Proxy_Diagnose_Get_Chip_Info();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 20);
      if (NULL != response_message)
      {
        if (WIFI_MGR_PUBLISH_DIAG_GET_CHIP_INFO == response_message->event_id)
  	   {

           memcpy(&pits_wifi_swid, response_message->data, sizeof(WIFI_Diagnose_Chip_Info_T));

           Length_item = Num_Elems(pits_wifi_swid.firmware);
           memcpy(&data[0], &pits_wifi_swid.firmware, Length_item);
           *length = Length_item;

           pits_swid_results = SUCCESS;

	      }
	    }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_swid_results);
}

#endif
#if 0
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_WIFI_SWID(uint8_t * data)
{

   char pits_wifi_scratch_memory[70];
   uint8_t pit_string_len = 0;
   uint8_t pit_index = 0;

   pit_string_len = strlen(Get_WiFi_Firmware_ID());
   memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_Firmware_ID(),pit_string_len);
   for (pit_index = 0; pit_index < pit_string_len;pit_index++)
   {
      data[pit_index] = pits_wifi_scratch_memory[pit_index];
   }
   return (SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_WIFI_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_WIFI_Lenght (void)
{
   uint8_t pit_string_len = strlen(Get_WiFi_Firmware_ID());
   return(pit_string_len);
}
#endif
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_BT_Stack_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_BT_Stack_SWID(uint8_t * data)
{

  /**
   * The Bluetooth stack software ID comes from betula_sdk_version.h,
   * which I just added to bb_gmicr13_betula_sdk and
   * bb_gmsbx14_betula_sdk. So if you get a compile error here you may
   * need to pull in a new version of that block.
   */
  memcpy(&data[0], BETULA_SDK_VERSION, strlen(BETULA_SDK_VERSION));
  return (SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_BT_Stack_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_BT_Stack_Lenght (void)
{
   return((uint8_t)(strlen(BETULA_SDK_VERSION)));
}
#if 0
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;


  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_engine_id[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           swid_speech_data_size = 50 - speech_size;
           if (swid_speech_data_size > 50)
           {
              swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_engine_id[0],swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }
  return (pits_response);
}
#endif
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_SWID(uint8_t * data, uint8_t *data_len)
{
   int8_t fp;
   int rc = 0;
   int sysret = 0;
   char buffer[PITS_VR_SWID_SIZE] = {0x00};
   char file[]="/tmp/test.txt";
   uint8_t ret = FAIL;

   /*Get VR SWID*/
   char cmd[] = "grep \"Version:\" /usr/local/bin/run_natp_delphi_b041.sh | awk -F \": \" '{print $2}' >/tmp/test.txt";
   sysret = system(cmd);

   if(0 <= sysret)
   {
      fp = open(file, O_RDONLY, 0);
      if(0 <= fp)
      {
         /*  obtain Reflash Status*/
         rc = read(fp, &buffer, PITS_VR_SWID_SIZE);

         if(PITS_VR_SWID_SIZE <= rc)
         {
            memcpy(data, buffer, PITS_VR_SWID_SIZE);
            *data_len = PITS_VR_SWID_SIZE;
            ret = SUCCESS;
         }
         else
         {
            Tr_Warn("VR SWID do not read properly");
         }

         if(0 > close(fp))
         {
            Tr_Warn("PITS file close operation failed");
         }

         if(0 > remove(file))
         {
            Tr_Warn("PITS file remove operation failed");
         }
      }
      else
      {
         Tr_Warn("VR SWID can not read out");
      }
   }
   else
   {
      Tr_Warn("VR SWID system read failed");
   }

   return ret;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_SWID_Lenght (void)
{
   return (swid_speech_data_size);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Samantha_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_Samantha_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;


  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_ENGLISH].tts_voice_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           samantha_swid_speech_data_size = 50 - speech_size;
           if (samantha_swid_speech_data_size > 50)
           {
              samantha_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_ENGLISH].tts_voice_ver[0],samantha_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }
  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Samantha_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_Samantha_SWID_Lenght (void)
{
  return (samantha_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_Julie_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_Julie_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;


  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_FRENCH].tts_voice_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           julie_swid_speech_data_size = 50 - speech_size;
           if (julie_swid_speech_data_size > 50)
           {
              julie_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_FRENCH].tts_voice_ver[0],julie_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }
  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_Julie_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_Julie_SWID_Lenght (void)
{
   return (julie_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_Paulina_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_Paulina_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;

  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_SPANISH].tts_voice_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           paulina_swid_speech_data_size = 50 - speech_size;
           if (paulina_swid_speech_data_size > 50)
           {
              paulina_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_SPANISH].tts_voice_ver[0],paulina_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_Paulina_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_Paulina_SWID_Lenght (void)
{
   return (paulina_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_English_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_English_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;

  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_ENGLISH].tts_lng_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           english_swid_speech_data_size = 50 - speech_size;
           if (english_swid_speech_data_size > 50)
           {
              english_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_ENGLISH].tts_lng_ver[0],english_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }
  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_English_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_English_SWID_Lenght (void)
{
   return (english_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_French_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_French_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;

  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_FRENCH].tts_lng_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           french_swid_speech_data_size = 50 - speech_size;
           if (french_swid_speech_data_size > 50)
           {
              french_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_FRENCH].tts_lng_ver[0],french_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }


  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_French_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_French_SWID_Lenght (void)
{
   return (french_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_Mexican_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_Mexican_SWID(uint8_t * data)
{
 uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     PROMPT_EVG_REP_GET_ENGINE_VERSION,
  };
  PITS_Prompt_Mgr_Engine_Version_Status_T voice_data_results;
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;

  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_Prompt_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");
        if (PROMPT_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&voice_data_results, response_message->data, response_message->data_size);
           for (speech_index=0; speech_index<50; speech_index++)
           {
              if (voice_data_results.tts_voice_ids[LANGUAGE_SPANISH].tts_lng_ver[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           mexican_swid_speech_data_size = 50 - speech_size;
           if (mexican_swid_speech_data_size > 50)
           {
              mexican_swid_speech_data_size = 50;
           }
           memcpy(&data[0],&voice_data_results.tts_voice_ids[LANGUAGE_SPANISH].tts_lng_ver[0],mexican_swid_speech_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }


  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_Mexican_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_Mexican_SWID_Lenght (void)
{
  return (mexican_swid_speech_data_size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VR_Speech_Rec_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_Get_VR_Speech_Rec_SWID(uint8_t * data)
{
  uint8_t pits_response = (uint8_t) FAIL;

  SAL_Message_T const *response_message = NULL;
  SAL_Event_Id_T event_id_list[] =
  {
     ASR_EVG_REP_GET_ENGINE_VERSION,
  };
  uint8_t speech_data_result[110] = {0};
  uint8_t speech_index = 0;
  uint8_t speech_size = 0;

  if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
  {
     Pits_ASR_Mgr_Get_Engine_Version();
     response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
     if (NULL != response_message)
     {
        Tr_Info_Lo("Speech Rec Swid Response Received");

        if (ASR_EVG_REP_GET_ENGINE_VERSION == response_message->event_id)
        {
           pits_response = (uint8_t) SUCCESS;
           memcpy(&speech_data_result[0], response_message->data, 100);
           for (speech_index=0; speech_index<100; speech_index++)
           {
              if (speech_data_result[speech_index] == 0)
              {
                 speech_size++;
              }
           }
           speech_rec_data_size = 100 - speech_size;
           if (speech_rec_data_size > 100)
           {
              speech_rec_data_size = 100;
           }
           memcpy(&data[0],response_message->data,speech_rec_data_size);
        }
     }
     SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
  }

  return (pits_response);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VR_Speech_Rec_SWID_Lenght
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_VR_Speech_Rec_SWID_Lenght (void)
{
   return (speech_rec_data_size);
}
/*
* Please refer to the detailed description in pits_processing_misc_cbk.h.
*/
bool_t PIT_Set_Radio_Power(uint8_t data)
{
   bool_t results_radio = true;

   char idpower[12];
   Persistent_Section_ID_T section_id_power = PS_SECTION_NONVOL;
   uint8_t read_buffer_power[10];
   uint8_t radio_power_state = 0;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;

   snprintf(idpower, sizeof(idpower), "Radio_Power");
   if(PS_Read(section_id_power, (const char *)&idpower[0], &read_buffer_power[0], 1))
   {
      radio_power_state = read_buffer_power[0];
   }
   if ((data == 0) && (radio_power_state == 1))
   {
      PITs_GM_Set_DID (0,7);
      PITs_GM_Set_DID(1, data);
      PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
      results_radio = false;
   }
   else if ((data == 1) && (radio_power_state == 0))
   {
      PITs_GM_Set_DID (0,7);
      PITs_GM_Set_DID(1, data);
      PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
      results_radio = false;
   }

   return (results_radio);
}
/*===========================================================================*
 * FUNCTION: PITS_Get_NAV_MAP_DATABASE_Info
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Get_NAV_MAP_DATABASE_Info (uint8_t *data, uint8_t *data_len)
{
   uint8_t pits_response = (uint8_t) FAIL;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      PITS_NAV_MAP_DATABASE_ID_RPT,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      SAL_Publish(PITS_NAV_MAP_DATABASE_ID_GET, NULL, 0);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (PITS_NAV_MAP_DATABASE_ID_RPT == response_message->event_id)
         {
            if (response_message->data_size <= 50)
            {
               memcpy(data, response_message->data, response_message->data_size - 1);
               *data_len = response_message->data_size - 1;
               pits_response = SUCCESS;
            }
            else
            {
               Tr_Warn_1("Navi map database version length too long, length: %d", response_message->data_size);
            }
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return (pits_response);
}

uint8_t PIT_Get_Microphone_Status(void)
{
   return(0);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h
 */
uint8_t PITS_Get_Remote_Enabled_Status (void)
{
   return PWM_Remote_Enabled;
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h
 */
void PITS_Set_Remote_Enabled_Status(uint8_t rmt_en)
{

   PWM_Remote_Enabled = (bool_t)rmt_en;
   PITS_Set_Remote_Enable(PWM_Remote_Enabled);
}

/*
* Please refer to the detailed description in pits_processing_misc_cbk.h.
*/
bool_t PIT_Get_Microphone_AD_Value (uint8_t mic_terminal, uint8_t *tx_data)
{
   return(0);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h
 */
uint8_t PITS_Get_Power_Antenna_Status(uint8_t antenna)
{
   SAL_Message_T const *msg = NULL;
   SAL_Event_Id_T subscribe_list[] = {EVG_VIP_PWR_ANTENA_CURRENT_STATUS};
   uint8_t ant_status = 0;

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      VIP_Get_Power_Antenna();
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

      if((NULL != msg) && (EVG_VIP_PWR_ANTENA_CURRENT_STATUS == msg->event_id))
      {
            memcpy(&antenna_status, msg->data, sizeof(antenna_status));
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));

   switch (antenna)
   {
      case PITS_ANTENNA_1:
         ant_status = antenna_status.Antenna_1;
         break;
      case PITS_ANTENNA_2:
         ant_status = antenna_status.Antenna_2;
         break;
      case PITS_DAB_ANTENNA:
         #if 0
         if(BoardOptions_PS_Diag_Read_DAB_Present())
         {
            ant_status = (uint8_t)pits_dab_antenna_status;
         }
         #endif
         break;
      default:
         break;
   }
   return(ant_status);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
void PITS_Put_Power_Antenna_Status(uint8_t antenna, uint8_t status)
{
   PITS_Get_Power_Antenna_Status(antenna);

   switch (antenna)
   {
      case PITS_ANTENNA_1:
         antenna_status.Antenna_1 = status;
         break;
      #if 0
      case PITS_ANTENNA_2:
         /* currently antenna 2 is not available in NGK project */
         antenna_status.Antenna_2 = status;
         break;
      case PITS_DAB_ANTENNA:
         if(BoardOptions_PS_Diag_Read_DAB_Present())
         {
            pits_dab_antenna_status = (bool_t)status;
            DAB_Mngr_Set_Antenna(pits_dab_antenna_status);
         }
         break;
      #endif
     default:
         break;
   }
   VIP_Set_Power_Antenna(antenna_status);
}

uint8_t Pits_Misc_Display_Status(void)
{
   return (Pits_Display_Override_Status());
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
uint16_t PITS_Get_AD_Port_Status(uint8_t port)
{
   SAL_Message_T const *msg = NULL;
   SAL_Event_Id_T subscribe_list[] = {EVG_VIP_AD_PORTS_REPORT};
   uint16_t port_status = 0;

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      VIP_Get_AD_Port_Value(port);
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

      if((NULL != msg) && (EVG_VIP_AD_PORTS_REPORT == msg->event_id))
      {
         port_status = Util_Get_Big_Endian_U16((uint8_t *)msg->data);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return(port_status);
}
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
uint16_t PITS_Get_KB_AD_Port_Status(uint8_t port)
{
   SAL_Message_T const *msg = NULL;
   SAL_Event_Id_T subscribe_list[] = {PCAN_APPL_EVG_KEYBOARD_AD_VALUE_REPORT};
   uint16_t port_status = 0;

   if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
   {
      PCAN_Keyboard_AD_Value_Request(port);
      msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 500);

      if((NULL != msg) && (PCAN_APPL_EVG_KEYBOARD_AD_VALUE_REPORT == msg->event_id))
      {
         port_status = Util_Get_Big_Endian_U16((uint8_t *)msg->data);
      }
   }
   SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
   return(port_status);
}
#endif
/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
uint8_t PITS_Get_IO_Port_Status(uint8_t port)
{
   return(0);

}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
bool_t PITS_Get_AD_Port_Available(uint8_t port)
{
   bool_t port_correct = false;
   if(PITS_AD_PORT >= port)
   {
      port_correct = true;
   }
   return(port_correct);
}

/*
 * Please refer to the detailed description in pits_misc_services_cbk.h.
 */
bool_t PITS_Get_IO_Port_Available(uint8_t port)
{
   return(true);
}

/*
 * Please refer to the detailed description in pits_processing_misc.h
 */
void PITS_Clear_All_Overrides (void)
{
   PITS_Misc_Clear_Overrides();
   PITS_Audio_Clear_Overrides();
   PITS_Tuner_Clear_Overrides();
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_GPS_SWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_GPS_SWID(uint8_t * data, uint8_t *data_len)
{
   Success_Or_Fail_T pits_swid_results = FAIL;
   nav_gps_firmware_t nav_gps_firmware;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      NAV_EVG_GPS_VERSION,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Nav_GPS_Get_Version();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 5000);
      if (NULL != response_message)
      {
         if (NAV_EVG_GPS_VERSION == response_message->event_id)
         {
            memcpy(&nav_gps_firmware, response_message->data, sizeof(nav_gps_firmware));
            memcpy(data, nav_gps_firmware.sw_ver, sizeof(nav_gps_firmware.sw_ver));
            *data_len = sizeof(nav_gps_firmware.sw_ver);
            pits_swid_results = SUCCESS;
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_GPS_HWID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_GPS_HWID(uint8_t * data, uint8_t *data_len)
{
   Success_Or_Fail_T pits_swid_results = FAIL;
   nav_gps_firmware_t nav_gps_firmware;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      NAV_EVG_GPS_VERSION,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Nav_GPS_Get_Version();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (NAV_EVG_GPS_VERSION == response_message->event_id)
         {
            memcpy(&nav_gps_firmware, response_message->data, sizeof(nav_gps_firmware));
            memcpy(data, nav_gps_firmware.hw_ver, sizeof(nav_gps_firmware.hw_ver));
            *data_len = sizeof(nav_gps_firmware.hw_ver);
            pits_swid_results = SUCCESS;
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_GPS_ROMID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Misc_GPS_ROMID(uint8_t * data, uint8_t *data_len)
{
   Success_Or_Fail_T pits_swid_results = FAIL;
   nav_gps_firmware_t nav_gps_firmware;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      NAV_EVG_GPS_VERSION,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Nav_GPS_Get_Version();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (NAV_EVG_GPS_VERSION == response_message->event_id)
         {
            memcpy(&nav_gps_firmware, response_message->data, sizeof(nav_gps_firmware));
            memcpy(data, nav_gps_firmware.rom_ver, sizeof(nav_gps_firmware.rom_ver));
            *data_len = sizeof(nav_gps_firmware.rom_ver);
            pits_swid_results = SUCCESS;
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return (pits_swid_results);
}

/*===========================================================================*
 * FUNCTION: PITS_Read_Swmark_data
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 * Reads len data at the given offset into the buffer provided by the first
 * parameter.  Offset is based on the sw marks offset, not the beginning of
 * the flash partition.
 */
/*===========================================================================*/
uint8_t PITS_Read_Swmark_data(uint8_t * data, off_t offset, int len)
{
   uint8_t return_val = FAIL;
   int fd;

   /* read SW Boot information  */
   fd = open(PITS_SW_MARKS_PATH, O_RDONLY);
   if (-1 != fd)
   {
      off_t ret_offset;

      offset += PITS_SW_MARKS_OFFSET;
      ret_offset = lseek(fd, offset, SEEK_SET);
      if (offset == ret_offset)
      {
         ssize_t bytes_read = read(fd, data, len);
         if (bytes_read == len)
         {
            return_val = SUCCESS;
         }
         else
         {
            Tr_Fault_3("Only read %d bytes of %d: %s", bytes_read, len,
                       bytes_read == -1 ? strerror(errno) : "short read");
         }
      }
      else
      {
         Tr_Fault_3("Seek fail, at %d out of %d: %s", (int)ret_offset, (int)offset,
                    ret_offset == (off_t)-1 ? strerror(errno) : "short seek");
      }
      close(fd);
   }
   else
   {
      Tr_Fault_2("Failed to open file %s: %s", PITS_SW_MARKS_PATH, strerror(errno));
   }
   return (return_val);
}
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
uint8_t PITS_Misc_Get_Align_Coordinate(uint8_t * data)
{
   Success_Or_Fail_T ret = FAIL;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      PITS_EV_TSC_COORDINATE_RPT,
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      SAL_Publish(PITS_EV_TSC_COORDINATE_REQ, NULL, 0);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (PITS_EV_TSC_COORDINATE_RPT == response_message->event_id)
         {
            memcpy(data, response_message->data, 4);
            ret = SUCCESS;
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return (ret);
}
#endif

/*===========================================================================*/
/*!
 * @file pits_processing_misc.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  13-Jan-2017 Mandar Bhat
 *  Task ctc_ec#173246: All NAVI related event timeouts are increased to 5000 .
 *
 * 30-Jun-2014 Tim Wang
 * Implemention PITS_Misc_Get_VIP_App_SWID function.
 *
 * 06-Sep-2012 Oscar Vega 20
 * Task kok_basa#117698: 2_0 - Request/Report Read A/D and I/O Ports
 *
 *  06-Sep-2012 Darinka L�pez Rev 19
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Aug-2012 Darinka Lopez 18
 * Taks kok_basa#116889 - Change MID 30/32 - Set standarized Input
 * Fix Include issue. *_cbk.h should not be call in *.h files.
 *
 * 22-Aug-2012 Miguel Garcia 17
 * Include pits display status
 *
 * 16 Aug 2012 Oscar Vega Rev 16
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 7-Aug-2012 Oscar Vega Rev 15
 * Task kok_basa#113317: 2_0 - Request/Report  Get Power Antenna
 *
 * 08-Jun-2012   Manuel Alejandro Robledo Rev 14
 * Task kok_basa#100889:   Implement Get_Set Remote Enabled - pits 2_0
 *
 * 5-Jun-2012 Marco Castillo Rev 13
 * Task kok_basa#100215: mdf_2_0: Microphone AD Value 1A92/93
 *
 * 31-May-2012 Marco Castillo Rev 12
 * Task kok_basa#100232:  Request Microphone Status 1A90/91
 *
 * 29-May-2012 Juan Carlos Castillo  Rev 11
 * Task kok_basa#99843: CLKOUT pin enable/disable PIT
 *
 * 21 May 2012 Miguel Garcia Rev 10
 * Remove call for boot swid to gmdiag
 *
 * 04 May 2012 Miguel Garcia Rev 9
 * Include new swids
 *
 * 1-May-2012 Darinka Lopez  Rev 7
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 12 Apr 2012 Miguel Garcia Rev 6
 * Update boot swid location
 *
 * 14-Mar-2012 Darinka Lopez  Rev 5
 * Task kok_basa#82581: Update part number lenght for SBX program
 * Fix lenght in SWIDs for SBX program.
 *
 * 29-Jan-2012 Darinka Lopez  Rev 4
 * Task kok_basa#79858: Update SWID function for K0R Boot ID.
 * Add callouts functions for swids.
 *
 * 25-Jan-2012 Erick Sanchez Rev 3
 * SCR kok_basa#19539: PITS: MSID 1A - MID 12 - Exit Diagnostics Mode
 * Fix: Implement PITS (MSID 1A - MID 12) to Exit Diagnostics Mode
 *
 * 19-Jan-2012 Oscar Vega  Rev 2
 * SCR kok_basa#19539: PITS: MSID 1A - MID 16 - Module Reset (cold start)
 * SCR kok_basa#19537: PITS: MSID 1A - MID 14 -  Enter Sleep Mode
 * Fix: Implement desip messages to reset and enter sleep mode.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
