/*===========================================================================*/
/**
 * @file pits_processing_bt.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_bt.c~1:csrc:ctc_ec#22 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Mon May 23 14:13:43 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_bt_services.h"
#include "pits_bt_services_cbk.h"
#include "pits_processing_bt.h"
#include "xsal_util.h"


EM_FILENUM(PITS_MODULE_ID_5, 31);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
#if PITS_BLUETOOTH_IS
/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
uint8_t PITS_BT_Get_Name_Req_Processing(uint8_t* data)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] = {BT_DIAG_EVG_PS_DATA};
   BT_DIAG_EVG_PS_DATA_T ps_data;
   uint8_t result = FAIL;

   /* subscribe to the response event */
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      /* trigger the PS read */
      BT_DIAG_PS_Read(BT_DIAG_PS_AP_STORAGE, BT_DIAG_PS_FRIENDLY_NAME, BT_PITS_NAME_LENGTH);

      /* wait for the response event */
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 200); /** @todo what is an appropriate timeout? how long can we block the queue? */

      if (NULL != response_message)
      {
         Tr_Info_Lo("PSKey Response Received");
         if (BT_DIAG_EVG_PS_DATA == response_message->event_id)
         {
            /* parse the response data */
            ps_data = BT_DIAG_Get_PS_Data_Info(response_message->event_id, response_message->data, response_message->data_size);
            Tr_Info_Lo_1("PSKey Received: 0x%4.4X", ps_data.ps_key);
            
            /* is this the same key we were trying to read? */
            if (ps_data.ps_key == BT_DIAG_PS_FRIENDLY_NAME)
            {
               /* check the data length */
               if (BT_PITS_NAME_LENGTH >= ps_data.data_length)
               {
                  Tr_Info_Lo_1("Returning Friendly Name: %s", ps_data.data_pointer);
                  /* copy the data into the outgoing buffer */
                  result = SUCCESS;
                  data[0] = ps_data.data_length;
                  BT_DIAG_Copy_PS_Data(response_message->event_id, response_message->data, response_message->data_size, &data[1]);
               }
               else
               {
                  Tr_Info_Lo_1("Friendly Name data was too large: %d", ps_data.data_length);
                  /* there is really no way this should be possible... */
                  (void)PITS_PBS_Error_Report("BT: Friendly Name data was too large");
               }
            }
         }
      }
      /* unsubscribe from the response event */
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
   return(result);
}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
uint8_t PITS_BT_Get_Align_Cal_Req_Processing(uint8_t* data)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] = {BT_DIAG_EVG_PS_DATA};
   BT_DIAG_EVG_PS_DATA_T ps_data;
   uint8_t result = FAIL;

   /* subscribe to the response event */
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Tr_Info_Lo("Requesting XTAL FTRIM from AP PS");
      /* trigger the PS read */
      BT_DIAG_PS_Read(BT_DIAG_PS_AP_STORAGE, BT_DIAG_PS_XTAL_FTRIM, 1);
      
      /* wait for the response event */
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 200); /** @todo what is an appropriate timeout? how long can we block the queue? */

      if (NULL != response_message)
      {
         Tr_Info_Lo("AP PS Response Received");
         if (BT_DIAG_EVG_PS_DATA == response_message->event_id)
         {
            /* parse the response data */
            ps_data = BT_DIAG_Get_PS_Data_Info(response_message->event_id, response_message->data, response_message->data_size);
            Tr_Info_Lo_1("AP PS Received Key: 0x%X", ps_data.ps_key);
            
            /* is this the same key we were trying to read? */
            if ( (ps_data.ps_store == BT_DIAG_PS_AP_STORAGE) && (ps_data.ps_key == BT_DIAG_PS_XTAL_FTRIM) )
            {
               /* check the data length */
               if (1 == ps_data.data_length)
               {
                  Tr_Info_Lo_1("Returning XTAL FTRIM = 0x%2.2X", ps_data.data_pointer[0]);

                  /* copy the data into the outgoing buffer */
                  result = SUCCESS;
                  data[0] = ps_data.data_pointer[0];
               }
               else if (2 == ps_data.data_length)
               {
                  Tr_Info_Lo_1("Returning XTAL FTRIM = 0x%2.2X", ps_data.data_pointer[1]);

                  /* copy the data into the outgoing buffer */
                  result = SUCCESS;
                  data[0] = ps_data.data_pointer[1];
               }
               else
               {
                  Tr_Info_Lo_1("AP PS data Mis-Match (%d)", ps_data.data_length);
                  /* there is really no way this should be possible... */
                  (void) PITS_PBS_Error_Report("BT: AP PS data was too large");
               }
            }
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
   return(result);

}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
void PITS_BT_DIAG_PS_Write_Name(uint8_t * data, size_t data_size)
{
   BT_DIAG_PS_Write(BT_DIAG_PS_AP_STORAGE, BT_DIAG_PS_FRIENDLY_NAME, &data[0], data_size);
}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
void PITS_BT_DIAG_PS_Write_Cal(uint8_t * data, size_t data_size)
{
   BT_DIAG_PS_Write(BT_DIAG_PS_AP_STORAGE, BT_DIAG_PS_XTAL_FTRIM, &data[0], data_size);
}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
void PITS_HFAP_Diag_Set_Diag_Mode(bool state)
{
   HFAP_Diag_Set_Diag_Mode(state);
}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
void PITS_HFAP_Diag_Set_AEC_State(uint8_t value)
{
   HFAP_Diag_Set_AEC_State(value);
}

/*
* Please refer to the detailed description in pits_processing_bt_cbk.h.
*/
bool PITS_HFAP_Diag_Get_AEC_State(void)
{
   HFAP_AEC_Diag_State_T  echo_state;
   bool state = false;

   echo_state = HFAP_Diag_Get_AEC_State();
   if (echo_state.state == 1)
   {
      state = true;
   }
   return(state);
}
#endif /* BLUETOOTH_IS*/

/*===========================================================================*/
/*!
 * @file pits_processing_bt.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 4
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 26 Jul 2012 Miguel Garcia Rev 3
 * Fix HFAP_Diag_Set_AEC_State call
 *
 * 14-Mar-2012 Oscar Vega  Rev 2
 * SCR task_kok_basa#82989 : Add bluetooth services handler in SBX program
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
