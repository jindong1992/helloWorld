/*===========================================================================*/
/**
 * @file pits_processing_parameters.cpp
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_parameters.c~3:csrc:ctc_ec#4 %
 * @version %version:3 %
 * @author  %derived_by:tzl4my %
 * @date    %date_modified: Mon Jan  9 20:52:15 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "bt_connection_mgr_diag_ps.h"
#include "bt_connection_mgr_ps.h"
#include <fcntl.h>
#include "pits_programming_services.h"
#include "pits_programming_services_cbk.h"
#include "pits_processing_manufacturing.h"
#include "pits_mfg_parameters_ps.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "source_manager_ps.h"
#include "utilities.h"
#include "xsal_util.h"
#include "wifi_proxy.h"
#include "pits_processing_wifi.h"
#include "wifi_mgr_event_types.h"
#include "dimming_gm_ps.h"
#include "gm_dimming_vip_interface_ps.h"
#include "bt_connection_mgr_ps.h"
#include "theft_lock.h"
#include "theft_lock_ps.h"
#include "icr_eng_cals_ps.h"
#include "source_manager_helper.h"
#include "disc_pbk_diag_proxy_types.h"
#include "disc_pbk_diag_proxy.h"
#include "preset_mgr_ps.h"
#include "pits_programming_services.h"
#include "mfg_parameters_ps.h"
#include "hmi_ps.h"
#include "pits_processing_misc.h"
#include "wifi_mgr_ps.h"
#include "pits_bt_services_cbk.h"
#include "diag_proxy.h"
#include "diag_event_id.h"
#include "dtc_handler.h"
#include "diag_ps.h"

EM_FILENUM(PITS_MODULE_ID_5, 45);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_MAN_TRACEABILITY_LEN    16
#define PITS_MTC_COMP_ID_INDX         0
#define PITS_MTC_PN_INDX              2
#define PITS_MTC_SUP_CODE_INDX        6
#define PITS_MTC_ECU_INDX             7
#define PITS_MTC_DAY_INDX            13
#define PITS_MAX_PN_VALID_DIGIT      (99999999)
#define PITS_MAX_LANGUAGES          0x21

#define PITS_FM_STOPPING_INDEX        0
#define PITS_AM_STOPPING_INDEX        1
#define PITS_HIGH_STOPPING_INDEX      0
#define PITS_LOW_STOPPING_INDEX       1

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef uint8_t(*pits_list01_read) (uint8_t * data, uint8_t length);
typedef uint8_t(*pits_list01_write) (uint8_t * data, uint8_t length);

typedef struct PITS_Param_List_01_Tag
{
   uint8_t            size;
   pits_list01_read   funct_read;
   pits_list01_write  funct_write;

} PITS_Param_List_01_T;

typedef struct PITS_Param_List_01_Index_Tag
{
   uint8_t                        param_id;
   const PITS_Param_List_01_T*    table_ptr;
} PITS_Parameter_Index_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
 /*===========================================================================*
 *              PARAMETER LIST 03 - READ/WRITE FUNCTIONS
 *===========================================================================*/
static uint8_t pits_read_param_id_list01(uint8_t * data, uint8_t length, uint8_t id_indx, uint8_t id_elems);
static uint8_t pits_write_param_id_list01(uint8_t * data, uint8_t length, uint8_t id_indx, uint8_t id_elems);

uint8_t PITS_PPS_BT_ADDRESS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BT_ADDRESS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BT_XTAL_FTRIM_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BT_XTAL_FTRIM_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_WIFI_MAC_ADDRESS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_WIFI_MAC_ADDRESS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_WIFI_XTAL_FTRIM_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_WIFI_XTAL_FTRIM_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_LANGUAGE_SELECT_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_LANGUAGE_SELECT_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SPEED_LIMITED_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SPEED_LIMITED_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HW_SW_CONFIG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HW_SW_CONFIG_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DAY_TRIM_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DAY_TRIM_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BRIGHTNESS_LEVEL_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BRIGHTNESS_LEVEL_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_RANGE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_RANGE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_RANGE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_RANGE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STEP_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STEP_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STEP_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STEP_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STOPLEV_HIGH_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STOPLEV_HIGH_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STOPLEV_LOW_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_STOPLEV_LOW_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STOPLEV_HIGH_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STOPLEV_HIGH_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STOPLEV_LOW_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_STOPLEV_LOW_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_SCAN_LEVEL_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_SCAN_LEVEL_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_THEFT_MODE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_THEFT_MODE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_2_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_2_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_3_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_3_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_4_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_4_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_5_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_lDICE_BYTE_5_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_2_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_2_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_3_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_3_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_4_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_4_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_5_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_lDICE_BYTE_5_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_LEVEL_OFFSET_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_LEVEL_OFFSET_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_LEVEL_OFFSET_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_LEVEL_OFFSET_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_IF_MIXER_OFFSET_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_IF_MIXER_OFFSET_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_IF_MIXER_OFFSET_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_IF_MIXER_OFFSET_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_ULT_ST_SEPT_HI_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_ULT_ST_SEPT_HI_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_ULT_ST_SEPT_LO_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_ULT_ST_SEPT_LO_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_WBAM_THRESHOLD_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_WBAM_THRESHOLD_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_USN_THRESHOLD_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_FM_USN_THRESHOLD_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_USN_THRESHOLD_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AM_USN_THRESHOLD_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RDS_CONFIG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RDS_CONFIG_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_TYPE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_TYPE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_LOUDNESS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_LOUDNESS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_PEQ_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_AMP_PEQ_Write(uint8_t * data, uint8_t length);

/*===========================================================================*
 *              PARAMETER LIST 04 - READ/WRITE FUNCTIONS
 *===========================================================================*/


/*===========================================================================*
 *              PARAMETER LIST 05 - READ/WRITE FUNCTIONS
 *===========================================================================*/
uint8_t PITS_PPS_BENCH_TIME_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BENCH_TIME_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RESUME_SOURCE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RESUME_SOURCE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DISPLAY_BRIGHTNESS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DISPLAY_BRIGHTNESS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BT_CONNECED_NUMBER_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_BT_CONNECED_NUMBER_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DTC_CAL_MASK_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DTC_CAL_MASK_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_IGN_CYCLE_COUNTER_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_IGN_CYCLE_COUNTER_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RADIO_OP_HOURS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RADIO_OP_HOURS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_PLAYBACK_OP_HOURS_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_PLAYBACK_OP_HOURS_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_VIN_CODE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_VIN_CODE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_T_BOX_CFG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_T_BOX_CFG_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RSE_CFG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_RSE_CFG_Write(uint8_t * data, uint8_t length);

/*===========================================================================*
 *              PARAMETER LIST 06 - READ/WRITE FUNCTIONS
 *===========================================================================*/
uint8_t PITS_PPS_SUPPLY_ID_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPPLY_ID_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HW_VERSION_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HW_VERSION_Write(uint8_t * data, uint8_t length);
#if defined(GWM_CHB041)
uint8_t PITS_PPS_SUPP_HW_VERSION_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPP_HW_VERSION_Write(uint8_t * data, uint8_t length);
#elif defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
uint8_t PITS_PPS_SUPP_HW_VERSION_1_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPP_HW_VERSION_1_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPP_HW_VERSION_2_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPP_HW_VERSION_2_Write(uint8_t * data, uint8_t length);
#endif
uint8_t PITS_PPS_SYSTEM_CONFIG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SYSTEM_CONFIG_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HMI_CONFIG_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_HMI_CONFIG_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DELPHI_PN_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_DELPHI_PN_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_JULIAN_DATE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_JULIAN_DATE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_ENDMOD_PN_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_ENDMOD_PN_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_GWM_IDENTITY_NUM_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_GWM_IDENTITY_NUM_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_C_MATRIX_VER_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_C_MATRIX_VER_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_MFG_SPAREPART_NUM_Read(uint8_t *data, uint8_t length);
uint8_t PITS_PPS_MFG_SPAREPART_NUM_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SYS_SUPPLIER_ID_Read(uint8_t *data, uint8_t length);
uint8_t PITS_PPS_SYS_SUPPLIER_ID_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_SUPP_SW_VERSION_Read(uint8_t *data, uint8_t length);
uint8_t PITS_PPS_SUPP_SW_VERSION_Write(uint8_t *data, uint8_t length);
uint8_t PITS_PPS_ECU_SERIAL_NUM_Read(uint8_t *data, uint8_t length);
uint8_t PITS_PPS_ECU_SERIAL_NUM_Write(uint8_t *data, uint8_t length);

/*===========================================================================*
 *              PARAMETER LIST 07 - READ/WRITE FUNCTIONS
 *===========================================================================*/
uint8_t PITS_PPS_MFG_USE_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_MFG_USE_Write(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_TUNER_PRESET_Read(uint8_t * data, uint8_t length);
uint8_t PITS_PPS_TUNER_PRESET_Write(uint8_t * data, uint8_t length);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Const Object Definitions
 *===========================================================================*/
/*-------------------------------------------------------------------------------------------------------*
 *                PARAMETER LIST 1 --> Read/Write Tables for parmater List
 *
 *                name,   id,    size,   access   name --> size, Read, Write (functions)
 *-------------------------------------------------------------------------------------------------------*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_FACTORY_PRESET_table[] =
{
   PPS_PARAM_LIST_03_IDS
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_PWM_SETTING_table[] =
{
   PPS_PARAM_LIST_04_IDS
};

#undef PARAM_IDS
/*Note: Write Macro is "No_Write"*/
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_USER_SETTING_table[] =
{
   PPS_PARAM_LIST_05_IDS
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_PRODUCT_INFO_table[] =
{
   PPS_PARAM_LIST_06_IDS
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_DTCS_table[] =
{
   PPS_PARAM_LIST_07_DTCS
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_MANUFACTURING_USE_table[] =
{
   PPS_PARAM_LIST_07_MANUFACTURING_USE
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {size,     PITS_##pmid##_Read,   PITS_##pmid##_Write},
static const PITS_Param_List_01_T pits_list01_PPS_CURRENT_PRESET_PAGE_table[] =
{
   PPS_PARAM_LIST_07_CURRENT_PRESET_PAGE
};

#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  {pmidnum,     pits_list01_##pmid##_table},
static const PITS_Parameter_Index_T pits_list01_index_table[] =
{
   PPS_PARAM_LIST_01_IDS
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * Autogenerate Read Function with invalid answer for unimplemented features
 *===========================================================================*/
/*#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length)\
{\
   return (PARAM_MAX_NUM);\
}
  PPS_PARAM_LIST_02_IDS*/


#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Write(uint8_t * data, uint8_t length)\
{\
   return (PARAM_UNABLE_WRITE);\
}
  PPS_PARAM_LIST_02_IDS

/*===========================================================================*
 *              PARAMETER LIST 01 - READ/WRITE FUNCTIONS
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Read (For List 01 Elements)
 *===========================================================================*
 * @brief Read parameter id elements based on a cosntant table information
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length)\
{                                                          \
   uint8_t ret_result;                      \
   ret_result = pits_read_param_id_list01(&data[0], length, pmidnum-1, Num_Elems(pits_list01_##pmid##_table));\
   return(ret_result);                                                                                     \
}
  PPS_PARAM_LIST_01_IDS


/*===========================================================================*
 * FUNCTION: pits_read_param_id_list01 (For List 01 Elements)
 *===========================================================================*
 * @brief Read parameter id elements based on a constant table information
 *
 */
/*===========================================================================*/
uint8_t pits_read_param_id_list01(uint8_t * data, uint8_t length, uint8_t id_indx, uint8_t id_elems)
{
   uint8_t ret_result = PARAM_SUCCESS;
   uint8_t pit_indx = 0;
   uint8_t pit_length = 0;
   uint8_t indx;
   memset (data, 0,  length);
   for (indx = 0; ((PARAM_SUCCESS == ret_result) && (indx < id_elems)); indx++)
   {
      pit_length = pits_list01_index_table[id_indx].table_ptr[indx].size;
      ret_result = pits_list01_index_table[id_indx].table_ptr[indx].funct_read(&data[pit_indx], pit_length);
      pit_indx += pit_length;

   }
   return(ret_result);
}


/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Write (For List 01 Elements)
 *===========================================================================*
 * @brief Write parameter id elements based on a constant table information
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Write(uint8_t * data, uint8_t length)\
{                                                          \
   uint8_t ret_result;                      \
   ret_result = pits_write_param_id_list01(&data[0], length, pmidnum-1, Num_Elems(pits_list01_##pmid##_table));\
   return(ret_result);                                                                                     \
}
  PPS_PARAM_LIST_01_IDS


/*===========================================================================*
 * FUNCTION: pits_write_param_id_list01 (For List 01 Elements)
 *===========================================================================*
 * @brief Write parameter id elements based on a cosntant table information
 *
 */
/*===========================================================================*/
uint8_t pits_write_param_id_list01(uint8_t * data, uint8_t length, uint8_t id_indx, uint8_t id_elems)
{
   uint8_t ret_result = PARAM_SUCCESS;
   uint8_t pit_indx = 0;
   uint8_t pit_length = 0;
   uint8_t indx;

   for (indx = 0; ((PARAM_SUCCESS == ret_result) && (indx < id_elems)); indx++)
   {
      pit_length = pits_list01_index_table[id_indx].table_ptr[indx].size;
      ret_result = pits_list01_index_table[id_indx].table_ptr[indx].funct_write(&data[pit_indx], pit_length);
      pit_indx += pit_length;

   }
   return(ret_result);
}

/*===========================================================================*
 *              PARAMETER LIST 02 - READ/WRITE FUNCTIONS
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Read_MD5_cksum
 *===========================================================================*
 *
 * @brief Read an MD5 checksum parameter from sw marks
 * @return PARAM_SUCCESS or PARAM_NO_ID_EXIST
 * @param [out] data
 *   Buffer for MD5 data, at least PITS_SW_MARKS_MD5_SIZE/2 bytes
 * @param [in] index
 *   Index of MD5 cksum to lead, starting at 0
 */
/*===========================================================================*/
static uint8_t PITS_Read_MD5_cksum(uint8_t *data, uint16_t par_index)
{
   uint8_t buffer[PITS_SW_MARKS_MD5_SIZE];
   uint8_t result;

   const off_t offset = PITS_SW_MARKS_REFLASH_OFFSET + (par_index * PITS_SW_MARKS_MD5_OFFSET);

   if (PITS_Read_Swmark_data(buffer, offset, PITS_SW_MARKS_MD5_SIZE) == SUCCESS)
   {
      unsigned int idx;

      /*convert to hex*/
      for (idx = 0; idx < PITS_SW_MARKS_MD5_SIZE; idx++)
      {
         uint8_t digit = PITS_Man_Map_Ascii_To_Hex_MD5(buffer[idx]);
         if ((idx % 2) == 0)
         {
            *data = digit << 4;
         }
         else
         {
            *data |= digit;
            data++;
         }
      }
      result = PARAM_SUCCESS;
   }
   else
   {
      Tr_Fault_1("Couldn't read parameter %d", par_index);
      result = PARAM_NO_ID_EXIST;
   }

   return result;
}


/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Read (For List 02 Elements of MD5)
 *===========================================================================*
 * @brief Read parameter id elements of md5
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length)\
{                                                         \
   return PITS_Read_MD5_cksum(data, pmidnum - 1);         \
}
  PPS_PARAM_LIST_02_IDS

/*===========================================================================*
 *              PARAMETER LIST 03 - READ/WRITE FUNCTIONS
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_PPS_BT_ADDRESS_Read
 *===========================================================================*
 * @brief Read PITS_PPS_BT_ADDRESS_Read information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_ADDRESS_Read(uint8_t * data, uint8_t length)
{
   BT_CM_Device_Address_T bt_addr;

   BT_CM_PS_Get_BDAddress(&bt_addr);
   memcpy(data, bt_addr, sizeof(BT_CM_Device_Address_T));

   return(PARAM_SUCCESS);
}

 /*===========================================================================*
 * FUNCTION: PITS_PPS_BT_ADDRESS_Write
 *===========================================================================*
 * @brief Write PPS_BT_ADDRESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_ADDRESS_Write(uint8_t * data, uint8_t length)
{
   uint8_t bt_index;
   uint8_t bt_addr[6] = {0};

   for (bt_index = 0; bt_index < length; bt_index++)
   {
      bt_addr[bt_index] = data[bt_index];
   }
   BT_CM_PS_Put_BDAddress(&bt_addr[0]);

   return(PARAM_SUCCESS);
}

 /*===========================================================================*
 * FUNCTION: PITS_PPS_BT_XTAL_FTRIM_Read
 *===========================================================================*
 * @brief Read PPS_BT_XTAL_FTRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_XTAL_FTRIM_Read(uint8_t * data, uint8_t length)
{
/*   PITS_BT_Get_Align_Cal_Req_Processing(data);   */
   data[0] = (uint8_t)BT_CM_PS_Get_XTAL_FTrim();

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BT_XTAL_FTRIM_Write
 *===========================================================================*
 * @brief Write PPS_BT_XTAL_FTRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_XTAL_FTRIM_Write(uint8_t * data, uint8_t length)
{
   PITS_BT_DIAG_PS_Write_Cal(data, 1);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_WIFI_MAC_ADDRESS_Read
 *===========================================================================*
 * @brief Read PPS_WIFI_MAC_ADDRESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_WIFI_MAC_ADDRESS_Read(uint8_t * data, uint8_t length)
{
   PITS_WIFI_Get_Mac_Addr(data);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_WIFI_MAC_ADDRESS_Write
 *===========================================================================*
 * @brief Write PPS_WIFI_MAC_ADDRESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_WIFI_MAC_ADDRESS_Write(uint8_t * data, uint8_t length)
{
   if (length == 6)
   {
      PITS_WIFI_Set_Mac_Addr(data);
   }
   else
   {
      Tr_Warn_1("Invalid WIFI MAC address length: %d", length);
   }


   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_WIFI_XTAL_FTRIM_Read
 *===========================================================================*
 * @brief Read PPS_WIFI_XTAL_FTRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_WIFI_XTAL_FTRIM_Read(uint8_t * data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_SUCCESS,
      WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_FAILED
   };

   /* Request SWID information*/
   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Wifi_Proxy_Diagnose_Get_Final_XtalTrim();

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      {
         if (WIFI_MGR_PUBLISH_GET_FINAL_XTALTRIM_SUCCESS == response_message->event_id)
         {
             data[0] = ((uint8_t *)response_message->data)[0];
         }
         else
         {
            Tr_Warn("Get WIFI XTAL Final value failed!");
         }
         SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
      }
  }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_WIFI_XTAL_FTRIM_Write
 *===========================================================================*
 * @brief Write PPS_WIFI_XTAL_FTRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_WIFI_XTAL_FTRIM_Write(uint8_t * data, uint8_t length)
{
   Wifi_Proxy_Diagnose_Set_Final_XtalTrim(data[0]);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_LANGUAGE_SELECT_Read
 *===========================================================================*
 * @brief Read PPS_LANGUAGE_SELECT information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_LANGUAGE_SELECT_Read(uint8_t * data, uint8_t length)
{
   data[0] = HMI_PS_Get_Current_Language();

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_LANGUAGE_SELECT_Write
 *===========================================================================*
 * @brief Write PPS_LANGUAGE_SELECT information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_LANGUAGE_SELECT_Write(uint8_t * data, uint8_t length)
{
   HMI_PS_Put_Current_Language((PS_LANGUAGE_T)data[0]);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SPEED_LIMITED_Read
 *===========================================================================*
 * @brief Read PPS_SPEED_LIMITED information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SPEED_LIMITED_Read(uint8_t * data, uint8_t length)
{
   Limit_Speed_Status_Value_T limit_speed;
   limit_speed = Limit_Speed_Status_PS_Get();

   data[0] = limit_speed;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SPEED_LIMITED_Write
 *===========================================================================*
 * @brief Write PPS_SPEED_LIMITED information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SPEED_LIMITED_Write(uint8_t * data, uint8_t length)
{
   Limit_Speed_Status_PS_Set((Limit_Speed_Status_Value_T)data[0]);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HW_SW_CONFIG_Read
 *===========================================================================*
 * @brief Read PPS_HW_SW_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HW_SW_CONFIG_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HW_SW_CONFIG_Write
 *===========================================================================*
 * @brief Write PPS_HW_SW_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HW_SW_CONFIG_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DAY_TRIM_Read
 *===========================================================================*
 * @brief Read PPS_DAY_TRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DAY_TRIM_Read(uint8_t * data, uint8_t length)
{
   Whole_DayTrim_T day_trim;

   Mfg_PS_Get_RTC_Daytrim(day_trim);
   memcpy(data, &day_trim[0], sizeof(Whole_DayTrim_T));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DAY_TRIM_Write
 *===========================================================================*
 * @brief Write PPS_DAY_TRIM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DAY_TRIM_Write(uint8_t * data, uint8_t length)
{
   uint8_t day_trim_index;
   Whole_DayTrim_T day_trim = {0x00};

   for (day_trim_index = 0; day_trim_index < length; ++day_trim_index)
   {
      day_trim[day_trim_index] = data[day_trim_index];
   }
   Mfg_PS_Put_RTC_Daytrim(day_trim);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BRIGHTNESS_LEVEL_Read
 *===========================================================================*
 * @brief Read PPS_BRIGHTNESS_LEVEL information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BRIGHTNESS_LEVEL_Read(uint8_t * data, uint8_t length)
{
   Brightness_Level_T brightness_level;

   brightness_level = Brightness_Level_PS_Get();
   data[0] = brightness_level.night_highest_max;
   data[1] = brightness_level.day_highest;
   data[2] = brightness_level.night_high_max;
   data[3] = brightness_level.day_high;
   data[4] = brightness_level.night_mid_max;
   data[5] = brightness_level.day_mid;
   data[6] = brightness_level.night_low_max;
   data[7] = brightness_level.day_low;
   data[8] = brightness_level.night_lowest_max;
   data[9] = brightness_level.day_lowest;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BRIGHTNESS_LEVEL_Write
 *===========================================================================*
 * @brief Write PPS_BRIGHTNESS_LEVEL information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BRIGHTNESS_LEVEL_Write(uint8_t * data, uint8_t length)
{
   Brightness_Level_T brightness_level = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

   brightness_level.night_highest_max = data[0];
   brightness_level.day_highest = data[1];
   brightness_level.night_high_max = data[2];
   brightness_level.day_high = data[3];
   brightness_level.night_mid_max = data[4];
   brightness_level.day_mid = data[5];
   brightness_level.night_low_max = data[6];
   brightness_level.day_low = data[7];
   brightness_level.night_lowest_max = data[8];
   brightness_level.day_lowest = data[9];
   Brightness_Level_PS_Set(brightness_level);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_RANGE_Read
 *===========================================================================*
 * @brief Read PPS_AM_RANGE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_RANGE_Read(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   data[0] = region.AM_Range;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_RANGE_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_RANGE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_RANGE_Write(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   region.AM_Range = data[0];
   PS_Region_Config_Put(&region);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_PPS_AM_RANGE_Read
 *===========================================================================*
 * @brief Read PPS_FM_RANGE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_RANGE_Read(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   data[0] = region.FM_Range;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_RANGE_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_RANGE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_RANGE_Write(uint8_t * data, uint8_t length)
{
  Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   region.FM_Range = data[0];
   PS_Region_Config_Put(&region);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_TYPE_Read
 *===========================================================================*
 * @brief Read PPS_AMP_TYPE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_TYPE_Read(uint8_t *data, uint8_t length)
{
   bool_t ampType;

   ampType = Mfg_PS_Get_Amplifier_Type();
   memcpy(data, &ampType, sizeof(ampType));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_TYPE_Write
 *===========================================================================*
 * @brief Wrote PPS_AMP_TYPE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_TYPE_Write(uint8_t *data, uint8_t length)
{
   bool_t ampType;

   memcpy(&ampType, data, sizeof(ampType));
   Mfg_PS_Set_Amplifier_Type(ampType);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_LOUDNESS_Read
 *===========================================================================*
 * @brief Read PPS_AMP_LOUDNESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_LOUDNESS_Read(uint8_t *data, uint8_t length)
{
   bool_t enableLoudness;

   enableLoudness = Mfg_PS_Get_Amp_Loudness();
   memcpy(data, &enableLoudness, sizeof(enableLoudness));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_LOUDNESS_Write
 *===========================================================================*
 * @brief Wrote PPS_AMP_LOUDNESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_LOUDNESS_Write(uint8_t *data, uint8_t length)
{
   bool_t enableLoudness;

   memcpy(&enableLoudness, data, sizeof(enableLoudness));
   Mfg_PS_Set_Amp_Loudness(enableLoudness);

   return(PARAM_SUCCESS);

}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_PEQ_Read
 *===========================================================================*
 * @brief Read PPS_AMP_PEQ information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_PEQ_Read(uint8_t *data, uint8_t length)
{
   bool_t enablePeq;

   enablePeq = Mfg_PS_Get_Amp_Peq();
   memcpy(data, &enablePeq, sizeof(enablePeq));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AMP_PEQ_Write
 *===========================================================================*
 * @brief Wrote PPS_AMP_PEQ information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AMP_PEQ_Write(uint8_t *data, uint8_t length)
{
   bool_t enablePeq;

   memcpy(&enablePeq, data, sizeof(enablePeq));
   Mfg_PS_Set_Amp_Peq(enablePeq);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_STEP_Read
 *===========================================================================*
 * @brief Read PPS_AM_STEP information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STEP_Read(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   data[0] = region.AM_Step;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_PPS_AM_RANGE_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_STEP information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STEP_Write(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   region.AM_Step= data[0];
   PS_Region_Config_Put(&region);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_PPS_AM_RANGE_Read
 *===========================================================================*
 * @brief Read PPS_FM_STEP information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STEP_Read(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   data[0] = region.FM_Step;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_STEP_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_STEP information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STEP_Write(uint8_t * data, uint8_t length)
{
   Tuner_Region_Config_T region;

   region = PS_Region_Config_Get();
   region.FM_Step= data[0];
   PS_Region_Config_Put(&region);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_STOPLEV_HIGH_Read
 *===========================================================================*
 * @brief Read PPS_AM_STOPLEV_HIGH information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STOPLEV_HIGH_Read(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   data[0] = pit_stopping_levels.tuner_stoping_levels[1][0];

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_STOPLEV_HIGH_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_STOPLEV_HIGH information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STOPLEV_HIGH_Write(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   pit_stopping_levels.tuner_stoping_levels[1][0] = data[0];
   PS_stopping_levels_Put(&pit_stopping_levels);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_STOPLEV_LOW_Read
 *===========================================================================*
 * @brief Read PPS_AM_STOPLEV_LOW information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STOPLEV_LOW_Read(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   data[0] = pit_stopping_levels.tuner_stoping_levels[1][1];

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_STOPLEV_LOW_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_STOPLEV_LOW information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_STOPLEV_LOW_Write(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   pit_stopping_levels.tuner_stoping_levels[1][1] = data[0];
   PS_stopping_levels_Put(&pit_stopping_levels);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_STOPLEV_HIGH_Read
 *===========================================================================*
 * @brief Read PPS_FM_STOPLEV_HIGH information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STOPLEV_HIGH_Read(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   data[0] = pit_stopping_levels.tuner_stoping_levels[0][0];

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_STOPLEV_HIGH_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_STOPLEV_HIGH information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STOPLEV_HIGH_Write(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   pit_stopping_levels.tuner_stoping_levels[0][0] = data[0];
   PS_stopping_levels_Put(&pit_stopping_levels);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_STOPLEV_LOW_Read
 *===========================================================================*
 * @brief Read PPS_FM_STOPLEV_LOW information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STOPLEV_LOW_Read(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   data[0] = pit_stopping_levels.tuner_stoping_levels[0][1];

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_STOPLEV_LOW_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_STOPLEV_LOW information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_STOPLEV_LOW_Write(uint8_t * data, uint8_t length)
{
   Tuner_Stopping_Levels_T pit_stopping_levels;

   pit_stopping_levels = PS_stopping_levels_Get();
   pit_stopping_levels.tuner_stoping_levels[0][1] = data[0];
   PS_stopping_levels_Put(&pit_stopping_levels);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_SCAN_LEVEL_Read
 *===========================================================================*
 * @brief Read PPS_FM_SCAN_LEVEL information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_SCAN_LEVEL_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_SCAN_LEVEL_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_SCAN_LEVEL information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_SCAN_LEVEL_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_THEFT_MODE_Read
 *===========================================================================*
 * @brief Read PPS_THEFT_MODE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_THEFT_MODE_Read(uint8_t * data, uint8_t length)
{
#if 0
   Theft_Handler_Mode_T theft_mode;

   theft_mode = Theft_PS_Get_Mode();
   data[0] = theft_mode;
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_THEFT_MODE_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_SCAN_LEVEL information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_THEFT_MODE_Write(uint8_t * data, uint8_t length)
{
#if 0
   Theft_PS_Put_Mode((Theft_Handler_Mode_T)data[0]);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_2_Read
 *===========================================================================*
 * @brief Read PPS_AM_lDICE_BYTE_2 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_2_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_2_Write
 *===========================================================================*
 * @brief Write PPS_AM_lDICE_BYTE_2 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_2_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_3_Read
 *===========================================================================*
 * @brief Read PPS_AM_lDICE_BYTE_3 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_3_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_3_Write
 *===========================================================================*
 * @brief Write PPS_AM_lDICE_BYTE_3 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_3_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_4_Read
 *===========================================================================*
 * @brief Read PPS_AM_lDICE_BYTE_4 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_4_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_4_Write
 *===========================================================================*
 * @brief Write PPS_AM_lDICE_BYTE_4 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_4_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_5_Read
 *===========================================================================*
 * @brief Read PPS_AM_lDICE_BYTE_5 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_5_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_lDICE_BYTE_5_Write
 *===========================================================================*
 * @brief Write PPS_AM_lDICE_BYTE_5 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_lDICE_BYTE_5_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_2_Read
 *===========================================================================*
 * @brief Read PPS_FM_lDICE_BYTE_2 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_2_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_2_Write
 *===========================================================================*
 * @brief Write PPS_FM_lDICE_BYTE_2 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_2_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_3_Read
 *===========================================================================*
 * @brief Read PPS_FM_lDICE_BYTE_3 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_3_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_3_Write
 *===========================================================================*
 * @brief Write PPS_FM_lDICE_BYTE_3 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_3_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_4_Read
 *===========================================================================*
 * @brief Read PPS_FM_lDICE_BYTE_4 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_4_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_4_Write
 *===========================================================================*
 * @brief Write PPS_FM_lDICE_BYTE_4 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_4_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_5_Read
 *===========================================================================*
 * @brief Read PPS_FM_lDICE_BYTE_5 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_5_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_lDICE_BYTE_5_Write
 *===========================================================================*
 * @brief Write PPS_FM_lDICE_BYTE_5 information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_lDICE_BYTE_5_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_LEVEL_OFFSET_Read
 *===========================================================================*
 * @brief Read PPS_FM_LEVEL_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_LEVEL_OFFSET_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_LEVEL_OFFSET_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_LEVEL_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_LEVEL_OFFSET_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_LEVEL_OFFSET_Read
 *===========================================================================*
 * @brief Read PPS_AM_LEVEL_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_LEVEL_OFFSET_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_LEVEL_OFFSET_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_LEVEL_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_LEVEL_OFFSET_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_IF_MIXER_OFFSET_Read
 *===========================================================================*
 * @brief Read PPS_FM_IF_MIXER_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_IF_MIXER_OFFSET_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_IF_MIXER_OFFSET_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_IF_MIXER_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_IF_MIXER_OFFSET_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_IF_MIXER_OFFSET_Read
 *===========================================================================*
 * @brief Read PPS_AM_IF_MIXER_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_IF_MIXER_OFFSET_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_IF_MIXER_OFFSET_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_IF_MIXER_OFFSET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_IF_MIXER_OFFSET_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_ULT_ST_SEPT_HI_Read
 *===========================================================================*
 * @brief Read PPS_FM_ULT_ST_SEPT_HI information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_ULT_ST_SEPT_HI_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_ULT_ST_SEPT_HI_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_ULT_ST_SEPT_HI information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_ULT_ST_SEPT_HI_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_ULT_ST_SEPT_LO_Read
 *===========================================================================*
 * @brief Read PPS_FM_ULT_ST_SEPT_LO information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_ULT_ST_SEPT_LO_Read(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_ULT_ST_SEPT_LO_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_ULT_ST_SEPT_LO information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_ULT_ST_SEPT_LO_Write(uint8_t * data, uint8_t length)
{
     /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_WBAM_THRESHOLD_Read
 *===========================================================================*
 * @brief Read PPS_FM_WBAM_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_WBAM_THRESHOLD_Read(uint8_t * data, uint8_t length)
{
#if 0
   data[0] = AMFM_Mgr_Get_FM_WBAM_Values(1);
   data[1] = AMFM_Mgr_Get_FM_WBAM_Values(0);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_WBAM_THRESHOLD_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_WBAM_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_WBAM_THRESHOLD_Write(uint8_t * data, uint8_t length)
{
#if 0
     AMFM_Mgr_Set_FM_WBAM_Values(1, data[0]);
     AMFM_Mgr_Set_FM_WBAM_Values(0, data[1]);
#endif
    return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_USN_THRESHOLD_Read
 *===========================================================================*
 * @brief Read PPS_FM_USN_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_USN_THRESHOLD_Read(uint8_t * data, uint8_t length)
{
#if 0
   data[0] = AMFM_Mgr_Get_FM_USN_Values(1);
   data[1] = AMFM_Mgr_Get_FM_USN_Values(0);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_FM_USN_THRESHOLD_Write
 *===========================================================================*
 * @brief Wrote PPS_FM_USN_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_FM_USN_THRESHOLD_Write(uint8_t * data, uint8_t length)
{
#if 0
   AMFM_Mgr_Set_FM_USN_Values(1, data[0]);
   AMFM_Mgr_Set_FM_USN_Values(0, data[1]);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_USN_THRESHOLD_Read
 *===========================================================================*
 * @brief Read PPS_AM_USN_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_USN_THRESHOLD_Read(uint8_t * data, uint8_t length)
{
#if 0
   data[0] = AMFM_Mgr_Get_AM_USN_Values(1);
   data[1] = AMFM_Mgr_Get_AM_USN_Values(0);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_AM_USN_THRESHOLD_Write
 *===========================================================================*
 * @brief Wrote PPS_AM_USN_THRESHOLD information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_AM_USN_THRESHOLD_Write(uint8_t * data, uint8_t length)
{
#if 0
   AMFM_Mgr_Set_AM_USN_Values(1, data[0]);
   AMFM_Mgr_Set_AM_USN_Values(0, data[1]);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RDS_CONFIG_Read
 *===========================================================================*
 * @brief Read PPS_RDS_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RDS_CONFIG_Read(uint8_t * data, uint8_t length)
{
   data[0] = PS_RDS_CONFIG_Get();

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RDS_CONFIG_Write
 *===========================================================================*
 * @brief Wrote PPS_RDS_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RDS_CONFIG_Write(uint8_t * data, uint8_t length)
{
     PS_RDS_CONFIG_Put(&data[0]);

   return(PARAM_SUCCESS);
}


/*===========================================================================*
 *              PARAMETER LIST 04 - READ/WRITE FUNCTIONS
 *===========================================================================*/

 /*===========================================================================*
 * FUNCTION: PITS_##pmid##_Read (For PWM Brightness Duty)
 *===========================================================================*
 * @brief Read PWM Brightness Duty information
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length)\
{ \
   PWM_Brighteness_Duty_T duty; \
   \
   duty = Brightness_Duty_PS_Get(); \
   if (pmidnum%2 == 0) \
   {\
      data[0] = duty.pwm_duty[(pmidnum - 1)/2].brightness_duty; \
   } \
   else \
   {\
      data[0] = duty.pwm_duty[(pmidnum - 1)/2].pwm_point; \
   } \
   return(PARAM_SUCCESS); \
}
   PPS_PARAM_LIST_04_IDS


/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Write (For PWM Brightness Duty)
 *===========================================================================*
 * @brief Write DTCs information
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)  \
uint8_t PITS_##pmid##_Write(uint8_t * data, uint8_t length)   \
{ \
   PWM_Brighteness_Duty_T duty; \
   \
   duty = Brightness_Duty_PS_Get(); \
   if (pmidnum%2 == 0) \
   {\
      duty.pwm_duty[(pmidnum - 1)/2].brightness_duty = data[0]; \
   } \
   else \
   {\
      duty.pwm_duty[(pmidnum - 1)/2].pwm_point = data[0]; \
   } \
   \
   Brightness_Duty_PS_Set(duty); \
   \
   return (PARAM_SUCCESS); \
}
  PPS_PARAM_LIST_04_IDS


/*===========================================================================*
 *              PARAMETER LIST 05 - READ/WRITE FUNCTIONS
 *===========================================================================*/

 /*===========================================================================*
 * FUNCTION: PITS_PPS_BENCH_TIME_Read
 *===========================================================================*
 * @brief Read PPS_BENCH_TIME information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BENCH_TIME_Read(uint8_t * data, uint8_t length)
{
   uint32_t bench_timer;

   bench_timer = IcrEngCals_PS_Get_Bench_Mode_Timer_Value();
   Util_Put_Big_Endian_U32(data, bench_timer);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BENCH_TIME_Write
 *===========================================================================*
 * @brief Write PPS_BENCH_TIME information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BENCH_TIME_Write(uint8_t * data, uint8_t length)
{
   uint32_t bench_timer;

   bench_timer = Util_Get_Big_Endian_U32(data);
   IcrEngCals_PS_Put_Bench_Mode_Timer(bench_timer);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RESUME_SOURCE_Read
 *===========================================================================*
 * @brief Read PPS_RESUME_SOURCE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RESUME_SOURCE_Read(uint8_t * data, uint8_t length)
{
   SSM_Source_T ssm_src;
   PITS_Source_T  pits_src = PITS_SRC_NONE;

   SSM_Get_Last_User_Source(0, &ssm_src);
   pits_audio_map_ssm_src_to_pits_src(ssm_src.type,  &pits_src);
   data[0] = pits_src;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RESUME_SOURCE_Write
 *===========================================================================*
 * @brief Write PPS_RESUME_SOURCE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RESUME_SOURCE_Write(uint8_t * data, uint8_t length)
{
   pits_audio_set_ssm_source_present(data[0]);
#if 0
   pits_audio_set_ssm_source_last_source(0, data[0]);

   Audio_Logical_Src_T logical_source;

   pits_audio_map_pits_src_to_logical_src(data[0], &logical_source);
   SSM_Store_Source_Type(data[0], data[0]);

   SSM_Store_Source_Type(SSM_SRC_FM, 0);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DISPLAY_BRIGHTNESS_Read
 *===========================================================================*
 * @brief Read PPS_DISPLAY_BRIGHTNESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DISPLAY_BRIGHTNESS_Read(uint8_t * data, uint8_t length)
{
   HMI_Brightness_Value_T brightness;

   brightness = Dimming_PS_Get_HMI_Brightness();

   data[0] = brightness;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DISPLAY_BRIGHTNESS_Write
 *===========================================================================*
 * @brief Write PPS_DISPLAY_BRIGHTNESS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DISPLAY_BRIGHTNESS_Write(uint8_t * data, uint8_t length)
{
   HMI_Brightness_Value_T brightness;

   brightness = data[0];
   Dimming_PS_Set_HMI_Brightness(brightness);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BT_CONNECED_NUMBER_Read
 *===========================================================================*
 * @brief Read PPS_BT_CONNECED_NUMBER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_CONNECED_NUMBER_Read(uint8_t * data, uint8_t length)
{
   data[0] = (uint8_t)Pits_Get_Diag_Btdevices_Number();

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_BT_CONNECED_NUMBER_Write
 *===========================================================================*
 * @brief Write PPS_BT_CONNECED_NUMBER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_BT_CONNECED_NUMBER_Write(uint8_t * data, uint8_t length)
{
   /*to do*/

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DTC_CAL_MASK_Read
 *===========================================================================*
 * @brief Read PPS_DTC_CAL_MASK information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DTC_CAL_MASK_Read(uint8_t * data, uint8_t length)
{
   DTC_Cal_Mask_T cal_mask;

   cal_mask = DTC_Cal_Mask_PS_Get();
   memcpy(data, &(cal_mask.dtc_cal_mask[0]), length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DTC_CAL_MASK_Write
 *===========================================================================*
 * @brief Write PPS_DTC_CAL_MASK information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DTC_CAL_MASK_Write(uint8_t * data, uint8_t length)
{
   DTC_Cal_Mask_T cal_mask;

   memcpy(&(cal_mask.dtc_cal_mask[0]), data, length);
   DTC_Cal_Mask_PS_Set(cal_mask);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_IGN_CYCLE_COUNTER_Read
 *===========================================================================*
 * @brief Read PPS_IGN_CYCLE_COUNTER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_IGN_CYCLE_COUNTER_Read(uint8_t * data, uint8_t length)
{
   Disc_Pbk_Diag_Playback_Error_t error;

   error = Disc_Pbk_Diag_Get_Playback_Error();
   data[0] = error.error_count.cd_focus;

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_IGN_CYCLE_COUNTER_Write
 *===========================================================================*
 * @brief Write PPS_IGN_CYCLE_COUNTER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_IGN_CYCLE_COUNTER_Write(uint8_t * data, uint8_t length)
{
   Disc_Pbk_Diag_Clear_Error(data[0]);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RADIO_OP_HOURS_Read
 *===========================================================================*
 * @brief Read PPS_RADIO_OP_HOURS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RADIO_OP_HOURS_Read(uint8_t * data, uint8_t length)
{
#if 0
   Operation_Time_T radio_time = Operation_Time_PS_Get();
   Util_Put_Big_Endian_U16(data, radio_time.radio_operation_time);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_RADIO_OP_HOURS_Write
 *===========================================================================*
 * @brief Write PPS_RADIO_OP_HOURS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RADIO_OP_HOURS_Write(uint8_t * data, uint8_t length)
{
#if 0
   Operation_Time_T operation_time;
   uint16_t radio_time;

   radio_time = Util_Get_Big_Endian_U16(data);
   operation_time.radio_operation_time = radio_time;
   Operation_Time_PS_Set(operation_time);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_PLAYBACK_OP_HOURS_Read
 *===========================================================================*
 * @brief Read PPS_PLAYBACK_OP_HOURS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_PLAYBACK_OP_HOURS_Read(uint8_t * data, uint8_t length)
{
#if 0
   Operation_Time_T radio_time = Operation_Time_PS_Get();
   Util_Put_Big_Endian_U16(data, radio_time.playback_operation_time);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_PLAYBACK_OP_HOURS_Write
 *===========================================================================*
 * @brief Write PPS_PLAYBACK_OP_HOURS information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_PLAYBACK_OP_HOURS_Write(uint8_t * data, uint8_t length)
{
#if 0
   Operation_Time_T operation_time;
   uint16_t playback_time;

   playback_time = Util_Get_Big_Endian_U16(data);
   operation_time.playback_operation_time = playback_time;
   Operation_Time_PS_Set(operation_time);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_VIN_CODE_Read
 *===========================================================================*
 * @brief Read PPS_VIN_CODE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_VIN_CODE_Read(uint8_t * data, uint8_t length)
{
#if 0
   data[0] = Theft_PS_Get_VIN_Learnt_Count();
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_VIN_CODE_Write
 *===========================================================================*
 * @brief Write PPS_VIN_CODE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_VIN_CODE_Write(uint8_t * data, uint8_t length)
{
#if 0
   Theft_PS_Put_VIN_Learnt_Count(data[0]);
#endif
   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_T_BOX_CFG_Read
 *===========================================================================*
 * @brief Read PPS_T_BOX_CFG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_T_BOX_CFG_Read(uint8_t * data, uint8_t length)
{
#if defined(GWM_CHB041)
   Vehicle_Configure_T vehicle_cfg = {0x00};

   vehicle_cfg = HMI_PS_Get_Vehicle_Configure();
   data[0] = vehicle_cfg.t_box;
#elif defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
   NE_Vehicle_Configure_T vehicle_cfg = {0x00};

   vehicle_cfg = HMI_PS_Get_NE_Vehicle_Configure();
   data[0] = vehicle_cfg.t_box;
#endif

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_T_BOX_CFG_Write
 *===========================================================================*
 * @brief Write PPS_T_BOX_CFG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_T_BOX_CFG_Write(uint8_t * data, uint8_t length)
{

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_T_BOX_CFG_Read
 *===========================================================================*
 * @brief Read PPS_T_BOX_CFG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RSE_CFG_Read(uint8_t * data, uint8_t length)
{
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
   NE_Vehicle_Configure_T vehicle_cfg = {0x00};

   vehicle_cfg = HMI_PS_Get_NE_Vehicle_Configure();
   data[0] = vehicle_cfg.rear_seat_entertainment_present;
#endif

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_T_BOX_CFG_Write
 *===========================================================================*
 * @brief Write PPS_T_BOX_CFG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_RSE_CFG_Write(uint8_t * data, uint8_t length)
{

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 *              PARAMETER LIST 06 - READ/WRITE FUNCTIONS
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPPLY_ID_Read
 *===========================================================================*
 * @brief Read PPS_SUPPLY_ID information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPPLY_ID_Read(uint8_t * data, uint8_t length)
{
   Identify_Code_T identify_code;

    identify_code = Identify_Code_PS_Get();
   memcpy(data, &identify_code, sizeof(Identify_Code_T));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPPLY_ID_Write
 *===========================================================================*
 * @brief Write PPS_SUPPLY_ID information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPPLY_ID_Write(uint8_t * data, uint8_t length)
{
   Identify_Code_T identify_code;

   memcpy(&identify_code, data, sizeof(Identify_Code_T));
   Identify_Code_PS_Set(identify_code);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HW_VERSION_Read
 *===========================================================================*
 * @brief Read PPS_HW_VERSION information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HW_VERSION_Read(uint8_t * data, uint8_t length)
{
   GWM_HW_Version_T hw_version;

   hw_version = GWM_HW_Version_PS_Get();
   memcpy(data, (void*)&hw_version, sizeof(GWM_HW_Version_T));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HW_VERSION_Write
 *===========================================================================*
 * @brief Write PPS_HW_VERSION information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HW_VERSION_Write(uint8_t * data, uint8_t length)
{
   GWM_HW_Version_T hw_version;

   memcpy((void*)&hw_version, data, length);
   GWM_HW_Version_PS_Set(hw_version);

   return(PARAM_SUCCESS);
}
#if defined(GWM_CHB041)
/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Read
 *===========================================================================*
 * @brief Read PPS_SUPP_HW_VERSION information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_Read(uint8_t * data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;

   uint32_t didIndex = 0x06000A;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Write
 *===========================================================================*
 * @brief Write PPS_SUPP_HW_VERSION information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x0A;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}
#endif
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Read
 *===========================================================================*
 * @brief Read Part 1 of PPS_SUPP_HW_VERSION information, first 10 bytes of supply hardware version
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_1_Read(uint8_t * data, uint8_t length)
{
   SUPP_HW_Version_T supp_hw_version;

   supp_hw_version = SUPP_HW_Version_PS_Get();
   memcpy(data, (void*)&supp_hw_version, 10);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Write
 *===========================================================================*
 * @brief Write Part 1 of PPS_SUPP_HW_VERSION information, first 10 bytes of supply hardware version
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_1_Write(uint8_t * data, uint8_t length)
{
   SUPP_HW_Version_T supp_hw_version;

   /*Get supply HW version*/
   supp_hw_version = SUPP_HW_Version_PS_Get();

   memcpy((void*)&supp_hw_version, data, 10);
   SUPP_HW_Version_PS_Set(supp_hw_version);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Read
 *===========================================================================*
 * @brief Read Part 2 of PPS_SUPP_HW_VERSION information, last 6 bytes of supply hardware version
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_2_Read(uint8_t * data, uint8_t length)
{
   SUPP_HW_Version_T supp_hw_version;

   supp_hw_version = SUPP_HW_Version_PS_Get();
   memcpy(data, (void*)&supp_hw_version.version_byte10, 6);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SUPP_HW_VERSION_Write
 *===========================================================================*
 * @brief Write Part 2 of PPS_SUPP_HW_VERSION information, last 6 bytes of supply hardware version
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_HW_VERSION_2_Write(uint8_t * data, uint8_t length)
{
   SUPP_HW_Version_T supp_hw_version;

   /*Get supply HW version*/
   supp_hw_version = SUPP_HW_Version_PS_Get();

   memcpy((void*)&supp_hw_version.version_byte10, data, 6);
   SUPP_HW_Version_PS_Set(supp_hw_version);

   return(PARAM_SUCCESS);
}
#endif
/*===========================================================================*
 * FUNCTION: PITS_PPS_SYSTEM_CONFIG_Read
 *===========================================================================*
 * @brief Read PPS_SYSTEM_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SYSTEM_CONFIG_Read(uint8_t *data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x060003;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SYSTEM_CONFIG_Write
 *===========================================================================*
 * @brief Write PPS_SYSTEM_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_SYSTEM_CONFIG_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x03;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HMI_CONFIG_Read
 *===========================================================================*
 * @brief Read PITS_PPS_HMI_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HMI_CONFIG_Read(uint8_t * data, uint8_t length)
{
   NP_HMI_Configure_T config;

   config = HMI_PS_Get_NP_HMI_Configure();
   memcpy(data, (void*)&config, length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_HMI_CONFIG_Write
 *===========================================================================*
 * @brief Write PITS_PPS_HMI_CONFIG information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_HMI_CONFIG_Write(uint8_t * data, uint8_t length)
{
   NP_HMI_Configure_T config;

   memcpy((void*)&config, data, length);
   HMI_PS_Set_NP_HMI_Configure(config);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DELPHI_PN_Read
 *===========================================================================*
 * @brief Read PPS_DELPHI_PN information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DELPHI_PN_Read(uint8_t * data, uint8_t length)
{
   Delphi_PN_T dpn;

   MFT_Get_Delphi_Part_Number(dpn);
   memcpy(data, dpn, length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_DELPHI_PN_Write
 *===========================================================================*
 * @brief Write PPS_DELPHI_PN information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_DELPHI_PN_Write(uint8_t * data, uint8_t length)
{
   Delphi_PN_T dpn;

   memcpy(dpn, data, length);
   MFT_Set_Delphi_Part_Number(dpn);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_JULIAN_DATE_Read
 *===========================================================================*
 * @brief Read PPS_JULIAN_DATE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_JULIAN_DATE_Read(uint8_t * data, uint8_t length)
{
   Julianday_T julian_date;

   MFT_Get_Julianday(julian_date);
   memcpy(data, julian_date, sizeof(Julianday_T));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_JULIAN_DATE_Write
 *===========================================================================*
 * @brief Write PPS_JULIAN_DATE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_JULIAN_DATE_Write(uint8_t * data, uint8_t length)
{
   Julianday_T julian_date;

   memcpy(julian_date, data, length);
   MFT_Set_Julianday(julian_date);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ENDMOD_PN_Read
 *===========================================================================*
 * @brief Read PPS_ENDMOD_PN information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_ENDMOD_PN_Read(uint8_t * data, uint8_t length)
{
   Part_Num_T part_num;

   part_num = Part_Num_PS_Get();
   memcpy(data, (void*)&part_num, length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ENDMOD_PN_Write
 *===========================================================================*
 * @brief Write PPS_ENDMOD_PN information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_ENDMOD_PN_Write(uint8_t * data, uint8_t length)
{
   Part_Num_T part_num;

   memcpy((void*)&part_num, data, length);
   Part_Num_PS_Set(part_num);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_GWM_IDENTITY_NUM_Read
 *===========================================================================*
 * @brief Read PPS_GWM_IDENTITY_NUM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_GWM_IDENTITY_NUM_Read(uint8_t * data, uint8_t length)
{
   GWM_identify_Num_T num;

   num = GWM_Identify_Num_PS_Get();
   memcpy(data, (void*)&num, length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_GWM_IDENTITY_NUM_Write
 *===========================================================================*
 * @brief Write PPS_GWM_IDENTITY_NUM information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_GWM_IDENTITY_NUM_Write(uint8_t * data, uint8_t length)
{
   GWM_identify_Num_T num;

   memcpy((void*)&num, data, length);
   GWM_Identify_Num_PS_Set(num);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_C_MATRIX_VER_Read
 *===========================================================================*
 * @brief Read PPS_C_MATRIX_VER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_C_MATRIX_VER_Read(uint8_t * data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x060009;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_C_MATRIX_VER_Write
 *===========================================================================*
 * @brief Write PPS_C_MATRIX_VER information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_C_MATRIX_VER_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x09;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_MFG_SPAREPART_NO_Read
 *===========================================================================*
 * @brief Read vehicle manufacture spare part number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_MFG_SPAREPART_NUM_Read(uint8_t *data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x06000C;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_MFG_SPAREPART_NO_Write
 *===========================================================================*
 * @brief Write vehicle manufacture spare part number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_MFG_SPAREPART_NUM_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x0C;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SYS_SUPPLIER_ID_Read
 *===========================================================================*
 * @brief Read system supplier identification number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_SYS_SUPPLIER_ID_Read(uint8_t *data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x06000D;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_SYS_SUPPLIER_ID_Write
 *===========================================================================*
 * @brief Write system supplier identification number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_SYS_SUPPLIER_ID_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x0D;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ECU_SW_VERSION_NO_Read
 *===========================================================================*
 * @brief Read software version number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_SW_VERSION_Read(uint8_t *data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x06000B;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ECU_SW_VERSION_NO_Write
 *===========================================================================*
 * @brief Write version number number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_SUPP_SW_VERSION_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x0B;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ECU_SERIAL_NO_Read
 *===========================================================================*
 * @brief Read ECU serial number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_ECU_SERIAL_NUM_Read(uint8_t *data, uint8_t length)
{
   SAL_Message_T const *response_message = NULL;
   uint32_t didIndex = 0x060006;

   SAL_Event_Id_T event_id_list[] = {DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE};

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      Diag_Proxy_Read_PS_Data_For_PITS(&didIndex, length);

      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 300);

      if((NULL != response_message) && (DIAG_EVG_READ_PS_DATA_FOR_PITS_RESPONSE == response_message->event_id))
      {
         memcpy(data, (uint8_t*) response_message->data, length);
      }

      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_ECU_SERIAL_NO_Write
 *===========================================================================*
 * @brief Write ECU serial number.
 */
/*===========================================================================*/
uint8_t PITS_PPS_ECU_SERIAL_NUM_Write(uint8_t * data, uint8_t length)
{
   uint8_t didIndex[length + 3];

   didIndex[0] = 0x06;
   didIndex[1] = 0x00;
   didIndex[2] = 0x06;

   memcpy(&didIndex[3], data, length);

   Diag_Proxy_Write_PS_Data_For_PITS(didIndex, (length+3));

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 *              PARAMETER LIST 07 - READ/WRITE FUNCTIONS
 *===========================================================================*/


#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)                    \
uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length)                 \
{                                                                          \
   uint8_t  response = PARAM_NO_ID_EXIST;                                  \
   DTC_T dtc;                                                              \
                                                                           \
   if (pmidnum <= NUM_FIXED_DTCS)                                          \
   {                                                                       \
      PS_Get_DTC_Info((pmidnum-1), &dtc);                                  \
      if(dtc.availability)                                                 \
      {                                                                    \
         data[0] = dtc.status.dtcStatusByte;                               \
         response = PARAM_SUCCESS;                                         \
      }                                                                    \
   }                                                                       \
   return(response);                                                       \
}
   PPS_PARAM_LIST_07_DTCS

/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Write (For DTCs)
 *===========================================================================*
 * @brief Write DTCs information
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#define PARAM_IDS(pmid, pmidnum, size, read_write,name)                    \
uint8_t PITS_##pmid##_Write(uint8_t * data, uint8_t length)                \
{                                                                          \
   uint8_t  response = PARAM_NO_ID_EXIST;                                  \
   DTC_T dtc;                                                              \
   if (pmidnum <= NUM_FIXED_DTCS)                                          \
   {                                                                       \
      PS_Get_DTC_Info((pmidnum-1), &dtc);                                  \
      if(dtc.availability)                                                 \
      {                                                                    \
         dtc.status.dtcStatusByte = data[0];                               \
         PS_Put_DTC_Info((pmidnum-1), &dtc);                               \
         response = PARAM_SUCCESS;                                         \
      }                                                                    \
   }                                                                       \
   return(response);                                                       \
}
  PPS_PARAM_LIST_07_DTCS


/*===========================================================================*
 * FUNCTION: PITS_PPS_MFG_USE_Read
 *===========================================================================*
 * @brief Read PPS_MFG_USE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_MFG_USE_Read(uint8_t * data, uint8_t length)
{
   Whole_Param_T    param_number = {0};

   Mfg_PS_Get_Whole_Param(param_number);
   memcpy(data, &param_number[0], length);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_MFG_USE_Write
 *===========================================================================*
 * @brief Write PPS_MFG_USE information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_MFG_USE_Write(uint8_t * data, uint8_t length)
{
   Whole_Param_T param_number;

   memcpy(&param_number[0], data, length);
   Mfg_PS_Put_Whole_Param(param_number);

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_TUNER_PRESET_Read
 *===========================================================================*
 * @brief Read PPS_TUNER_PRESET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_TUNER_PRESET_Read(uint8_t * data, uint8_t length)
{
   Preset_Type_T presets;
   uint8_t dev;
   uint8_t rem;
   uint16_t freq;
   uint8_t offset = 0;

   data[0] = Preset_PS_Get_Current_Page(0);
   data[1] = Preset_PS_Get_Current_Preset(0);
   data[2] = Preset_PS_Get_Num_Pages(0);

   offset = 3;
   for (dev = 0; dev < 5; ++dev)
      for (rem = 0; rem < 6; ++rem)
      {
         freq = Pits_Get_Param_Band_Value_Mpi(0, dev, rem);
         presets = Preset_PS_Get_Preset_Data(0, dev, rem);
         data[offset] = (uint8_t)((0xff00 & freq)>>8);
         data[offset + 1] = (uint8_t)(0x00ff & freq);
         data[offset + 2] = presets.tuner_info.pi;
         offset += 3;
      }

   return(PARAM_SUCCESS);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_TUNER_PRESET_Write
 *===========================================================================*
 * @brief Write PPS_TUNER_PRESET information
 *
 */
/*===========================================================================*/
uint8_t PITS_PPS_TUNER_PRESET_Write(uint8_t * data, uint8_t length)
{
   Tuner_Info_T tuner_info = {0x00};
   uint8_t dev;
   uint8_t rem;
   uint16_t freq;
   uint8_t offset = 0;

   Preset_PS_Put_Current_Page(0, data[0]);
   Preset_PS_Put_Current_Preset(0, data[1]);
   Preset_PS_Put_Num_Pages(0, data[2]);

   offset = 3;
   for (dev = 0; dev < 5; ++dev)
      for (rem = 0; rem < 6; ++rem)
     {
         freq = ((((uint16_t)data[offset]&0xff)<<8)&0xff00) + (uint16_t)data[offset + 1];
         tuner_info.band = 0;
         tuner_info.idd = freq;

         if(freq == 0xffff)
         {
            #ifdef FEATURE_EMPTY_PRESET
            tuner_info.empty_flag = true;
            #endif
         }

         tuner_info.pi = data[offset + 2];
         tuner_info.subchannel = 0;
         Preset_Prog_PS_Put_Preset_Data(tuner_info, 0, dev, rem);
         offset += 3;
     }

   return(PARAM_SUCCESS);
}

/*===========================================================================*/
/*!
 * @file pits_processing_parameters.cpp
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 09Jan2017  Mandar Bhat (tzl4my) Rev. 19
 * ctc_ec#172934: Vehicle Configuration's Read and Write Parameter for PITS.
 *
 * 12 Dec 2016 Mandar Bhat Rev 18
 * Task ctc_ec#68919. use diag_write(HMI_PS_Set_Diag_NP_Vehicle_Configure(config)) function for vehicle configure
 *
 * 28 Mar 2014 Bao Qifan Rev 17
 * Task ctc_ec#68919. [NGK PTIS] change wifi mac address and xtaltrim read and write function from wifi module to pits module
 *
 * 28-Mar-2014 Bao Qifan  Rev 16
 * Task ctc_ec#68911 Fix Task for ctc_ec#68779: [NGK PITS] add IR calibration function to parameter list
 *
 * 27-Mar-2014 Bao Qifan  Rev 15
 * Task ctc_ec#68779 [NGK PITS] add IR calibration function to parameter list
 *
 * 02-Mar-2014 Bao Qifan Rev 14
 * Task ctc_ec#63523 [NGK PITS] add wifi Xtal get function for parameter list
 *
 * 02-Apr-2014 Bao Qifan  Rev 13
 * Task ctc_ec#63420 [NGK PITS] add wifi address get and set function for paramater list
 *
 * 02-Jan-2013 Bao Qifan  Rev 12
 * Task ctc_ec#56175 [NGK PITS] add IR touch calibration function pits msg
 *
 * -23-Dec-2013  Bao Qifan Rev 11
 * -Task ctc#ec#55421: - [NGK PITS] add DID $B3 - DUNS number to parameter list 06 000F
 *
 * -17-Dec-2013  Bao Qifan Rev 10
 * -Task ctc#ec#54848: - [NGK PITS] remove workaround for parameter list 02 md5
 *
 * -11-Dec-2013  Bao Qifan Rev 9
 * -Task ctc#ec#54321: - [NGK PITS] make a workaround for parameter list 02 md5
 *
 * -29-Nov-2013  Bao Qifan Rev 8
 * -Task ctc#ec#53184: - [NGK PITS] change itme HW_LVL to IGN CYC in parameter list
 *
 * -06-Nov-2013  Bao Qifan Rev 7
 * -Task ctc#ec#50702: - [NGK PITS] use SAL_Run_Command_L instand of system
 *
 * 18-Oct-2013 Bao Qifan Rev 6
 * Task ctc_ec#48791 : [NGK PITS] modify parameter list for mpi
 *
 * 10-Jun-2013 Bao Qifan  Rev 5
 * Task ctc_ec#41160 [NGK PITS] integrate PITS code from B9
 *
 * 07-Mar-2013 Bao Qifan  Rev 4
 * Task ctc_ec#36515 [NGK PITS] add warning print info for unexpected situation
 *
 * 13-Nov-2012 Long Liping
 * Task ctc_ec#31732 Create NGK PITS baseline
 *
 *   11-Feb-2013 Joel Kiger Rev 32
 *   SCR kok_basa#38324/Task kok_basa#139605
 *   Added PS_Diag_Read(), PS_Diag_Write() routines so DIAG/PITS always Reads/Writes to PS in the file system.
 *   PS_Diag_Reload() routine was added for BBs to call when PS_EVG_DIAG_CHANGED_PS_DATA msg is received.
 *
 * 25 Jan 2013 Erick Sanchez Rev 31
 * Task kok_basa#136802 - mdf: PITS: Add to PS patameter 0C and CA/SMD certificates
 *
 * 21-Jan-2013 Oscar Vega Rev 30
 * Task kok_basa#127432 PITS - Update parameter List
 *
 * 14-Jan-2013 Darinka Lopez  Rev 29
 * SCR kok_basa#36398: PITS Message 10FC/10FD are needed
 * Tasks kok_basa#134961, kok_basa#134962, kok_basa#134965
 *
 * 07-Nov-2012 Miguel Garcia Rev 28
 * Task kok_basa#127432 - SBX Include WBAM and USN parameters
 *
 * 06-Nov_2012 Joel Kiger Rev 27
 * Task kok_basa#127151 Remove BT PS variables from Tuner build
 *
 * 03-Oct-2012 Oscar Vega Rev 26
 * Task kok_basa#122160 - SBX - AM_FM_DRV_NUMBER_OF_TUNERS is hard coded
 * to 2 on single tuner boards in PITs component
 *
 * 21-Sep-2012 Darinka L�pez Rev 25
 * Task kok_basa#120404 - Add Tuner 2 in Paramet IDs.
 *
 * 21-Sep-2012 Darinka L�pez Rev 24
 * Task kok_basa#120034 - Implement Parmeter List A - TMC Parameters
 *
 * 21-Sep-2012 Darinka L�pez Rev 23
 * Task kok_basa#120424 - Remove Tuner items from List 01, ID 0x0007
 *
 * 21-Sep-2012 Darinka L�pez Rev 22
 * Task kok_basa#120282 - Implement Parameter List B - Tuner Calibration
 *
 * 21-Sep-2012 Darinka L�pez Rev 21
 * Task kok_basa#120034 - Implement Parmeter List A - TMC Parameters
 *
 * 20 Sep 2012 Miguel Garcia Rev 20
 * Task kok_basa#120148 - Change size parameters HW Lev and Prod Date
 *
 * 18-Sep-2012 Darinka Lopez  Rev 19
 * Task kok_basa#119375 - Fix tuner include files in pits processing parameters
 *
 *  12-Sep-2012 Darinka L�pez Rev 18
 *  Task kok_basa#117929 - PITS - MSID $01, MID $61 - Report Error is not correct
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 17
 * Task kok_basa#114796 - sbx - Audio klocwork issues
 *
 * 09-Aug-2012 Chris Baker  Rev 16
 * Task kok_basa#113476 - Update BT PS calls to match new prototypes
 *
 * 9-Aug-2012 Darinka Lopez  Rev 15
 * Task kok_basa#113269 - Implement TOD Parameter ID
 *
 * 27-Jul-2012 Keerthika Pandiselvan  Rev 14
 * Task kok_basa#111070 - Klocwork bug fix for resource leak
 *
 * 16-Jul-2012 Darinka Lopez  Rev 13
 * Task kok_basa#108415 - Implement Read  Parmeter IDs of Valet Mode & Logistic Mode
 *
 * 27-Jun-2012 Darinka Lopez  Rev 12
 * Task kok_basa#105486: Implement Read of Parameter List 02
 *
 * 26-Jun-2012 Darinka Lopez  Rev 11
 * Task kok_basa#104984: Implement Write of Parameter List 07
 *
 * 22-Jun-2012 Oscar Vega  Rev 10
 * Task kok_basa#104654 -  Remove memset in write function
 *
 * 22-Jun-2012 Darinka Lopez Rev 9
 * Task kok_basa#104401: Implement Read/Write of List 01
 *
 * 21-Jun-2012 Darinka Lopez Rev 8
 * Task kok_basa#104301: Implement Read/Write of List 05
 *
 * 21-Jun-2012 Darinka Lopez Rev 7
 * Task kok_basa#103764: Implement Read/Write of List 04
 *
 * 20-Jun-2012 Darinka Lopez Rev 6
 * Task kok_basa#103382: Implement Read/Write of List 03
 *
 * 17-Jun-2012 Darinka Lopez  Rev 5
 * Task kok_basa#102916: Implement Read of Parameter List 07
 *
 * 13-Jun-2012 Darinka Lopez  Rev 4
 * Task kok_basa#102463 - Implement Read/Write of Parameter List 08
 *
 * 13-Jun-2012 Darinka Lopez  Rev 3
 * Task kok_basa#102406 - Implement Read/Write of Parameter List 09
 *
 * 8-Jun-2012 Darinka Lopez  Rev 2
 * Task kok_basa#101654 - Implement Read/Write of List 06
 *
 * 7-Jun-2012 Darinka Lopez  Rev 1
 * Task kok_basa#101504 - Implement Read/Write Handler for Programming Services
 *
 * Initial version.
 *
 */
/*===========================================================================*/
