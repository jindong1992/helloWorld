/*===========================================================================*/
/**
 * @file pits_processing_audio.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_processing_audio.c~2:csrc:ctc_ec#22 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Wed Jun  8 11:00:34 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_audio_services.h"
#include "pits_audio_services_cbk.h"
#include "pits_processing_audio.h"
#include "pits_tuner_services.h"
#include "pits_tuner_services_cbk.h"
#include "string.h"
#include "utilities.h"
#include "unistd.h"
#include "xsal_util.h"
#include "tuner_manager_cbk.h"
#include "audio_drvr_mgr.h"

EM_FILENUM(PITS_MODULE_ID_5, 30);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define FM_CHANNEL_SPACE     (0xC8)
#define FM_BASE_CONST        (0x0A)
#define AM_CHANNEL_SPACE     (0x0A)
#define AM_LOW_FREC          (0x0212)
#define FM_LOW_FREC          (0x2242)
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define THREE_BYTES_LENGHT       0x03

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static bool_t pits_audio_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel);
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static bool_t pits_sdar_quality = true;
static bool_t pits_amfm_quality = true;

static uint8_t pits_chime_on = 0;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
SSM_Source_Type_T                 pits_audio_source_type=0;
/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Get_Audio_Source_Type
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_Audio_Band_T PITS_Get_Audio_Source_Type(void)
{
   return pits_audio_source_type;
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Audio_Source_Type
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Process_Set_Balance(uint8_t  data)
{
   uint8_t process_data;
   process_data = ((((((data)*100)/255)*0x77)/100)+0x44);
   return (process_data);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Audio_Source_Type
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
uint8_t PITS_Process_Set_Fade(uint8_t  data)
{
   uint8_t process_data;
   process_data = (0xFF - ((((((data)*100)/255)*0x77)/100)+0x44));
   return (process_data);
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
void PITS_AU_Enable_Internal_Audio(bool_t data)
{
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
uint8_t PITS_Processing_Audio_UNMUTE(uint8_t data, Sys_Zone_T zone, Sys_Audio_Bus_T bus)
{
  uint8_t result_unmute = data;
  Audio_Logical_Src_T logical_source;
  PITS_Source_T pits_source = PITS_SRC_NONE;
  bool_t source_found = false;
  
  logical_source = PITS_AU_Get_Source(zone, bus);
  source_found = PITS_Audio_Map_Logical_Src_To_Pits_Src(logical_source, &pits_source);
  UNUSED_PARAM(source_found);
  
  if ((pits_source == PITS_SRC_TUNER_AM)||(pits_source == PITS_SRC_TUNER_FM1))
  {
     if (!pits_amfm_quality)
     {
       result_unmute = 0x01;
     }
  }
#if 0  
  if ((pits_source == PITS_SRC_SDAR))
  {
     if (!pits_sdar_quality)
     {
        result_unmute = 0x01;
     }
  }
#endif  
  return(result_unmute); 
    
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_volume_diag_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Volume Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio volume level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_volume_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T volume;
   uint8_t adjust_vol;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            adjust_vol = (uint8_t) Scale(PITS_AU_Get_Volume(zone, bus),
                                                     VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
            PITS_Set_Audio_Overrides(PITS_AU_EN_VOLUME, true);
            volume = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);
            if (adjust_vol == 0)
            {
               if (volume == 0)
               {
                  PITS_AU_Set_Volume(zone, bus, volume);
               }
               else
               {
                  PITS_AU_Set_Volume(zone, bus, (volume-1));
               }
            }
            else
            {
               PITS_AU_Set_Volume(zone, bus, volume);
            }

            if (adjust_vol == 0)
            {
               if (volume == 0)
               {

               }
               else
               {
                  PITs_GM_Set_DID (0,12);
                  PITs_GM_Set_DID(1, 1);
                  PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
               }
            }
         }
         pits_status = DONE;
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_audio_set_mute_diag_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Mute Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Mute Status
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Mute Status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_mute_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Mute_State_T mute_state = AUDIO_UNMUTE;
   uint8_t data;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      zone = (Sys_Zone_T)message->data[0];
      bus  = (Sys_Audio_Bus_T)message->data[1];
      if(message->data[2] == 0)
      {
         mute_state = AUDIO_UNMUTE;
      }
      else if(message->data[2] == 1)
      {
         mute_state = AUDIO_MUTE;
      }
      else
      {
         /* Do nothing */
      }

      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         PITS_AU_Set_Mute_State_Bus(zone, bus, mute_state);
         if (mute_state == AUDIO_MUTE)
         {
            data = AUDIO_MUTE;
            Pits_Get_Muted_Data(&data,1);
         }
         else
         {
            data = AUDIO_UNMUTE;
            Pits_Get_Unmuted_Data(&data,1);
         }
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_tone_diag_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Tone Control
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = zone
 * @param [in] (message->data)[1] = bus
 * @param [in] (message->data)[2] = Base settings
 * @param [in] (message->data)[4] = Mid settings
 * @param [in] (message->data)[6] = Trebel settings
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_tone_diag_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Tone_T tone_settings;
   Audio_Logical_Src_T logical_source;
   PITS_TUNER_EVG_CHANNEL_T tune_band_info_dpid;
   Tuner_Mgr_Target_T tune_band_info;
   PITS_SSM_Src_T src_band;
   bool_t valid_channel = false;
   Tuner_Mgr_Dev_Type_T pit_tun_device = TUNER_MGR_DEV_AM;
   Tuner_Mgr_Target_T pit_last_target;

   tune_band_info_dpid.service_identifier = 0;
   tune_band_info_dpid.channel_number = 0;
   tune_band_info.target_value = 0;

   if (NULL != message)
   {
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];

         logical_source = PITS_AU_Get_Source(zone, bus);

         if ((logical_source == AUDIO_LOGICAL_SRC_AM)||(logical_source == AUDIO_LOGICAL_SRC_FM)||(logical_source == AUDIO_LOGICAL_SRC_XM))
         {
            if (logical_source == AUDIO_LOGICAL_SRC_AM)
            {
               pit_tun_device = TUNER_MGR_DEV_AM;
               Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_FM)
            {
               pit_tun_device = TUNER_MGR_DEV_FM;
               Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_XM)
            {
               pit_tun_device = TUNER_MGR_DEV_XM;
               Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
            }
            else
            {
               /* Do nothing */
            }


            tune_band_info_dpid.zone = SYS_ZONE_MAIN;
            tune_band_info_dpid.channel_number = PITS_Get_AMFM_Tuner_Frequency();
            tune_band_info_dpid.band = PITS_Get_Tuner_Source_Type();
            tune_band_info_dpid.service_identifier = 0;
            if (logical_source == AUDIO_LOGICAL_SRC_XM)
            {
               tune_band_info_dpid.service_identifier = PITS_Get_XM_Tuner_SID();
            }
         }

         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            PITS_Set_Audio_Overrides(PITS_AU_EN_TONE, true);
            tone_settings.absolute_detent[AUDIO_BASS_BAND] =
                (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_MID_BAND] =
                (Audio_Detent_T) Scale(message->data[3], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
                (Audio_Detent_T) Scale(message->data[4], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            PITS_AU_Set_All_Tone_Bands(zone, bus, tone_settings);
         }
         /*usleep(500*1000);
         PITS_Set_Audio_Overrides(PITS_AU_EN_TONE, false);*/
         if ((logical_source == AUDIO_LOGICAL_SRC_AM)||(logical_source == AUDIO_LOGICAL_SRC_FM)||(logical_source == AUDIO_LOGICAL_SRC_XM))
         {

            if (logical_source == AUDIO_LOGICAL_SRC_AM)
            {
               src_band.type = SSM_SRC_AM;
               tune_band_info.target_value= (pit_last_target.target_value)&0x0000FFFF;
               tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               tune_band_info.target_subchannel = 0;
               src_band.device = 1;
               valid_channel = pits_audio_amfm_channel_is_valid(AM_BAND, tune_band_info.target_value);
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_XM)
            {
               src_band.type = SSM_SRC_XM;
               tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_SERVICE_ID;
               tune_band_info.target_value = (tune_band_info_dpid.service_identifier & 0x0000FFFF);
               tune_band_info.target_subchannel =  tune_band_info_dpid.channel_number;
               src_band.device = 1;
               valid_channel = true;
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_FM)
            {
               src_band.type = SSM_SRC_FM;
               tune_band_info.target_value= (pit_last_target.target_value & 0x0000FFFF);
               tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               tune_band_info.target_subchannel = 0;
               src_band.device = 1;
               valid_channel = pits_audio_amfm_channel_is_valid(FM_BAND, tune_band_info.target_value);
            }
            else
            {
               /* Do nothing */
            }
            if (valid_channel)
            {
               UNUSED_PARAM(src_band);              
               /*RemRcvr_Enable_Override();
               Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);*/
            }

            if (logical_source == AUDIO_LOGICAL_SRC_AM)
            {
               pit_tun_device = TUNER_MGR_DEV_AM;
               pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               /*  pit_last_target.target_value = pit_last_target.target_value; */
               pit_last_target.target_last_known_freq = pit_last_target.target_value;
               pit_last_target.target_is_primary = 0;
               pit_last_target.target_scid = 0;
               pit_last_target.target_service_id = 0;
               pit_last_target.target_subchannel = 0;
               Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_FM)
            {
               pit_tun_device = TUNER_MGR_DEV_FM;
               pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               /*pit_last_target.target_value = pit_last_target.target_value;*/
               pit_last_target.target_last_known_freq = pit_last_target.target_value;
               pit_last_target.target_is_primary = 0;
               pit_last_target.target_scid = 0;
               pit_last_target.target_service_id = 0;
               pit_last_target.target_subchannel = 0;
               Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);
            }
            else if (logical_source == AUDIO_LOGICAL_SRC_XM)
            {
               pit_tun_device = TUNER_MGR_DEV_XM;
               pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_SERVICE_ID;
               /*pit_last_target.target_value = pit_last_target.target_value;*/
               pit_last_target.target_last_known_freq = pit_last_target.target_value;
               pit_last_target.target_is_primary = 0;
               pit_last_target.target_scid = 0;
               pit_last_target.target_service_id = 0;
               pit_last_target.target_subchannel = 0;
               Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);
            }
            else
            {
               /* Do nothing */
            }
         }
         usleep(500*1000);
         PITS_Set_Audio_Overrides(PITS_AU_EN_TONE, false);
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_amfm_channel_is_valid
 *===========================================================================*
 * @brief verify valid am/fm band
 *
 * @returns
 *    true = valid band limit
 *    false = No valid band.
 *
 * @param [in] band = FM/AM band
 * @param [in] channel = frequency value.

 */
/*===========================================================================*/
static bool_t pits_audio_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel)
{
   uint16_t lower_band_limit = AM_FM_Drv_Get_Lower_Band_Limit(band);
   uint16_t upper_band_limit = AM_FM_Drv_Get_Upper_Band_Limit(band);
   uint16_t band_step_size = AM_FM_Drv_Get_Tune_Step_Size(band);

   return ( (upper_band_limit >= channel) &&
            (lower_band_limit <= channel) &&
            (((channel - lower_band_limit) % band_step_size) == 0) );
}
/*===========================================================================*
 * FUNCTION: pits_audio_get_quality_diag_req
 *===========================================================================*
 * @brief Receive a Request to get_quality_diag_req
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = quality
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_quality_diag_req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
         pits_amfm_quality = message->data[0];
   }
   return (DONE);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_fade_diag_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Fade Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio fade level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Fade level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_fade_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T fade;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            PITS_Set_Audio_Overrides(PITS_AU_EN_FADE, true);
            fade = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
            PITS_AU_Set_Fade(zone, bus, fade);
         }
         pits_status = DONE;

      }
   }
   return (pits_status);
}

void Pits_Get_Sdar_Quality (const uint8_t * data,  size_t length)
{
   if((data[3] & 0x01)== 1)
   {
      pits_sdar_quality = true;
   }
   else
   {
      pits_sdar_quality = false;
   }
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_balance_diag_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Balance Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Balance level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Balance level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_balance_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T balance;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            PITS_Set_Audio_Overrides(PITS_AU_EN_BALANCE, true);
            balance = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
            PITS_AU_Set_Balance(zone, bus, balance);

         }
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/

void PITS_Set_Audio_Chime_Setting(uint8_t data)
{
   pits_chime_on = data;
   
   if(0x01 == pits_chime_on)
   {
      AuDM_Set_Sine_Tone_On(0xF0, 0x2EE, -3000);
   }
   else if(0x00 == pits_chime_on)
   {
      AuDM_Set_Sine_Tone_Off();
   }
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
uint8_t PITS_Get_Audio_Chime_Setting(void)
{
   return(pits_chime_on);
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
void PITS_Get_Playback_Status(uint8_t* data, PITS_Playback_T playback_source)
{
   memset(&data[0], 0xFF, THREE_BYTES_LENGHT);
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
uint8_t PITS_Get_Audio_DDL_Setting(void)
{
   return 0;
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
void PITS_Set_Audio_DDL_Setting(uint8_t data)
{

}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
uint8_t PITS_Get_RSA_Status(void)
{
   return 0;
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
void PITS_Set_RSA_Status(uint8_t data)
{

}

/*===========================================================================*/
/*!
 * @file pits_processing_audio.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 15
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 14
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 15-Aug-2012 Arturo Perez  Rev 13
 * Task kok_basa#114601 - Implement PIT 42/43 & 44/45 - Get/Set RSA Enable Status
 *
 * 18-Jul-2012 Arturo Perez  Rev 12
 * Task kok_basa#109514 - MID 2C/2D - Request Set DDL/Report Get DDL
 *
 * 26-Jun-2012 Oscar Vega  Rev 10
 * Task kok_basa#105387: 2_0 - MID 40/41 - Request/Report  Get Playback Status
 *
 * 20-Jun-2012 Oscar Vega  Rev 9
 * Task kok_basa#103740 -  Get and Set Chime
 *
 * 07 June 2012 Miguel Garcia Rev 7
 * Include cast and valid the frequency for cpid4
 *
 * 03 June 2012 Miguel Garcia Rev6
 * Insert set source after cpid4
 *
 * 02 June 2012 Miguel Garcia Rev 5
 * Remove tone set false for vast
 *
 * 1-May-2012 Darinka Lopez  Rev 4
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 29 Mar 2012 Miguel Garcia Rev 3
 * Include Pits Process Set Fade, Balance
 *
 * 16-Jan-2012 Juan Carlos Castillo  Rev 2
 * SCR kok_basa#19216: PITS Get Source - Audio Services
 * Fix: Get Source directly from SSM instead of logical audio.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 1
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Initial version for pits specific services .
 */
/*===========================================================================*/
