#ifndef SIPPITS_H
#   define SIPPITS_H
/*===========================================================================*/
/**
 * @file sippits.h
 *
 * This is the interface for init, open, close of desip channel for pits.
 *
 * %full_filespec:sippits.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:00 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    PITS DESIP Interface Layer.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - DESIP: Delco Electronics Serial Interface Protocol.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None.
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "sippits_cfg.h"
#   include "desip.h"

#   define CLKS_PER_SEC 1000

extern int SIPPITS_Init(void);

extern SIP_HANDLE SIPPITS_Open(void);

extern void SIPPITS_Close(void);

extern void SIPPITS_FSM(void);

extern int TmrGet(void);

extern void SIPPITS_Tmr_Update(void);

extern void SIPPITS_Tmr_Clear(void);

/*===========================================================================*/
/*!
 * @file sippits.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-05-30  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2003-10-01  Gitesh
 *    - Declared the variable SIPPITS_Tmr, Version 2.
 *
 * - 2003-04016  Roger/Srikant
 *    - Created initial file, Version 1.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* SIPPITS_H */
