#ifndef PITS_SOH_SERVICES_CBK_H
#   define PITS_SOH_SERVICES_CBK_H
/*===========================================================================*/
/**
 * @file pits_soh_services_cbk.h
 *
 * PITS Health Services Callout API Definitions.
 *
 * %full_filespec:pits_soh_services_cbk.h~1:incl:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:09:32 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *    This module defines the PITS Health Services callout APIs,
 *    the callout functions are implemented elsewhere.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - PSS: PITS SOH Services.
 *    - DTC: Diagnostic Trouble Code.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_soh_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * External Function Prototypes for API Callouts
 *===========================================================================*/
/**
 * Set DTCs to defaults values.
 */
extern void PITS_Diag_Reset_Enable_Bit_Deault (void);

/**
 * Set Enale of Single DTC.
 *
 * @param [in]   enable
 */
extern void PITS_Set_Enable_Status_Single_DTC(uint8_t dtc_id, uint8_t enable);

/**
 * Set Status of Single DTC.
 *
 * @param [in]   dtc id
 * @param [in]   status
 */
extern void PITS_Set_Status_Single_DTC(uint8_t dtc_id, uint8_t status);

/**
 * Set Status of Single DTC.
 *
 * @param [in]   dtc id
 * @param [in]   status
 */
extern void PITS_Clear_All_DTC(uint8_t dtc_id);

/**
 * Set the Ignition Counter.
 *
 * @param [in]   ignition counter
 */
extern void PITS_Set_DTC_Ignition_Counter(uint8_t counter);

/**
 * Retrieve the Ignition Counter.
 *
 *   Returns the ignition counter.
 */
extern uint8_t PITS_Get_DTC_Ignition_Counter(void);

/**
 * Get the Status of single DTC.
 *
 * @param [in]   dtc id
 */
extern uint8_t PITS_Get_Status_Single_DTC(uint8_t dtc_id);

/**
 * Get the Enalbe Status of single DTC.
 *
 * @param [in]   dtc id
 *   Returns the enable status.
 */
extern uint8_t PITS_Get_Enable_Status_Single_DTC(uint8_t dtc_id);
/**
 * Get the DTC count.
 *
 * @param [in]
 *   Returns the dtc quantity.
 */
extern uint8_t PITS_Get_DTC_Count (void);
/*===========================================================================*/
/*!
 * @file pits_soh_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 23-Aug-2012 Miguel Garcia 5
 * Task kok_basa#115924 - Update Pits_soh_services for SBX
 *
 * 31-Mar-2012 Oscar Vega 4
 * Task kok_basa#86597 - MID 1A/1B - Clear all DTCs.
 *
 * 30-Mar-2012 Oscar Vega 3
 * Task kok_basa#86394 - MID 1C/1D - Request/Report reset enable bits to Default State.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 23-Nov-2011 Oscar Vega  Rev 1
 * SCR kok_basa#17216 :  Implement MSID(05h) - SOH Services.
 * Implement PITS SOH services.
 * Initial Revision
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_SOH_SERVICES_CBK_H */
