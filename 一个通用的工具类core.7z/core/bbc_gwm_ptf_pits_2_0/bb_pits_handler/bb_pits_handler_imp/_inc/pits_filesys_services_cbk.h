#ifndef PITS_FILESYS_SERVICES_CBK_H
#   define PITS_FILESYS_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_filesys_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_filesys_services_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:23 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_filesys_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*
* Report if usb device is connected
*/
extern uint8_t PITS_FSYS_USB_Device_Conected(void);

/*
* Report type of USB connected
*/
extern uint8_t PITS_FSYS_USB_Device_Type(void);

/*
* Report device athetification self test
*/
extern uint8_t PITS_FSYS_Device_Self_Tests_Status(uint8_t device);

/**
 * Get media position information. 
 *
 * @return     
 *   media_positions
 *
 * @param [in]    media_positions
 *   Structure for media position info.
 */
extern void PITS_Get_Media_Position(PITS_FILESYS_Pos_T * media_positions);

/**
 * Go to next track 
 *
 * @return     
 *   none
 * 
 * @param [in]    device
 *   type of device
 * @param [in]    new_track
 *   new track selection.
 */
extern void PITS_FSYS_Set_Next_Track(uint16_t new_track);

/**
 * Go to previous track 
 *
 * @return     
 *   none
 * 
 * @param [in]    device
 *   type of device
 * @param [in]    new_track
 *   new track selection.
 */
extern void PITS_FSYS_Set_Prev_Track(uint16_t new_track);

/**
 * Get device information. 
 *
 * @return     
 *   device_info
 *
 * @param [in]    device_info
 *   Structure for device information.
 */
extern void PITS_FSYS_Get_Device_Info(PITS_Device_Info_T * device_info, PITS_DEVICE_ID_T device);

extern void PITS_Set_Ipod_Diag_Lingos_Enable (uint8_t lingo_enable);

extern uint8_t PITS_Get_Ipod_Diag_Lingos_Enable(void);
/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
extern uint8_t Pits_Filesys_Track_Select (uint8_t track);
/*===========================================================================*/
/*!
 * @file pits_filesys_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 31-Jul-2012 Miguel Garcia  Rev 9
 * Task kok_basa#112058: PITS: Update Pits filesys services
 * Update PITS_FILESYS_Pos_T
 *
 * 11 June 2012 Miguel Garcia Rev 8
 * Move pits icr filesys to processing services
 *
 * 04 May 2012 Miguel Garcia Rev 7
 * Include pits filesys track select
 *
 * 07 Mar 2012 Miguel Garcia Rev 5
 * Include Ipod lingos enable
 *
 * 27 Jan 2012 Miguel Garcia Rev 4
 * Include Filesys getter
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 2-Dec-2011 Oscar Vega  Rev 2
 * SCR kok_basa#16243 : Implement MSID(16h) - File System Services.
 * Implement File System Services
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_FILESYS_SERVICES_CBK_H */
