#ifndef PITS_MANAGER_CBK_H
#   define PITS_MANAGER_CBK_H
/*===========================================================================*/
/**
 * @file pits_manager_cbk.h
 *
 * The Required external functions for the Pits Manager MODULE
 *
 * %full_filespec:pits_manager_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:42 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    The list of functions defined by the Pits Manager and implemented in other modules.
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "xsal.h"
/*===========================================================================*
 * Exported Preprocessor #define Constants for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for API Callouts
 *===========================================================================*/
extern const size_t PITS_Queue_Size;

/*===========================================================================*
 * External Function Prototypes for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Bus_Initialize
 *===========================================================================*
 * @brief Initialize the bearing bus.
 *
 * @returns 
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Bus_Initialize(void);

/*===========================================================================*
 * FUNCTION: PITS_Bus_Close
 *===========================================================================*
 * @brief Close the Bearing Bus.
 *
 * @returns 
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Bus_Close(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_RX_Message
 *===========================================================================*
 * @brief Check For Receive message on the Bearing bus.
 *
 * @returns 
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Check_RX_Message(void);

/*===========================================================================*
 * FUNCTION: PITS_Process_Pm_Message
 *===========================================================================*
 * @brief Process Pm events.
 *
 * @returns
 *    true - if the event was a process manager event or if the thread
 *           is in off state.
 *    false - event not a process manager event or thread not in off state.
 *
 * @param [in] event_id - The event to process.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 */
/*===========================================================================*/
extern bool_t PITS_Process_Pm_Message(SAL_Event_Id_T event_id);

/**
 * Callout function that must be implemented by the program using the PITS
 * manager module in order to provide the thread attribute for the PITS
 * manager thread.
 *
 * @param thread_attr [out] pointer to location to which thread attribute is
 *                          to be written.
 */
extern void PITS_Manager_Get_Thread_Attr(SAL_Thread_Attr_T * thread_attr);

/**
 * This callout is called by the PITS Service when it is ready to process
 * requests.
 */
extern void PITS_Activated(void);

/**
 * This callout is called by the PITS service manager when it has finished a
 * command to terminate.
 */
extern void PITS_Terminated(void);

/*===========================================================================*/
/*!
 * @file pits_manager_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 12 Dec 2011 Oscar Vega Rev 7
 * SCR kok_basa#18660 : Fix queue depth and/or width in pits_manager_j2.c.
 * Create a variable for PITS_QUEUE_SIZE.
 *
 * - 10-Dec-2008 Yi Liu
 * + SCR 58578 - Run PITS unit test.
 *             - APM_Activated() not called.
 *
 * - 05-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *               Added PITS thread attribute initialization.
 *
 * - 2007-11-23  Jaroslaw Saferna
 *    - Prototype for PITS_Process_Pm_Message() added.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-14  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_MANAGER_CBK_H */
