#ifndef PITS_PROGRAMMING_SERVICES_CBK_H
#   define PITS_PROGRAMMING_SERVICES_CBK_H
/*===========================================================================*/
/**
 * @file pits_programming_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_programming_services_cbk.h~1:incl:ctc_ec#17 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:09:23 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_programming_services_cfg.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: Calculate chksum from memory read
 * @returns  checksum
 * @param    addres to read
 *           bytes to read
 *            algorithm used
 */
/*===========================================================================*/
extern uint8_t Pits_Calculate_Ckhsum(PPS_Segment_ID_T session_segment,uint8_t index, uint8_t* data);

extern void Pits_Start_Mds_Calculation (uint8_t mds_value, uint32_t mds_block);

extern uint8_t Pits_Get_Mds_Calc_Status (uint8_t mds_value);

#if defined(GWM_CHK041_8AT)
extern uint32_t Pits_Get_Faceplate_Ckhsum(void);
#endif

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file pits_programming_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 30-Jun-2014 Tim Wang
 *   - Added Pits_Start_Mds_Calculation and Pits_Get_Mds_Calc_Status functions.
 *
 * - 20-jun-2014 Tim Wang
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* PITS_PROGRAMMING_SERVICES_CBK_H */
