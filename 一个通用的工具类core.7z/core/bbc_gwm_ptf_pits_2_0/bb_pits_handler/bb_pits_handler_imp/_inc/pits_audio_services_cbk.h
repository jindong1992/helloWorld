#ifndef PITS_AUDIO_SERVICES_CBK_H
#   define PITS_AUDIO_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_audio_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_audio_services_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:07:50 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_audio_services.h"
#include "pits_audio_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/**
 * Connects the specified soure to the audio bus on the given zone.    
 *
 * @note 
 *     Zone gets enabled if it is disabled.  
 * 
 * @return     
 *   None
 *   Publishes: AUMGR_EVG_SRC_CONNECTED_ZONE or AUMGR_EVG_SRC_CONNEXION_FAILED
 *              source_report.zone - the given zone
 *              source_report.audio_bus - the affected audio_bus 
 *              source_report.logical_path - the affected logical path 
 *              source_report.logical_source - the new logical source
 *              source_report.error_code - the error code (0 = ok)
 *  
 * @param [in]    zone 
 *   given zone. 
 * 
 * @param [in]    audio_bus 
 *   audio_bus for the given zone to which the source is connected. 
 * 
 * @param [in]   logical_source 
 *   new logical source. 
 * 
 */
extern void PITS_AU_Connect_Src_To_Zone(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Logical_Src_T logical_source);

/**
 * Return the current source for the given zone and audio bus.    
 * 
 * @return     
 *   current logical source for the given zone and audio bus.
 * 
 * @param [in]   zone   
 *   given zone.
 * 
 * @param [in]   audio_bus   
 *   given audio bus. 
 * 
 */
extern Audio_Logical_Src_T PITS_AU_Get_Source(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);

/** 
 * Temporary function to enable internal_audio control (QBA)
 * @param data - Enable 0x01 / Disable 0x00
 */
extern void PITS_AU_Enable_Internal_Audio(bool_t data);
/**
 * Request a Speed Comp setting
 *
 * @param [in] zone
 * @param [in] audio bus
 * @param [in] speed_comp_lvl
 */
extern Audio_SCV_Lvl_T Pits_AuMgr_Get_SCV(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);
/**
 * Request a Speed Comp setting
 *
 * @param [in] zone
 * @param [in] audio bus
 * @param [in] speed_comp_lvl
 */
extern void Pits_AuMgr_Set_Speed_Comp(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Speed_Comp_T speed_comp_lvl);


/**
 * Get the Fade Value.
 *
 * @param [in]   adj_tone
 *   Returns the adj_tone.
 */
extern uint8_t PITS_Get_Fade_Val(uint8_t adj_tone);


/**
 * Get the Balance Value.
 *
 * @param [in]   adj_tone
 *   Returns the adj_tone.
 */
extern uint8_t PITS_Get_Balance_Val(uint8_t adj_tone);

/**
 * PITS_Get_Audio_Source_Type - Gets current audio source type.
 *
 * @param None.
 *
 * @return PITS_Audio_Band_T
 *   The current source type.
 */

extern PITS_Audio_Band_T PITS_Get_Audio_Source_Type(void);

/**
 * PITS_Processing_Audio_UNMUTE - Process current unmute state.
 *
 * @param data.
 *
 * @return unmute state (uint8_t)
 */
extern uint8_t PITS_Processing_Audio_UNMUTE(uint8_t data, Sys_Zone_T zone, Sys_Audio_Bus_T bus);

/**
 * Pits_AuMgr_Set_Dsp_Mode - Sets DSP Mode channel.
 *
 * @param audio_channel.
 *
 */
extern void Pits_AuMgr_Set_Dsp_Mode(uint8_t audio_channel);
/**
 * Pits_AuMgr_Set_SSM_Source_Present
 *
 * @param audio_channel.
 *
 */
extern void Pits_AuMgr_SSM_Source_Present (uint8_t source);

/**
 * Pits_Set_Audio_Chime_Setting - Set chime
 * @param data.
 * @return
 */
extern void PITS_Set_Audio_Chime_Setting(uint8_t data);

/**
 * Pits_Get_Audio_Chime_Setting - Get chime
 * @param
 * @return chime active
 */
extern uint8_t PITS_Get_Audio_Chime_Setting(void);

/**
 * Pits_Get_Audio_DDL_Setting - Get DDL
 * @param
 * @return DDL state
 */
extern uint8_t PITS_Get_Audio_DDL_Setting(void);

/**
 * Pits_Set_Audio_DDL_Setting - Enable/Disable DDL
 * @param data
 * @return
 */
extern void PITS_Set_Audio_DDL_Setting(uint8_t data);

/**
 * Pits_Get_RSA_Status - Get RSA Status
 * @param
 * @return RSA status
 */
extern uint8_t PITS_Get_RSA_Status(void);

/**
 * Pits_Set_RSA Status - Enable/Disable RSA
 * @param data
 * @return
 */
extern void PITS_Set_RSA_Status(uint8_t data);

/**
 * Pits Get_Playback Status
 * @param data
 * @return success or not supported
 */
extern void PITS_Get_Playback_Status(uint8_t* data, PITS_Playback_T playback_source);

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_audio_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 16 Aug 2012 Oscar Vega Rev 17
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 15-Aug-2012 Arturo Perez  Rev 16
 * Task kok_basa#114601 - Implement PIT 42/43 & 44/45 - Get/Set RSA Enable Status
 *
 * 18-Jul-2012 Arturo Perez  Rev 15
 * Task kok_basa#109514 - MID 2C/2D - Request Set DDL/Report Get DDL
 *
 * 26-Jun-2012 Oscar Vega  Rev 13
 * Task kok_basa#105387 - 2_0 - MID 40/41 - Request/Report  Get Playback Status
 *
 * 20-Jun-2012 Oscar Vega  Rev 12
 * Task kok_basa#103740 -  2_0 - Get and Set Chime
 *
 * 09 May 2012 Miguel Garcia Rev 11
 * Include SMM source present
 *
 * 04 May 2012 Miguel Garcia Rev 10
 * Include set dsp mode
 * 
 * 1-May-2012 Darinka Lopez  Rev 9
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 16-Jan-2012 Juan Carlos Castillo  Rev 8
 * SCR kok_basa#19216: PITS Get Source - Audio Services
 * Fix: Get Source directly from SSM instead of logical audio.
 * 
 * 6-Dec-2011 Marco Castillo 7
 * SCR kok_basa#10714 : Audio CPID 0x04 implementation
 *
 * 31 Oct 2011 Miguel Garcia Rev 6
 * Include speed comp callouts
 *
 * 27-Oct-2011 Juan Carlos Castillo  Rev 5
 * SCR kok_basa#17097: Create a temporary PITS message to notify when internal audio control is needed.
 * Fix: Add include for PITS_SBX_IS.
 *
 *
 * 27-Oct-2011 Juan Carlos Castillo  Rev 4
 * SCR kok_basa#17097: Create a temporary PITS message to notify when internal audio control is needed.
 * Fix: Add event to request internal audio control..
 *
 * 20-Oct-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#14623: Implement MSID(14h) - Audio Services
 * Fix: Make changes in Audio Services BB to support SBX program.
 *
 * - 01-oct-2008 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_AUDIO_SERVICES_CBK_H */
