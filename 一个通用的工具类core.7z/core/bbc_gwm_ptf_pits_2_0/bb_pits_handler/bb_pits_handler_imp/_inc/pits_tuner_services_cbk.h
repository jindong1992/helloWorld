#ifndef PITS_TUNER_SERVICES_CBK_H
#   define PITS_TUNER_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_tuner_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_tuner_services_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:09:37 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_tuner_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/**
 * PITS_Get_Tuner_Source_Type - Gets current source type.
 *
 * @param None.
 *
 * @return SSM_Source_Type_T
 *   The current source type.
 */

extern PITS_Tuner_Band_T PITS_Get_Tuner_Source_Type(void);

/**
 * PITS_Tuner_Mgr_Absolute_Tune - Sets current source and tuner.
 *
 * @param channel_id, source, target.
 *
 * @return
 *
 */
extern void PITS_Tuner_Mgr_Absolute_Tune (SSM_Channel_T channel_id, PITS_SSM_Src_T source, PITS_Tuner_Mgr_Target_T target);

/*===========================================================================*
 * FUNCTION: PITS_Get_AMFM_Tuner_Frequency
 *===========================================================================*
 * @brief Getter function for Tuner Current frequency
 *
 * @returns
 *    Current Tuner frequency multiplied x100. 
 *    i.e  Freq 91.5. return = 9150d = 0x23BE 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint32_t PITS_Get_AMFM_Tuner_Frequency(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_DAB_Tuner_Frequency
 *===========================================================================*
 * @brief Getter function for DAB Current frequency
 *
 * @returns
 *    Current DAB frequency
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_DAB_Tuner_Frequency(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_XM_Tuner_Channel
 *===========================================================================*
 * @brief Getter function for DAB Current frequency
 *
 * @returns
 *    Current XM Channel
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint32_t PITS_Get_XM_Tuner_Channel(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_HD_Subchannel
 *===========================================================================*
 * @brief Getter function for Tuner Current HD Subchannel
 *
 * @returns
 *    Current HD Subchannel (formerly know as "sideband")
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint16_t PITS_Get_Tuner_HD_Subchannel(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Quality
 *===========================================================================*
 * @brief Getter function for Tuner Current Quality
 *
 * @returns
 *    Current Tuner quality
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_Tuner_Quality(void);


/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_User_PI_Code
 *===========================================================================*
 * @brief Getter function for Tuner Current PI code
 *
 * @returns
 *    Current Tuner quality
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern RDS_Pi_T PITS_Get_Tuner_User_PI_Code(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Received_PI
 *===========================================================================*
 * @brief Getter function for Tuner Current PI code
 *
 * @returns
 *    Current Tune Received PI code
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern RDS_Pi_T PITS_Get_Tuner_Received_PI(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Received_PTY
 *===========================================================================*
 * @brief Getter function for Tuner received PTY
 *
 * @returns
 *    Current uint8_t
 *
 * @param  none *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_Tuner_Received_PTY(void);

#if PITS_TUNER_2_IS

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_2_User_PI_Code
 *===========================================================================*
 * @brief Getter function for Tuner 2 Current PI code
 *
 * @returns
 *    Current Tuner quality
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern RDS_Pi_T PITS_Get_Tuner_2_User_PI_Code(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_2_Received_PI
 *===========================================================================*
 * @brief Getter function for Tuner 2 Current PI code
 *
 * @returns
 *    Current Tuner 2 PI code
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern RDS_Pi_T PITS_Get_Tuner_2_Received_PI(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_2_Field_Strenght
 *===========================================================================*
 * @brief Getter function for Tuner Field_Strenght
 *
 * @returns
 *    Current Tuner quality
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_Tuner_2_Field_Strenght(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_2_Received_PTY
 *===========================================================================*
 * @brief Getter function for Tuner 2 Received PTY
 *
 * @returns
 *    Current RDS_Pty_T
 *
 * @param  none *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern RDS_Pty_T PITS_Get_Tuner_2_Received_PTY(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_2_Frequency
 *===========================================================================*
 * @brief Getter function for Tuner 2 Frequency
 *
 * @returns
 *    Current Tuner 2 Frequency
 *
 * @param  none *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint16_t PITS_Get_Tuner_2_Frequency(void);

/*===========================================================================*
 * FUNCTION: PITS_AMFM_Mngr_EM_Tune_Frequency
 *===========================================================================*
 * @brief Set function for Tuner 2 Frequency
 *
 * @returns
 *    none
 *
 * @param  instance_id = 0, frequency, index for tuner2
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_AMFM_Mngr_EM_Tune_Frequency (AMFM_Mngr_Instance_T instance_id, AMFM_Frequency_kHz_T frequency, uint32_t tuner_index);
#endif /*PITS_TUNER_2_IS*/
/*===========================================================================*
 * FUNCTION: PITS_Get_XM_Tuner_SID
 *===========================================================================*
 * @brief Getter function for Tuner XM Sid
 *
 * @returns
 *    
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_XM_Tuner_SID(void);

/**
 * Set FM Frequency status information. 
 *
 * @return     
 *   true - Set execution correctly
 *   false - Invalid frequency.
 * 
 * @param [in]    tune_band_info
 *   Structure for tune band info.
 * @param [in]    message->data[3]
 *   Data information.
 * @param [in]    message->data[4]
 *   Data information.
 */
extern bool_t PITS_Tuner_Set_FM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2);

/**
 * Set AM Frequency status information. 
 *
 * @return     
 *   true - Set execution correctly
 *   false - Invalid frequency.
 * 
 * @param [in]    tune_band_info
 *   Structure for tune band info.
 * @param [in]    message->data[3]
 *   Data information.
 * @param [in]    message->data[4]
 *   Data information.
 */
extern bool_t PITS_Tuner_Set_AM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2);

/**
 * Set XM Frequency status information. 
 *
 * @return     
 *   true - Set execution correctly
 *   false - Invalid frequency.
 * 
 * @param [in]    tune_band_info
 *   Structure for tune band info.
 * @param [in]    message->data[3]
 *   Data information.
 * @param [in]    message->data[4]
 *   Data information.
 */
extern bool_t PITS_Tuner_Set_XM_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2);

/**
 * Set DAB Frequency status information. 
 *
 * @return     
 *   true - Set execution correctly
 *   false - Invalid frequency.
 * 
 * @param [in]    tune_band_info
 *   Structure for tune band info.
 * @param [in]    message->data[3]
 *   Data information.
 * @param [in]    message->data[4]
 *   Data information.
 */
extern bool_t PITS_Tuner_Set_DAB_Value(PITS_Tuner_Mgr_Target_T * pits_band_info, uint8_t msg_data_1, uint8_t msg_data_2);


#if PITS_TMC_IS/**
* Tune to absolute Frequency.
* tune to frequency
*/
extern void PITS_TMC_Tune_Frequency(PITS_Tuner_Mgr_Target_T * frequency, uint8_t msg_data1, uint8_t msg_data2);

/*===========================================================================*
 * FUNCTION: PITS_subscribing_TMC
 *===========================================================================*
 * @brief Function to subscribe TMC Tuner Message XSAL Message
 * @returns
 *    
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_subscribing_TMC(void);

/*===========================================================================*
 * FUNCTION: PITS_TMC_Frequency
 *           PITS_TMC_User_Pi
 *           PITS_TMC_Received_Pi
 *===========================================================================*
 * @brief Functions to retrieve the TMC Data
 *
 * @returns
 *
 * @param [in] msg_data = pointer to the data from event
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint16_t PITS_TMC_Frequency(void);
extern uint16_t PITS_TMC_User_Pi(void);
extern uint16_t PITS_TMC_Received_Pi(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_TMC_RSSI
 *===========================================================================*
 * @brief Getter function for Tuner Field_Strenght
 *
 * @returns
 *    Current TMC Signal Strength
 *
 * @param 
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_TMC_RSSI(void);

#endif

/*===========================================================================*/
/*!
 * @file pits_tuner_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 01 Ago 2012 Miguel Garcia 15
 * Task kok_basa#112307 Include Pits Set Tuner 2
 *
 * 6-Jul-2012 Arturo Perez 14
 * Task kok_basa#107504 - Implement MID 10/11 & 38/39 for Tuner2
 *
 * 4-Jul-2012 Juan Carlos Castillo 13
 * Task kok_basa#106816 - implement TMC Signal Strength
 *
 * 22-May-2012 Juan Carlos Castillo 12
 * Task kok_basa#98416 - gmsbx14_pits - Received PTY PITs
 *
 * 17-May-2012 Juan Carlos Castillo 11
 * Task kok_basa#96194 - gmsbx14_pits - Signal Strength and PI code Pit.
 *
 * 30-Mar-2012 Oscar Vega 10
 * Task kok_basa#86208 - Fix DAB message to use 1 byte to get frequency.
 *
 * 28-Mar-2012 Oscar Vega 9
 * Task kok_basa#85766 - 20 - Fix DAB message to use 1 byte.
 *
 * 30-Jan-2012 Oscar Vega  Rev 8
 * SCR kok_basa#21073: Implemente set/get Request Band and Frequency for DAB
 * Fix: Implement code to get and set frequency for DAB.
 *
 * 13-Jan-2012 Darinka Lopez  Rev 7
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move specific functions for TMC.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 6
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move tuner specif fuctions to proccesing_tuner file .
 *
 * 27 Dec 2011 Miguel Garcia Rev 5
 * Update pits ICR functions to match PDD and SBX
 *
 * 19-Dec-2011 Manuel Robledo  Rev 4 
 * SCR kok_basa#17410: Use SSM event to define current band 
 *
 * 07-Nov-2011 Oscar Vega  Rev 3
 * SCR kok_basa#17473 :  Create PIT to support TMC RF circuitry manufacturing test.
 * Create functionality to support TMC RF circuitry manufacturing test.
 *
 * 26-Oct-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#16236: Implement MSID(11h) - Tuner Services
 * Fix: Make Tuner Services common for ICR and SBX projects.
 *
 * - 12-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_TUNER_SERVICES_CBK_H */
