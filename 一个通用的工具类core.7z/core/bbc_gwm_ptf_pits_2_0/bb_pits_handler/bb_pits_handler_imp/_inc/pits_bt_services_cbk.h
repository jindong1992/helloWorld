#ifndef PITS_BT_SERVICES_CBK_H
#   define PITS_BT_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_bt_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_bt_services_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:07:55 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_bt_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
#if PITS_BLUETOOTH_IS
/**
 * Retrieve BT status connected
 */
extern uint8_t PITS_Get_Bt_Status_Connected(void);

/**
 * Receive a Request for the Initialization, status, and completion of the pairing process
 */
extern uint8_t PITS_BT_Get_Name_Req_Processing(uint8_t* data);

/**
 * Receive a Request message for the Alignment CAL Value.
 */
extern uint8_t PITS_BT_Get_Align_Cal_Req_Processing(uint8_t* data);

/**
 * Writes the data to the selected Persistent Store for the selected PS Key.
 */
extern void PITS_BT_DIAG_PS_Write_Cal(uint8_t * data, size_t data_size);

/**
 * Writes the data to the selected Persistent Store for the selected PS Key.
 */
extern void PITS_BT_DIAG_PS_Write_Name(uint8_t * data, size_t data_size);

/**
 * Set HFAP diat mode.
 */
extern void PITS_HFAP_Diag_Set_Diag_Mode(bool state);

/**
 * Set HFAP AEC state.
 */
extern void PITS_HFAP_Diag_Set_AEC_State(uint8_t value);

/**
 * Get HFAP AEC state.
 */
extern bool PITS_HFAP_Diag_Get_AEC_State(void);

#endif /* BLUETOOTH_IS */

/*===========================================================================*/
/*!
 * @file pits_bt_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 14-Mar-2012 Oscar Vega  Rev 4
 * SCR task_kok_basa#82989 : Add bluetooth services handler in SBX program
 *
 * 27 Jan 2012 Miguel Garcia Rev 3
 * Include Get Bt Status connected
 *
 * 5-Jan-2012 Darinka Lopez  Rev 2
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_BT_SERVICES_CBK_H */
