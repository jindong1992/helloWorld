#ifndef PITS_MESSAGE_HANDLER_CBK_H
#   define PITS_MESSAGE_HANDLER_CBK_H
/*===========================================================================*/
/**
 * @file pits_message_handler_cbk.h
 *
 * PITS Message Handler Callout API definition.
 *
 * %full_filespec:pits_message_handler_cbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:47 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    The list of functions defined by the Pits Message Handler and implemented in other modules.
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * External Function Prototypes for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: send_function
 *===========================================================================*
 * @brief Called by the PITS Message Handler to transmit a PITS packet/message.
 *
 * @returns 
 *    true - if message transmit request was accepted.
 *    false - if message transmit request was rejected or input parameter is invalid.
 *
 * @param [in] *data - pointer to a received message to be handled by PITS
 * @param [in] length - received message length
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 */
/*===========================================================================*/
bool_t send_function(uint8_t * data, uint16_t length);

/*===========================================================================*/
/*!
 * @file pits_message_handler_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2008-04-29  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_MESSAGE_HANDLER_CBK_H */
