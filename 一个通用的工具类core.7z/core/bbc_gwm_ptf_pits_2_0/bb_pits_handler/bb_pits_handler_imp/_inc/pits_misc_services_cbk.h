#ifndef PITS_MISC_SERVICES_CBK_H
#   define PITS_MISC_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_misc_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_misc_services_cbk.h~2:incl:ctc_ec#19 %
 * @version %version:2 %
 * @author  %derived_by:vj430z %
 * @date    %date_modified:Thu May  4 19:40:49 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_misc_services_cfg.h"
#include "pwm.h"
#include "pits_misc_services.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/
extern const PWM_Channel_T GM_PWM_Amp_Channel;

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
/*
 * Gets the Remote Enabled Status.
 *
 * @param   none
 * @return  remote enabled status
 *
 */
extern uint8_t PITS_Get_Remote_Enabled_Status(void);

/*
 * Sets the Remote Enabled Status.
 *
 * @param   remote enabled
 * @return  none
 *
 */
extern void PITS_Set_Remote_Enabled_Status(uint8_t rmt_en);



/*
 * Gets the part Number from the app_header in callouts.
 *
 * @param   none
 * @return  part number 4 bytes
 *
 */

extern uint8_t *PITS_SW_Identifier(void);

/*
 * Gets the VIN Number from the persistent storage and return the same .
 *
 * @param   vin staorage after reading from ps
 * @return  16 digits vin
 *
 */

extern void PITS_Theft_PS_Get_Whole_VIN(Whole_Vin_T vin);
/*
 * Puts the whole VIN Number to the persistent storage.
 *
 * @param   16 bytes of vin
 * @return  none
 *
 */
extern void PITS_Theft_PS_Put_Whole_VIN(Whole_Vin_T vin);

/** 
 *  Generate a PWM output 
 *    This function will configure the necessary I/O and timer to generate the 
 *    requested output signal
 *
 * @param [in] channel_num - PWM output channel number (0-(number of PWM outputs-1))
 * @param [in] freq_hz - Frequency of output signal in hertz.  
 *    The actual lower and upper values may be limit by hardware but need to cover minimum of 90 Hz - 300 KHz. 
 *    A frequency of 0, disables the associated timer and PWM output.  
 * @param duty_cycle - This value specifies the percent high time (duty_cycle / 0x10000) of each pulse.
 *    Actual resolution will be based on timer clock source.
 *    - 0 will generate a continous low output  
 *    - 0xFFFF will generate a continous high output  
 */
extern void PITS_PWM_Set_Output(PWM_Channel_T channel_num, uint32_t freq_hz, uint16_t duty_cycle);


/*
 * Set Key Press
 *
 * @param   diag_keypress
 * @return  none
 *
 */
extern void PITS_Key_Press(PITS_System_Input_T diag_keypress);
/*
 * Get Key Press
 *
 * @param   diag_keypress
 * @return  none
 *
 */
extern void PITS_Enable_Misc_Override(void);
extern void PITS_Disable_Misc_Override(void);
extern void Pits_Prompt_Mgr_Get_Engine_Version(void);
extern void Pits_Get_RTD_Version(void); 
extern void Pits_Get_RTD_Checksum(void);
extern void Pits_ASR_Mgr_Get_Engine_Version(void);

/*
 * Set radio power state.
 *
 * @param   data
 * @return  bool
 *
 */
extern bool_t PIT_Set_Radio_Power(uint8_t data);

#if 0
/**
 * PITS_Get_RTC_Info return md5 checksum
 *
 * @param RTC info
 *
 * @return param [in] - RTC info
 */
extern void PITS_Get_RTC_Info(uint8_t* dtc);
#endif

#if PITS_TMC_IS
/*===========================================================================*
 * FUNCTION: PITS_Get_TMC_Revision
 *===========================================================================*
 * @brief Getter function for TMC revision info *
 * @returns
 *    Current TMC Revision
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t* PITS_Get_TMC_Revision(void);


/*===========================================================================*
 * FUNCTION: PITS_Get_TMC_Revision_Lenght
 *===========================================================================*
 * @brief Getter function for TMC revision info *
 * @returns
 *    Current Lenght of TMC Revision
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern uint8_t PITS_Get_TMC_Revision_Lenght(void);

/*===========================================================================*
 * FUNCTION: PITS_TMC_Ready
 *===========================================================================*
 * @brief Getter function to indicate if data was received from TMC
 *
 * @returns
 *
 * @param [in] bool = true if event was received.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_TMC_Ready(void);
#endif

/**
 * Retrieve the RTD Revision ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_RTD_SWID(uint8_t * data);


/**
 * Retrieve the RTD  Ad value
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern void  Pits_Get_RTD_Ad_Value( uint8_t *data);

/**
 * Retrieve the RTD  Ad value
 *
 * @param [in]   
 *   
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */

extern uint8_t PITS_Misc_Get_RTD_Temperature(void *data);

/**
 * convert RTD  AD value to temperature
 *
 * @param [in]   
 *   .
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */

extern int8_t Pits_RTD_Convert_AD_2_Temperature(uint16_t AD_Value);

/**
 * Retrieve the RTD  Checksum
 *
 * @param [in]   
 *   
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_RTD_Checksum(uint8_t * data);

/*===========================================================================*
 * FUNCTION: PITS_Module_Reset
 *===========================================================================*
 * @brief Function to send Desip message for a reset *
 * @returns
 *
 * @param [in] none
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Module_Reset(void);

/*===========================================================================*
 * FUNCTION: PITS_Module_Reset
 *===========================================================================*
 * @brief Function send desip message to enter sleep mode *
 * @returns
 *
 * @param [in] none
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Module_Enter_Sleep_Mode(void);

/*===========================================================================*
 * FUNCTION: PITS_Exit_Manufacturing mode
 *===========================================================================*
 * @brief Function send to Exit manufacturing mode *
 * @returns
 *
 * @param [in] none
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Exit_Manufacturing_Mode (void);


/**
 * Retrieve the VIP Boot Revision ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VIP_Boot_SWID(uint8_t * data, uint8_t *data_len);

/**
 * Get GPS SWID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_GPS_SWID(uint8_t * data, uint8_t *data_len);

/**
 * Get GPS HWID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_GPS_HWID(uint8_t * data, uint8_t *data_len);

/**
 * Get GPS ROMID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_GPS_ROMID(uint8_t * data, uint8_t *data_len);

/**
 * Retrieve the VIP App Revision ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VIP_App_SWID(uint8_t * data, uint8_t *data_len);

/**
 * Retrieve the Imx app Revision ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_App_SWID(uint8_t * data);

/**
 * Retrieve the Imx Boot Revision ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_Boot_SWID(uint8_t * data, uint8_t *data_len);

/**
 * @brief Get the current radio status.
 *
 * @return
 *   0 - radio off
 *   1 - radio on
 *
 */
extern uint8_t PITS_Get_Radio_Status (void);

/**
 * @brief Get the current ClkOut status.
 *
 * @return
 *   0 - Disabled
 *   1 - Enabled
 *
 */
extern uint8_t PITS_Get_ClkOut_Status (void);

/*
 * Set ClkOut pin state.
 *
 * @param   data
 *   0 - Disabled
 *   1 - Enabled
 * @return  void
 *
 */
extern void PIT_Set_ClkOut(uint8_t data);

/**
 * Retrieve the Imx Playback SWID
 *
 * @param [in]
 *   Pointer to pits buffer structure.
 *
 * @param [out]
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_PLBK_SWID(uint8_t * data);
/**
 * Retrieve the NAV_MAP_DATABASE
 *
 * @param [in]
 *   Pointer to pits buffer structure.
 *
 * @param [out]
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Get_NAV_MAP_DATABASE_Info (uint8_t * data, uint8_t *data_len);

/**
 * Retrieves Microphone Failure Status
 *
 * @param [in] none
 *
 *
 * @param [out]
 *   Returns Failure status.
 */
extern uint8_t PIT_Get_Microphone_Status(void);

/**
 * Microphone AD Value per terminal
 *
 * @param [in] terminal
 *
 *
 * @param [out]
 *   Returns AD Value for specified terminal.
 */
extern bool_t PIT_Get_Microphone_AD_Value (uint8_t mic_terminal, uint8_t *tx_data);
/**
 * Get Display Status
 *
 * @param [in]
 *
 *
 * @param [out]
 *   Returns Display Status.
 */
extern uint8_t Pits_Misc_Display_Status(void);

#if PITS_NAV_IS
/**
 * Retrieve the Nav Map Database Version ID from persistent storage.
 *
 * @param [out]   fw_revision
 *   Returns the Firmware Revision.
 */
extern void Pits_NAV_Mgr_Get_MAP_Database_Version(void);
#endif

#if PITS_BLUETOOTH_IS 

/**
 * Retrieve the Bluetooth Firmware Revision ID from persistent storage.
 *
 * @param [out]   fw_revision
 *   Returns the Firmware Revision.
 */
extern uint8_t PITS_BT_CM_PS_Get_FW_Revision(uint16_t * fw_revision);

/**
 * Retrieve the BT Stack SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_BT_Stack_SWID(uint8_t * data);

/**
 * Retrieve the BT Stack lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_BT_Stack_Lenght(void);
#endif

#if PITS_WIFI_IS
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Build_ID
 *===========================================================================*
 * @brief Get WIFI Build ID
 * @returns none
 * @param [in] none
 */
/*===========================================================================*/
extern uint8_t PITS_Misc_Get_WIFI_Build_ID(uint8_t * data, uint8_t * length);

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Chip_Rev
 *===========================================================================*
 * @brief Get WIFI Chip Revision
 * @returns none
 * @param [in] none
 */
/*===========================================================================*/
extern uint8_t PITS_Misc_Get_WIFI_Chip_Rev(uint8_t * data, uint8_t * length);

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Rom_Name
 *===========================================================================*
 * @brief Get WIFI Rom Name 
 * @returns none
 * @param [in] none
 */
/*===========================================================================*/
extern uint8_t PITS_Misc_Get_WIFI_Rom_Name(uint8_t * data, uint8_t * length);

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_WIFI_Firmware_ID
 *===========================================================================*
 * @brief Get WIFI Firmware ID
 * @returns none
 * @param [in] none
 */
/*===========================================================================*/
extern uint8_t PITS_Misc_Get_WIFI_Firmware_ID(uint8_t * data, uint8_t * length);

#endif

#if PITS_VR_IS
/**
 * Retrieve the VR SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_SWID(uint8_t * data, uint8_t *data_len);

/**
 * Retrieve the VR lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_SWID_Lenght(void);

/**
 * Retrieve the VR Samantha SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_Samantha_SWID(uint8_t * data);

/**
 * Retrieve the VR Samantha lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_Samantha_SWID_Lenght(void);

/**
 * Retrieve the VR Julie SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_Julie_SWID(uint8_t * data);

/**
 * Retrieve the VR Julie lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_Julie_SWID_Lenght(void);

/**
 * Retrieve the VR Paulina SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_Paulina_SWID(uint8_t * data);

/**
 * Retrieve the VR Paulina lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_Paulina_SWID_Lenght(void);

/**
 * Retrieve the VR English SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_English_SWID(uint8_t * data);

/**
 * Retrieve the VR English lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_English_SWID_Lenght(void);

/**
 * Retrieve the VR French SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_French_SWID(uint8_t * data);

/**
 * Retrieve the VR French lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_French_SWID_Lenght(void);

/**
 * Retrieve the VR Mexican SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_Mexican_SWID(uint8_t * data);

/**
 * Retrieve the VR Mexican lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_Mexican_SWID_Lenght(void);

/**
 * Retrieve the VR Speech Rec SW ID
 *
 * @param [in]   
 *   Pointer to pits buffer structure.
 *
 * @param [out]   
 *   Returns SUCCESS/ FAIL/ COMMAND_NO_SUPPORTED
 */
extern uint8_t PITS_Misc_Get_VR_Speech_Rec_SWID(uint8_t * data);

/**
 * Retrieve the VR Speech Rec lenght
 *
 * @param [in]   
 *   none
 *
 * @param [out]   
 *   Returns lenght
 */
extern uint8_t PITS_Get_VR_Speech_Rec_SWID_Lenght(void);
#endif

#ifdef PITS_CCR_IS
/**
 * Save received Software Setting to persistent storage
 *
 * @param [in]
 *   Software Setting to save
 *
 * @param [out]
 *   none
 */
extern void PITS_Set_Sw_Setting(SIP_Set_Software_Project_T setting);

/**
 * Get Software Setting from persistent storage
 *
 * @param [in]
 *   none
 *
 * @param [out]
 *   Returns Software Setting
 */
extern SIP_Set_Software_Project_T PITS_Get_Sw_Setting(void);

#endif

#if PITS_INIC_IS

/*===========================================================================*
 * FUNCTION: PITS_Get_INIC_SWID
 *===========================================================================*
 * Retrieve INIC SWID by processing all ids obtained from MOST
 *
 * @param [in]
 *   none
 *
 * @param [out]
 *   Returns
 *   none
 *===========================================================================*/
extern uint8_t PITS_Get_INIC_SWID(uint8_t *data);

/*===========================================================================*
 * FUNCTION: PITS_Get_INIC_HWID
 *===========================================================================*
 * Retrieve INIC HWID by processing all ids obtained from MOST
 *
 * @param [in]
 *   none
 *
 * @param [out]
 *   Returns
 *   none
 *===========================================================================*/

extern uint8_t PITS_Get_INIC_HWID(uint8_t *data);

/*===========================================================================*
 * FUNCTION:PITS_Get_INIC_FWID
 *===========================================================================*
 *Retrieve INIC FWID by processing all ids obtained from MOST
 *
 * @param [in]
 *   none
 *
 * @param [out]
 *   Returns
 *   none
 *===========================================================================*/
extern uint8_t PITS_Get_INIC_FWID(uint8_t *data);

/*===========================================================================*
 * FUNCTION: PITS_Get_INIC_NSID
 *===========================================================================*
 * Retrieve Net service version by processing all ids obtained from MOST
 *
 * @param [in]
 *   none
 *
 * @param [out]
 *   Returns
 *   none
 *===========================================================================*/
extern uint8_t PITS_Get_INIC_NSID(uint8_t *data);
#endif

#if PITS_DAB_IS
/*===========================================================================*
 * FUNCTION: PITS_Get_DAB_SWID
 *===========================================================================*
 * Retrieve Software Id version by processing data coming from tune module
 *
 * @param [in]
 * pointer to data info (DAB SW Id)
 *
 *
 * @param [out]
 *  Returns SUCCESS
 *===========================================================================*/
extern uint8_t PITS_Get_DAB_SWID(uint8_t *data);

/*===========================================================================*
 * FUNCTION: PITS_Get_DAB_HWID
 *===========================================================================*
 * Retrieve Hardware Id version by processing data coming from tune module
 *
 * @param [in]
 * pointer to data info (DAB HW Id)
 *
 * @param [out]
 *   Returns
 *   SUCCESS
 *===========================================================================*/
extern uint8_t PITS_Get_DAB_HWID(uint8_t *data);
#endif

/**
 * This function receives Antenna power status *
 * @param [in] None
 *
 * @return SIP_Power_Antenna_Status_T
 *
 */
extern void PITS_Put_Power_Antenna_Status(uint8_t antenna, uint8_t status);

/**
 * PITS_Get_Power_Antenna_Status
 * @param [in] SIP_Power_Antenna_Status_T new_power_ANT_status
 * @return none 
 */
extern uint8_t PITS_Get_Power_Antenna_Status(uint8_t antenna);

/**
 * PITS_Get_AD_Port_Status
 * @param [in] AD port
 * @return status 
 */
extern uint16_t PITS_Get_AD_Port_Status(uint8_t port);

#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/**
 * PITS_Get_KB_AD_Port_Status
 * @param [in] KB AD port
 * @return status 
 */
extern uint16_t PITS_Get_KB_AD_Port_Status(uint8_t port);
#endif
/**
 * PITS_Get_IO_Port_Status
 * @param [in] IO port
 * @return status 
 */
extern uint8_t PITS_Get_IO_Port_Status(uint8_t port);

/**
 * if AD port is available
 * @param [in] port
 * @return port available 
 */
extern bool_t PITS_Get_AD_Port_Available(uint8_t port);

/**
 * if IO port is available
 * @param [in] por
 * @return port available 
 */
extern bool_t PITS_Get_IO_Port_Available(uint8_t port);

/*===========================================================================*/
/*!
 * @file pits_misc_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 04-May-2017 Sunil G Rev 2
 * Task ctc_ec#182869: Impl change in PITS\MISC RTC service by getting RTC values from VIP
 *
 * 31-May-2012 Marco Castillo Rev 16
 * Task kok_basa#100232:  Request Microphone Status 1A90/91
 *
 * 29-May-2012 Juan Carlos Castillo  Rev 15
 * Task kok_basa#99843: CLKOUT pin enable/disable PIT
 *
 * 04 May 2012 Miguel Garcia Rev 14
 * Include new Swids
 *
 * 1-May-2012 Darinka Lopez  Rev 13
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 10 Apr 2012 Miguel Garcia Rev 12
 * Fix set power functions
 *
 * 14-Mar-2012 Darinka Lopez  Rev 11
 * Task kok_basa#82581: Update part number lenght for SBX program 
 * Fix lenght in SWIDs for SBX program.
 *
 * 29-Jan-2012 Darinka Lopez  Rev 10
 * Task kok_basa#79858: Update SWID function for K0R Boot ID.
 * Add callouts functions for swids..
 *
 * 25-Jan-2012 Erick Sanchez Rev 9
 * SCR kok_basa#19539: PITS: MSID 1A - MID 12 - Exit Diagnostics Mode
 * Fix: Implement PITS (MSID 1A - MID 12) to Exit Diagnostics Mode
 *
 * 19-Jan-2012 Oscar Vega  Rev 8
 * SCR kok_basa#19539: PITS: MSID 1A - MID 16 - Module Reset (cold start)
 * SCR kok_basa#19537: PITS: MSID 1A - MID 14 -  Enter Sleep Mode
 * Fix: Implement desip messages to reset and enter sleep mode.
 *
 * 13-Jan-2012 Darinka Lopez  Rev 7
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move specific functions for TMC.
 *
 * 08 Dic 2011 Erick Sanchez Rev 6
 * SCR kok_basa#17782 Implement PIT part number (MSID=1A, MID=E2).
 * Add an extern function to recognize and Implement PIT part number (MSID=1A, MID=E2).
 *
 * 31 Oct 2011 Miguel Garcia Rev 4
 * Include Voice Swids callouts
 *
 * 26 Oct 2011 Oscar Vega Rev 3
 * kok_basa#16264: Implement MSID(1Ah) - Other Misc. Services.
 *
 * 10-Sept-2009 David Mooar  Rev 1
 * SCR kok_aud#62401/62406/62439/62488: Implement Misc Services.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_MISC_SERVICES_CBK_H */
