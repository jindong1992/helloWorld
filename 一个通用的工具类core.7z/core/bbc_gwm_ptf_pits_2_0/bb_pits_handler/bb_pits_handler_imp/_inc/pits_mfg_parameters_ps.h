#ifndef PITS_MFG_PARAMETERS_PS_H
#   define PITS_MFG_PARAMETERS_PS_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*/
/**
 * @file pits_mfg_parameters_ps.h
 *
 * Persistant Storage Prototypes for the pits mfg parameters.
 *
 * %full_filespec:pits_mfg_parameters_ps.h~1:incl:ctc_ec#24 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:51 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Prototypes for accessing persistent storage of theft.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_J2_Theft_Lock_Draft.doc.
 *	 - J2_Theft_Lock_Use_Cases_v2.0.doc
 *
 *   - Requirements Document(s):
 *     - PDD_J2_20090923.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   -  "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_common_types.h"
#include "pits_application_manager.h"
#include "pits_parameter_list_cfg.h"
#include "mfg_parameters_ps.h"
/*===========================================================================*
 * Exported Preprocessor #define Constants for Persistent Storage
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Persistent Storage
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for persistent storage access routines
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Read
 *===========================================================================*
 * @brief Read Function for specific parameter id
 *
 * @returns
 *    unit8_t = Parameter status
 *
 * @param [in] data =  TX Buffer data
 * @param [in] length = length expected
 *
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#undef PARAM_LIST
#define PARAM_IDS(pmid, pmidnum, size, read_write, name)   extern uint8_t PITS_##pmid##_Read(uint8_t * data, uint8_t length);
#define PARAM_LIST(pmlist, plnum, name)                    PPS_##pmlist##_IDS 
PPS_PARAMETER_LISTS

/*===========================================================================*
 * FUNCTION: PITS_##pmid##_Write
 *===========================================================================*
 * @brief Write Function for specific parameter id
 *
 * @returns
 *    unit8_t = Parameter status
 *
 * @param [in] data =  TX Buffer data
 * @param [in] length = length expected
 *
 *
 */
/*===========================================================================*/
#undef PARAM_IDS
#undef PARAM_LIST
#define PARAM_IDS(pmid, pmidnum, size, read_write, name)   extern uint8_t PITS_##pmid##_Write(uint8_t * data, uint8_t length);
#define PARAM_LIST(pmlist, plnum, name)                    PPS_##pmlist##_IDS 
PPS_PARAMETER_LISTS

/*===========================================================================*/
/*!
 * @file pits_mfg_parameters_ps.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 26-Nov-2012 Arthur Chen
 * Add variables to PS for gwm mpi
 * 
 * 21-Aug-2012 Christian Nigri
 * SCR kok_basa#30915/Task kok_basa#115478: Remove Hand Drive Selection Get/Put function
 *
 * 02-Aug-2012 Christian Nigri
 * SCR kok_basa#29475/Task kok_basa#112335 Add Hand Drive Selection Get/Put function
 *
 * 1-May-2012 Darinka Lopez  Rev 9
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 23 Apr 2012 Miguel Garcia and Gustavo M Guzman
 * SCR kok_basa#24936 XM setting to 1 the bit 5 of the DID $7C XM
 * Update to check the bit 5 and added function to Get value
 *
 * 23 Mar 2012 Miguel Garcia
 * Include DID XM enable flag
 *
 * 07 Mar 2012 Miguel Garcia
 * Include ipdo diag lingos
 * Include pits mics dtcs
 *
 * 09 Feb 2012 Miguel Garcia
 * Include Vip App SWID
 *
 * 22 Nov 2011 Miguel Garcia
 * Include RTC daytrim
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /*PITS_MFG_PARAMETERS_PS_H */
