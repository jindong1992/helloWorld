#ifndef PITS_MFG_SERVICES_CBK_H
#   define PITS_MFG_SERVICES_CBK_H
/*===========================================================================*/
/**
 * @file pits_mfg_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_mfg_services_cbk.h~2:incl:ctc_ec#3 %
 * @version %version:2 %
 * @author  %derived_by:vj430z %
 * @date    %date_modified:Tue Mar 28 15:06:01 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_mfg_services_cfg.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * PITS_Set_Load_Defaults - Load Rom Defaults.
 *
 * @param uint8_t default_option   0 all, 1 factory data, 2 customer cals, 3 Nonvol, 4 USB, 5 Metadata, 6 Tuner
 *
 * @return success, not supported
 */
extern uint8_t PITS_Set_Load_Defaults (uint8_t default_option);

/**
 * PITS_Get_Reflash_Status
 *
 * @param none
 *
 * @return reflash status
 */
extern uint8_t PITS_Get_Reflash_Status(void);

/**
 * PITS_Get_Reflash_Mode 
 *
 * @param none
 *
 * @return true if not already set
 */
extern bool_t PITS_Get_Reflash_Mode(void);

/**
 * PITS_Set_Reflash_Mode 
 *
 * @param none
 *
 * @return nonet
 */
extern void PITS_Set_Reflash_Mode(void);

/**
 * PITS_Man_Test_Request_MD5_Calc send info to calculate md5.
 *
 * @param mtd section, block size of the current mtd.
 *
 * @return none
 */
extern void PITS_Man_Test_Request_MD5_Calc(uint8_t mtd, uint_least64_t block_size);

/**
 * PITS_MAN_Test_Get_MD5_Calc_Status return calculation status.
 *
 * @param mtd section
 *
 * @return status
 */
extern uint8_t PITS_MAN_Test_Get_MD5_Calc_Status(uint8_t mtd);

/**
 * PITS_Man_Test_Get_MD5_Checksum return md5 checksum
 *
 * @param mtd section
 *
 * @return param [in] - md5 checksum
 */
extern void PITS_Man_Test_Get_MD5_Checksum(uint8_t mtd, uint8_t* md5_chksum);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file pits_mfg_services_cbk.h
 *
 *  19April2017 Sunil G(vj430z)
 *  ctc_ec#179701: Checksum Calculation for mmcblk0p7
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 24-jun-2014 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* PITS_MFG_SERVICES_CBK_H */
