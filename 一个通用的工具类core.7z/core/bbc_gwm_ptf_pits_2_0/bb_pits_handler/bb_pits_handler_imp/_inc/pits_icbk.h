#ifndef PITS_ICBK_H
#   define PITS_ICBK_H
/*===========================================================================*/
/**
 * @file pits_icbk.h
 *
 * Defines the implementation-specific callouts and constants that must be
 * provided by another module in the system
 *
 * %full_filespec:pits_icbk.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:38 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 * 	  Isolates the implementation-specific constants and callouts so that the
 *    remainder of the module can be reused without modification.
 * 
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#   include "xsal.h"

/*===========================================================================*\
 * Exported Preprocessor #define Constants for Callouts
\*===========================================================================*/

/*===========================================================================*\
 * Exported Preprocessor #define MACROS for Callouts
\*===========================================================================*/

/*===========================================================================*\
 * Exported Type Declarations for Callouts
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Declarations
\*===========================================================================*/

/**
 * Thread configuration for State of Health Manager
 */
extern const SAL_Thread_Attr_T SOH_Thread_Attr;


/*===========================================================================*\
 * Exported Function Prototypes for Callouts
\*===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_icbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2008-07-15  Larry Ong
 * 	  - Created initial file.
 *
\*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_ICBK_H */
