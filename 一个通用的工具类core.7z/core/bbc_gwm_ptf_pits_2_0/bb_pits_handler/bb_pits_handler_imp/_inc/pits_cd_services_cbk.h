#ifndef PITS_CD_SERVICES_CBK_H
#   define PITS_CD_SERVICES_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_cd_services_cbk.h
 *
 * @todo Add a one line description of the header.
 *
 * %full_filespec:pits_cd_services_cbk.h~1:incl:ctc_ec#17 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:08:03 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_cd_services_cfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/
/**
 * Get CD status information. 
 *
 * @return     
 *   pits_cd_status
 *
 * @param [in]    pits_cd_status
 *   Structure for cd status info.
 */
extern void PITS_Get_CD_Status(PITS_CD_DVD_Status_T * pits_cd_status);

/**
 * Get DVD status information. 
 *
 * @return     
 *   pits_dvd_status
 * 
 * @param [in]    pits_dvd_status
 *   Structure for dvd status info.
 */
extern void PITS_Get_DVD_Status(PITS_CD_DVD_Status_T * pits_dvd_status);

/**
 * Get CD position information. 
 *
 * @return     
 *   cd_positions
 *
 * @param [in]    cd_positions
 *   Structure for cd position info.
 */
extern void PITS_Get_CD_Media_Position(PITS_CD_DVD_Media_Pos_T * cd_positions);

/**
 * Get DVD position information. 
 *
 * @return     
 *   dvd_positions
 * 
 * @param [in]    dvd_positions
 *   Structure for dvd position info.
 */
extern void PITS_Get_DVD_Media_Position(PITS_CD_DVD_Media_Pos_T * dvd_positions);

/**
 * Get If disc is a valid CD. 
 *
 * @return     
 *   true/false
 * 
 * @param [in]    disc_type
 *   disc type received.
 */
extern bool_t PITS_Valid_CD_Type (uint8_t disc_type);



/**
 * Get If disc is a valid DVD. 
 *
 * @return     
 *   true/false
 * 
 * @param [in]    disc_type
 *   disc type received.
 */
extern bool_t PITS_Valid_DVD_Type (uint8_t disc_type);

/**
 * Go to next track 
 *
 * @return     
 *   none
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 * @param [in]    new_track
 *   new track selection.
 */
extern void PITS_Set_Next_Track(uint8_t mech_data, uint16_t new_track);

/**
 * Go to previous track 
 *
 * @return     
 *   none
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 * @param [in]    new_track
 *   new track selection.
 */
extern void PITS_Set_Prev_Track(uint8_t mech_data, uint16_t new_track);

/**
 * Verify if no media is preset
 *
 * @return     
 *   bool (Media no Available = true)
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 * @param [in]    pits_media_status
 *   Current media status (CD or DVD).
 */
extern bool_t PITS_Verify_No_Media_Available(uint8_t mech_data, uint8_t pits_media_status);

/**
 * Verify if ejected status is true
 *
 * @return     
 *   bool (Ejected status = true)
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 * @param [in]    pits_media_status
 *   Current media status (CD or DVD).
 */
extern bool_t PITS_Verify_Ejected_Status(uint8_t mech_data, uint8_t pits_media_status);

/**
 * Eject CD (CD or DVD)
 *
 * @return     
 *   none
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 */
extern void PITS_Disc_Eject(uint8_t mech_data);

/**
 * Insert CD (CD or DVD)
 *
 * @return     
 *   none
 * 
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 */
extern void PITS_Disc_Insert(uint8_t mech_data);

/**
 * Get the current Device type according ps value.
 *
 * @return     
 *   unit8_t = device type (CD or DVD)
 * 
 * @param [in] none
 */
extern uint8_t PITS_Device_Type(void);

/**
 * Go to position track/title chapter
 *
 * @return
 *   none
 *
 * @param [in]    mech_data
 *   type of device (CD or DVD).
 * @param [in]    new_track
 *   new track selection.
 *   * @param [in]    new_chapter
 *   new chapter selection.
 */
extern void PITS_Set_Go_To_Track(uint8_t mech_data, uint16_t new_track, uint16_t new_chapter);

/*===========================================================================*/
/*!
 * @file pits_cd_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka Lopez Rev 8
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 1-May-2012 Darinka Lopez  Rev 6
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 20 Dec 2011 Miguel Garcia Rev 4
 * Include pits get dvd number of titles
 *
 * 28 Nov 2011 Oscar Vega Rev 3
 * Rename files to pits_cd_services_cfg to avoid borke builds
 *
 * 22-Nov-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#16242: Implement MSID(15h) - CD/DVD Services.
 * Fix: Make changes in CD Services BB to support SBX program.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_CD_SERVICES_CBK_H */
