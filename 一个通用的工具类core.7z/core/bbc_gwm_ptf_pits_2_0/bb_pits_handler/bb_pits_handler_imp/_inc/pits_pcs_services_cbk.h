#ifndef PITS_PCS_SERVICES_CBK_H
#   define PITS_PCS_SERVICES_CBK_H
/*===========================================================================*/
/**
 * @file pits_pcs_services_cbk.h
 *
 * PITS PCS Services Callout API Definitions.
 *
 * %full_filespec:pits_pcs_services_cbk.h~1:incl:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:09:17 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *    This module defines the PITS PCS Services callout APIs for the J2 project,
 *    the callout functions are implemented elsewhere.
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "iic.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * External Function Prototypes for API Callouts
 *===========================================================================*/

/**
 * @brief Get the currently tuned receiver band.
 *
 * @param [in] tuner_id   ID of tuner to get receiver band from
 *
 * @return
 *   receiver band TUNER_BAND_AM, TUNER_BAND_FM, TUNER_BAND_WX.
 *
 */
extern uint8_t PITS_Get_Receiver_Band(uint8_t tuner_id);

/**
 * @brief Get the currently tuned frequency.
 *
 * @param [in] tuner_id   ID of tuner to get receiver frequency from
 *
 * @return
 *   frequency (for FM in 10kHz steps, for AM in 1kHz steps)
 *
 */
extern uint16_t PITS_Get_Frequency(uint8_t tuner_id);

/**
 * @brief Get the current signal strength.
 *
 * @param [in] tuner_id   ID of tuner to get signal strength from
 *
 * @return
 *   signal strength
 *
 */
extern uint8_t PITS_Get_Signal_Strength(uint8_t tuner_id);

/**
 * @brief Set receiver to the given band.
 *
 * @param [in] tuner_band   radio band to set to
 * @param [in] tuner_id     ID of tuner to set band
 *
 * @return
 *   none
 *
 */
extern void PITS_Set_Receiver_Band(uint8_t tuner_band, uint8_t tuner_id);

/**
 * @brief Set receiver to the given frequency.
 *
 * @param [in] tuner_frequency   radio frequency to tune to
 * @param [in] tuner_id          ID of tuner to tune
 *
 * @return
 *   none
 *
 * HMI is also updated with new frequency.
 *
 */
extern void PITS_Set_Frequency(uint16_t tuner_frequency, uint8_t tuner_id);

/**
 * @brief Hook function to handle IIC comunication with DICE ICs.
 *
 * @param [in] channel        IIC channel
 * @param [in] device         IIC device address
 * @param [in] timeout_msec   timeout for writting data into DSP
 *
 * @return
 *   none
 *
 * Function check device address of message sent via IIC bus.
 * If data is read from or written to one of DICE ICs, function send
 * first special IIC command to DSP to open the communication gate
 * between DSP and DICE.
 *
 */
extern void PITS_IIC_hook(IIC_Channel_T channel, uint8_t device, uint32_t timeout_msec);

/**
 * @brief Write data into Persistent Storage.
 *
 * @param [in] addr        destination address to write data
 * @param [in] w_data      pointer to data
 * @param [in] num_bytes   number of bytes to write
 * @param [in] Key         currently not used
 *
 * @return
 *   TRUE   if success
 *   FALSE  if cannot write data
 *
 */
extern bool_t PITS_PS_Write_DIAG (uint32_t addr, const void *w_data, size_t num_bytes, int16_t Key);

/**
 * @brief Read data from Persistent Storage.
 *
 * @param [in] addr        destination address to read data
 * @param [in] w_data      pointer to data
 * @param [in] num_bytes   number of bytes to read
 *
 * @return
 *   TRUE   if success
 *   FALSE  if cannot read data
 *
 */
extern bool_t PITS_PS_Read_DIAG (uint32_t addr, const void *w_data, size_t num_bytes);

/**
 * @brief Get the current volume level.
 *
 * @return
 *   volume level
 *   0x00=min. volume...0xFF=max. volume
 *
 */
extern uint8_t PITS_Get_Volume (void);

/**
 * @brief Set volume to the given level.
 *
 * @param [in] volume   volume level to set to
 *                      0x00=min. volume...0xFF=max. volume
 *
 * @return
 *   none
 *
 */
extern void PITS_Set_Volume (uint8_t volume);

/**
 * @brief Set radio status.
 *
 * @param [in] radio_status
 *             0=radio off
 *             1=radio on
 *
 * @return
 *   none
 *
 */
extern void PITS_Set_Radio_Status (uint8_t radio_status);

/**
 * @brief Get the current balance level.
 *
 * @return
 *   balance level
 *   0x00=left only...0xFF=right only
 *
 */
extern uint8_t PITS_Get_Balance(void);

/**
 * @brief Set balance to the given level.
 *
 * @param [in] balance   balance level to set to
 *                       0x00=left only...0xFF=right only
 *
 * @return
 *   none
 *
 */
extern void PITS_Set_Balance(uint8_t balance);

/**
 * @brief Get the current fade level.
 *
 * @return
 *   fade level
 *   0x00=rear only...0xFF=front only
 *
 */
extern uint8_t PITS_Get_Fade(void);

/**
 * @brief Set fade to the given level.
 *
 * @param [in] fade   fade level to set to
 *                    0x00=rear only...0xFF=front only
 *
 * @return
 *   none
 *
 */
extern void PITS_Set_Fade(uint8_t fade);

/**
 * @brief Get the current tone level for given equalizer number.
 *
 * @param [in] eq_number   equalizer number
 *
 * @return
 *   tone level
 *   0x00=min. gain...0xFF=max. gain
 *
 *   Function return 0 if equalizer number is greater than
 *   number of equalizers available.
 *
 */
extern uint8_t PITS_Get_Tone(uint8_t eq_number);

/**
 * @brief Set tone to the given level for specified equalizer.
 *
 * @param [in] eq_number   equalizer number
 * @param [in] tone        tone level
 *                         0x00=min. gain...0xFF=max. gain
 *
 * @return
 *   TRUE   if success
 *   FALSE  if equalizer number is greater than
 *          number of equalizers available
 *
 */
extern bool_t PITS_Set_Tone(uint8_t eq_number, uint8_t tone);

/*===========================================================================*/
/*!
 * @file pits_pcs_services_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2007-11-30  Jaroslaw Saferna
 *    - External function prototypes for API callouts:
 *       - PITS_Get_Balance()
 *       - PITS_Set_Balance()
 *       - PITS_Get_Fade()
 *       - PITS_Set_Fade()
 *       - PITS_Get_Tone()
 *       - PITS_Set_Tone()
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-24  Jaroslaw Saferna
 *    - External function prototypes for API callouts:
 *       - PITS_Get_Volume()
 *       - PITS_Set_Volume()
 *       - PITS_Get_Radio_Status()
 *       - PITS_Set_Radio_Status()
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-09-27  dz23f5 - Jaroslaw Saferna
 *    - External function prototypes for API callouts:
 *       - PITS_PS_Write_DIAG()
 *       - PITS_PS_Read_DIAG()
 *
 * - 2007-09-19  dz23f5 - Jaroslaw Saferna
 *    - Prototype for PITS_IIC_hook() function added
 *
 * - 2007-09-19  dz23f5 - Jaroslaw Saferna
 *    - External function prototypes for API callouts added
 *       - PITS_Get_Receiver_Band()
 *       - PITS_Get_Frequency()
 *       - PITS_Get_Signal_Strength()
 *       - PITS_Set_Receiver_Band()
 *       - PITS_Set_Frequency()
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-09-14 dz23f5 - Jaroslaw Saferna
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_PCS_SERVICES_CBK_H */
