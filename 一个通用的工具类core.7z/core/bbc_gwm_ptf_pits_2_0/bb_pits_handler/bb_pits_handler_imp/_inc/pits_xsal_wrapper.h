#ifndef PITS_XSAL_WRAPPER_H
#   define PITS_XSAL_WRAPPER_H
/*===========================================================================*/
/**
 * @file pits_xsal_wrapper.h
 *
 * Exposes the interface for the XSAL wrapper.
 *
 * %full_filespec:pits_xsal_wrapper.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:09:56 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    PITS XSAL Bearing Bus Wapper.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - XSAL:  "next generation" System Abstraction Layer (XSAL).
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None.
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_configuration.h"
#   include "pits_message_handler.h"

/**********************************************************************
 * Application specific Header files
 *********************************************************************/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
/* @todo make this const */
/* Bearing Bus structure to be included in the Configuration. */
extern PITS_Bearing_Bus_T GM_Diag_Bearing_Bus;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*/
/**
 * @brief Called by the Bearing Bus when a message is received for PITS.
 *
 * @returns 
 *    true - if message transmit request was accepted.
 *    false - if message transmit request was rejected or input parameter is invalid.
 *
 * @param
 *    *data - pointer to a received message to be handled by PITS.
 *    length - received message length.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * @param length
 *   Number of data bytes included in *data.
 *
 */
/*===========================================================================*/
extern void PITS_XSAL_Receive_Function(const uint8_t * data, uint16_t length);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_xsal_wrapper.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 3
 *  Merged: Fix parallel versions
 *
 * 25-May-2010 Miguel Garcia  Rev 2
 * SCR kok_basa#1674: Change Bearing Bus name to GM_Diag_Bearing_Bus.
 *
 * - 2008-10-09  Yi Liu
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_XSAL_WRAPPER_H */
