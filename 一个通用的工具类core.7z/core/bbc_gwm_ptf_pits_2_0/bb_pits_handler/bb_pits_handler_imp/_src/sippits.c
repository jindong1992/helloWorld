/*===========================================================================*/
/**
 * @file sippits.c
 *
 * DESIP (Delco Electronics Serial Interface Protocol) module for BASA
 *
 * %full_filespec:sippits.c~1:csrc:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:21 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This is the interface module for init, open, close of desip channel for pits and the timer interfaces.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - DESIP: Delco Electronics Serial Interface Protocol.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "sippits.h"
#   include "pits_configuration.h"

#   include "uart.h"
#   include "em.h"
#   include <stdio.h>

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID_2, 3);     /**< define file for assert handling for BASA */

static int sipGetChar(void);

static int sipPutChar(int data);

static int tmr_counter = 0;

/*
 * Initialize the DESIP channel
 */
int SIPPITS_Init(void)
{
   int sipinit = 1;

   /* UART configuration */
   const UA_Attribute_T pits_attributes = {
      UA_8_DATA_BITS,
      UA_1_STOP_BIT,
      UA_ODD_PARITY,
      115200,
      UA_HANDSHAKE_NONE
   };

   /* Open PITS UART Channel */
   PITS_CHANNEL != UA_Open(PITS_CHANNEL, &pits_attributes);
   sipinit = SIPInit();
   return sipinit;
}

/*
 * Open a DESIP channel
 */
SIP_HANDLE SIPPITS_Open(void)
{
   SIP_HANDLE sh;

   sh = SIPOpen("PITS Node", sipGetChar, sipPutChar);
   return sh;
}

/*
 * Close the DESIP channel
 */
void SIPPITS_Close(void)
{
   UA_Close(PITS_CHANNEL);
}

/*
 * DESIP State Machine Periodic Call --
 */
void SIPPITS_FSM(void)
{
   SIPFSM();
}

/* Returns Timer counter  */
int TmrGet(void)
{
   return tmr_counter;
}

/* Increment Timer counter by periodic rate */
void SIPPITS_Tmr_Update(void)
{
   tmr_counter += PITS_POLL_RATE_MS;
}

/* Clear Timer counter */
void SIPPITS_Tmr_Clear(void)
{
   tmr_counter = 0;
}

/*
 * sipGetChar -- This is helper function provides wrapper function for
 *               UA_Get_Byte function to be used by SIP_Open function
 *               return the received character on active serial port
 *               or -1 if none ready.
 */
static int sipGetChar(void)
{
   /* Needs  different variables to be compatible with UART and DESIP Interfaces */
   int status;

   status = (int)UA_Getc(PITS_CHANNEL);

   if (status == EOF)
   {
      status = -1;
   }

   return status;
}

/*
 * sipPutChar -- This is helper function provides wrapper function for
 *               UA_Put_Data function to be used by SIP_Open function
 *               Returns character sent or -1 if buffer is full.
 */
static int sipPutChar(int data)
{
   /* Needs different variables to be compatible with UART and DESIP Interfaces */
   uint8_t data_byte = (uint8_t) data;
   int status;

   status = (int)UA_Putc(PITS_CHANNEL, data_byte);

   if (status == EOF)
   {
      status = -1;
   }

   return status;
}


/*===========================================================================*/
/*!
 * @file sipPITS.C
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-06-02  Larry Ong
 *    - Adapted for PITS DESIP Manager.
 *
 * - 2003-10-01  Gitesh
 *    - Changed the tmr_counter increment value from a hardcoded value to a global
 *      variable. This variable is initialized in the SIPInit_Pits() function to 32ms.
 *
 * - 2003-04-16  Roger/Srikant
 *    - Initial version.
 */
/*===========================================================================*/
