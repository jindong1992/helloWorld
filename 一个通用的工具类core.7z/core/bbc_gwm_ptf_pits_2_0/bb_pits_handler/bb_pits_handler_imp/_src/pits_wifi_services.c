/*===========================================================================*/
/**
 * @file pits_wifi_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_wifi_services.c~2:csrc:ctc_ec#20 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Thu Jun 23 17:09:21 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_configuration.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "pits_wifi_services_cfg.h"
#include "pits_wifi_services.h"
#include "pits_processing_wifi.h"
#include "wifi_proxy.h"


EM_FILENUM(PITS_MODULE_ID_5, 18);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void PITS_Wifi_Initialize(void);
static void PITS_Wifi_Compose_Message_Header(uint8_t mid, uint8_t size);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_WIFI_RX_INDEX

#define MID_WIFI_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T PITS_Wifi_RX_Messages[] = {
   MID_WIFI_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_WIFI_TX_INDEX

#define MID_WIFI_TX_INDEX(name, mid) (mid),

static const uint8_t PITS_Wifi_TX_Messages[] = {
   MID_WIFI_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_WIFI_RX_INDEX
#define MSID_WIFI_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T PITS_Wifi_RX_Message_Sets[] = {
   MSID_WIFI_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_WIFI_TX_INDEX
#define MSID_WIFI_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T PITS_Wifi_TX_Message_Sets[] = {
   MSID_WIFI_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static uint8_t Wifi_TX_Bus_ID;   /* ID of the bearing bus on which to send response */

static PITS_Message_T Wifi_TX_Message;      /* for construction of a misc service message to be transmitted */

static uint8_t Wifi_TX_Data[PITS_MAX_MESSAGE_SIZE];

static uint8_t Pits_wifi_connect_req_channel = 0;
static uint8_t Pits_wifi_connect_req_Mac_addr[6];
static bool Pits_wifi_connect_req_filter = false;

static bool_t pits_wifi_set_flag = false;

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Wifi_Services_Interface = {
   PITS_Wifi_Initialize,
   PITS_Wifi_RX_Message_Sets,
   Num_Elems(PITS_Wifi_RX_Message_Sets),
   PITS_Wifi_TX_Message_Sets,
   Num_Elems(PITS_Wifi_TX_Message_Sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Misc_Initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
static void PITS_Wifi_Initialize(void)
{
   Wifi_TX_Bus_ID = 0;
   memset(&Wifi_TX_Message, 0x00, sizeof(PITS_Message_T));
   memset(Wifi_TX_Data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

static void PITS_Wifi_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   Wifi_TX_Message.bus = Wifi_TX_Bus_ID;
   Wifi_TX_Message.data = Wifi_TX_Data;
   Wifi_TX_Message.MSID = MSID_WIFI_SERVICES;
   Wifi_TX_Message.MID = mid;
   Wifi_TX_Message.data_size = size;
   memset(&Wifi_TX_Data[0], 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Test_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Test_Req(const PITS_Message_T * message)
{
   
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_TEST_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if ( PITS_WIFI_ON == message->data[0])
         {
            Wifi_Proxy_Diagnose_Start();
            PITS_Wifi_Test_In_Processing();
         }
         else if(PITS_WIFI_OFF == message->data[0])
         {
            Wifi_Proxy_Diagnose_Stop();
            PITS_Wifi_Test_In_Processing();
         }
         else
         {
            Wifi_TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Test_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Query_Test_Status_Req(const PITS_Message_T * message)
{
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_QUERY_WIFI_TEST_STATUS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {

         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = (uint8_t) PITS_Get_Wifi_Test_Status();
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}


/*===========================================================================*
 * FUNCTION: PITS_Wifi_Set_Mac_Addr_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Set_Mac_Addr_Req(const PITS_Message_T * message)
{
   uint8_t Mac_Address[PITS_WIFI_MAC_ADDR_MAX_LENS];
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SET_MAC_ADDR_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 6)
      {
         PITS_PBS_Error_Report("WiFi Set Mac Address: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         memcpy(Mac_Address, &message->data[0], PITS_WIFI_MAC_ADDR_MAX_LENS);
         PITS_WIFI_Set_Mac_Addr(Mac_Address);
         memcpy(&Wifi_TX_Data[1], Mac_Address, PITS_WIFI_MAC_ADDR_MAX_LENS);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Query_Mac_Addr_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Addr_Req(const PITS_Message_T * message)
{
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MAC_ADDR_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi get Mac Address: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {

         if ( false != PITS_WIFI_Get_Mac_Addr(&Wifi_TX_Data[1]))
         {
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            Wifi_TX_Data[0] = (uint8_t) FAIL;
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}



/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_IP_Address_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_IP_Address_Req(const PITS_Message_T * message)
{
   uint8_t  IP_Address_Pits[4] = {0,0,0,0};
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_IP_ADDRESS_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         #if 0
         memcpy(&IP_Address_Pits[0],Get_WiFi_IP_Address(),4);
         #endif
         Wifi_TX_Data[1] = IP_Address_Pits[0];
         Wifi_TX_Data[2] = IP_Address_Pits[1];
         Wifi_TX_Data[3] = IP_Address_Pits[2];
         Wifi_TX_Data[4] = IP_Address_Pits[3];
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_IP_Address_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Set_IP_Address_Req(const PITS_Message_T * message)
{
#if 0
   uint8_t  IP_Address_Pits[4] = {0,0,0,0};
   uint8_t  IP_Address_Pits2[4] = {0,0,0,0};
#endif
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SET_IP_ADDRESS_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
      #if 0
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         IP_Address_Pits[0] = message->data[0];
         IP_Address_Pits[1] = message->data[1];
         IP_Address_Pits[2] = message->data[2];
         IP_Address_Pits[3] = message->data[3];

         memcpy(&IP_Address_Pits2[0],Set_WiFi_IP_Address(IP_Address_Pits),4);
         Wifi_TX_Data[1] = IP_Address_Pits2[0];
         Wifi_TX_Data[2] = IP_Address_Pits2[1];
         Wifi_TX_Data[3] = IP_Address_Pits2[2];
         Wifi_TX_Data[4] = IP_Address_Pits2[3];
      #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Tot_Networks_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Tot_Networks_Req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_TOT_NETWORKS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
      #if 0
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = Get_WiFi_Total_NUM_Networks();
      #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Start_Packets_trans_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Start_Packets_trans_Req(const PITS_Message_T * message)
{
   uint8_t pits_wifi_mac_addr[PITS_WIFI_MAC_ADDR_MAX_LENS];
   uint16_t pit_channel = 0;
   uint8_t pit_PowerValue = 0;
   uint16_t pit_DataRate = 1;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_START_PACKETS_TRANS_RPT, 10);

      /* Compose Message Data */
      if (message->data_size != 9)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Start_Packets_trans_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         memcpy(pits_wifi_mac_addr, &message->data[0], PITS_WIFI_MAC_ADDR_MAX_LENS);
         pit_channel = (uint16_t)(message->data[6]);
         pit_PowerValue = message->data[7];
         pit_DataRate = (uint16_t)message->data[8];

         Wifi_Proxy_Diagnose_Start_Send(pit_channel, pit_PowerValue, pit_DataRate, 0, pits_wifi_mac_addr);

         memcpy(&Wifi_TX_Data[1], &message->data[0], 9);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Noise_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Set_Carrier_Req(const PITS_Message_T * message)
{
   uint16_t pit_channel = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SET_CARRIER_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Set_Carrier_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;

         pit_channel = (uint16_t)(message->data[0]);
         PITS_WIFI_Save_Carrier_Channel(pit_channel);
         Wifi_Proxy_Diagnose_Start_CW_Send(pit_channel);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Carrier_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Carrier_Req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_CARRIER_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Carrier_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = (uint8_t) PITS_WIFI_Get_Carrier_Channel();
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}


/*===========================================================================*
 * FUNCTION: PITS_Wifi_Set_Alignment_Cal_Req
 *===========================================================================*
 * @brief PITS_Wifi_Set_Alignment_Cal_Req
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] 

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = 
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Set_Alignment_Cal_Req(const PITS_Message_T * message)
{
   uint8_t XtalTrim = 0;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SET_ALIGN_CAL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Set_Alignment_Cal_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         XtalTrim = (message->data[0]);
         PITS_WIFI_Save_XtalTrim(XtalTrim);
         pits_wifi_set_flag = true;
         Wifi_TX_Data[1] = XtalTrim;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}


/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Alignment_Cal_Req
 *===========================================================================*
 * @brief PITS_Wifi_Get_Alignment_Cal_Req
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] 

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = 
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Alignment_Cal_Req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_ALIGN_CAL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Alignment_Cal_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (pits_wifi_set_flag)
         {
            Wifi_TX_Data[1] = PITS_WIFI_Get_XtalTrim();
         }
         else
         {
            PITS_WIFI_Get_Final_XtalTrim(&Wifi_TX_Data[1]);
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Save_Alignment_Cal_Req
 *===========================================================================*
 * @brief PITS_Wifi_Save_Alignment_Cal_Req
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] 

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = 
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Save_Alignment_Cal_Req(const PITS_Message_T * message)
{
   uint8_t XtalTrim = 0;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SAVE_ALIGN_CAL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Save_Alignment_Cal_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         XtalTrim = (message->data[0]);
         PITS_WIFI_Save_XtalTrim(XtalTrim);
         Wifi_Proxy_Diagnose_Set_Final_XtalTrim(XtalTrim);
         pits_wifi_set_flag = false;
#if 0
         PITS_WIFI_Save_Final_XtalTrim(XtalTrim);
         
#endif
         Wifi_TX_Data[1] =  XtalTrim;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Stop_Packets_trans_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Stop_Packets_trans_Req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_STOP_PACKETS_TRANS_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Stop_Packets_trans_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_Proxy_Diagnose_Stop_Send();
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Connect_Network_Req
 *===========================================================================*
 * @brief Receive a Request to connect or disconnect WiFi network
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Connect_Network_Req(const PITS_Message_T * message)
{
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_CONNECT_NETWORK_RPT, 9);

      /* Compose Message Data */
      if (message->data_size != 9)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Connect_Network_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Pits_wifi_connect_req_channel = message->data[8];
         memcpy(Pits_wifi_connect_req_Mac_addr, &message->data[0], 6);
         Pits_wifi_connect_req_filter = message->data[7];
         if ( PITS_WIFI_CONNECT == message->data[6])
         {
            Wifi_Proxy_Diagnose_Start_Read((uint16_t)Pits_wifi_connect_req_channel, Pits_wifi_connect_req_Mac_addr, Pits_wifi_connect_req_filter);
            PITS_Wifi_Connect_In_Processing();
         }
         else if ( PITS_WIFI_DISCONNECT == message->data[6])
         {
            Wifi_Proxy_Diagnose_Stop_Read();
            PITS_Wifi_Connect_In_Processing();
         }
         else
         {
            Wifi_TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
         }

         memcpy(&Wifi_TX_Data[1], Pits_wifi_connect_req_Mac_addr, 6);
         Wifi_TX_Data[7] = Pits_wifi_connect_req_filter;
         Wifi_TX_Data[8] = Pits_wifi_connect_req_channel;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Disconnect_Network_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Query_Connect_Status_Req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_QUERY_CONNECT_STATUS_RPT, 10);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Query_Connect_Status_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         /* Connect Status */
         Wifi_TX_Data[1] = (uint8_t)PITS_Get_Wifi_Connect_Status();
         memcpy(&Wifi_TX_Data[2], Pits_wifi_connect_req_Mac_addr, 6);
         Wifi_TX_Data[8] = Pits_wifi_connect_req_filter;
         Wifi_TX_Data[9] = Pits_wifi_connect_req_channel;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Signal_Level_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Signal_Level_Req(const PITS_Message_T * message)
{
   int16_t pits_wifi_level = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SIGNAL_LEVEL_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Signal_Level_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pits_wifi_level = PITS_Wifi_Get_Current_Level();
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = (uint8_t)(pits_wifi_level >> 8);
         Wifi_TX_Data[2] = (uint8_t)(pits_wifi_level & 0x00FF);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Signal_Level_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Signal_PER_Req(const PITS_Message_T * message)
{
   float pits_wifi_PER_raw = 0;
   uint16_t pits_wifi_PER = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SIGNAL_PER_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Signal_PER_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pits_wifi_PER_raw = PITS_Wifi_Get_Current_PER();
         /* enlarge 10000 times, 68.56% -> 6856 */
         pits_wifi_PER = (uint16_t)(pits_wifi_PER_raw *10000 + 0.5);
         
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = (uint8_t)(pits_wifi_PER >> 8);
         Wifi_TX_Data[2] = (uint8_t)(pits_wifi_PER & 0x00FF);
         
         pits_wifi_PER_raw = PITS_Wifi_Get_Average_PER();
         /* enlarge 10000 times, 68.56% -> 6856 */
         pits_wifi_PER = (uint16_t)(pits_wifi_PER_raw *10000 + 0.5);
         Wifi_TX_Data[3] = (uint8_t)(pits_wifi_PER >> 8);
         Wifi_TX_Data[4] = (uint8_t)(pits_wifi_PER & 0x00FF);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Signal_Level_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Clear_Signal_Packet_Number_Req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_CLEAR_SIGNAL_PAC_NUM_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Clear_Signal_Packet_Number_Req : Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         PITS_Wifi_Clear_Current_Packet_Number();
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Signal_Level_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Signal_Packet_Number_Req(const PITS_Message_T * message)
{
   uint32_t pits_wifi_packet_number = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SIGNAL_PAC_NUM_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Signal_Packet_Number_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pits_wifi_packet_number = PITS_Wifi_Get_Current_Packet_Number();
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = (uint8_t)(pits_wifi_packet_number >> 24);
         Wifi_TX_Data[2] = (uint8_t)((pits_wifi_packet_number >> 16) & 0x000000FF);
         Wifi_TX_Data[3] = (uint8_t)((pits_wifi_packet_number >> 8) & 0x000000FF);
         Wifi_TX_Data[4] = (uint8_t)(pits_wifi_packet_number & 0x000000FF);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}



/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Mac_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Req(const PITS_Message_T * message)
{
#if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MAC_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {

         }
         else
         {
            PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MAC_RPT, 17+3);
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = message->data[0];
            Wifi_TX_Data[2] = 0x01;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_MAC_Address(message->data[0]),17);
            for (pit_index = 0; pit_index < 17;pit_index++)
            {
              Wifi_TX_Data[pit_index+3] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }

            }
            if (pit_ceros)
            {
               Wifi_TX_Data[2] = 0;
               memcpy(&pits_wifi_scratch_memory[0], "--:--:--:--:--:--" ,17+1);
               for (pit_index = 0; pit_index < 17;pit_index++)
               {
                  Wifi_TX_Data[pit_index+3] = pits_wifi_scratch_memory[pit_index];
               }
            }

         }
      }
   }
#endif
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Ssid_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Ssid_Req(const PITS_Message_T * message)
{
         #if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_string_len = 0;
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Get_Ssid_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {

         }
         else
         {
            pit_string_len = strlen(Get_WiFi_SSID(message->data[0]));
            PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_RPT, pit_string_len+4);
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = message->data[0];
            Wifi_TX_Data[2] = 0x01;
            Wifi_TX_Data[3] = pit_string_len;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_SSID(message->data[0]),pit_string_len);
            for (pit_index = 0; pit_index < pit_string_len;pit_index++)
            {
              Wifi_TX_Data[pit_index+4] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }
            }
            if (pit_ceros)
            {
               /*PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_RPT, 5);
               Wifi_TX_Data[0] = (uint8_t) SUCCESS;
               Wifi_TX_Data[1] = message->data[0];
               Wifi_TX_Data[2] = 0;
               Wifi_TX_Data[3] = 1;
               Wifi_TX_Data[4] = 0x20;*/
            }

         }
      }
   }
            #endif
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Mode_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Mode_Req(const PITS_Message_T * message)
{
#if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_string_len = 0;
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;
#endif

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MODE_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {

         }
         else
         {
         #if 0
            pit_string_len = strlen(Get_WiFi_Mode(message->data[0]));
            PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MODE_RPT, pit_string_len+4);
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = message->data[0];
            Wifi_TX_Data[2] = 0x01;
            Wifi_TX_Data[3] = pit_string_len;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_Mode(message->data[0]),pit_string_len);
            for (pit_index = 0; pit_index < pit_string_len;pit_index++)
            {
              Wifi_TX_Data[pit_index+4] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }
            }
            if (pit_ceros)
            {
               /*PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MODE_RPT, 5);
               Wifi_TX_Data[0] = (uint8_t) SUCCESS;
               Wifi_TX_Data[1] = message->data[0];
               Wifi_TX_Data[2] = 0;
               Wifi_TX_Data[3] = 1;
               Wifi_TX_Data[4] = 0x20;*/
            }

            #endif
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Encryp_State_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Encryp_State_Req(const PITS_Message_T * message)
{
#if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_string_len = 0;
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;
#endif

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_ENCRYP_STATE_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {

         }
         else
         {
         #if 0
            pit_string_len = strlen(Get_WiFi_Encryption_State(message->data[0]));
            PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_ENCRYP_STATE_RPT, pit_string_len+4);
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = message->data[0];
            Wifi_TX_Data[2] = 0x01;
            Wifi_TX_Data[3] = pit_string_len;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_Encryption_State(message->data[0]),pit_string_len);
            for (pit_index = 0; pit_index < pit_string_len;pit_index++)
            {
              Wifi_TX_Data[pit_index+4] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }
            }
            if (pit_ceros)
            {
               /*PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_ENCRYP_STATE_RPT, 5);
               Wifi_TX_Data[0] = (uint8_t) SUCCESS;
               Wifi_TX_Data[1] = message->data[0];
               Wifi_TX_Data[2] = 0;
               Wifi_TX_Data[3] = 1;
               Wifi_TX_Data[4] = 0x20;*/
            }

            #endif
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Encryp_Type_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Encryp_Type_Req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_ENCRYP_TYPE_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {

         }
         else
         {

         #if 0
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = message->data[0];
            Wifi_TX_Data[3] = Get_WiFi_Encryption_Type(message->data[0]);
            if (Wifi_TX_Data[3]== 0)
            {
               Wifi_TX_Data[2] = 0;
            }
            else if (Wifi_TX_Data[3] > 3)
            {
               Wifi_TX_Data[2] = 0x02;
            }
            else
            {
               Wifi_TX_Data[2] = 0x01;
            }

            #endif
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_IP_Address_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Set_Ping_Test_Req(const PITS_Message_T * message)
{
#if 0
   uint8_t  IP_Address_Pits[4] = {0,0,0,0};
#endif


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_SET_PING_TEST_RPT, 6);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
      #if 0
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         IP_Address_Pits[0] = message->data[0];
         IP_Address_Pits[1] = message->data[1];
         IP_Address_Pits[2] = message->data[2];
         IP_Address_Pits[3] = message->data[3];
         Set_WiFi_Ping_Test(IP_Address_Pits);


         Wifi_TX_Data[1] = message->data[0];
         Wifi_TX_Data[2] = message->data[1];
         Wifi_TX_Data[3] = message->data[2];
         Wifi_TX_Data[4] = message->data[3];
         Wifi_TX_Data[5] = 0x01;

         #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_IP_Address_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Ping_Test_Req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_PING_TEST_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
      #if 0
         Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         Wifi_TX_Data[1] = Get_WiFi_Ping_Test_Result();

        #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}
/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Mac_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Ad_Req(const PITS_Message_T * message)
{
#if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;
#endif

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_MAC_AD_RPT, 17+2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         #if 0

            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = 0x01;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_Connected_MAC_Address(),17);
            for (pit_index = 0; pit_index < 17;pit_index++)
            {
              Wifi_TX_Data[pit_index+2] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }

            }
            if (pit_ceros)
            {
               Wifi_TX_Data[1] = 0x01;
               memcpy(&pits_wifi_scratch_memory[0], "00:01:02:03:04:05" ,17+1);
               for (pit_index = 0; pit_index < 17;pit_index++)
               {
                  Wifi_TX_Data[pit_index+2] = pits_wifi_scratch_memory[pit_index];
               }
            }
         #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Get_Ssid_Req
 *===========================================================================*
 * @brief Receive a Request to Test WiFi
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Get_Ssid_Ad_Req(const PITS_Message_T * message)
{
#if 0
   char pits_wifi_scratch_memory[70];
   uint8_t pit_string_len = 0;
   uint8_t pit_index = 0;
   bool_t  pit_ceros = true;
#endif

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_AD_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("WiFi Request: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
      #if 0
            pit_string_len = strlen(Get_WiFi_Connected_SSID());
            PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_AD_RPT, pit_string_len+3);
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
            Wifi_TX_Data[1] = 0x01;
            Wifi_TX_Data[2] = pit_string_len;
            memcpy(&pits_wifi_scratch_memory[0],Get_WiFi_Connected_SSID(),pit_string_len);
            for (pit_index = 0; pit_index < pit_string_len;pit_index++)
            {
              Wifi_TX_Data[pit_index+3] = pits_wifi_scratch_memory[pit_index];
              if (pits_wifi_scratch_memory[pit_index] != 0x00)
              {
                pit_ceros = false;
              }
            }
            if (pit_ceros)
            {
               /*PITS_Wifi_Compose_Message_Header(MID_WIFI_GET_SSID_RPT, 4);
               Wifi_TX_Data[0] = (uint8_t) SUCCESS;
               Wifi_TX_Data[1] = 0;
               Wifi_TX_Data[2] = 1;
               Wifi_TX_Data[3] = 0x20;*/
            }
      #endif
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Wifi_Observe_Coexistence_Status_Req
 *===========================================================================*
 * @brief Check coexistence pin status between wifi and bt chip
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Request

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = WiFi Test status
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Wifi_Observe_Coexistence_Status_Req(const PITS_Message_T * message)
{

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      Wifi_TX_Bus_ID = message->bus;
      PITS_Wifi_Compose_Message_Header(MID_WIFI_OBSERVE_COEX_STATUS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("PITS_Wifi_Observe_Coexistence_Status_Req: Message Data Error");
         Wifi_TX_Message.data_size = 3;
         Wifi_TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         if (false != PITS_WIFI_Get_Coex_Pin_Status(&Wifi_TX_Data[1]))
         {
            Wifi_TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            Wifi_TX_Data[0] = (uint8_t) FAIL;
         }
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&Wifi_TX_Message));
}

/*===========================================================================*/
/*!
 * @file pits_wifi_services.c
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 2
 * ctc_ec#156415: Remove build warnings.
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 25-Jun-2014 Bao Qifan  Rev 14
 * Task ctc_ec#71800 [NGK PITS] fix compile warning
 *
 * 28 Mar 2014 Bao Qifan Rev 13
 * Task ctc_ec#68919. [NGK PTIS] change wifi mac address and xtaltrim read and write function from wifi module to pits module
 *
 * 06 Mar 2014 Bao Qifan Rev 12
 * Task ctc_ec#60736. [NGK PITS] add bt and wifi coexistance function
 *
 * 12-Feb-2014 Bao Qifan Rev 11
 * Task ctc_ec#58862 [NGK PITS] add pits msg 12 7E save wifi alignment cal value function
 *
 * 12-Feb-2014 Bao Qifan Rev 10
 * Task ctc_ec#58837 [NGK PITS] add pits12 BA clear wifi packet number function
 *
 * 22-Jan-2014 Bao Qifan Rev 9
 * Task ctc_ec#58181 [NGK PITS] add pits wifi function 12 7C query alignment value
 *
 * 21-Jan-2014 Bao Qifan Rev 8
 * Task ctc_ec#58134 [NGK PITS] add wifi pits message
 *
 * -13-Sep-2013  Bao Qifan Rev 7 
 * Task ctc_ec#44240 [NGK PITS] fix wifi service report wrong message number
 *
 * 02-Sept-2013 Bao Qifan Rev 5
 * Task ctc_ec#43085 [NGK PITS] update wifi service connect and disconnect notify event
 *
 * 30-Augu-2013 Bao Qifan Rev 3
 * Task ctc_ec#43034 [NGK PITS]draf version for wif pits function
 *
 * 08 Jan 2013 Bao Qifan Rev 2
 * ctc_ec#33077:[NGK PITS] modify PITS_Wifi_Test_Req 
 *
 *==============================================================================
 * 10-Jun-2013 Bao Qifan  Rev 10
 * Task ctc_ec#41160 [NGK PITS] integrate PITS code from B9
 *
 * 07 Mar 2012 Miguel Garcia Rev 9
 * Include mac address when 0
 *
 * 27 Jan 2012 Miguel Garcia Rev 8
 * fix safe strncpy issue
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 6
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 06 Jun 2011 Miguel Garcia
 * Include missing wifi functions
 *
 * 19 May 2011 Miguel Garcia
 * Include Wifi functions
 */
/*===========================================================================*/
