/*===========================================================================*/
/**
 * @file pits_nav_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_nav_services.c~3:csrc:ctc_ec#25 %
 * @version %version:3 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Fri Feb 17 21:16:39 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "icr_eng_cals_ps.h"
#include "pits_nav_services.h"
#include "pits_nav_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "nav_gps_ublox_6010.h"
#include "vip_proxy.h"

EM_FILENUM(PITS_MODULE_ID_5, 19);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void PITS_Nav_Initialize(void);
static void PITS_Nav_Compose_Message_Header(uint8_t mid, uint8_t size);
static void Pits_Nav_Vss_Count_Result (void);
static void Pits_Nav_Gyro_Count_Periodic (void);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_NAV_RX_INDEX

#define MID_NAV_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T PITS_Nav_RX_Messages[] = {
   MID_NAV_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_NAV_TX_INDEX

#define MID_NAV_TX_INDEX(name, mid) (mid),

static const uint8_t PITS_Nav_TX_Messages[] = {
   MID_NAV_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_NAV_RX_INDEX
#define MSID_NAV_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T PITS_Nav_RX_Message_Sets[] = {
   MSID_NAV_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_NAV_TX_INDEX
#define MSID_NAV_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T PITS_Nav_TX_Message_Sets[] = {
   MSID_NAV_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static uint8_t nav_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T nav_message;      /* for construction of a misc service message to be transmitted */

static uint8_t nav_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint8_t pits_gyro_test_flag;

static SAL_Timer_Id_T pits_GYRO_periodic_send_timer_id;

static SIP_VSS_INFO_T pits_VSS_info;

static bool pits_gyro_test_running = false;

static SAL_Timer_Id_T pits_VSS_periodic_send_timer_id;

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Nav_Services_Interface = {
   PITS_Nav_Initialize,
   PITS_Nav_RX_Message_Sets,
   Num_Elems(PITS_Nav_RX_Message_Sets),
   PITS_Nav_TX_Message_Sets,
   Num_Elems(PITS_Nav_TX_Message_Sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Misc_Initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
static void PITS_Nav_Initialize(void)
{
   nav_tx_bus_id = 0;
   memset(&nav_message, 0x00, sizeof(PITS_Message_T));
   memset(nav_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

static void PITS_Nav_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   nav_message.bus = nav_tx_bus_id;
   nav_message.data = nav_tx_data;
   nav_message.MSID = MSID_NAV_SERVICES;
   nav_message.MID = mid;
   nav_message.data_size = size;
   memset(&nav_tx_data[0], 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_GYRO_Timer
 *===========================================================================*
 * @brief Create GYRO periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Create_GYRO_Timer(void)
{
   SAL_Create_Timer(PITS_EV_GYRO_PERIODIC_SEND_TIMEOUT, &pits_GYRO_periodic_send_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_GYRO_Timer
 *===========================================================================*
 * @brief Destroy GYRO periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Destroy_GYRO_Timer(void)
{
   SAL_Destroy_Timer(pits_GYRO_periodic_send_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_GYRO_Timer
 *===========================================================================*
 * @brief Check whether GYRO send timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_GYRO_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_GYRO_PERIODIC_SEND_TIMEOUT)
   {
      Pits_Nav_Gyro_Count_Periodic();
      status = true;
   }
   
   return status;
}

void Pits_Nav_Gyro_Count_Periodic (void)
{
   
   nav_tx_bus_id = 0;
   PITS_Nav_Compose_Message_Header(MID_NAV_GET_GYRO_ACK, 5);
   nav_tx_data[0] = (uint8_t) SUCCESS;
   if (false != pits_gyro_test_running)
   {
      nav_tx_data[1] = 0x01; /* GYRO test runing */
   }
   else
   {
      nav_tx_data[1] = 0x00; /* GYRO test stopped */
   }
   
   nav_tx_data[2] = (uint8_t)((pits_VSS_info.GYRO_axis_x_mdps >= 0 ? pits_VSS_info.GYRO_axis_x_mdps : pits_VSS_info.GYRO_axis_x_mdps * -1)/ 1000);
   nav_tx_data[3] = (uint8_t)((pits_VSS_info.GYRO_axis_y_mdps >= 0 ? pits_VSS_info.GYRO_axis_y_mdps : pits_VSS_info.GYRO_axis_y_mdps * -1)/ 1000);
   nav_tx_data[4] = (uint8_t)((pits_VSS_info.GYRO_axis_z_mdps >= 0 ? pits_VSS_info.GYRO_axis_z_mdps : pits_VSS_info.GYRO_axis_z_mdps * -1)/ 1000);

   PITS_Send_Message(&nav_message);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_VSS_Timer
 *===========================================================================*
 * @brief Create VSS periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Create_VSS_Timer(void)
{
   SAL_Create_Timer(PITS_EV_VSS_PERIODIC_SEND_TIMEOUT, &pits_VSS_periodic_send_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_VSS_Timer
 *===========================================================================*
 * @brief Check whether VSS send timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_VSS_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;
   
   if (event_id == PITS_EV_VSS_PERIODIC_SEND_TIMEOUT)
   {
      Pits_Nav_Vss_Count_Result();
      status = true;
   }
   
   return status;
}

/*===========================================================================*
 * FUNCTION: Pits_Destroy_VSS_Timer
 *===========================================================================*
 * @brief destroy VSS send timer 
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void Pits_Destroy_VSS_Timer(void)
{
   SAL_Destroy_Timer(pits_VSS_periodic_send_timer_id);
}


/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Enter_Gyro_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_ENTER_GYRO_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         pits_gyro_test_flag = message->data[0];
         if ((pits_gyro_test_flag >= 0x01)&&(pits_gyro_test_flag <= 0x0A))
         {
            pits_gyro_test_flag = pits_gyro_test_flag * 100;
            SAL_Start_Timer(pits_GYRO_periodic_send_timer_id, pits_gyro_test_flag, true);
            nav_tx_data[1] = 0x01; /* GYRO Test Running  */
            pits_gyro_test_running = true;
         }
         else
         {
            nav_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
            nav_tx_data[1] = 0x00; /* GYRO Test unable to Running  */
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Stop_Gyro_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_STOP_GYRO_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = 0x00; /*  Unable to Execute GYRO Test  */
         if (false != pits_gyro_test_running)
         {
            SAL_Stop_Timer(pits_GYRO_periodic_send_timer_id);
            nav_tx_data[1] = 0x01; /*GRYO test Stopped*/
            pits_gyro_test_running = false;
         }
         else
         {
            /* do nothing */
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Test_Gyro_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_GET_GYRO_ACK, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         if (false != pits_gyro_test_running)
         {
            nav_tx_data[1] = 0x01; /* GYRO test runing */
         }
         else
         {
            nav_tx_data[1] = 0x00; /* GYRO test stopped */
         }
         
         nav_tx_data[2] = (uint8_t)((pits_VSS_info.GYRO_axis_x_mdps >= 0 ? pits_VSS_info.GYRO_axis_x_mdps : pits_VSS_info.GYRO_axis_x_mdps * -1)/ 1000);
         nav_tx_data[3] = (uint8_t)((pits_VSS_info.GYRO_axis_y_mdps >= 0 ? pits_VSS_info.GYRO_axis_y_mdps : pits_VSS_info.GYRO_axis_y_mdps * -1)/ 1000);
         nav_tx_data[4] = (uint8_t)((pits_VSS_info.GYRO_axis_z_mdps >= 0 ? pits_VSS_info.GYRO_axis_z_mdps : pits_VSS_info.GYRO_axis_z_mdps * -1)/ 1000);
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Gyro_Selftest_Req
 *===========================================================================*
 * @brief send a GYRO selftest request to k0r
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GYRO selftest Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Gyro_Selftest_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
	SAL_Message_T const *msg =NULL;
   SAL_Event_Id_T subscribe_list[] = {EVG_PITS_GYRO_TEST_STATUS};
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_GYRO_SELFTEST_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) FAIL;

         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {

            VIP_GYRO_Selftest_Request(message->data[0]); 
            
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

            if(NULL != msg)
            {
               if (EVG_PITS_GYRO_TEST_STATUS == msg->event_id)
               {
                  nav_tx_data[1] = *(uint8_t *)(msg->data);
                  nav_tx_data[0] = (uint8_t) SUCCESS;
               }
            }
            else
            {
               /* error handle */
            }
         }
         SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list)); 
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Begin_Temp_Sensor_Req
 *===========================================================================*
 * @brief Receive a Request to begin temp sensor test
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Temp Sensor Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Begin_Temp_Sensor_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_BEGIN_TEMP_SENSOR_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Nav Request: Message Data Error");
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = (uint8_t) NAV_NOT_IMPLEMENTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&nav_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Get_Temp_Sensor_Req
 *===========================================================================*
 * @brief Receive a Request to get temp sensor test
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Temp Sensor Test Status:
 * @param [out] TX_Message[2] = Temp Reading
 * @param [out] TX_Message[3] = Temp Reading
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Get_Temp_Sensor_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_GET_TEMP_SENSOR_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Nav Request: Message Data Error");
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = (uint8_t) NAV_NOT_IMPLEMENTED;
         nav_tx_data[2] = (uint8_t) NAV_NOT_IMPLEMENTED;
         nav_tx_data[3] = (uint8_t) NAV_NOT_IMPLEMENTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&nav_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Enter_GPS_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_ENTER_GPS_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Nav Request: Message Data Error");
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = (uint8_t) NAV_NOT_IMPLEMENTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&nav_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Enter_VSS_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint32_t periodic_timer = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_ENTER_VSS_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         if (0 == message->data[0]) /* stop timer request */
         {
            SAL_Stop_Timer(pits_VSS_periodic_send_timer_id);
            nav_tx_data[1] = 0x00; /*  Unable to Execute VSS Test  */
         }
         else
         {
            periodic_timer = (uint32_t)message->data[0] * 100;
            SAL_Start_Timer(pits_VSS_periodic_send_timer_id, periodic_timer, true);
            nav_tx_data[1] = 0x01; /* VSS Test Running  */
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Get_Single_Vss_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_GET_SINGLE_VSS_ACK, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = 0x02;  /* Test Finished */
         if (255 < pits_VSS_info.VSS_speed)
         {
            nav_tx_data[2] = 255;
         }
         else
         {
            nav_tx_data[2] = (uint8_t)pits_VSS_info.VSS_speed;
         }
         /* clear received VSS info */
         pits_VSS_info.VSS_speed = 0;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Test_GPS_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_TEST_GPS_ACK, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 2;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = (uint8_t) NAV_TEST_RUNNING;      
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Get_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to get GPS test
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Test Status:
 * @param [out] TX_Message[2] = GPS LAT data
 * @param [out] TX_Message[3] = GPS LAT data
 * @param [out] TX_Message[4] = GPS LAT data
 * @param [out] TX_Message[5] = GPS LAT data
 * @param [out] TX_Message[6] = GPS Long data
 * @param [out] TX_Message[7] = GPS Long data
 * @param [out] TX_Message[8] = GPS Long data
 * @param [out] TX_Message[9] = GPS Long data
 * @param [out] TX_Message[10] = GPS Signal Strenght
 * @param [out] TX_Message[11] = GPS Antenna Present
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Get_GPS_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   PIT_UBX_REQUEST_T id;

   SAL_Message_T const *msg =NULL;
   SAL_Event_Id_T subscribe_list[] = {NAV_EVG_GPS_PITS_GET_GPS_TEST_REPORT};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_TEST_RESULT_GPS_ACK, 39);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         nav_tx_data[1] = (uint8_t) PITS_GPS_TEST_NONE ;
		 
      }
      else
      {
         nav_tx_data[0] = (uint8_t) FAIL;
         nav_tx_data[1] = (uint8_t) PITS_GPS_TEST_IN_PROGRESS ;
      
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            /*get NAV-POSLLH 0X01 0X02*/
            id.header= (0xB5<<8)+0X62;;
            id.id = (0x01<<8)+0x02;

            SAL_Publish(NAV_EVG_GPS_PITS_GET_GPS_TEST_REQUEST, &id, sizeof(id) );

            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);
            if(NULL != msg)
            {
               if (NAV_EVG_GPS_PITS_GET_GPS_TEST_REPORT == msg->event_id)
               {
                  nav_gps_posllh_t * pt = (nav_gps_posllh_t *)msg->data;

                  memcpy((void *)&nav_tx_data[2],(void *)&pt->latitude, 4);
                  memcpy((void *)&nav_tx_data[6],(void *)&pt->longitude, 4);
	              memcpy((void *)&nav_tx_data[10],(void *)&pt->height, 4);
	              memcpy((void *)&nav_tx_data[14],(void *)&pt->hor_acc, 4);
	              memcpy((void *)&nav_tx_data[18],(void *)&pt->ver_acc, 4);	
               }
           } 
           else 
           {
               return NOT_DONE;
	   }
	  
           /*get NAV-VELNED 0x01 0x12*/
           id.header= (0xB5<<8)+0X62;;
           id.id = (0x01<<8)+0x12;

           SAL_Publish(NAV_EVG_GPS_PITS_GET_GPS_TEST_REQUEST, &id, sizeof(id) );

           msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);

           if(NULL != msg)
           {
              if (NAV_EVG_GPS_PITS_GET_GPS_TEST_REPORT == msg->event_id)
              {
                 nav_gps_speed_t * pt = (nav_gps_speed_t *)msg->data;

              	 memcpy((void *)&nav_tx_data[22],(void *)&pt->ground_speed, 4);
	         memcpy((void *)&nav_tx_data[26],(void *)&pt->heading, 4);
              }
      	   }
           else 
           {
              return NOT_DONE;
           }
		
           /*get NAV-STATUS 0x01 0x03*/
           id.header= (0xB5<<8)+0X62;;
           id.id = (0x01<<8)+0x03;

           SAL_Publish(NAV_EVG_GPS_PITS_GET_GPS_TEST_REQUEST, &id, sizeof(id) );

           msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);

           if(NULL != msg)
           {
              if (NAV_EVG_GPS_PITS_GET_GPS_TEST_REPORT == msg->event_id)
              {
                 nav_gps_status_t * nav_status_data  = (nav_gps_status_t *)msg->data;
#if 0				 
                 nav_status_t * status_flags = &nav_status_data->status_flags;
                 nav_fix_stat_t * fix_status = &nav_status_data->fix_status;
                 nav_status2_t * status_flags2 = &nav_status_data->status_flags2;
#endif					 
                 nav_tx_data[30] = nav_status_data->gps_fix;
              	 memcpy((void *)&nav_tx_data[31],(void *)&nav_status_data->time_to_fix, 4);
                 memcpy((void *)&nav_tx_data[35],(void *)&nav_status_data->time_since_start, 4);

                 nav_tx_data[0] = (uint8_t) SUCCESS;
                 nav_tx_data[1] = (uint8_t)PITS_GPS_TEST_FINISHED;
         	}
           }
           else 
           {
              return NOT_DONE;
           }
        }
        SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list)); 
      }
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);

}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Enter_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Satellite_GPS_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   PIT_UBX_REQUEST_T id;

   nav_satellite_t* satellite=NULL;
   uint8_t i;
   uint8_t* pnav_tx_datab;

   SAL_Message_T const *msg =NULL;
   SAL_Event_Id_T subscribe_list[] = {NAV_EVG_GPS_PITS_UBX_REPORT};
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_SATELLITE_GPS_ACK, 50);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         nav_tx_data[1] = (uint8_t) PITS_GPS_TEST_NONE ;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) FAIL;
         nav_tx_data[1] = (uint8_t) PITS_GPS_TEST_IN_PROGRESS ; 

         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            id.header= (0xB5<<8)+0X62;;
            id.id = (0x01<<8)+0x30;

           SAL_Publish(NAV_EVG_GPS_PITS_UBX_REQUEST, &id, sizeof(id) );

           msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);
           if(NULL != msg)
           {
               if (NAV_EVG_GPS_PITS_UBX_REPORT == msg->event_id)
               {           
                  satellite =  (nav_satellite_t *)msg->data;
 
                  nav_tx_data[2] = satellite->gen_info.num_channels;
                  nav_message.data_size = satellite->gen_info.num_channels * 2 + 3;
                  pnav_tx_datab = &nav_tx_data[3];
                  for (i = 0; i<satellite->gen_info.num_channels; i++)
                  {
                     *pnav_tx_datab++ = satellite->sat_info[i].satellite_id;
                     *pnav_tx_datab++ = satellite->sat_info[i].signal_strength;
                  }
 
                  nav_tx_data[0] = (uint8_t) SUCCESS;
                  nav_tx_data[1] = (uint8_t) PITS_GPS_TEST_FINISHED; 		
              }
            }
         }
         SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list)); 
      }
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }

   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Set_Antenna_GPS_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Set_Antenna_GPS_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T status = NOT_DONE;

   nav_gps_antenna_t* gps_antenna;

   PIT_UBX_REQUEST_T id;

	SAL_Message_T const *msg =NULL;
   SAL_Event_Id_T subscribe_list[] = {NAV_EVG_GPS_PITS_GET_GPS_ANTENNA_DIAGNOSTIC_REPORT};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_ANTENNA_GPS_ACK, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
		 
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {

	         id.header= (0xB5<<8)+0x62;
            id.id = (0x0a<<8)+0x09;

            SAL_Publish(NAV_EVG_GPS_PITS_GET_GPS_ANTENNA_DIAGNOSTIC_REQUEST, &id, sizeof(id) );

            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);

            if(NULL != msg)
            {
               if (NAV_EVG_GPS_PITS_GET_GPS_ANTENNA_DIAGNOSTIC_REPORT == msg->event_id)
               {
                  gps_antenna = (nav_gps_antenna_t*)msg->data;
      	         nav_tx_data[1] = gps_antenna->antenna_status;
                  nav_tx_data[2] = gps_antenna->power_status;
               }
            }
         }
         SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list)); 
      }
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Display_Map_Req
 *===========================================================================*
 * @brief Receive a Request to Display Nav Map
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Display Nav Map Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Display_Map_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_DISPLAY_MAP_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Nav Request: Message Data Error");
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         nav_tx_data[1] = (uint8_t) NAV_NOT_IMPLEMENTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&nav_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_Nav_Set_Key_Mode_Req
 *===========================================================================*
 * @brief Receive a Request to Display Nav Map
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Display Nav Map Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Set_Key_Mode_Req(const PITS_Message_T * message)
{
   SIP_Icr_Eng_Cals_Info_T radio_version = SIP_NAV_CHINA;
   uint8_t pit_radio_status = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_SET_KEY_MODE_ACK, 2);

      /* Compose Message Data */
      nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      pit_radio_status = message->data[0];
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Nav Request: Message Data Error");
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;

#ifndef GWM_EDU_BOARD /* limingmin change SIP_BASE/SIP_NAV to SIP_NAV_CHINA/SIP_NAV_EUROPE 123435 */
         /* Nav Radio*/
         nav_tx_data[1] = 0x01;

        if (pit_radio_status== 0x01)
        {
          /*Europe*/
          radio_version = SIP_NAV_EUROPE;
        }
        if (pit_radio_status== 0x02)
        {
          /*China*/
          radio_version = SIP_NAV_CHINA;
        }

         IcrEngCals_PS_Put_Radio_Version(radio_version);
#else /* limingmin change SIP_BASE/SIP_NAV to SIP_NAV_CHINA/SIP_NAV_EUROPE 123435 */
         if (pit_radio_status== 0x01)
         {
           /*Set Nav Keyboard*/
           radio_version = SIP_NAV_EUROPE;
         }
         if (pit_radio_status== 0x02)
         {
           /*Set Non Nav Keyboard*/
           radio_version = SIP_NAV_CHINA;
         }

         if (pit_radio_status > 0x02)
         {
            nav_tx_data[1] = 0x00;
         }
         else
         {
            if (pit_radio_status > 0x00)
            {
               IcrEngCals_PS_Put_Radio_Version(radio_version);
            }
            if (IcrEngCals_PS_Get_Radio_Version()== SIP_NAV_EUROPE)
            {
               /* Nav Radio*/
               nav_tx_data[1] = 0x01;
            }
            else
            {
               /* Non nav radio*/
               nav_tx_data[1] = 0x02;
            }

         }
#endif         
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&nav_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Nav_Ubx_Message_Req
 *===========================================================================*
 * @brief Receive a Request to enter GPS
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Nav_Ubx_Message_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint16_t ubx_header;
   uint16_t ubx_id;
   PIT_UBX_REQUEST_T id;
   uint8_t ubx_size;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      nav_tx_bus_id = message->bus;
      PITS_Nav_Compose_Message_Header(MID_NAV_UBX_MESSAGE_ACK, 255);
      
      /* Compose Message Data */
      if (message->data_size <= 1)
      {
         PITS_PBS_Error_Report("Nav Request: Message Data Error");
         nav_message.data_size = 3;
         nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         nav_tx_data[0] = (uint8_t) SUCCESS;
         ubx_size = message->data[0];
         if (ubx_size == 4)
         {
            SAL_Message_T const *msg = NULL;
            SAL_Event_Id_T subscribe_list[] = {NAV_EVG_GPS_PITS_UBX_REPORT};
         
            ubx_header = message->data[1];
            ubx_header = (ubx_header<<8) + message->data[2];
            ubx_id = message->data[3];
            ubx_id = (ubx_id<<8) + message->data[4];
            id.header = ubx_header;
            id.id = ubx_id;

            if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
            {

               SAL_Publish(NAV_EVG_GPS_PITS_UBX_REQUEST, &id, sizeof(id) );

               msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);

               if(NULL != msg)
               {
                  if (NAV_EVG_GPS_PITS_UBX_REPORT == msg->event_id)
                  {
                     nav_message.data_size = sizeof(nav_satellite_t)+2;
         	     nav_tx_data[1] = sizeof(nav_satellite_t);
                     memcpy (&nav_tx_data[2], msg->data , sizeof(nav_satellite_t));
         			
                  }
               }
            }
           SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list)); 
          
         }
         else
         {
            nav_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
      }
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&nav_message));
   }

   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_VSS_Info
 *===========================================================================*
 * @brief Save VSS information for pits diagnostic
 *
 * @returns
 *    Void
 *
 * @param [in] message = the point of message
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Get_VSS_Info(const uint8_t * data, size_t length)
{
   uint32_t VSS_speed ;
   VSS_speed = Util_Get_Little_Endian_U32(data);
   pits_VSS_info.VSS_speed = (uint32_t)((float)VSS_speed / (float)1000 + (float)0.5);
   pits_VSS_info.GYRO_axis_x_mdps = (int32_t)Util_Get_Little_Endian_U32(data + 4);
   pits_VSS_info.GYRO_axis_y_mdps = (int32_t)Util_Get_Little_Endian_U32(data + 8);
   pits_VSS_info.GYRO_axis_z_mdps = (int32_t)Util_Get_Little_Endian_U32(data + 12);
}

/*===========================================================================*
 * FUNCTION: Pits_Nav_Vss_Count_Result
 *===========================================================================*
 * @brief report a message
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = GPS Status:
 *
 */
/*===========================================================================*/
static void Pits_Nav_Vss_Count_Result (void)
{
   nav_tx_bus_id = 0;
   PITS_Nav_Compose_Message_Header(MID_NAV_GET_SINGLE_VSS_ACK, 3);
   nav_tx_data[0] = (uint8_t) SUCCESS;
   nav_tx_data[1] = 0x02;  /* Test Finished */
   if (255 < pits_VSS_info.VSS_speed)
   {
      nav_tx_data[2] = 255;
   }
   else
   {
      nav_tx_data[2] = (uint8_t)pits_VSS_info.VSS_speed;
   }


   PITS_Send_Message(&nav_message);
}

/*===========================================================================*/
/*!
 * @file pits_nav_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 
 *  17-Feb-2017 Rahul Chirayil (vzm576) Rev.3
 *  Task ctc_ec#175759:Increase the time delay to receive response from NAVI for GPS test results to 5s.
 *
 *  13-Jan-2017 Mandar Bhat
 *  Task ctc_ec#173246: All NAVI related event timeouts are increased to 5000 .
 *
 *  30-Jun-2014 Tim Wang
 *  Added GRYO related functions.
 *  Added PITS_Nav_Get_GPS_Req, PITS_Nav_Satellite_GPS_Req, PITS_Nav_Set_Antenna_GPS_Req
 *  function.
 * 
 *  06-Sep-2012 Darinka L�pez Rev 7
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 26 Jul 2012 Miguel Garcia Rev 6
 * Fix Error size for get mode
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 11 May 2011 kzvhr7 Miguel Garcia kzvhr7
 *   Include Base and Nav radio options in PS
 *
 * - 22-Nov-2010 kzvhr7 (Miguel Garcia) Rev 1
 *   SCR kok_basa#xxxx: Implement PITS NAV and PITS CAPSENSE services
 * - Created initial file.
 */
/*===========================================================================*/
