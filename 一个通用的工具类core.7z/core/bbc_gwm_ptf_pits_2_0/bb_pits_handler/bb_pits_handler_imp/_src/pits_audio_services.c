/*===========================================================================*/
/**
 * @file pits_audio_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_audio_services.c~2:csrc:ctc_ec#22 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified: Thu Jun 23 17:08:55 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_configuration.h"
#include "pits_audio_services.h"
#include "pits_audio_services_cbk.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "utilities.h"
#include "unistd.h"
#include "xsal_util.h"
#include "source_manager_sound_settings.h"
#include "ssm_soundparameter_cfg.h"
#include "source_manager_ps.h"
#include "audio_facade.h"
#include "audio_facade.h"
#include "bb_t_box_src_mgr_interface.h"
#include "bb_t_box_proxy.h"
#include "rear_aux_local_types.h"
#include "pcan_appl_proxy.h"

EM_FILENUM(PITS_MODULE_ID_5, 5);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_V_SRC_NAV_PATH "/usr/local/data/pits/nav_pits.wav"
#define PITS_V_SRC_TTS_PATH "/usr/local/data/pits/tts_pits.wav"

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

typedef struct Source_Translation_Tag
{
   PITS_Source_T       pits_source;
   Audio_Logical_Src_T logical_source;
} Source_Translation_T;

typedef struct Playback_Translation_Tag
{
   PITS_Playback_T     pits_playback;
   Audio_Logical_Src_T logical_source;
} Playback_Translation_T;

typedef struct Source_Translation_SSM_Tag
{
   PITS_Source_T       pits_source;
   SSM_Source_Type_T   logical_source_ssm;
} Source_Translation_SSM_T;

typedef struct SSM_Playback_Translation_Tag
{
   PITS_Playback_T     pits_playback_source;
   SSM_Source_Type_T   ssm_source;
} SSM_Playback_Translation_T;

typedef enum PITS_INFO_CAN_STATE_Tag
{
   PITS_INFO_CAN_DISCONNECTED = 0,
   PITS_INFO_CAN_CONNECTED,	
}PITS_INFO_CAN_STATE_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_audio_initialize(void);
static void pits_audio_compose_message_header(uint8_t mid, uint8_t size);
static bool_t pits_audio_map_pits_src_to_logical_src(PITS_Source_T pits_source, Audio_Logical_Src_T *logical_source);
static bool_t pits_audio_map_logical_src_to_pits_playback(Audio_Logical_Src_T logical_source, PITS_Playback_T *pits_playback);
bool_t pits_audio_map_ssm_src_to_pits_src(SSM_Source_Type_T ssm_source, PITS_Source_T *pits_source);
static bool_t pits_audio_map_ssm_src_to_pits_playback_src(SSM_Source_Type_T ssm_source, PITS_Playback_T *pits_source);
static SSM_Source_Type_T PITS_AU_Get_last_source(Sys_Zone_T zone);
static void do_alarm_channel_test(void);
static uint8_t PITS_Get_Info_CAN_state();
static bool_t stop_alarm_channel_test(void);
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
static void do_res_play_test(void);
static bool_t stop_res_play_test(void);
static SAL_Timer_Id_T pits_res_play_timer_id;
#endif


/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_AUDIO_RX_INDEX
#define MID_AUDIO_RX_INDEX(name, mid, function) {mid, function},
static const PITS_MID_T pits_audio_rx_messages[] = {
   MID_AUDIO_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_AUDIO_TX_INDEX
#define MID_AUDIO_TX_INDEX(name, mid) (mid),
static const uint8_t pits_audio_tx_messages[] = {
   MID_AUDIO_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_AUDIO_RX_INDEX
#define MSID_AUDIO_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},
static const PITS_MSID_T pits_audio_rx_message_sets[] = {
   MSID_AUDIO_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_AUDIO_TX_INDEX
#define MSID_AUDIO_TX_INDEX(msid, mid, size) {msid, mid, size},
static const PITS_TX_MSID_T pits_audio_tx_message_sets[] = {
   MSID_AUDIO_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},
static const Source_Translation_T Source_Translation[] =
{
   PITS_SRC_TO_LOGICAL_SRC_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source to Playback translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_playback, logical_src) {pits_playback, logical_src},
static const Playback_Translation_T Playback_Translation[] =
{
   PITS_PLAYBACK_TO_LOGICAL_SRC_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the  Set source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, ssm_src) {pits_src, ssm_src},
static const Source_Translation_SSM_T Set_Source_SSM_Table[] =
{
   PITS_SRC_TO_SET_SRC_SSM_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the  Set source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, ssm_src) {pits_src, ssm_src},
static const SSM_Playback_Translation_T SSM_Playback_Translation[] =
{
   PITS_PLAYBACK_SRC_TO_SRC_SSM_TABLE
};

/**
 * Used to request override or not for each audio feature.
 */
static AuMgr_DO_Enable_T Audio_Overrides;
static uint8_t audio_tx_bus_id;   /* ID of the bearing bus on which to send response */
static PITS_Message_T audio_message;      /* for construction of a pbs message to be transmitted */
static uint8_t audio_tx_data[PITS_MAX_MESSAGE_SIZE];
static uint32_t audio_session_timeout_sec;  /* stores the configurable session timeout in sec */
static PITS_EVG_SESSION_T audio_session_state;

/**
 * Stores Timer ID for PBS Session
 */
static SAL_Timer_Id_T pits_audio_session_timer_id;
static Audio_Mute_State_T pits_mute_state = AUDIO_MUTE;
static bool_t pits_audio_dsp = false;

SAL_Timer_Id_T alarm_channel_test_timeout;

#if PITS_SINAD_IS
static bool_t pits_enable_sinad_state = false;
static bool_t pits_sinad_duration = false;
static bool_t pits_enable_mfg_sinad = false;
static bool_t pits_playaudio_sinad = false;
static bool_t pits_stop_sinad = false;
static uint8_t sinad_test_source;
#endif

static bool_t pits_test_channel_flag = false;
static uint8_t pits_test_channel = PITS_SRC_NONE;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Audio_Services_Interface = {
   pits_audio_initialize,
   pits_audio_rx_message_sets,
   Num_Elems(pits_audio_rx_message_sets),
   pits_audio_tx_message_sets,
   Num_Elems(pits_audio_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: pits_audio_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_audio_initialize(void)
{
   audio_tx_bus_id = 0;
   memset(&audio_message, 0x00, sizeof(PITS_Message_T));
   memset(audio_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   audio_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   audio_session_state = SESSION_CLOSE;
}

/*===========================================================================*
 * FUNCTION: PITS_Create_ALARM_Timer
 *===========================================================================*
 * @brief Create alarm channel test timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Create_ALARM_Timer(void)
{
   SAL_Create_Timer(PITS_EV_ALARM_CHANNEL_TEST_TIMEOUT, &alarm_channel_test_timeout);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_ALARM_Timer
 *===========================================================================*
 * @brief Check whether alarm channel test timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_ALARM_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;
   
   if (event_id == PITS_EV_ALARM_CHANNEL_TEST_TIMEOUT)
   {
      status = stop_alarm_channel_test();
   }
   
   return status;
}

/*===========================================================================*
 * FUNCTION: Pits_Destroy_ALARM_Timer
 *===========================================================================*
 * @brief destroy alarm channel test timer 
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void Pits_Destroy_ALARM_Timer(void)
{
   SAL_Destroy_Timer(alarm_channel_test_timeout);
}
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: PITS_Create_RES_Timer
 *===========================================================================*
 * @brief Create RES periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Create_RES_Timer(void)
{
   SAL_Create_Timer(PITS_EV_RES_PERIODIC_TIMEOUT, &pits_res_play_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_RES_Timer
 *===========================================================================*
 * @brief Destroy RES periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Destroy_RES_Timer(void)
{
   SAL_Destroy_Timer(pits_res_play_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_RES_Timer
 *===========================================================================*
 * @brief Check whether RES send timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_RES_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;
   RSE_Status_T res_state = {0x00};

   if (event_id == PITS_EV_RES_PERIODIC_TIMEOUT)
   {
      res_state.monitor = 0x01;
      res_state.mode = 0x02;
      res_state.play_status = 0x01;
      res_state.earphone_state = 0x01;
      res_state.spdif_state= 0x01;
      res_state.connection_state = 0x01;
      SAL_Publish(EVG_RSE_STATUS, &res_state, sizeof(RSE_Status_T));

      status = true;
   }
   
   return status;
}
#endif
/*===========================================================================*
 *
 * Please refer to the detailed description in pits_audio_services.h.
 *
 *===========================================================================*/
void PITS_Audio_Clear_Overrides(void)
{
   memset(&Audio_Overrides, 0, sizeof(Audio_Overrides));
   PITS_AU_Enable_Overrides(Audio_Overrides);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_audio_services.h.
 *
 *===========================================================================*/
void PITS_Audio_Connect_Src_To_Zone(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Logical_Src_T logical_source)
{
   RemRcvr_Enable_Override();
   #if USE_AUDIO_MGR_SOURCE_OVERRIDE
   Audio_Overrides.Source_Change = true;
   PITS_AU_Enable_Overrides(Audio_Overrides);
   #endif
   PITS_AU_Connect_Src_To_Zone(zone, audio_bus, logical_source);
}

/**
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
static void pits_audio_compose_message_header(uint8_t mid, uint8_t size)
{
   audio_message.bus = audio_tx_bus_id;
   audio_message.data = audio_tx_data;
   audio_message.MSID = MSID_AUDIO_SERVICES;
   audio_message.MID = mid;
   audio_message.data_size = size;
   memset(audio_tx_data, 0x00, size);
}

/**
 * Map from logical source to the appropriate PITS source ID.
 *
 * @param [in] logical_source - Logical source from audio manager
 * @param [in] pits_source - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */

bool_t PITS_Audio_Map_Logical_Src_To_Pits_Src(Audio_Logical_Src_T logical_source, PITS_Source_T *pits_source)
{
   int8_t i;
   PITS_Source_T new_pits_source = (*pits_source);
   bool_t pits_source_found = false;

   for (i = (Num_Elems(Source_Translation) - 1); i >= 0; i--)
   {
      if (Source_Translation[i].logical_source == logical_source)
      {
         pits_source_found = true;
         if (Source_Translation[i].pits_source == new_pits_source)
         {
            break;
         }
         new_pits_source = Source_Translation[i].pits_source;
      }
   }

   (*pits_source) = new_pits_source;

   return(pits_source_found);
}

/**
 * Map from PITS source ID to the appropriate logical source
 *
 * @param [in] pits_source - PITS source ID from PITS message
 * @param [in] logical_source - pointer to data, to supply the logical source
 *                           back to the calling function
 */

static bool_t pits_audio_map_pits_src_to_logical_src(PITS_Source_T pits_source, Audio_Logical_Src_T *logical_source)
{
   uint8_t i;
   bool_t logical_source_found = false;

   for (i = 0; i < Num_Elems(Source_Translation); i++)
   {
      if (Source_Translation[i].pits_source == pits_source)
      {
         (*logical_source) = Source_Translation[i].logical_source;
         logical_source_found = true;
         break;
      }
   }

   return(logical_source_found);
}

/**
 * Map from logical source to the appropriate PITS Playback ID.
 *
 * @param [in] logical_source - Logical source from audio manager
 * @param [in] pits_playback - pointer to data, to supply the PITS PLayback ID
 *                           back to the calling function
 */
static bool_t pits_audio_map_logical_src_to_pits_playback(Audio_Logical_Src_T logical_source, PITS_Playback_T *pits_playback)
{
   int8_t i;
   bool_t pits_playback_found = false;

   for (i = 0; i < Num_Elems(Playback_Translation); i++)
   {
      if (Playback_Translation[i].logical_source == logical_source)
      {
         (*pits_playback) = Playback_Translation[i].pits_playback;
         pits_playback_found = true;
         break;
      }
   }
   return(pits_playback_found);
}

/**
 * Map from ssm source to the appropriate PITS source ID.
 *
 * @param [in] logical_source - Logical source from audio manager
 * @param [in] pits_source - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
 bool_t pits_audio_map_ssm_src_to_pits_src(SSM_Source_Type_T ssm_source, PITS_Source_T *pits_source)
{
   int8_t i;
   PITS_Source_T new_pits_source = (*pits_source);
   bool_t pits_source_found = false;

   for (i = (Num_Elems(Set_Source_SSM_Table) - 1); i >= 0; i--)
   {
      if (Set_Source_SSM_Table[i].logical_source_ssm == ssm_source)
      {
         pits_source_found = true;
         if (Set_Source_SSM_Table[i].pits_source == new_pits_source)
         {
            break;
         }
         new_pits_source = Set_Source_SSM_Table[i].pits_source;
      }
   }

   (*pits_source) = new_pits_source;

   return(pits_source_found);
}

/**
 * Map from ssm source to the appropriate PITS playback source ID.
 *
 * @param [in] logical_source - samantha source from audio manager
 * @param [in] pits_source - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
bool_t pits_audio_map_ssm_src_to_pits_playback_src(SSM_Source_Type_T ssm_source, PITS_Playback_T *pits_play_source)
{
   int8_t i;
   bool_t pits_playback_found = false;

   for (i = 0; i < Num_Elems(SSM_Playback_Translation); i++)
   {
      if (SSM_Playback_Translation[i].ssm_source == ssm_source)
      {
         (*pits_play_source) = SSM_Playback_Translation[i].pits_playback_source;
         pits_playback_found = true;
         break;
      }
   }
   return(pits_playback_found);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_volume_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_volume_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_VOLUME_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) && (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            audio_tx_data[3] = (uint8_t)SSM_Get_Volume(SSM_CHAN_MAIN_AUDIO);
#if 0			
            audio_tx_data[3] = (uint8_t) Scale(PITS_AU_Get_Volume(zone, bus),
                                               VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
#endif
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_volume_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Volume Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio volume level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_volume_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_VOLUME_SET_ACK, 4);
  
      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;

         audio_tx_data[0] = (uint8_t) SUCCESS;
#if 0		 
         Audio_Overrides.Volume = true;
         PITS_AU_Enable_Overrides(Audio_Overrides);
         volume = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);
         PITS_AU_Set_Volume(zone, bus, volume);
         audio_tx_data[3] = (uint8_t) Scale(PITS_AU_Get_Volume(zone, bus),
                                               VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
#endif
         SSM_Set_Volume(SSM_CHAN_MAIN_AUDIO, message->data[2]);
         sleep(1);
         audio_tx_data[3] = (uint8_t)SSM_Get_Volume(SSM_CHAN_MAIN_AUDIO);

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_audio_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio fade level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio fade level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_fade_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_FADE_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) && (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            audio_tx_data[3] = (uint8_t)SSM_Get_Fade();
#if 0			
            adjust_tone = (uint8_t) Scale(PITS_AU_Get_Fade(zone, bus),
                                               FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[3] = PITS_Get_Fade_Val(adjust_tone);
#endif			
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_fade_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Fade Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio fade level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Fade level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_fade_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_FADE_SET_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
#if 0			
            Audio_Overrides.Fade = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            fade = (Audio_Detent_T) Scale(PITS_Process_Set_Fade (message->data[2]), 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
            PITS_AU_Set_Fade(zone, bus, fade);
            adjust_tone = (uint8_t) Scale(PITS_AU_Get_Fade(zone, bus),
                                               FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[3] = PITS_Get_Fade_Val(adjust_tone);
#endif
            SSM_Set_Fade(message->data[2]);
            audio_tx_data[3] = message->data[2];
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            audio_tx_data[3] = message->data[2];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_balance_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio balance level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Balance level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_balance_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_BALANCE_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) && (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            audio_tx_data[3] = (uint8_t)SSM_Get_Balance();

#if 0
            adjust_tone = (uint8_t) Scale(PITS_AU_Get_Balance(zone, bus),
                                               BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[3] = PITS_Get_Balance_Val(adjust_tone);
#endif			
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_balance_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Balance Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Balance level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Balance level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_balance_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_BALANCE_SET_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         audio_tx_data[3] = message->data[2];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
#if 0			
            Audio_Overrides.Balance = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            balance = (Audio_Detent_T) Scale(PITS_Process_Set_Balance (message->data[2]), 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
            PITS_AU_Set_Balance(zone, bus, balance);
            adjust_tone = (uint8_t) Scale(PITS_AU_Get_Balance(zone, bus),
                                                           BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[3] = PITS_Get_Balance_Val(adjust_tone);
#endif
            SSM_Set_Balance(message->data[2]);
            audio_tx_data[3] = message->data[2];
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            audio_tx_data[3] = message->data[2];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_audio_get_source_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio source.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_source_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_Source_Type_T logical_source;
   PITS_Source_T pits_source = PITS_SRC_NONE;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SOURCE_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;

         logical_source = PITS_AU_Get_last_source(zone);
         source_found = pits_audio_map_ssm_src_to_pits_src(logical_source,  &pits_source);

         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) &&
             source_found)
         {
#if 0         
            if(pits_source == PITS_SRC_DVD)
            {
               pits_source = PITS_SRC_DVD2;
            }
#endif			
            audio_tx_data[0] = (uint8_t) SUCCESS;
            if (pits_test_channel_flag)
            {
               audio_tx_data[3] = pits_test_channel;
            }
            else
            {
               audio_tx_data[3] = (uint8_t) pits_source;
            }
         }
         else
         {
            if (pits_test_channel_flag)
            {
               audio_tx_data[0] = (uint8_t) SUCCESS;
               audio_tx_data[3] = (uint8_t)pits_test_channel;
            }
            else
            {
               audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;               
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_ssm_source_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio source.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = SSM Audio source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_ssm_source_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_Source_Type_T ssm_source;
   PITS_Source_T pits_source = PITS_SRC_NONE;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SOURCE_GET_SSM_ACK, 4);
      audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         ssm_source = PITS_Get_Audio_Source_Type();
         source_found = pits_audio_map_ssm_src_to_pits_src(ssm_source, &pits_source);
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) && source_found)
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            audio_tx_data[3] = (uint8_t) pits_source;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_ssm_source_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Source
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio source
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_ssm_source_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   /*Audio_Logical_Src_T logical_source = AUDIO_LOGICAL_SRC_NULL;*/
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   PITS_Source_T pits_source;
   uint8_t source_index = 0;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SOURCE_SET_SSM_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         pits_source = (PITS_Source_T) message->data[2];
         for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
         {
            if( Set_Source_SSM_Table[source_index].pits_source == pits_source )
            {
               new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
               source_found = true;
               break;
            }
         }
         /*source_found = pits_audio_map_pits_src_to_logical_src(pits_source,
                                                               &logical_source);*/
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) &&
             source_found)
         {
            /*PITS_Audio_Connect_Src_To_Zone(zone, bus, logical_source);*/
            PITS_AU_Select_Source_Type(new_source_ssm, new_zone_ssm);
            audio_tx_data[3] = message->data[2];
            audio_tx_data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            audio_tx_data[3] = message->data[2];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_mic_source_req
 *===========================================================================*
 * @brief Receive a Request to Set virtual mic source just for EE EMC test requirement
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = None
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = None
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_virtual_source_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t pit_source;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SET_VIRTUAL_SOURCE_ACK, 4);
  
      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         pit_source = message->data[2];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         audio_tx_data[3] = pit_source;

         PITS_AU_Select_Virtual_Source_Type(pit_source, message->data[3]);
         
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}


void pits_audio_set_ssm_source_present(uint8_t source)
{
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   PITS_Source_T pits_source;
   uint8_t source_index = 0;

   pits_source = (PITS_Source_T) source;
   for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
   {
      if( Set_Source_SSM_Table[source_index].pits_source == pits_source )
      {
         new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
      }
   }
   PITS_AU_Select_Source_Type(new_source_ssm, new_zone_ssm);

   PITS_SSM_Store_Source_Type(new_source_ssm, new_zone_ssm);
}

void pits_audio_set_ssm_source_last_source(Sys_Zone_T zone, uint8_t source)
{

  SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   PITS_Source_T pits_source;
   SSM_Source_T ssm_src = {SSM_SRC_FM, 1};
   uint8_t source_index = 0;

   pits_source = (PITS_Source_T) source;
   for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
   {
      if( Set_Source_SSM_Table[source_index].pits_source == pits_source )
      {
         new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
      }
   }

   ssm_src.type = new_source_ssm;

   ssm_Save_Channel_Source(zone, &ssm_src);
 
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_source_audio_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Source
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio source
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_source_audio_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Logical_Src_T logical_source = AUDIO_LOGICAL_SRC_NULL;
   PITS_Source_T pits_source;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   Audio_Logical_Src_T source;
   Audio_Logical_Path_T pits_path;
   char cmd_name[100] = {0};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SOURCE_AUDIO_SET_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         audio_tx_data[3] = message->data[2];
         pits_source = (PITS_Source_T) message->data[2];

         switch (pits_source)
         {
            case PITS_SRC_TTS:
            case PITS_SRC_NAV:
            {
               source = AUDIO_LOGICAL_SRC_MEDIA_SRVR2;
               pits_path = AUDIO_MAIN_ZONE_NAV_LOG_PATH;
               Audio_Select_Source(pits_path, source);
               Audio_Set_Volume(pits_path, 20);
               Audio_Set_Mute_State_w_Time(pits_path, AUDIO_UNMUTE, 50);

               if (pits_source == PITS_SRC_TTS)
               {
                  snprintf(cmd_name, 100, "aplay -DTts -r48000 -fS16_LE -c2 %s &", PITS_V_SRC_TTS_PATH);
                  system(cmd_name); 
               }
               else
               {
                  snprintf(cmd_name, 100, "aplay -DNavi -r48000 -fS16_LE -c2 %s &", PITS_V_SRC_NAV_PATH);
                  system(cmd_name); 
               }

               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
            }
            break;

            case PITS_SRC_T_BOX_AUDIO:
            {
               Tbox_SSM_Source_Active_Set_handle();

               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
            }
            break;

            case PITS_SRC_T_BOX_AUDIO_CANCEL:
            {
               Tbox_SSM_Source_Deactive_Set_handle();

               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
            }
            break;

            case PITS_SRC_MIC:
            {
               AuMgr_Connect_Src_To_Zone(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS, AUDIO_LOGICAL_SRC_MIC);

               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
            }
            break;

            case PITS_SRC_ALARM:
            {
               do_alarm_channel_test();

              pits_test_channel_flag = true;
              pits_test_channel = pits_source;
            }
            break;

            case PITS_SRC_ALARM_CANCEL:
            {
               stop_alarm_channel_test();

              pits_test_channel_flag = true;
              pits_test_channel = pits_source;
            }
            break;
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
            case PITS_SRC_SPDIF:
            {
               /*Rear Entertainmnet System*/
               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
               do_res_play_test();
            }
            break;

            case PITS_SRC_SPDIF_CANCEL:
            {
               stop_res_play_test();
               pits_test_channel_flag = true;
               pits_test_channel = pits_source;
            }
            break;
#endif
            default:
            {
               source_found = pits_audio_map_pits_src_to_logical_src(pits_source, &logical_source);
	    
               if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus || SYS_AUDIO_NAV_BUS == bus) &&
                   (SYS_ZONE_MAIN == zone) && source_found)
               {
                  PITS_Audio_Connect_Src_To_Zone(zone, bus, logical_source);
                  Pits_AuMgr_SSM_Source_Present (pits_source);
               }
               else
               {
                  audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
               }
               pits_test_channel_flag = false;
               pits_test_channel = PITS_SRC_NONE;
            }
            break;
         }
         
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: Pits_Get_Muted_Data
 *===========================================================================*
 * @brief Receive Mute message from audio module.
 *
 * @returns
 *    None
 *
 * @param [in] data = data value
 * @param [in] length = message length
 *
 */
/*===========================================================================*/
void Pits_Get_Muted_Data (const uint8_t * data,  size_t length)
{
   pits_mute_state = AUDIO_MUTE;
}

/*===========================================================================*
 * FUNCTION: Pits_Get_Unmuted_Data
 *===========================================================================*
 * @brief Receive Unmute message from audio module.
 *
 * @returns
 *    None
 *
 * @param [in] data = data value
 * @param [in] length = message length
 *
 */
/*===========================================================================*/
void Pits_Get_Unmuted_Data (const uint8_t * data,  size_t length)
{
   pits_mute_state = AUDIO_UNMUTE;
}


/*===========================================================================*
 * FUNCTION: pits_audio_get_mute_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio equalizer level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio mute status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_mute_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_MUTE_Status_T mute_state = SSM_CHAN_UNMUTE;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_MUTE_REPORT, 4);

      zone = (Sys_Zone_T) message->data[0];
      bus  = (Sys_Audio_Bus_T) message->data[1];
      audio_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;

        mute_state = SSM_Get_Mute_Status();

         if(SSM_CHAN_MUTE == mute_state)
         {
              audio_tx_data[3] = 0x01;
         }
         else if(SSM_CHAN_UNMUTE == mute_state)
         {
            audio_tx_data[3] = 0x00;
/*            audio_tx_data[3] = PITS_Processing_Audio_UNMUTE(audio_tx_data[3], zone, bus);*/
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_mute_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Mute Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Mute Status
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Mute Status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_mute_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_MUTE_Status_T mute_state = SSM_CHAN_UNMUTE;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_MUTE_SET_ACK, 4);


      zone = (Sys_Zone_T)message->data[0];
      bus  = (Sys_Audio_Bus_T)message->data[1];
      if(message->data[2] == 0)
      {
         mute_state = SSM_CHAN_UNMUTE;
      }
      if(message->data[2] == 1)
      {
         mute_state = SSM_CHAN_MUTE;
      }
      audio_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         SSM_Set_Mute(mute_state);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if (mute_state == SSM_CHAN_MUTE)
         {
            audio_tx_data[3] = 0x01;
         }
         else
         {
            audio_tx_data[3] = 0x00;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_audio_get_chime_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio chime setting.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio chime setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_chime_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_CHIME_REPORT, 2);
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = PITS_Get_Audio_Chime_Setting();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_chime_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Chime Setting
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio chime setting
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio chime setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_chime_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_CHIME_SET_ACK, 2);
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         PITS_Set_Audio_Chime_Setting(message->data[0]);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = message->data[0];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_cdsp_mute_req
 *===========================================================================*
 * @brief Receive a Request to Set CDSP FAST MUTE
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio chime setting
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_cdsp_mute_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SET_CDSP_FAST_MUTE_ACK, 2);

      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Set CDSP Fast Mute Request: Message Data Error");
      }
      else
      {
         Audio_Set_Fast_Mute_State(message->data[0]);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = message->data[0];
          
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
#if 0
/*this function do not used in CHB041 project*/
/*===========================================================================*
 * FUNCTION: pits_audio_get_ddl_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio DDL setting.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio DDL setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_ddl_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_DDL_REPORT, 2);
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)PITS_Get_Audio_DDL_Setting();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
#endif
/*===========================================================================*
 * FUNCTION: pits_audio_get_info_can_state_req
 *===========================================================================*
 * @brief Get Information CAN connect status.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_info_can_state_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_INFO_CAN_STATUS_ACK, 2);
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Get Info CAN connect status Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = PITS_Get_Info_CAN_state();
#if 0
         fixed_dtc = CHB041_Diag_DTC_Get(BUS_OFF_IF_CAN);
         /*no DTC set*/
         if (fixed_dtc.Dtc_Status_Union.Dtc_Status_Byte == 0)
         {
            audio_tx_data[1] = PITS_INFO_CAN_CONNECTED;
         }
         else
         {
            audio_tx_data[1] = PITS_INFO_CAN_DISCONNECTED;
         }
#endif
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);
      }
   }
   return (pits_status);
}
#if 0
/*===========================================================================*
 * FUNCTION: pits_audio_set_ddl_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio DDL Setting
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio DDL Setting
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio DDL Setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_ddl_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_DDL_SET_ACK, 2);
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         PITS_Set_Audio_DDL_Setting(message->data[0]);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)PITS_Get_Audio_DDL_Setting();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
#endif
/*===========================================================================*
 * FUNCTION: pits_audio_get_rsa_req
 *===========================================================================*
 * @brief Receive a Request to Get the RSA status.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = RSA status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_rsa_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_RSA_REPORT, 2);

      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)PITS_Get_RSA_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_rsa_req
 *===========================================================================*
 * @brief Receive a Request to Set the RSA Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = RSA Status
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = RSA Status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_rsa_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_RSA_SET_ACK, 2);

      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         PITS_Set_RSA_Status(message->data[0]);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)PITS_Get_RSA_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_scv_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio SCV setting.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio SCV setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_scv_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = 0;
   Sys_Audio_Bus_T bus = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SCV_REPORT, 2);

      audio_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)Pits_AuMgr_Get_SCV(zone, bus);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_scv_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Chime Setting
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio SCV setting
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio SCV setting
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_scv_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = 0;
   Sys_Audio_Bus_T bus = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SCV_SET_ACK, 2);

      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         Pits_AuMgr_Set_Speed_Comp(zone, bus, (message->data)[0]);
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = (uint8_t)(message->data)[0];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_tone_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio tone control.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = zone
 * @param [in] (message->data)[1] = bus
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = bus
 * @param [out] pbs_tx_data[3] = Base settings
 * @param [out] pbs_tx_data[5] = Mid settings
 * @param [out] pbs_tx_data[7] = Trebel settings
 *
 * @pre message->data_size = 9
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_tone_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Tone_T tone_settings;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_TONE_REPORT, 6);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) && (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            tone_settings = PITS_AU_Get_All_Tone_Bands(zone, bus);
            audio_tx_data[3] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_BASS_BAND],
                                               TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[4] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_MID_BAND],
                                               TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
            audio_tx_data[5] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_TREBLE_BAND],
                                               TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_tone_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Tone Control
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = zone
 * @param [in] (message->data)[1] = bus
 * @param [in] (message->data)[2] = Base settings
 * @param [in] (message->data)[4] = Mid settings
 * @param [in] (message->data)[6] = Trebel settings
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_tone_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Tone_T tone_settings;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_TONE_SET_ACK, 6);

      /* Compose Message Data */
      memset(&audio_tx_data[0], 0x00, sizeof(audio_message.data_size));
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */

         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         audio_tx_data[1] = zone;
         audio_tx_data[2] = bus;
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            Audio_Overrides.Tone = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            tone_settings.absolute_detent[AUDIO_BASS_BAND] =
                (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_MID_BAND] =
                (Audio_Detent_T) Scale(message->data[3], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
                (Audio_Detent_T) Scale(message->data[4], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            PITS_AU_Set_All_Tone_Bands(zone, bus, tone_settings);
            audio_tx_data[3] = message->data[2];
            audio_tx_data[4] = message->data[3];
            audio_tx_data[5] = message->data[4];
         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            audio_tx_data[3] = message->data[2];
            audio_tx_data[4] = message->data[3];
            audio_tx_data[5] = message->data[4];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_dsp_mode_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Mute Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = DSP Mode
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = DSP Mode
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_set_dsp_mode_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      audio_message.bus = audio_tx_bus_id;
      audio_message.data = audio_tx_data;
      audio_message.MSID = MSID_AUDIO_SERVICES;
      audio_message.MID = MID_AUDIO_SET_DSP_MODE_RPT;
      /* Compose Message Data */
      audio_message.data_size = 2;
      memset(&audio_tx_data[0], 0x00, sizeof(audio_message.data_size));
      audio_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         if (message->data[0]< 3)
         {
            audio_tx_data[0] = (uint8_t) SUCCESS;
            audio_tx_data[1] = message->data[0];
            if (message->data[0] == 0)
            {
               if (pits_audio_dsp)
               {
                  pits_audio_dsp = false;
                  PITS_Audio_Clear_Overrides();
                  PITS_Audio_Clear_Source_Override();
               }
            }
            else
            {
               pits_audio_dsp = true;
               Pits_AuMgr_Set_Dsp_Mode(message->data[0]);
            }

         }
         else
         {
            audio_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_playback_status_req
 *===========================================================================*
 * @brief Receive a Request to Get the Playback Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_get_playback_status_req(const PITS_Message_T * message)
{
   Audio_Logical_Src_T logical_source;
   PITS_Playback_T pits_playback = PITS_PLAYBACK_TUNER;
   bool_t playback_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_PLAYBACK_STATUS_RPT, 5);

      /* Compose Message Data */
      audio_tx_data[0] = COMMAND_NOT_SUPPORTED;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         logical_source = PITS_AU_Get_Source(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS);
         playback_found = pits_audio_map_logical_src_to_pits_playback(logical_source, &pits_playback);

         if(playback_found)
         {
            audio_tx_data[0] = SUCCESS;
            audio_tx_data[1] = pits_playback;
            PITS_Get_Playback_Status(&audio_tx_data[2], pits_playback);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_get_playback_status_req
 *===========================================================================*
 * @brief Receive a Request to Get the Playback Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Audio_Get_SSM_Playback_Status_Req(const PITS_Message_T * message)
{
   PITS_Playback_T pits_source = PITS_PLAYBACK_TUNER;
   SSM_Source_Type_T ssm_source;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_SSM_PLAYBACK_STATUS_RPT, 5);

      /* Compose Message Data */
      audio_tx_data[0] = COMMAND_NOT_SUPPORTED;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         ssm_source = PITS_Get_Audio_Source_Type();
         source_found = pits_audio_map_ssm_src_to_pits_playback_src(ssm_source, &pits_source);
         if(source_found)
         {
            audio_tx_data[0] = SUCCESS;
            audio_tx_data[1] = pits_source;
            PITS_Get_Playback_Status(&audio_tx_data[2], pits_source);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

void PITS_Audio_Clear_Source_Override(void)
{
   Sys_Zone_T zone = 0;
   Sys_Audio_Bus_T bus = 0;
   Audio_Logical_Src_T logical_source;
   PITS_Source_T pits_source = PITS_SRC_NONE;
   PITS_Source_T pits_source_init = PITS_SRC_SPDIF;
   bool_t source_found = false;
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   uint8_t source_index = 0;

    logical_source = PITS_AU_Get_Source(zone, bus);
    source_found = PITS_Audio_Map_Logical_Src_To_Pits_Src(logical_source,
                                                          &pits_source);
    if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
        (SYS_ZONE_MAIN == zone) &&
        source_found)
    {
       if (pits_source == PITS_SRC_SPDIF)
       {
          pits_source_init = PITS_SRC_TUNER_FM1;
       }
       else
       {
          pits_source = PITS_SRC_TUNER_FM1;
       }

       for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
       {
          if( Set_Source_SSM_Table[source_index].pits_source == pits_source_init )
          {
             new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
          }
       }
       PITS_AU_Select_Source_Type(new_source_ssm, new_zone_ssm);
       usleep(500 * 1000);
       for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
       {
          if( Set_Source_SSM_Table[source_index].pits_source == pits_source )
          {
             new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
          }
       }
       PITS_AU_Select_Source_Type(new_source_ssm, new_zone_ssm);
    }

}


/*===========================================================================*
 * FUNCTION: PITS_Audio_Set_Internal_Audio
 *===========================================================================*
 * @brief Receive a Request to Set the Internal Audio (qba)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Balance level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Internal audio
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Audio_Set_Internal_Audio(const PITS_Message_T * message)
{
   bool_t internal_audio=false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_INTERNAL_AUDIO_RPT, 2);
      
      /* Compose Message Data */
      audio_tx_data[0] = (uint8_t) FAIL;
      audio_tx_data[1] = message->data[0];
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         if(0x00 != audio_tx_data[1])
         {
            internal_audio= true;
         }
         audio_tx_data[0] = (uint8_t) SUCCESS;
         PITS_AU_Enable_Internal_Audio(internal_audio);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

#if PITS_SINAD_IS
/*===========================================================================*
 * FUNCTION: pits_audio_start_sinad_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_start_sinad_req(const PITS_Message_T * message)
{

   bool_t  pits_enable_sinad = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_START_SINAD_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = message->data[0];
         if (message->data[0] == 0)
         {
            pits_enable_sinad = false;
            pits_enable_sinad_state = false;
            pits_sinad_duration = false;
         }
         else
         {
            pits_enable_sinad = true;
            pits_enable_sinad_state = true;
            pits_sinad_duration = false;
         }
         Audio_Overrides.Source_Change = true;
         PITS_AU_Enable_Overrides(Audio_Overrides);
         SINAD_Enable_Test_Req(pits_enable_sinad);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_audio_play_sinad_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_play_sinad_req(const PITS_Message_T * message)
{

   SINAD_REQ_ID_PLAY_AUDIO_T pits_play_sinad;
   uint16_t pits_duration = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_PLAY_SINAD_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = pits_enable_sinad_state;
         if (pits_enable_sinad_state)
         {
            audio_tx_data[2] = message->data[0];
            audio_tx_data[3] = message->data[1];
            audio_tx_data[4] = message->data[2];
            audio_tx_data[5] = message->data[3];
            audio_tx_data[6] = message->data[4];
            audio_tx_data[7] = message->data[5];

            pits_play_sinad.channel = message->data[0];
            pits_play_sinad.zone = message->data[1];
            pits_play_sinad.signal = message->data[2];
            pits_play_sinad.volume_db = message->data[3];
            pits_duration = message->data[4];
            pits_duration = ((pits_duration<<8)&0xFF00)+message->data[5];
            if (pits_duration == 0)
            {
               pits_sinad_duration = true;
            }
            pits_play_sinad.duration_ms = pits_duration;
            SINAD_Play_Audio_Req(&pits_play_sinad);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_stop_sinad_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_stop_sinad_req(const PITS_Message_T * message)
{
   SINAD_Outgoing_Channel_T pits_out_channel;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_STOP_SINAD_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;
         audio_tx_data[1] = pits_enable_sinad_state;
         if (pits_enable_sinad_state)
         {
            if (pits_sinad_duration)
            {
               pits_out_channel = message->data[0];
               audio_tx_data[2] = message->data[0];
               SINAD_Stop_Audio_Req(pits_out_channel);
               Audio_Overrides.Source_Change = false;
               PITS_AU_Enable_Overrides(Audio_Overrides);
           }
            else
            {
               audio_tx_data[2] = 0;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&audio_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_measure_sinad_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_measure_sinad_req(const PITS_Message_T * message)
{
   SINAD_REQ_ID_MEASURE_SINAD_T pits_measure_sinad;
   uint16_t pits_duration = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      audio_tx_bus_id = message->bus;
      pits_audio_compose_message_header(MID_AUDIO_MEASURE_SINAD_RPT, 11);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         audio_tx_data[0] = (uint8_t) SUCCESS;

         pits_measure_sinad.channel = message->data[0];
         sinad_test_source = message->data[0];
         pits_duration = message->data[1];
         pits_duration = ((pits_duration<<8)&0xFF00)+message->data[2];
         pits_measure_sinad.duration_ms = pits_duration;
         SINAD_Measure_Req(&pits_measure_sinad);
         pits_status = DONE;
      }
   }
   return (pits_status);
}

void PITS_SINAD_Enable_Mfg_Test_Rsp(const uint8_t * data, size_t length)
{
   pits_enable_mfg_sinad = data[0];
}

void PITS_SINAD_Play_Audio_Rsp(const uint8_t * data, size_t length)
{
   pits_playaudio_sinad = data[0];
}

void PITS_SINAD_Stop_Audio_Rsp(const uint8_t * data, size_t length)
{
   pits_stop_sinad = data[0];
}

void PITS_SINAD_Measure_SINAD_Rsp(const uint8_t * data, size_t length)
{
   uint8_t sinad_output[10];
   audio_tx_bus_id = 0;
   pits_audio_compose_message_header(MID_AUDIO_MEASURE_SINAD_RPT, 10);
   memcpy(&sinad_output[0],&data[0],sizeof(SINAD_Get_SINAD_Vals_T));
   audio_tx_data[0] = sinad_output[0];
   audio_tx_data[1] = sinad_test_source;
   audio_tx_data[2] = sinad_output[1];
   audio_tx_data[3] = (0xFF - sinad_output[2])+1;
   audio_tx_data[4] = sinad_output[5];
   audio_tx_data[5] = sinad_output[4];
   audio_tx_data[6] = sinad_output[6];
   audio_tx_data[7] = (0xFF - sinad_output[7])+1;
   audio_tx_data[8] = sinad_output[9];
   audio_tx_data[9] = sinad_output[8];
   PITS_Send_Message(&audio_message);
}
#endif /* PITS_SINAD_IS*/

/*===========================================================================*
 * FUNCTION: PITS_Create_Audio_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_Audio_Timer(void)
{
   SAL_Create_Timer(PITS_EV_AUDIO_SESSION_TIMEOUT, &pits_audio_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Audio_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_Audio_Timer(void)
{
   SAL_Destroy_Timer(pits_audio_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_Audio_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_Audio_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_AUDIO_SESSION_TIMEOUT)
   {
      if (PITS_Set_Audio_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS CONTROL SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_Audio_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_Audio_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (audio_session_state != session)   /* Session State change? */
   {
      audio_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_AUDIO_SESSION, &audio_session_state, sizeof(audio_session_state));   /* Publish new Session State */
      if (audio_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_audio_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_audio_session_timer_id, audio_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Audio_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_Audio_Session(void)
{
   return (audio_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_PCS_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Audio_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &audio_session_state, sizeof(audio_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Audio_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_Audio_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_AUDIO_SESSION,NULL,0,PITS_EVG_AUDIO_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_AUDIO_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*
 * FUNCTION: PITS_Set_Audio_Overrides
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Set_Audio_Overrides(PITS_Audio_Overrides_T au_override, bool_t state)
{
  switch (au_override)
  {
     case PITS_AU_EN_VOLUME:
        Audio_Overrides.Volume = state;      
        break;      
     case PITS_AU_EN_FADE:
        Audio_Overrides.Fade = state;
        break;
     case PITS_AU_EN_BALANCE:
        Audio_Overrides.Balance = state;
        break;
     case PITS_AU_EN_TONE:
        Audio_Overrides.Tone = state;
        break;
     default:
        break;
  }
  PITS_AU_Enable_Overrides(Audio_Overrides);
}

/*
* Please refer to the detailed description in pits_audio_services_cbk.h.
*/
SSM_Source_Type_T PITS_AU_Get_last_source(Sys_Zone_T zone)
{
   SSM_Source_T src;

   SSM_Get_Last_User_Source(zone, &src);
   	
   return src.type;
}

/*===========================================================================*
 * FUNCTION: do_alarm_channel_test
 *===========================================================================*
 * @brief Do alarm channel test.
 *
 * @returns
 *
 *
 */
/*===========================================================================*/
static void do_alarm_channel_test(void)
{
   AuMgr_DO_Enable_T enable_data = {0};
   Audio_Speaker_Flags_T all_mute = {0x00};
   Audio_Speaker_Flags_T channel = {.FL = 0, .FR = 0, .RR = 0, .RL = 1};

   /*enable speaker test*/
   enable_data.Ch_Mute = true;
   enable_data.Test_Tone = true;
   AuMgr_DO_Enable(enable_data);

   /*mute all speakers*/
   AuMgr_DO_Set_Channel_State(all_mute);   

   /*unmute tested channel*/
   AuMgr_DO_Enable_Test_Tone(channel, 50, 20);
}


/*===========================================================================*
 * FUNCTION: stop_alarm_channel_test
 *===========================================================================*
 * @brief Stop alarm channel test.
 *
 * @returns
 *
 * @param
 *
 */
/*===========================================================================*/
static bool_t stop_alarm_channel_test(void)
{
   AuMgr_DO_Disable_Channel_State();
/*   SAL_Stop_Timer(alarm_channel_test_timeout);   */
   
   return true;
}
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: do_res_play_test
 *===========================================================================*
 * @brief Do alarm channel test.
 *
 * @returns
 *
 *
 */
/*===========================================================================*/
static void do_res_play_test(void)
{
   SAL_Start_Timer(pits_res_play_timer_id, 500, true);
}

/*===========================================================================*
 * FUNCTION: stop_res_play_test
 *===========================================================================*
 * @brief Stop alarm channel test.
 *
 * @returns
 *
 * @param
 *
 */
/*===========================================================================*/
static bool_t stop_res_play_test(void)
{
   RSE_Status_T res_state = {0x00};
   uint8_t i = 0;
   
   SAL_Stop_Timer(pits_res_play_timer_id);
   
   res_state.monitor = 0x01;
   res_state.mode = 0xFE;
   res_state.play_status = 0xFE;
   res_state.earphone_state = 0xFE;
   res_state.spdif_state = 0x00;
   res_state.connection_state = 0x01;

   for (; i <= 10; ++i)
   {
      SAL_Publish(EVG_RSE_STATUS, &res_state, sizeof(RSE_Status_T));      
   }
}
#endif
static uint8_t PITS_Get_Info_CAN_state()
{ 
   uint8_t state = 0;
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      PCAN_APPL_INFO_CAN_STATUS,
   };

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {
      PCAN_Get_Status();
   
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 500);
      if (NULL != response_message)
      { 
         if (PCAN_APPL_INFO_CAN_STATUS == response_message->event_id)
         {
            state = ((uint8_t *)response_message->data)[0];
         }
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   } 

   return (state);
}

/*===========================================================================*/
/*!
 * @file pits_audio_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 2
 * ctc_ec#156415: Remove build warnings.
 *
 *  06-Sep-2012 Darinka L\F3pez Rev 60
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 30-Aug-2012 Jorge Rodriguez Rev 59
 * Fix incorrect response for PIT 14/32 that after setting a new SCV value
 * it reported the previous value instead of the new one.
 *
 * 16 Aug 2012 Oscar Vega Rev 58
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 15-Aug-2012 Arturo Perez  Rev 57
 * Task kok_basa#114601 - Implement PIT 42/43 & 44/45 - Get/Set RSA Enable Status
 *
 * 18-Jul-2012 Arturo Perez  Rev 56
 * Task kok_basa#109514 - MID 2C/2D - Request Set DDL/Report Get DDL
 *
 * 26-Jun-2012 Oscar Vega  Rev 54
 * Task kok_basa#105387 - 2_0 - MID 40/41 - Request/Report  Get Playback Status
 *
 * 20-Jun-2012 Oscar Vega  Rev 53
 * Task kok_basa#103740 -  2_0 - Get and Set Chime
 *
 * 09 May 2012 Miguel Garcia Rev 52
 * Include SMM source present
 *
 * 04 May 2012 Miguel Garcia Rev 51
 * Include set audio dsp
 *
 * 1-May-2012 Darinka Lopez  Rev 49
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 27 Apr 2012 Miguel Garcia Rev 48
 * Fix cpid4 set tones
 *
 * 24 Apr 2012 Miguel Garcia Rev 47
 * Include Mute while scanning for ICR
 *
 * 29 Mar 2012 Miguel Garcia Rev 46
 * Fix Set Fade, Balance linearity
 *
 * 21-Mar-2012 Darinka Lopez  Rev 45
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 13 Mar 2012 Miguel Garcia Rev 44
 * Fix Set Fade is in opposite direction
 *
 * 07 Mar 2012 Miguel Garcia Rev 42
 * Remove overrides false for tones
 *
 * 27 Feb 2012 Miguel Garcia Rev 42
 * Include pits muted, unmuted
 *
 * 23 Feb 2012 Miguel Garcia Rev 41
 * Include Sinad fix in pits
 *
 * 02 Feb 2012 Miguel Garcia Rev 40
 * Fix diagnostics fade and balance
 *
 * 27-Jan-2012 Miguel Garcia Rev 39
 * Fix volume for diagnostics
 *
 * 12-Jan-2012 Juan Carlos Castillo  Rev 38
 * SCR kok_basa#19216: PITS Get Source - Audio Services
 * Fix task: Remove sinad_test_source warning on SBX
 *
 * 12-Jan-2012 Juan Carlos Castillo  Rev 37
 * SCR kok_basa#19216: PITS Get Source - Audio Services
 * Fix: Get Source directly from SSM instead of logical audio.
 *
 * 27 Dec 2011 Miguel Garcia
 * Fix sinad amplitud response
 *
 * 21 Dec 2011 Miguel Garcia
 * Remove zone and bus from pits set volume
 *
 * 14-Dec-2011 Darinka Lopez  Rev 31
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 30
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 6-Dec-2011 Marco Castillo 29
 * SCR kok_basa#10714 : Audio CPID 0x04 implementation
 *
 * 31 Oct 2011 Miguel Garcia Rev 28
 * Include mapping sources
 *
 * 27-Oct-2011 Juan Carlos Castillo  Rev 27
 * SCR kok_basa#17097: Create a temporary PITS message to notify when internal audio control is needed.
 * Fix: Add event to request internal audio control..
 *
 * 25 Oct 2011 Miguel Garcia Rev 26
 * Include DVD2 source
 *
 * 20-Oct-2011 Darinka Lopez  Rev 25
 * SCR kok_basa#14623: Implement MSID(14h) - Audio Services
 * Fix Include files
 *
 * 20-Oct-2011 Darinka Lopez  Rev 24
 * SCR kok_basa#14623: Implement MSID(14h) - Audio Services
 * Fix: Make changes in Audio Services BB to support SBX program.
 *
 * 22 Jun 2011 Miguel Garcia
 * Include audio sources and fix pits set source
 *
 * 18 Mar 2011 Miguel Garcia Rev19
 * Include cpid services
 *
 * 04 Mar 2011 Miguel Garcia Rev 18
 * Include dpids services
 *
 * 13-Jan-2011 Miguel Garcia  Rev 17
 * Remove unused Pits services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 15
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 08-Jul-2010 Miguel Garcia  Rev 14
 * SCR kok_basa#1674: Implement Diagnostic Services PITS for CPIDs and DPIDs.
 *
 * 11-Mar-2010 Pramod N K  Rev 12
 * SCR kok_basa#685: Remove references to old header files and API related to MH
 *
 * 2-Oct-2009 David Mooar  Rev 9
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * 10-Sept-2009 David Mooar  Rev 8
 * SCR kok_aud#62361/62399: Implement PITS audio messages.
 *
 * - 30-Apr-2009 Yi Liu
 *   - Fixed Compile warnings.
 *
 * - 11-Mar-2009 Yi Liu
 * + Added Tone report/set services.
 *
 * - 13-Jan-2009 Yi Liu
 * + SCR 58644 - Update MDF PITS and building blocks.
 *
 * - 19-Nov-2008 Yi Liu
 * + SCR 57688 - Update MDF PITS and building blocks.
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 03-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *               Type casting.
 * - 01-oct-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
