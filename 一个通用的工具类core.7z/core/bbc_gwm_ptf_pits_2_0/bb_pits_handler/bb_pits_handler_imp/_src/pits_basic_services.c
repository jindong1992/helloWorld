/*===========================================================================*/
/**
 * @file pits_basic_services.c
 *
 * PITS Basic Service Message Definitions
 *
 * %full_filespec:pits_basic_services.c~1:csrc:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:20 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module defines the PITS Basic Service Message used in the program.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - PBS: PITS Basic Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "em.h"
#   include "pits_basic_services.h"
#   include "pits_basic_services_cfg.h"
#   include <string.h>
#   include "utilities.h"
#   include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 0);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_pbs_initialize(void);
static void pits_pbs_compose_message_header(uint8_t mid, uint8_t size);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PBS_RX_INDEX

#define MID_PBS_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_pbs_rx_messages[] = {
   MID_PBS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PBS_TX_INDEX

#define MID_PBS_TX_INDEX(name, mid) (mid),

static const uint8_t pits_pbs_tx_messages[] = {
   MID_PBS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PBS_RX_INDEX
#define MSID_PBS_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_pbs_rx_message_sets[] = {
   MSID_PBS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PBS_TX_INDEX
#define MSID_PBS_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_pbs_tx_message_sets[] = {
   MSID_PBS_TX_TABLE
};

static uint8_t pbs_tx_bus_id;   /* ID of the bearing bus on which to send response */
static PITS_Message_T pbs_message;      /* for construction of a pbs message to be transmitted */
static uint8_t pbs_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t pbs_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T pbs_session_state;

/**
 * Stores Timer ID for PBS Session
 */
static SAL_Timer_Id_T pits_pbs_session_timer_id;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_PBS_Interface = {
   pits_pbs_initialize,
   pits_pbs_rx_message_sets,
   Num_Elems(pits_pbs_rx_message_sets),
   pits_pbs_tx_message_sets,
   Num_Elems(pits_pbs_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: pits_pbs_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_pbs_initialize(void)
{
   pbs_tx_bus_id = 0;
   memset(&pbs_message, 0x00, sizeof(PITS_Message_T));
   memset(pbs_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   pbs_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   pbs_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that PBS Session is closed? */
}

/*===========================================================================*
 * FUNCTION: pits_pbs_compose_message_header
 *===========================================================================*
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
/*===========================================================================*/
void pits_pbs_compose_message_header(uint8_t mid, uint8_t size)
{
   pbs_message.bus = pbs_tx_bus_id;
   pbs_message.data = pbs_tx_data;
   pbs_message.MSID = MSID_BASIC_SERVICES;
   pbs_message.MID = mid;
   pbs_message.data_size = size;
   memset(pbs_tx_data, 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_PBS_Message_Set_Id_Supported_Req
 *===========================================================================*
 * @brief Receive a Request for the MIDs supported for a specific MSID
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = msid
 * @param [in] (message->data)[1] = mid
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = MSID
 * @param [out] pbs_tx_data[2] = MID
 * @param [out] pbs_tx_data[3] = result (SUPPORTED, NOT_SUPPORTED)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_PBS_Message_Set_Id_Supported_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_MESSAGE_SET_ID_SUPPORTED_RPT, 3);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE SET ID SUPPORTED REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         pbs_tx_data[1] = (message->data)[0];
         pbs_tx_data[2] = (uint8_t)PITS_Get_MSID((message->data)[0]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_pbs_size_packet_req
 *===========================================================================*
 * @brief Receive a Request for Message packet size
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS)
 * @param [out] pbs_tx_data[1 - 2] = message packet size
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_size_packet_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_SIZE_PACKET_REPORT, 3);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS PACKET SIZE REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&pbs_tx_data[1], (uint16_t) (PITS_MAX_PACKET_SIZE));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pbs_size_message_req
 *===========================================================================*
 * @brief Receive a Request for Message size
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS)
 * @param [out] pbs_tx_data[1 - 2] = message size
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_size_message_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
     /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_SIZE_MESSAGE_REPORT, 3);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE SIZE REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&pbs_tx_data[1], (uint16_t) (PITS_MAX_MESSAGE_SIZE));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pbs_message_set_name_req
 *===========================================================================*
 * @brief Receive a Request for the string name of a Message Set
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = msid
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = MSID
 * @param [out] pbs_tx_data[2] = result (SUPPORTED, NOT_SUPPORTED)
 * @param [out] pbs_tx_data[3] = string name length
 * @param [out] pbs_tx_data[4 - n] = string name
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_message_set_name_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
     /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_MESSAGE_SET_NAME_RPT, 4);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE SET NAME REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t)SUCCESS;
         pbs_tx_data[1] = (message->data)[0];
         pbs_tx_data[2] = (uint8_t)PITS_Get_MSID_Name(pbs_tx_data[1], &pbs_tx_data[3]);
         pbs_message.data_size = (uint8_t) (pbs_tx_data[3] + 4);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pbs_message_id_supported_req
 *===========================================================================*
 * @brief Receive a Request for the MIDs supported for a specific MSID
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = msid
 * @param [in] (message->data)[1] = mid
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = MSID
 * @param [out] pbs_tx_data[2] = MID
 * @param [out] pbs_tx_data[3] = result (SUPPORTED, NOT_SUPPORTED)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_message_id_supported_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_MESSAGE_ID_SUPPORTED_RPT, 4);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE ID SUPPORTED REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         pbs_tx_data[1] = (message->data)[0];
         pbs_tx_data[2] = (message->data)[1];
         pbs_tx_data[3] = (uint8_t)PITS_Get_MID((message->data)[0], (message->data)[1]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pbs_message_set_bit_req
 *===========================================================================*
 * @brief Receive a Request for Message Set Supported
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS)
 * @param [out] pbs_tx_data[1 - 2] = Number of bits in the array
 * @param [out] pbs_tx_data[3 - n] = bit array
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_message_set_bit_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {

      /* Compose Message Header */
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_MESSAGE_SET_BIT_RPT, PITS_MID_BIT_ARRAY_BYTE_SIZE + 3);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE SET BIT REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&pbs_tx_data[1], (uint16_t) (PITS_MID_BIT_ARRAY_SIZE));
         PITS_Get_MSID_List(&pbs_tx_data[3]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pbs_message_id_bit_req
 *===========================================================================*
 * @brief Receive a Request for Message IDs List for the given Message Set
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = MSID
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = MSID
 * @param [out] pbs_tx_data[2] = result (SUPPORTED, NOT_SUPPORTED)
 * @param [out] pbs_tx_data[3 - 4] = Number of bits in the array
 * @param [out] pbs_tx_data[5 - n] = bit array
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pbs_message_id_bit_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      pbs_tx_bus_id = message->bus;
      pits_pbs_compose_message_header(MID_PBS_MESSAGE_ID_BIT_RPT, PITS_MID_BIT_ARRAY_BYTE_SIZE + 4);

      /* Compose Message Data */
      pbs_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PBS MESSAGE ID BIT REQUEST: Message Data Error");
      }
      else
      {
         pbs_tx_data[0] = (uint8_t) SUCCESS;
         pbs_tx_data[1] = (message->data)[0];
         Util_Put_Big_Endian_U16(&pbs_tx_data[2], (uint16_t) (PITS_MID_BIT_ARRAY_SIZE));
         PITS_Get_MID_List((message->data)[0], &pbs_tx_data[4]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pbs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PBS_Error_Report
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_PBS_Error_Report(const char_t * string)
{
   uint16_t string_len = 0;

   pbs_tx_bus_id = 0;
   string_len = strlen(string);

   pits_pbs_compose_message_header(MID_PBS_ERROR_REPORT, string_len + 2);

   /* Compose Message Data */
   pbs_tx_data[0] = FAIL;
   pbs_tx_data[1] = string_len;
   memcpy(&pbs_tx_data[2],string,string_len);

   return PITS_Send_Message(&pbs_message);
}

/*===========================================================================*
 * FUNCTION: PITS_PBS_Status_Report
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_PBS_Status_Report(const char_t * string)
{

   uint16_t string_len = 0;

   pbs_tx_bus_id = 0;
   string_len = strlen(string);

   pits_pbs_compose_message_header(MID_PBS_STATUS_REPORT, string_len + 2);

   /* Compose Message Data */
   pbs_tx_data[0] = SUCCESS;
   pbs_tx_data[1] = string_len;
   memcpy(&pbs_tx_data[2],string,string_len);

   return PITS_Send_Message(&pbs_message);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_PBS_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
void PITS_Create_PBS_Timer(void)
{
   SAL_Create_Timer(PITS_EV_PBS_SESSION_TIMEOUT, &pits_pbs_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_PBS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_PBS_Timer (void)
{
   SAL_Destroy_Timer(pits_pbs_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_PBS_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_Check_PBS_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_PBS_SESSION_TIMEOUT)
   {
      if (PITS_Set_PBS_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS BASIC SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_PBS_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_Set_PBS_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (pbs_session_state != session)   /* Session State change? */
   {
      pbs_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_PBS_SESSION, &pbs_session_state, sizeof(pbs_session_state));  /* Publish new Session State */
      if (pbs_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_pbs_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_pbs_session_timer_id, pbs_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_PBS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_PBS_Session(void)
{
   return (pbs_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_PBS_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_PBS_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &pbs_session_state, sizeof(pbs_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PBS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_PBS_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_PBS_SESSION,NULL,0,PITS_EVG_PBS_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_PBS_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*
 * FUNCTION: PITS_PBS_Session_Is_Closed
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
bool_t PITS_PBS_Session_Is_Closed(void)
{
   bool_t state = false;
   
   if (pbs_session_state == SESSION_CLOSE)
   {
      state = true;
   }
   return (state);
}

/*===========================================================================*/
/*!
 * @file pits_basic_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Diagnostic Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 16
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 11-Apr-2012 Darinka Lopez  Rev 15
 * Task kok_basa#89011 - Implement Basic Services (MIDs 00, 02 and 08).
 * Fix basic services function to acomplish with PDD requirements.
 * Fix status report message similar to Error report message.
 *
 * 23 Mar 2012 Miguel Garcia  Rev 14
 * Fix Status Report lenght
 *
 * 14-Dec-2011 Darinka Lopez  Rev 13
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 19 May 2011 Miguel Garcia
 * Remove unused services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 6
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 9-Apr-2010 Pramod N K
 * SCR kok_basa#7952: Remove PC Lint errors.
 *
 * 2-Oct-2009 David Mooar  Rev 5
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 15-Dec-2008 Yi Liu
 * + SCR 58578 - Run PITS unit test.
 *             - Correct a boundary check for set timeout request command.
 *
 * - 01-Nov-2008 Yi Liu
 * + SCR 57706 - Change code to be BASA2.0 compatible.
 *
 * - 03-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-25  Larry Ong
 *    - Added Diagnostic Session in PBS as a master session, and allow other
 *      services in Diagnostic Session.
 *    - Added ability to change session timeout
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 *
 * - 2008-06-17  Larry Ong
 *    - Define 1st byte of transmit message data as Confirmation (SUCCESS, FAIL).
 *    - Check for valid receive message data length.
 *
 * - 2008-06-05  Larry Ong
 *    - Added MSID string name.
 *    - Added MID supported.
 *
 * - 2008-05-20  Larry Ong
 *    - Moved MID definitions to pits_basic_services_cfg file.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS SOH Services, MSID = 5.
 *    - Redefined DTC as SOH Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2007-12-14  Larry Ong
 *    - Added DTC Ignition Counter
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Add DTC messages
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-10-31  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-10-01  Larry Ong
 *    - Change pits services EM ID to PITS_MODULE_ID_5.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-06-02  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-12  Mike Gerig/Kris Boultbee
 *    - Created initial file.
 */
/*===========================================================================*/
