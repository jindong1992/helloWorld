/*===========================================================================*/
/**
 * @file pits_control_services.c
 *
 * PITS Control Service Message Definitions
 *
 * %full_filespec:pits_control_services.c~2:csrc:ctc_ec#24 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Wed Jul  6 17:26:34 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the PITS Control Service Message used in the program.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy
 *    - MSID: Message Set Identifier
 *    - MID: Message Identifier
 *    - PCS: PITS Control Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "em.h"
#   include "pits_control_services.h"
#   include "pits_control_services_cfg.h"
#   include "pits_pcs_services.h"
#   include "pits_pcs_services_cbk.h"
#   include <string.h>
#   include "utilities.h"
#   include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 2);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef void (*PITS_Download_Execute_Fptr) (void);

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_pcs_initialize(void);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PCS_RX_INDEX

#define MID_PCS_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_pcs_rx_messages[] = {
   MID_PCS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PCS_TX_INDEX

#define MID_PCS_TX_INDEX(name, mid) (mid),

static const uint8_t pits_pcs_tx_messages[] = {
   MID_PCS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PCS_RX_INDEX

#define MSID_PCS_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_pcs_rx_message_sets[] = {
   MSID_PCS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PCS_TX_INDEX
#define MSID_PCS_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_pcs_tx_message_sets[] = {
   MSID_PCS_TX_TABLE
};

static uint8_t pcs_tx_bus_id;   /* ID of the bearing bus on which to send response */
static PITS_Message_T pcs_message;      /* for construction of a PCS message to be transmitted */
static uint8_t pcs_tx_data[PITS_MAX_MESSAGE_SIZE];
static uint32_t pcs_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T pcs_session_state;

/**
 * Stores Timer ID for PCS Session
 */
static SAL_Timer_Id_T pits_pcs_session_timer_id;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_PCS_Interface = {
   pits_pcs_initialize,
   pits_pcs_rx_message_sets,
   Num_Elems(pits_pcs_rx_message_sets),
   pits_pcs_tx_message_sets,
   Num_Elems(pits_pcs_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: pits_pcs_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_pcs_initialize(void)
{
   pcs_tx_bus_id = 0;
   memset(&pcs_message, 0x00, sizeof(PITS_Message_T));
   memset(pcs_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   pcs_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   pcs_session_state = SESSION_CLOSE;
   /* @todo Broadcast XSAL message that PCS Session is closed */
}

/*===========================================================================*
 * FUNCTION: pits_pcs_parameter_write_req
 *===========================================================================*
 * @brief Receive a Request to Write Parameter.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0] = Parameter Group ID
 * @param [in] (message->data)[1] = Parameter Element ID
 * @param [in] (message->data)[2] = data byte length
 * @param [in] (message->data)[3 - n] = data bytes
 * @param [out] pcs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pcs_tx_data[1] = Parameter Group ID
 * @param [out] pcs_tx_data[2] = Parameter Element ID
 * @param [out] pcs_tx_data[3] = length
 *
 * @pre message->data_size > 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pcs_parameter_write_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t gid_index = 0;
   uint8_t pid_index = 0;
   const PITS_PCS_PAR_GID_T *gid;
   const PITS_PCS_PAR_EID_T *pid;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pcs_tx_bus_id = message->bus;
      pcs_message.bus = message->bus;
      pcs_message.data = pcs_tx_data;
      pcs_message.MSID = MSID_CONTROL_SERVICES;
      pcs_message.MID = MID_PCS_PARAMETER_WRITE_RPT;
      /* Compose Message Data */
      pcs_tx_data[0] = (uint8_t) FAIL;
      memset(&pcs_tx_data[1], 0, 3);
      pcs_message.data_size = 4;
      if ((message->data_size <= 3) || (message->data_size != ((message->data)[2] + 3)))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS PARAMETER WRITE REQUEST: Message Data Error");
      }
      else
      {
         pcs_tx_data[1] = (message->data)[0];
         pcs_tx_data[2] = (message->data)[1];
         pcs_tx_data[3] = (message->data)[2];

         for (gid_index = 0; gid_index < MAXIMUM_NUM_OF_PARAM_GROUPS_IN_GID_TABLE; gid_index++)
         {
            /* Is this the Group ID we're looking for? */
            gid = &(PCS_Param_Message_Sets[gid_index]);
            if (gid->GID == (message->data)[0])
            {
               /* This is the correct Group ID, look for matching Element ID */
               for (pid_index = 0; pid_index < gid->message_count; pid_index++)
               {
                  pid = &(gid->message_ids[pid_index]);
                  if (pid->EID == (message->data)[1])
                  {
                     /* This is the correct Parameter ID, Call Parameter Function */
                     if (pid->rx_par(message, &pcs_tx_data[3]))
                     {
                        pcs_tx_data[0] = (uint8_t) SUCCESS;
                     }
                     else
                     {
                        pcs_tx_data[3] = 0;
                     }
                     break;  /* Stop search. */
                  }
               }             /* look until the end of EID table */
               break;        /* Correct GID but no EID, stop search */
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pcs_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pcs_parameter_read_req
 *===========================================================================*
 * @brief Receive a Request to Read Parameter.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0] = Parameter Group ID
 * @param [in] (message->data)[1] = Parameter Element ID
 * @param [out] pcs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pcs_tx_data[1] = Parameter Group ID
 * @param [out] pcs_tx_data[2] = Parameter Element ID
 * @param [out] pcs_tx_data[3] = data byte length
 * @param [out] pcs_tx_data[4 - n] = data bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pcs_parameter_read_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   uint8_t gid_index;
   uint8_t pid_index;
   const PITS_PCS_PAR_GID_T *gid;
   const PITS_PCS_PAR_EID_T *pid;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pcs_tx_bus_id = message->bus;
      pcs_message.bus = message->bus;
      pcs_message.data = pcs_tx_data;
      pcs_message.MSID = MSID_CONTROL_SERVICES;
      pcs_message.MID = MID_PCS_PARAMETER_READ_RPT;
      /* Compose Message Data */
      pcs_tx_data[0] = (uint8_t) FAIL;
      memset(&pcs_tx_data[1], 0, 3);
      pcs_message.data_size = 4;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARAMETER READ REQUEST: Message Data Error");
      }
      else
      {
         pcs_tx_data[1] = (message->data)[0];
         pcs_tx_data[2] = (message->data)[1];

         for (gid_index = 0; gid_index < MAXIMUM_NUM_OF_PARAM_GROUPS_IN_GID_TABLE; gid_index++)
          {
             /* Is this the Group ID we're looking for? */
             gid = &(PCS_Param_Message_Sets[gid_index]);
             if (gid->GID == (message->data)[0])
             {
                /* This is the correct Group ID, look for matching Element ID */
                for (pid_index = 0; pid_index < gid->message_count; pid_index++)
                {
                   pid = &(gid->message_ids[pid_index]);
                   if (pid->EID == (message->data)[1])
                   {
                      /* This is the correct Element ID, call function */
                      if (pid->rx_par(message, &pcs_tx_data[3]))
                      {
                         pcs_tx_data[0] = (uint8_t) SUCCESS;
                         pcs_message.data_size = (uint8_t) (pcs_tx_data[3] + 4);
                      }
                      else
                      {
                         pcs_tx_data[3] = 0;
                      }
                      break;  /* Stop search. */
                   }
                }             /* look until the end of EID table */
                break;        /* Correct GID but no EID, stop search */
             }
          }

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pcs_message);
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_pcs_downloadx_req
 *===========================================================================*
 * @brief Receive a Request To Download and Execute a Routine.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0 - 3] = download memory address
 * @param [in] (message->data)[4 - 5] = data byte length
 * @param [in] (message->data)[6 - n] = data bytes
 * @param [out] pcs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pcs_tx_data[1 - 4] = memory address
 * @param [out] pcs_tx_data[5 - 6] = data byte length
 *
 * @pre message->data_size > 7
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pcs_downloadx_req(const PITS_Message_T * message)
{
   uint16_t length;
   uint32_t address;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pcs_tx_bus_id = message->bus;
      pcs_message.bus = message->bus;
      pcs_message.data = pcs_tx_data;
      pcs_message.MSID = MSID_CONTROL_SERVICES;
      pcs_message.MID = MID_PCS_DOWNLOAD_EX_RPT;
      /* Compose Message Data */
      pcs_tx_data[0] = (uint8_t) FAIL;
      memset(&pcs_tx_data[1], 0, 6);
      pcs_message.data_size = 7;
      length = Util_Get_Big_Endian_U16(&(message->data)[4]);
      if ((message->data_size < 7) || (message->data_size != (length + 6)))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS TEST EXECUTE REQUEST: Message Data Error");
      }
      else
      {
         address = Util_Get_Big_Endian_U32(&(message->data)[0]);
         length = (uint16_t) min(length, PITS_MAX_DATA_SIZE);
         memcpy(&(pcs_tx_data[1]), &address, 4);
         memcpy(&(pcs_tx_data[5]), &length, 2);

            /* Check for valid address and length */
            if (PITS_Download_Memory_Map_Check(address, (size_t) length))
            {
               pcs_tx_data[0] = (uint8_t) SUCCESS;
               memcpy((void *)address, &((message->data)[6]), (size_t) length); /* Download Routine to RAM */
               ((PITS_Download_Execute_Fptr) address) ();   /* Execute Downloaded Routine */
               pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pcs_message);                      
            }
            else
            {
               pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS DOWNLOAD EXECUTE REQUEST: Invalid Download Memory Address");
            }

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pcs_iic_write_req
 *===========================================================================*
 * @brief Receive a Request to Write IIC data.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0 - n] = IIC write parameters, defined in product specific file
 * @param [in] (message->data)[n+1] = number of data bytes
 * @param [in] (message->data)[n+2 - m] = data bytes
 * @param [out] pcs_tx_data[2] = confirmation (SUCCESS, FAIL)
 * @param [out] pcs_tx_data[1] = IIC channel
 * @param [out] pcs_tx_data[2] = IIC device address
 * @param [out] pcs_tx_data[3] = number of data bytes
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pcs_iic_write_req(const PITS_Message_T * message)
{
   bool_t pits_send_message = false; 
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pcs_tx_bus_id = message->bus;
      pcs_message.bus = pcs_tx_bus_id;
      pcs_message.data = pcs_tx_data;
      pcs_message.MSID = MSID_CONTROL_SERVICES;
      pcs_message.MID = MID_PCS_IIC_WRITE_RPT;
      /* Compose Message Data */
      pcs_tx_data[0] = (uint8_t) FAIL;
      pcs_tx_data[1] = (message->data)[1];   /* IIC channel */
      pcs_tx_data[2] = (message->data)[4];   /* IIC device address */
      pcs_tx_data[3] = (message->data)[14];  /* Number of bytes written */
      pcs_message.data_size = 4;
      pcs_tx_data[0] = (uint8_t) (PITS_IIC_Write(message, &pits_send_message, &pits_status));
      if (pits_send_message)
      {   
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pcs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pcs_iic_read_req
 *===========================================================================*
 * @brief Receive a Request to Read IIC data.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0 - n] = IIC read parameters, defined in product specific file
 * @param [out] pcs_tx_data[0] = Confirmation (SUCCESS, FAIL)
 * @param [out] pcs_tx_data[1] = IIC channel
 * @param [out] pcs_tx_data[2] = IIC device address
 * @param [out] pcs_tx_data[3] = Number of data bytes
 * @param [out] pcs_tx_data[4 - n] = data bytes
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pcs_iic_read_req(const PITS_Message_T * message)
{
   bool_t pits_send_message = false; 
   Done_Or_Not_Done_T pits_status = DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pcs_tx_bus_id = message->bus;
      pcs_message.bus = pcs_tx_bus_id;
      pcs_message.data = pcs_tx_data;
      pcs_message.MSID = MSID_CONTROL_SERVICES;
      pcs_message.MID = MID_PCS_IIC_READ_RPT;
      /* Compose Message Data */
      pcs_tx_data[0] = (uint8_t) FAIL;  /* Confirmation */
      pcs_tx_data[1] = (message->data)[1];      /* IIC channel */
      pcs_tx_data[2] = (message->data)[4];      /* IIC device address */
      pcs_tx_data[3] = (message->data)[14];     /* Report data size */

      {
         pcs_tx_data[0] = (uint8_t) (PITS_IIC_Read(message, &pcs_tx_data[4], &pits_send_message, &pits_status));

      }
      if (pcs_tx_data[0] == FAIL)
      {
         pcs_tx_data[3] = 0;    /* There is an error, clear data byte count */
      }
      /* message data size = IIC data size (pcs_tx_data[3]) + 4 (confirmation, channel, device, data size) */
      pcs_message.data_size = (uint8_t) (pcs_tx_data[3] + 4);
      if (pits_send_message)
      {   
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pcs_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_PCS_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_PCS_Timer(void)
{
   SAL_Create_Timer(PITS_EV_PCS_SESSION_TIMEOUT, &pits_pcs_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_PBS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_PCS_Timer (void)
{
   SAL_Destroy_Timer(pits_pcs_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_PCS_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_PCS_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_PCS_SESSION_TIMEOUT)
   {
      if (PITS_Set_PCS_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS CONTROL SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_PCS_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_PCS_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (pcs_session_state != session)   /* Session State change? */
   {
      pcs_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_PCS_SESSION, &pcs_session_state, sizeof(pcs_session_state));  /* Publish new Session State */
      if (pcs_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_pcs_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_pcs_session_timer_id, pcs_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_PCS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_PCS_Session(void)
{
   return (pcs_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_PCS_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_PCS_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &pcs_session_state, sizeof(pcs_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PCS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_PCS_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_PCS_SESSION,NULL,0,PITS_EVG_PCS_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_PCS_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*/
/*!
 * @file pits_control_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06July2016 Rahul Chiryil (vzm576) Rev.2
 *  ctc_ec#157446: Coverity warning removal
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Control Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 15
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 14
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 1-May-2012 Darinka Lopez  Rev 13
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 14-Dec-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 11
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 19 May 2011 Miguel Garcia
 * Remove unused services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 7
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 2-Oct-2009 David Mooar  Rev 6
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 18-august-2009 David Mooar  Rev 5
 *   SCR kok_aud#62242: Create PITS_Init_Fptr to use instead of void_fptr, to
 *   avoid warnings. 
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Change code to be BASA2.0 compatible.
 *
 * - 05-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-30  Larry Ong
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-06-25  Larry Ong
 *    - Added Diagnostic Session in PBS as a master session, and allow other
 *      services in Diagnostic Session.
 *    - Added ability to change session timeout
 *
 * - 2008-06-17  Larry Ong
 *    - Define 1st byte of transmit message data as Confirmation (SUCCESS, FAIL).
 *    - Check for valid receive message data length.
 *
 * - 2008-06-10  Larry Ong
 *    - Moved MID definitions to pits_control_services_cfg file.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-11-12  Larry Ong
 *    - Publish PCS Session Closed message when PCS session is closed.
 *
 * - 2007-10-01  Larry Ong
 *    - Change pits services EM ID to PITS_MODULE_ID_5.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-15  Larry Ong
 *    - Added Session Refresh message to Refresh Session Timer.
 *
 * - 2007-07-31  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
