/*===========================================================================*/
/**
 * @file pits_manager.c
 *
 * PITS Task module.
 *
 * %full_filespec:pits_manager.c~1:csrc:ctc_ec#17 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:14 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This is the PITS Task module. It initializes and close the Bearing bus,
 *    and manage the transmission and reception of message to and from the bus.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "application_manager.h"
#include "pits_configuration.h"
#include "pits_manager.h"
#include "pits_manager_cbk.h"
#include "pits_manager_cfg.h"
#include "pbc_trace.h"
#include "state_of_health.h"
#include "em.h"
#include "xsal.h"
#include "xsal_thread_id.h"
#include "pits_mfg_services_cbk.h"

EM_FILENUM(PITS_MODULE_ID, 1);
   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/* If the SOH_TIMEOUT is not defined in the cfg file, then default value will be taken */
#ifndef  PITS_SOH_TIMEOUT_MS
#define  PITS_SOH_TIMEOUT_MS  SOH_DEFAULT_TIMEOUT_MS
#endif

/* If SOH_TIMEOUT_MS time is less than twice the MSG_WAIT_TIME_MS
 * time then set the SOH Timeout error */
#if (PITS_SOH_TIMEOUT_MS < (2 * PITS_MSG_WAIT_TIMEOUT_MS))
#error "Invalid SOH timeout"
#endif

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/**
 * Trace IDs used internally by MODULE
 */
typedef enum PITS_Trace_ID_Tag
{
   PITS_TR_1 = (PITS_MODULE_ID << 16),
} PITS_Trace_ID_T;

typedef void(*pits_event_func) (const uint8_t * data, size_t length);

typedef struct PITS_Suscribe_Ev_Tag
{
   SAL_Event_Id_T event;            /**< Receive Pits Event */
   pits_event_func function;        /**< Receive function to handle the event */
} PITS_Suscribe_Ev_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static bool_t process_message(const SAL_Message_T * message);
static void pits_manager(void *param);
static void pits_create_timers (void);
static void pits_destroy_timers(void);
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * Stores thread ID for MODULE, initialized to SAL_UNKNOWN_THREAD_ID
 */
static SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

/**
 * X-Macro to define the list of the private events supported.
 * There must be an entry into this table of the type PITS_Private_Event_Handler_T
 * for each event that you wish to support.
 */

#   undef PITS_EV_INDEX

#   define PITS_EV_INDEX(name, setup, destroy, handler, desc) {name, setup, destroy, handler},

static PITS_Private_Event_Handler_T pits_private_events[] = {
   PITS_EV_TABLE
};

#undef PITS_SUSCRIBE_EV_INDEX

#define PITS_SUSCRIBE_EV_INDEX(event, function)   event,
static const SAL_Event_Id_T pits_events[] = {
   EVG_RSE_STATUS,		
   PITS_SUSCRIBE_EV_TABLE
};


#undef PITS_SUSCRIBE_EV_INDEX

#define PITS_SUSCRIBE_EV_INDEX(event, function)   {event, function},
static const PITS_Suscribe_Ev_T pits_handler_function[] = {
   PITS_SUSCRIBE_EV_TABLE
};

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*
 * Initializes the Module.
 *
 * See API header for full description
 */
void PITS_Initialize(void)
{
   SAL_Thread_Attr_T thread_attr;
   SAL_Thread_Id_T tid;

   PITS_Manager_Get_Thread_Attr(&thread_attr);
   tid = SAL_Create_Thread(pits_manager, NULL, &thread_attr);
   PBC_Ensure(PITS_THREAD_ID == tid, "Error creating PITS manager Thread");

   PITS_Configuration_Initialize();
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_manager.h.
 *
 *===========================================================================*/
void PITS_Handler_Shutdown (void)
{
   SAL_Send(PITS_APP_ID, PITS_THREAD_ID, PITS_EVG_SHUTDOWN, NULL, 0); 
}

/**
 * MODULE Task
 *
 *  Creates a message queue
 *  Creates and start a periodic timer to feed watchdog
 *  Enter endless loop waiting for messages
 *    - Update a task's alive time
 *    - Mark a task as dormant (i.e., stop monitoring)
 *    - Verify task timers and feed watchdog
 */
static void pits_manager(void *param)
{

   /** pointer to current receive message */
   const SAL_Message_T *message;
   uint8_t event_index = 0;
   bool_t    ok;
   bool thread_alive = true;
   
   (void)(param);

   Tr_Info_Lo("PITS manager Thread: start");

   ok =
      SAL_Create_Queue(PITS_QUEUE_SIZE, PITS_MSG_SIZE, SAL_Alloc, SAL_Free);
   PBC_Ensure(ok, "SAL_Create_Queue() failed");

   /* store own thread ID for communication if not stored yet */
   if (PITS_Thread_Id == SAL_UNKNOWN_THREAD_ID)
   {
      PITS_Thread_Id = SAL_Get_Thread_Id();
   }

   /* Signal ready to receive messages */
   SAL_Signal_Ready();
   PITS_Activated();

   /* Initialize the Bearing Bus */
/*
   PITS_Bus_Initialize();
*/
   SAL_Subscribe(pits_events, Num_Elems(pits_events));
   pits_create_timers();
   SOH_Register(PITS_SOH_TIMEOUT_MS);
   PITS_Get_App_SWID();

   while (thread_alive)
   {
      SOH_Alive(PITS_SOH_TIMEOUT_MS);

      message = SAL_Receive_Timeout(PITS_MSG_WAIT_TIMEOUT_MS);

      PITS_Message_Packet_Handler();
      PITS_Application_Manager();

      if (NULL != message)
      {
         switch (message->event_id)
         {
            case PITS_EVG_SHUTDOWN:
               thread_alive = false;
            break;
            case EVG_PITS_COMMAND:
               PITS_Message_Handler_Receive_Packet(&GM_Diag_Bearing_Bus, message->data, message->data_size);
            break;
            default:
               if (!process_message(message))
               {
                  for (event_index = 0; event_index < Num_Elems(pits_events)-1; event_index++)
                  {
                     if (pits_handler_function[event_index].event == message->event_id)
                     {
                        pits_handler_function[event_index].function(message->data, message->data_size);
                        break;
                     }
                  }
               }
             break;
         }
      }
   }
/*Thread cleanup*/
   pits_destroy_timers();
   SOH_Dormant();

   ok = SAL_Unsubscribe(pits_events, Num_Elems(pits_events));
   PBC_Ensure(ok, "SAL_Unsubscribe: error");

   PITS_Terminated();

   if(false == ok)
   {
      Tr_Warn("SAL_Unsubcribe Failed");
   }
   Tr_Info_Hi("VIP PITS Task Stopped");
}

/**
 * Decodes and processes incoming messages
 *
 * @param [in] message  Incoming message
 *
 *  If message actually received
 *    Update state machine
 *
 *    Handle requests for published data
 *    Handle other non-state related requests
 *
 */

bool_t process_message(const SAL_Message_T * message)
{
   uint8_t event_index = 0;
   bool_t status = false;
   if (message != NULL)
   {
      for (event_index = 0; event_index < Num_Elems(pits_private_events); event_index++)
      {
         if (pits_private_events[event_index].name == message->event_id)
         {
            if (pits_private_events[event_index].handler)
            {
               status = pits_private_events[event_index++].handler((SAL_Event_Id_T) message->event_id);
            }
         }
      }
   }
   return (status);
}

/*
 *  Accessor to get MODULE's thread id
 */
SAL_Thread_Id_T PITS_Get_Thread_Id(void)
{
   return (PITS_Thread_Id);
}


static void pits_create_timers(void)
{
   uint8_t event_index = 0;
   for (event_index = 0; event_index < Num_Elems(pits_private_events); event_index++)
   {
         if (pits_private_events[event_index].setup)
         {
            pits_private_events[event_index].setup();
         }
   }
}

static void pits_destroy_timers(void)
{
   uint8_t event_index = 0;
   for (event_index = 0; event_index < Num_Elems(pits_private_events); event_index++)
   {
         if (pits_private_events[event_index].destroy)
         {
            pits_private_events[event_index].destroy();  
         }
   }
}
/*---------------------------------------------------------------------------*
 * Helper Functions
 *---------------------------------------------------------------------------*/

/*===========================================================================*/
/*!
 * @file pits_manager.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 30-Jun-2014 Tim Wang
 * Change pits_create_timers and pits_destroy_timers function: create and destroy
 * all defined timers.
 * 
 * 23 Aug 2012 Miguel Garcia Rev24
 * Task kok_basa#115934 - Fix Pits Timers
 *
 * 16 Aug 2012 Oscar Vega Rev 23
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * - 16-Jul-2012  cz8yh3   Jorge Rodriguez
 *   - Use of system_threads.h is deprecated, instead of it xsal_thread_id.h shall 
 *     be used, the include has been changed according to that.
 *
 * 16-May-2012 Maheshkumar Rev 21
 * Incorporate system level SOH Timeout - bb_pits_xsal_2_0
 *
 * 21-Mar-2012 Oscar Vega Rev 20
 * Adding shutdown function for PITS.
 *
 * 21-Mar-2012 Darinka Lopez  Rev 19
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Change file to "pits_manager".
 * Fix suscribe list function prototype to "size_t"
 *
 * 27 Feb 2012 Miguel Garcia
 * Include bt events under Pits ICR is.
 *
 * 16 Jan 2012 Miguel Garcia
 * Include bt event under Pits ICR is.
 *
 * 01-Nov-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17394: Create general function for pits_manager (events)
 * Add X macro for suscribe events.
 *
 * 28-Oct-2011 Manuel Robledo  Rev 11
 * SCR kok_basa#16239: Implement message for Get Receiver Band and Frequency.
 * Implement PITS_Get_Current_Station_Info, PITS_Get_Tuner_Source_Type, PITS_Get_Tuner_Frequency
 * PITS_Get_Tuner_Quality and PITS_Get_Tuner_HD_Subchannel
 *
 * 22 Sep 2011 Miguel Garcia
 * Include Test screen events
 *
 * 22 Jun 2011 Miguel Garcia
 * Include apm terminated for avoiding segmentation faults
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 8
 *  Merged: Fix parallel versions
 *
 * 2-Oct-2009 David Mooar  Rev 9
 * SCR kok_aud#63052: Remove SAL_Is_Data_Request, and related code.
 *
 * - 15-Dec-2008 Yi Liu
 * + SCR 58578 - Run PITS unit test.
 *             - APM_Activated() not called.
 *
 * - 10-Dec-2008 Yi Liu
 * + SCR 58578 - Run PITS unit test.
 *             - APM_Activated() not called.
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 05-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-30  Larry Ong
 *    - Add functions to restart and stop the poll timer.
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-06-20  Larry Ong
 *    - Move XSAL Defines from pits_manager.c to pits_configuration.h.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2007-12-03  Larry Ong
 *    - Add DTC Test Execute Timeout timer
 *    - Integrate Changes from TCK:
 *       - 2007-11-23  Jaroslaw Saferna
 *          - Component power management implemented.
 *          - Send_Requested_Data() corrected to remove compiler warning.
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Add DTC messages
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-11-12  Larry Ong
 *    - Publish Session Closed message when session is closed.
 *
 * - 2007-11-09  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-10-22  Larry Ong
 *    - Fixed Compiler (ver 9.1.2) warning.
 *
 * - 2007-10-05  Larry Ong
 *    - Changed Task name from Module_Task to PITS_Task.
 *
 * - 2007-10-01  Jaroslaw Saferna
 *    - Module_Task() function defined as extern.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-14  Larry Ong
 *    - Renamed module as pits_manager.
 *    - Moved DESIP functions to pits_desip_handler.
 *    - Added XSAL publish message PITS_PPS_Session and PITS_PCS_Session.
 *
 * - 2007-06-02  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/

