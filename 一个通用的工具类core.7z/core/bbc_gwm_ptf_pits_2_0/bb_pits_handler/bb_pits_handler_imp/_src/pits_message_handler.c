/*===========================================================================*/
/**
 * @file pits_message_handler.c
 *
 * This module configure, send and receive messages on the bearing bus.
 *
 * %full_filespec:pits_message_handler.c~1:csrc:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:18 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module configure, send and receive messages on the bearing bus.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS - Product Integrated Test Strategy.
 *    - MSID - Message Set Identifier
 *    - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_message_handler.h"
#   include "pits_basic_services.h"

#   include "em.h"
#   include <string.h>
#   include "utilities.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID, 3);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_MIN_MESSAGE_SIZE     2

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static PITS_Bearing_Bus_T *const *busses;
static uint8_t num_busses;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static PITS_Bearing_Bus_T *get_bus(uint8_t bus_id);
static uint8_t build_packetization_byte(Packetization_Stage_T stage, uint8_t counter);
static bool_t build_tx_message(PITS_Bearing_Bus_T * bus, const PITS_Message_T * message);
static Packetization_Stage_T get_packetization_stage(uint8_t packetization_byte);
static uint8_t get_packetization_counter(uint8_t packetization_byte);
static void start_new_rx_message(PITS_Bearing_Bus_T * bus, const uint8_t * data, uint16_t length,
                                 Packetization_Stage_T new_stage);
static Done_Or_Not_Done_T try_to_send_one_packet(PITS_Bearing_Bus_T * bus);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Message_Handler_Send_Message
 *===========================================================================
 *
 * Initiates the transmission of a PITS message on the appropriate bus.
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Message_Handler_Send_Message(const PITS_Message_T * message)
{
   PITS_Bearing_Bus_T *bus;
   uint8_t bus_index;

   if (NULL == message)
   {
      return false;
   }
   if (PITS_BROADCAST == message->bus)
   {
      for (bus_index = 0; bus_index < num_busses; bus_index++)
      {
         build_tx_message(busses[bus_index], message);
      }
      /* DESIGN CONSIDERATION:  broadcast does not ensure delivery and always returns true! */
      return true;
   }
   else
   {
      bus = get_bus(message->bus);
      if (NULL == bus)
      {
         return false;
      }
      return build_tx_message(bus, message);
   }
}

/*===========================================================================*
 * FUNCTION: PITS_Message_Packet_Handler
 *===========================================================================
 *
 * Handles transmission of subsequent packets of a PITS message
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Message_Packet_Handler(void)
{
   uint8_t bus_index;
   PITS_Bearing_Bus_T *bus;
   Done_Or_Not_Done_T done = DONE;

   for (bus_index = 0; bus_index < num_busses; bus_index++)
   {
      bus = busses[bus_index];
      if (NOT_DONE == try_to_send_one_packet(bus))
      {
         done = NOT_DONE;
      }
   }
   return done;
}

/*===========================================================================*
 * FUNCTION: try_to_send_one_packet
 *===========================================================================
 *
 * Tries to send the next packet for the specified bus.
 *
 *===========================================================================*/
static Done_Or_Not_Done_T try_to_send_one_packet(PITS_Bearing_Bus_T * bus)
{
   uint8_t new_counter;
   Packetization_Stage_T stage;
   Done_Or_Not_Done_T done = DONE;
   uint16_t how_many_bytes_we_send_if_we_send_them_all;
   uint8_t *packet_pointer;
   if (bus->tx_state_machine.in_use)
   {
      how_many_bytes_we_send_if_we_send_them_all =
         (uint16_t) ((bus->tx_message.data_size - bus->tx_state_machine.buffer_position) + 1);
      packet_pointer = &(bus->tx_message.data[bus->tx_state_machine.buffer_position - 1]);
      new_counter = (uint8_t) ((bus->tx_state_machine.counter + 1) % 4);
      if (how_many_bytes_we_send_if_we_send_them_all > bus->max_packet_length)
      {
         /* this cannot be the last packet */
         done = NOT_DONE;
         if (1 == bus->tx_state_machine.buffer_position)
         {
            stage = STAGE_FIRST_OF_MULTIPLE;
         }
         else
         {
            stage = STAGE_MIDDLE_OF_MULTIPLE;
         }
         *packet_pointer = build_packetization_byte(stage, new_counter);
         if (bus->send_function(packet_pointer, bus->max_packet_length))
         {
            /* Packet send to bearing bus successfully, OK to move to next packet */
            bus->tx_state_machine.buffer_position += (uint16_t) (bus->max_packet_length - 1);
            bus->tx_state_machine.counter = new_counter;
         }
         else
         {
            /* retry case: leave state machine alone. We're already going to return NOT_DONE so there's nothing to do. */
         }
      }
      else
      {
         /* this is the last packet */
         if (1 == bus->tx_state_machine.buffer_position)
         {
            stage = STAGE_FIRST_OF_ONE;
         }
         else
         {
            stage = STAGE_LAST_OF_MULTIPLE;
         }
         *packet_pointer = build_packetization_byte(stage, new_counter);
         if (bus->send_function(packet_pointer, how_many_bytes_we_send_if_we_send_them_all))
         {
            /* Packet send to bearing bus successfully, OK to finish PITS message */
            bus->tx_state_machine.in_use = false;
         }
         else
         {
            /* retry case -- leave state machine alone.  Must return NOT_DONE to queue for retry */
            done = NOT_DONE;
         }
      }
   }
   return done;
}

/*===========================================================================*
 * FUNCTION: PITS_Message_Handler_Receive_Packet
 *===========================================================================
 *
 * Handles the reception of a single packet of a PITS message and places it
 * into a full PITS message. Passes on the full PITS message to the next layer 
 * when done.
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Message_Handler_Receive_Packet(PITS_Bearing_Bus_T * bus, const uint8_t * data, uint16_t length)
{

   Packetization_Stage_T new_stage;
   uint8_t new_counter;

   if (((NULL != data) && (NULL != bus)) && (!(data[0] & 0x0F)))
   {
      new_stage = get_packetization_stage(data[0]);
      new_counter = get_packetization_counter(data[0]);

      if (bus->rx_state_machine.in_use)
      {
         /* already in the middle of receiving a message */
         switch (new_stage)
         {
            case STAGE_FIRST_OF_ONE:
            case STAGE_FIRST_OF_MULTIPLE:
               (void)PITS_PBS_Error_Report("Packetization Error During Receive - First Packet");
               bus->rx_state_machine.in_use = false;
               break;

            case STAGE_MIDDLE_OF_MULTIPLE:
            case STAGE_LAST_OF_MULTIPLE:
               if (new_counter != (bus->rx_state_machine.counter + 1) % 4)
               {
                  (void)PITS_PBS_Error_Report("Packetization Error During Receive - Next Packet");
                  bus->rx_state_machine.in_use = false;
               }
               else
               {
                  memcpy(&(bus->rx_message.data[bus->rx_state_machine.buffer_position]), &(data[1]),
                         (size_t) (length - 1));
                  bus->rx_message.data_size += (uint16_t) (length - 1);
                  bus->rx_state_machine.buffer_position += (uint16_t) (length - 1);
                  bus->rx_state_machine.stage = new_stage;
                  bus->rx_state_machine.counter = new_counter;
                  if (STAGE_LAST_OF_MULTIPLE == new_stage)
                  {
                     PITS_Route_Receive_Message(&(bus->rx_message));
                     bus->rx_state_machine.in_use = false;
                  }
               }
               break;

            default:
               break;
         }
      }
      else
      {
         /* not already in the middle of receiving a message */
         switch (new_stage)
         {
            case STAGE_MIDDLE_OF_MULTIPLE:
            case STAGE_LAST_OF_MULTIPLE:
               /* report packetization error and reset state machine since existing depacketization is hosed */
               (void)PITS_PBS_Error_Report("Packetization Error During Receive - New Packet");
               bus->rx_state_machine.in_use = false;
               break;

            case STAGE_FIRST_OF_ONE:
            case STAGE_FIRST_OF_MULTIPLE:
               if ((0x00  == new_counter) && (PITS_MIN_MESSAGE_SIZE < length))
               {
                  start_new_rx_message(bus, data, length, new_stage);
                  if (STAGE_FIRST_OF_ONE == new_stage)
                  {
                     PITS_Route_Receive_Message(&(bus->rx_message));
                  }
               }
               else
               {
                  (void)PITS_PBS_Error_Report("Packetization Error During Receive - New Packet");
                  bus->rx_state_machine.in_use = false;
               }
               break;

            default:
               break;
         }
      }
   }
}

/*===========================================================================*
 * FUNCTION: PITS_Configure_Bearing_Busses
 *===========================================================================
 *
 * Retrieves the list of all registered bearing busses from the Configuration.
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Configure_Bearing_Busses(PITS_Bearing_Bus_T *const record[], uint8_t count)
{
   uint8_t local_index;
   for (local_index = 0; local_index < count; local_index++)
   {
/*    (*record)->bus_id = index; */
      record[local_index]->bus_id = local_index;
   }
   busses = record;
   num_busses = count;
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: get_bus
 *===========================================================================
 * @brief Gets the pointer to the bus specified by bus_id from the Configuration.
 *
 * @param [in] bus_id  This is the unique ID of the bus being retreived.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *	@returns A pointer to a bearing bus or NULL if no bearing bus with that ID exists.
 */
/*===========================================================================*/
static PITS_Bearing_Bus_T *get_bus(uint8_t bus_id)
{
   if (NULL == busses)
   {
      return NULL;
   }
   else
   {
      return busses[bus_id];
   }
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: build_packetization_byte
 *===========================================================================
 * @brief Builds a PITS packetization byte from a stage and counter.
 *
 * @param [in] stage  A PITS packetization stage.
 *
 * @pre
 *   stage must be between STAGE_FIRST_OF_ONE (0x00) and 
 *         STAGE_LAST_OF_MULTIPLE (0x03).
 *
 * @param [in] counter A PITS packet counter
 *
 * @pre
 *   counter must be between 0x00 and 0x03.
 *
 * @returns a packetization byte that contains the stage and counter.
 *
 * @see get_packetization_stage, get_packetization_counter
 *
 *===========================================================================*/
uint8_t build_packetization_byte(Packetization_Stage_T stage, uint8_t counter)
{
   return (uint8_t) (((((uint8_t) stage) & 3) << 6) | ((counter & 3) << 4));
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: build_tx_message
 *===========================================================================
 * @brief builds a flat message from a PITS Message and sends the first/only packet.
 *
 * @param [in] *bus  pointer to a bus to on which to transmit the PITS message.
 *
 * @param [in] *message	 pointer to a PITS message
 *
 * @returns
 *    - true : if message was successfully transmited
 *    - false : if message was not transmited
 */
/*===========================================================================*/
static bool_t build_tx_message(PITS_Bearing_Bus_T * bus, const PITS_Message_T * message)
{
   if ((NULL == bus) || (NULL == message))
   {
      return false;
   }
   if (bus->tx_state_machine.in_use)
   {
      return false;
   }
   if (message->data_size + 3 > bus->max_message_length)
   {
      return false;
   }
   bus->tx_message.data[1] = message->MSID;
   bus->tx_message.data[2] = message->MID;
   bus->tx_state_machine.buffer_position = 1;   /* points to next byte to send (one past packetization byte which is at zero) */
   bus->tx_state_machine.counter = 255; /* will increment to zero for first message */
   bus->tx_state_machine.in_use = true;
   memcpy(&(bus->tx_message.data[3]), message->data, (size_t) message->data_size);
   bus->tx_message.data_size = (uint16_t) (message->data_size + 3);
   /* Note that the return value here is ignored because the return value of this function is whether we succeeded */
   /* in queueing the message or not.  Whether the first packet went out already or not is irrelevant. */
   try_to_send_one_packet(bus);
   return true;
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: get_packetization_stage
 *===========================================================================
 * @brief Determines the packetization stage from a packetization byte.
 *
 * @param [in] packetization_byte PITS packetization byte 
 *
 * @returns a packetization stage value that was conatined in a packetization byte.
 *
 * @see get_packetization_counter, build_packetization_byte
 */
/*===========================================================================*/
static Packetization_Stage_T get_packetization_stage(uint8_t packetization_byte)
{
   return (Packetization_Stage_T) ((packetization_byte >> 6) & 3);
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: get_packetization_counter
 *===========================================================================
 * @brief Determines the packetization counter from a packetization byte.
 *
 * @param [in] packetization_byte  PITS packetization byte
 *
 * @returns a packetization counter that was contained in a packetization byte.
 *
 * @see get_packetization_stage, build_packetization_byte
 */
/*===========================================================================*/
static uint8_t get_packetization_counter(uint8_t packetization_byte)
{
   return (uint8_t) ((packetization_byte >> 4) & 3);
}

/*===========================================================================*/
/**
 *===========================================================================*\
 * FUNCTION: start_new_rx_message
 *===========================================================================
 * @brief Begins the construction of a new received PITS message.
 *
 * @param [in] bus  pointer to a bus on which the passed message was recieved.
 *
 * @pre
 *   bus must not equal NULL.
 *
 * @param [in] data  pointer to the data received on the bus.
 *
 * @pre
 *   data must not equal NULL.
 * 
 * @param [in] length  number of bytes received on bus in this message.
 *
 * @param [in] new_stage  the PITS packetization stage associated with this message.
 *                        This is used for error checking on subsequent packets.
 *
 */
/*===========================================================================*/
void start_new_rx_message(PITS_Bearing_Bus_T * bus, const uint8_t * data, uint16_t length,
                          Packetization_Stage_T new_stage)
{
/*   original block used #define for message_data_length */
/*   #define message_data_length (length - 3) */
   uint16_t message_data_length = (uint16_t) (length - 3);
   bus->rx_message.bus = bus->bus_id;

   /* Check for any data */
   if (message_data_length > 0)
   {
      memcpy(bus->rx_message.data, &(data[3]), (size_t) message_data_length);
   }
   bus->rx_message.data_size = message_data_length;
   bus->rx_message.MSID = data[1];
   bus->rx_message.MID = data[2];
   if (STAGE_FIRST_OF_MULTIPLE == new_stage)
   {
      bus->rx_state_machine.buffer_position = message_data_length;
      bus->rx_state_machine.in_use = true;
      bus->rx_state_machine.stage = new_stage;
      bus->rx_state_machine.counter = 0;
   }
}

/*===========================================================================*/
/*!
 * @file pits_message_handler.c
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 6
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 04-Jul-2012   Oscar Vega Rev 5
 * Task kok_basa#107238: When message of 3 bytes length is sent the main app crashes.
 *
 * 20-Jan-2012 Oscar Vega  Rev 4
 * SCR kok_basa#20799: Change PITS handler implementation.
 * Fix: Change implementationto validate stage and counter.
 *
 * - 2008-04-21  Larry Ong
 *    - PITS_Message_Handler_Receive_Packet stops message processing, but passes
 *      bad message to the application.
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-24  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-05-30  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-12  Mike Gerig/Kris Boultbee
 *    - Created initial file.
 */
/*===========================================================================*/
