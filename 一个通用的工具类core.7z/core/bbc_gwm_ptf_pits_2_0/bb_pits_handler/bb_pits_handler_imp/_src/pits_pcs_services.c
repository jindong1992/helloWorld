/*===========================================================================*/
/**
 * @file pits_pcs_services.c
 *
 * PITS Control Service Function Definitions
 *
 * %full_filespec:pits_pcs_services.c~1:csrc:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:41 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module defines the PITS Service Functions used in the VW3 program.
 *
 * @section ABBR ABBREVIATIONS:
 *   - HSM = Hierarchical State Machine
 *   - TMP = template
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "em.h"
#   include "pits_control_services.h"
#   include "pits_control_services_cfg.h"
#   include "pits_pcs_services.h"
#   include "pits_pcs_services_cbk.h"
#   include <string.h>
#   include "utilities.h"

EM_FILENUM(PITS_MODULE_ID_5, 3);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static Success_Or_Fail_T pits_pcs_param_audio_volume(const PITS_Message_T * message, uint8_t * txdata);
static Success_Or_Fail_T pits_pcs_param_audio_fade_balance(const PITS_Message_T * message, uint8_t * txdata);
static Success_Or_Fail_T pits_pcs_param_audio_eq(const PITS_Message_T * message, uint8_t * txdata);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * PITS Control Service Parameter Read/Write Routine Tables
 */


/*---------------------------------------------------------------------------*
 * X-Macro to define the Audio Parameter functions to be supported
 *---------------------------------------------------------------------------*/
#undef PARAM_AUDIO_INDEX
#define PARAM_AUDIO_INDEX(name, pid, function) {pid, function},

static const PITS_PCS_PAR_EID_T pcs_param_audio_messages[] = {
   PARAM_AUDIO_TABLE
};



/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * X-macro to define the Parameter Group IDs and Element IDs to be supported by the product
 *---------------------------------------------------------------------------*/
#undef PARAM_GID_INDEX
#define PARAM_GID_INDEX(gid, eid_table, size) {gid, eid_table, size},

const PITS_PCS_PAR_GID_T PCS_Param_Message_Sets[] = {
   PARAM_GID_TABLE
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/


/*===========================================================================*
 * FUNCTION: pits_pcs_param_audio_volume
 *===========================================================================*
 * @brief This function Read or Write Audio Parameter: Volume
 *
 * @param
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
static Success_Or_Fail_T pits_pcs_param_audio_volume(const PITS_Message_T * message, uint8_t * txdata)
{
   Success_Or_Fail_T status = SUCCESS;
   Audio_Detent_T audio_volume;

   switch (message->MID)        /* Parameter Read or Write? */
   {
      case MID_PCS_PARAMETER_READ_REQ:
         /* Read Volume */
         audio_volume =  Scale(PITS_AU_Get_Volume(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS),
                                               VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
         /* Build data portion of Report message */
         txdata[0] = 1;
         txdata[1] = (uint8_t)audio_volume;
         break;

      case MID_PCS_PARAMETER_WRITE_REQ:
         audio_volume = (Audio_Detent_T) Scale((message->data)[3], 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);

         /* Write Volume */
         PITS_AU_Set_Volume(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS, audio_volume);
         break;

      default:
         status = FAIL;
         break;
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: pits_pcs_param_audio_fade_balance
 *===========================================================================*
 * @brief This function Read or Write Audio Parameter: Fade & Balance
 *
 * @param
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
static Success_Or_Fail_T pits_pcs_param_audio_fade_balance(const PITS_Message_T * message, uint8_t * txdata)
{
   Success_Or_Fail_T status = SUCCESS;
   Audio_Detent_T audio_fade;
   Audio_Detent_T audio_balance;

   switch (message->MID)        /* Parameter Read or Write? */
   {
      case MID_PCS_PARAMETER_READ_REQ:
         /* Audio Fade & Balance Read */
         audio_balance = Scale(PITS_AU_Get_Balance(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS),
                                               BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);
         audio_fade =  Scale(PITS_AU_Get_Fade(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS),
                                               FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);

         /* Build data portion of Report message */
         txdata[0] = 2;
         txdata[1] = (uint8_t)audio_balance;
         txdata[2] = (uint8_t)audio_fade;
         break;

      case MID_PCS_PARAMETER_WRITE_REQ:
         audio_balance = (Audio_Detent_T) Scale(message->data[3], 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
         audio_fade = (Audio_Detent_T) Scale(message->data[4], 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);

         /* Audio Fade & Balance Write */
         PITS_AU_Set_Balance(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS, audio_balance);
         PITS_AU_Set_Fade(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS, audio_fade);
         break;

      default:
         status = FAIL;
         break;
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: pits_pcs_param_audio_eq
 *===========================================================================*
 * @brief This function Read or Write Audio Parameter: Equalizer
 *
 * @param
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
static Success_Or_Fail_T pits_pcs_param_audio_eq(const PITS_Message_T * message, uint8_t * txdata)
{
   Success_Or_Fail_T status = SUCCESS;
   Audio_Tone_T tone_settings;

   switch (message->MID)        /* Parameter Read or Write? */
   {
      case MID_PCS_PARAMETER_READ_REQ:
         tone_settings = PITS_AU_Get_All_Tone_Bands(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS);
         txdata[0] = 3;

         txdata[1] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_BASS_BAND],
                                            TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
         txdata[2] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_MID_BAND],
                                            TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
         txdata[3] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_TREBLE_BAND],
                                            TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);

         break;

      case MID_PCS_PARAMETER_WRITE_REQ:
         tone_settings.absolute_detent[AUDIO_BASS_BAND] =
             (Audio_Detent_T) Scale(message->data[3], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_MID_BAND] =
             (Audio_Detent_T) Scale(message->data[4], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
             (Audio_Detent_T) Scale(message->data[5], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         PITS_AU_Set_All_Tone_Bands(SYS_ZONE_MAIN, SYS_AUDIO_ENTERTAINMENT_BUS, tone_settings);
         break;


      default:
         status = FAIL;
         break;
   }
   return (status);
}


/*===========================================================================*
 * FUNCTION: PITS_PCS_Clear_Device_Control
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
void PITS_PCS_Clear_Device_Control(void)
{
   /* @todo: Add function to exit/clear Device Control Mode */
   PITS_PBS_Status_Report("PCS CLEAR DEVICE CONTROL:Need to implement");
}

/*===========================================================================*
 * FUNCTION: PITS_IIC_Read
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
Success_Or_Fail_T PITS_IIC_Read(const PITS_Message_T * message, uint8_t * txdata, bool_t *send_message, Done_Or_Not_Done_T *pits_status)
{
   Success_Or_Fail_T status = FAIL;
   IIC_Channel_T channel;       /* (message->data)[1] = channel # */
   uint16_t speed;              /* (message->data)[2-3] = bus speed, in KHz */
   uint8_t device;              /* (message->data)[4] = device address */
   uint8_t tries;               /* (message->data)[5] = iic control: retries, start, stop */
   uint32_t lock_timeout_msec;  /* (message->data)[6-9] = max time to wait for channel, in msec */
   uint32_t read_timeout_msec;  /* (message->data)[10-13] = max time to read data, in msec */
   size_t num_bytes;            /* (message->data)[14] = read data count */
   size_t sub_add_size;         /* (message->data)[15] = number of bytes to write (sub-address) */

   uint8_t data[IIC_NUM_MAX_BYTES];
   bool_t lock_status = false;
   bool_t write_status = false;
   bool_t read_status = false;

   memset(data, 0x00, IIC_NUM_MAX_BYTES);
   channel = (IIC_Channel_T) ((message->data)[1]);
   speed = Util_Get_Big_Endian_U16(&(message->data)[2]);
   device = (message->data)[4];
   tries = (message->data)[5];
   lock_timeout_msec = Util_Get_Big_Endian_U32(&(message->data)[6]);
   read_timeout_msec = Util_Get_Big_Endian_U32(&(message->data)[10]);
   num_bytes = (size_t) (message->data)[14];
   sub_add_size = (size_t) (message->data)[15];
   if (0 < sub_add_size)
   {
      memcpy(&data[0], &((message->data)[16]), sub_add_size);
   }

   if (channel >= NUMBER_IIC_CHANNELS)
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Channel");
   }
   else if ((speed < IIC_MIN_SPEED_KHZ) || (speed > IIC_MAX_SPEED_KHZ))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Speed");
   }
   else if ((tries < 1) || (tries > 15))
   {
      *pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Try Count");
   }
   else if ((lock_timeout_msec < IIC_MIN_TIMEOUT_MSEC) || (lock_timeout_msec > IIC_MAX_TIMEOUT_MSEC) ||
            (read_timeout_msec < IIC_MIN_TIMEOUT_MSEC) || (read_timeout_msec > IIC_MAX_TIMEOUT_MSEC))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Timeout");
   }
   else if ((num_bytes == 0) || (num_bytes > IIC_NUM_MAX_BYTES))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Byte Count");
   }
   else if (sub_add_size > 4)
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC READ REQUEST: Invalid IIC Sub Address Size");
   }
   else
   {
      do
      {
         lock_status = IIC_Lock(channel, speed, lock_timeout_msec);
         if (lock_status)
         {
            /* hook function to handle special IIC sequence - writing data to DICE IC */
            PITS_IIC_hook(channel, device, lock_timeout_msec);

            if (0 < sub_add_size)
            {
               write_status = IIC_Write(channel, device, (IIC_START), data, sub_add_size, read_timeout_msec);
            }
            else
            {
               write_status = true;
            }

            read_status = IIC_Read(channel, device, (IIC_START | IIC_STOP), data, num_bytes, read_timeout_msec);
            IIC_Unlock(channel);
         }
      }
      while ((--tries) && (!(lock_status && write_status && read_status)));

      status = (Success_Or_Fail_T)(lock_status && write_status && read_status);
      memcpy(&(txdata[0]), &(data[0]), num_bytes);      /* copy iic data read */
      *send_message = true;
      
   }
   return status;
}

/*===========================================================================*
 * FUNCTION: PITS_IIC_Write
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 *
 *===========================================================================*/
Success_Or_Fail_T PITS_IIC_Write(const PITS_Message_T * message, bool_t *send_message, Done_Or_Not_Done_T *pits_status)
{
   Success_Or_Fail_T status = FAIL;
                                /* (message->data)[0] = number of bytes in IIC Control parameters */
   IIC_Channel_T channel;       /* (message->data)[1] = channel # */
   uint16_t speed;              /* (message->data)[2-3] = bus speed, in KHz */
   uint8_t device;              /* (message->data)[4] = device address */
   uint8_t tries;               /* (message->data)[5] = iic control: retries, start, stop */
   uint32_t lock_timeout_msec;  /* (message->data)[6-9] = max time to wait for channel, in msec */
   uint32_t write_timeout_msec; /* (message->data)[10-13] = max time to write data, in msec */
   size_t num_bytes;            /* (message->data)[14] = write data count */
   uint8_t data[IIC_NUM_MAX_BYTES];     /* (message->data)[15...] = data bytes */

   bool_t lock_status = false;
   bool_t write_status = false;

   channel = (IIC_Channel_T) ((message->data)[1]);
   speed = Util_Get_Big_Endian_U16(&(message->data)[2]);
   device = (message->data)[4];
   tries = (uint8_t) max(((message->data)[5] & IIC_RETRY_MASK), 1);
   lock_timeout_msec = Util_Get_Big_Endian_U32(&(message->data)[6]);
   write_timeout_msec = Util_Get_Big_Endian_U32(&(message->data)[10]);
   num_bytes = (message->data)[14];
   memcpy(&(data[0]), &((message->data)[15]), num_bytes);

   if (channel >= NUMBER_IIC_CHANNELS)
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC WRITE REQUEST: Invalid IIC Channel");
   }
   else if ((speed < IIC_MIN_SPEED_KHZ) || (speed > IIC_MAX_SPEED_KHZ))
   {
      *pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PCS IIC WRITE REQUEST: Invalid IIC Speed");
   }
   else if ((tries < 1) || (tries > 15))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC WRITE REQUEST: Invalid IIC Try Count");
   }
   else if ((lock_timeout_msec < IIC_MIN_TIMEOUT_MSEC) || (lock_timeout_msec > IIC_MAX_TIMEOUT_MSEC) ||
            (write_timeout_msec < IIC_MIN_TIMEOUT_MSEC) || (write_timeout_msec > IIC_MAX_TIMEOUT_MSEC))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC WRITE REQUEST: Invalid IIC Timeout");
   }
   else if ((num_bytes == 0) || (num_bytes > IIC_NUM_MAX_BYTES))
   {
      *pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PCS IIC WRITE REQUEST: Invalid IIC Byte Count");
   }
   else
   {
      do
      {
         lock_status = IIC_Lock(channel, speed, lock_timeout_msec);
         if (lock_status)
         {
            /* hook function to handle special IIC sequence - writing data to DICE IC */
            PITS_IIC_hook(channel, device, lock_timeout_msec);

            write_status = IIC_Write(channel, device, (IIC_START | IIC_STOP), data, num_bytes, write_timeout_msec);
            IIC_Unlock(channel);
         }
      }
      while ((--tries) && (!(lock_status && write_status)));

      status = (Success_Or_Fail_T)(lock_status && write_status);
      *send_message = true;
   }
   return status;
}


/*===========================================================================*/
/*!
 * @file pits_pcs_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 9
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 21-Mar-2012 Darinka Lopez  Rev 8
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Remove _j2 in control services files too.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 28-Oct-2011 Darinka Lopez  Rev 6
 * SCR kok_basa#16494: Implement MSID(04h) - Control Services
 * Fix: Change control to use in ICR and SBX project.
 *
 * 20-Oct-2009 David Mooar  Rev 5
 * SCR kok_aud#63562: Move PITS Read SWID to Misc Services.
 *
 * - 2009-03-02  Yi Liu
 *    - task kok_aud#44086 - PITS services: Read A/D Port Status and test
 *    - SCR kok_aud#58963
 *
 * - 27-Feb-2009  Yi Liu
 *    - Added ability to read and write AP Software IDs.
 *
 * - 05-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-10  Larry Ong
 *    - Moved GID/EID  definitions to pits_control_services_cfg file.
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-10-09  Larry Ong
 *    - Stop search at the end of table of Correct Map ID with invalid address.
 *
 * - 2007-10-01  Larry Ong
 *    - Change pits services EM ID to PITS_MODULE_ID_5.
 *    - Fixed PITS_IIC_Read to work with sub address size of 0 to 4.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-09-27  Jaroslaw Saferna
 *    - Memory addresses for Persistent Storage added.
 *
 * - 2007-09-21  Jaroslaw Saferna
 *    - Fixed bug in PITS_IIC_Read() - now proper sub-address is provided
 *      to IIC_Write() function.
 *
 * - 2007-09-19  Jaroslaw Saferna
 *    - PITS_IIC_hook() function added in PITS_IIC_Read() and PITS_IIC_Write().
 *
 * - 2007-09-19  Jaroslaw Saferna
 *    - External functions for API callouts added
 *       - PITS_Get_Receiver_Band()
 *       - PITS_Get_Frequency()
 *       - PITS_Get_Signal_Strength()
 *       - PITS_Set_Receiver_Band()
 *       - PITS_Set_Frequency()
 *
 * - 2007-09-12  Jaroslaw Saferna
 *    - Function pits_pcs_param_tuner_band_frequency() updated with functions
 *      for reading and writing tuner band/frequency.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-01  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
