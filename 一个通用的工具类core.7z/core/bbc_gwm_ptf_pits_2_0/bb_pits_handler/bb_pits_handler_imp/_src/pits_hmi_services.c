/*===========================================================================*/
/**
 * @file pits_hmi_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_hmi_services.c~1:csrc:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:10 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "adaptor_database.h"
#include "disp_mngr.h"
#include "em.h"
#include "hmi_disp_db_acfg.h"
#include "hmi_disp_view_acfg_auto.h"
#include "pits_hmi_services.h"
#include "pits_hmi_services_cbk.h"
#include "pbc_trace.h"
#include "reuse.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "segger_widget_interface.h"




EM_FILENUM(PITS_MODULE_ID_5, 10);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define MEDIA_TYPE_CDROM 0x01;
#define MEDIA_TYPE_CDDA  0x02;
#define MP3_SRC 0x01;
#define WMA_SRC 0x02;

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/


/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static PITS_EVG_SESSION_T hmi_session_state;
static uint8_t hmi_tx_bus_id;   /* ID of the bearing bus on which to send response */
static PITS_Message_T hmi_message;      /* for construction of a pbs message to be transmitted */
static uint8_t hmi_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t hmi_session_timeout_sec;        /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T hmi_session_state;

static SAL_Timer_Id_T pits_hmi_session_timer_id;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_hmi_initialize(void);

static void pits_hmi_compose_message_header(uint8_t mid, uint8_t size);

/**View_Id_T HMI_Get_Current_View(void);**/
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_HMI_RX_INDEX

#define MID_HMI_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_hmi_rx_messages[] = {
   MID_HMI_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_HMI_TX_INDEX

#define MID_HMI_TX_INDEX(name, mid) (mid),

static const uint8_t pits_hmi_tx_messages[] = {
   MID_HMI_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_HMI_RX_INDEX
#define MSID_HMI_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_hmi_rx_message_sets[] = {
   MSID_HMI_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_HMI_TX_INDEX
#define MSID_HMI_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_hmi_tx_message_sets[] = {
   MSID_HMI_TX_TABLE
};

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_HMI_Services_Interface = {
   pits_hmi_initialize,
   pits_hmi_rx_message_sets,
   Num_Elems(pits_hmi_rx_message_sets),
   pits_hmi_tx_message_sets,
   Num_Elems(pits_hmi_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_tuner_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_hmi_initialize(void)
{
   hmi_tx_bus_id = 0;
   memset(&hmi_message, 0x00, sizeof(PITS_Message_T));
   memset(hmi_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   hmi_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   hmi_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that PBS Session is closed? */
}


bool_t PITS_HMI_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id,
            message->event_id, &hmi_session_state, sizeof(hmi_session_state));
   return (true);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_get_state_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] hmi_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] hmi_tx_data[1] = Session State (CLOSE, OPEN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_session_get_state_req(const PITS_Message_T *
                                                  message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      hmi_message.bus = hmi_tx_bus_id;
      hmi_message.data = hmi_tx_data;
      hmi_message.MSID = MSID_HMI_SERVICES;
      hmi_message.MID = MID_HMI_SESSION_STATE_RPT;
      /* Compose Message Data */
      hmi_tx_data[0] = (uint8_t) SUCCESS;
      hmi_tx_data[1] = (uint8_t) hmi_session_state;
      hmi_message.data_size = 2;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO SESSION GET REQUEST: Message Data Error");
      }
      else
      {
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

#if  1
/*===========================================================================*
 * FUNCTION: pits_audio_session_open_req
 *===========================================================================*
 * @brief Receive a Request to Open a Session
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Session State (CLOSE, OPEN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_session_open_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      hmi_message.bus = hmi_tx_bus_id;
      hmi_message.data = hmi_tx_data;
      hmi_message.MSID = MSID_HMI_SERVICES;
      hmi_message.MID = MID_HMI_SESSION_STATE_RPT;
      /* Compose Message Data */
      hmi_tx_data[0] = (uint8_t) FAIL;
      hmi_tx_data[1] = hmi_session_state;
      hmi_message.data_size = 2;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI SESSION OPEN REQUEST: Message Data Error");
      }
      else if (hmi_session_state == SESSION_OPEN)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI  SESSION OPEN REQUEST: Session Is Already Opened");
      }
      else
      {
         hmi_tx_data[0] = (uint8_t) SUCCESS;
         hmi_tx_data[1] = SESSION_OPEN;
         PITS_Set_HMI_Session(SESSION_OPEN);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_audio_session_close_req
 *===========================================================================*
 * @brief Receive a Request to close a Session.
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = Confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = State (OPEN, CLOSE)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_audio_session_close_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      hmi_message.bus = hmi_tx_bus_id;
      hmi_message.data = hmi_tx_data;
      hmi_message.MSID = MSID_HMI_SERVICES;
      hmi_message.MID = MID_HMI_SESSION_STATE_RPT;
      /* Compose Message Data */
      hmi_tx_data[0] = (uint8_t) FAIL;
      hmi_tx_data[1] = hmi_session_state;
      hmi_message.data_size = 2;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI SESSION CLOSE REQUEST: Message Data Error");
      }
      else if (hmi_session_state == SESSION_CLOSE)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI SESSION CLOSE REQUEST: Session Is Already Closed");
      }
      else
      {
         hmi_tx_data[0] = (uint8_t) SUCCESS;
         hmi_tx_data[1] = SESSION_CLOSE;
         PITS_Set_HMI_Session(SESSION_CLOSE);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

#endif


bool_t PITS_Set_HMI_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (hmi_session_state != session)    /* Session State change? */
   {
      hmi_session_state = session;      /* Set to new State */
      SAL_Publish(PITS_EVG_HMI_SESSION, &hmi_session_state, sizeof(hmi_session_state));        /* Publish new Session State */
      if (hmi_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_hmi_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_hmi_session_timer_id, hmi_session_timeout_sec,
                         false);
      }
      result = true;
   }
   return (result);

}



/**
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
static void pits_hmi_compose_message_header(uint8_t mid, uint8_t size)
{
   hmi_message.bus = hmi_tx_bus_id;
   hmi_message.data = hmi_tx_data;
   hmi_message.MSID = MSID_HMI_SERVICES;
   hmi_message.MID = mid;
   hmi_message.data_size = size;
   memset(hmi_tx_data, 0x00, size);
}






/*===========================================================================*
 * FUNCTION: pits_hmi_get_band_and_freq_req
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = Tuner Band
 * @param [out] tuner_tx_data[3] = Tuner Frequency
 *
 * @pre message->data_size = 4
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_band_and_freq_req(const PITS_Message_T *
                                                         message)
{

   Sys_Zone_T zone;
   char temp_freqValue[50];
   int freq_to_send;
   char *token;
   char *deci_freq;
   char *frc_freq;
   char search[2] = ".";
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_BAND_AND_FREQ_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         DB_Read_String(DB_FMMODEVIEW_FM_FREQUENCY, temp_freqValue, 40);
         token = strtok(temp_freqValue, search);
         printf("%s\n", token);
         deci_freq = token;
         token = strtok(NULL, search);
         printf("%s", token);
         frc_freq = token;
         strcat(deci_freq, frc_freq);
         freq_to_send = atoi(deci_freq);
         printf("\n%d", freq_to_send > 1000 ? freq_to_send : freq_to_send * 10);
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] =
               (uint8_t) DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND);
            hmi_tx_data[3] =
               (uint8_t) (freq_to_send >
                          1000 ? freq_to_send : freq_to_send * 10);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_hmi_get_HD_audio_status
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = Tuner Band
 * @param [out] tuner_tx_data[3] = HD audio status
 *
 * @pre message->data_size = 4
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_HD_audio_status_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_HD_AUDIO_AVAILABLE_REPORT, 5);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] =
               (uint8_t) DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND);
            if (ADAPTOR_BAND_FM ==
                DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND))
            {
               hmi_tx_data[3] =
                  (uint8_t) DB_Read_Boolean(DB_TUNER_FMHDGRAYICONVISIBLE);
            }
            else if (ADAPTOR_BAND_AM ==
                     DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND))
            {
               hmi_tx_data[3] =
                  (uint8_t) DB_Read_Boolean(DB_TUNER_AMHDGRAYICONVISIBLE);
            }
            else
            {
               /*do nothing */
            }
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_hmi_get_HD_available_status
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = Tuner Band
 * @param [out] tuner_tx_data[3] = HD icon visible status
 *
 * @pre message->data_size = 4
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_HD_available_status_req(const
                                                               PITS_Message_T *
                                                               message)
{

   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_HD_AVAILABLE_STATUS_REPORT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] =
               (uint8_t) DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND);
            if (ADAPTOR_BAND_FM ==
                DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND))
            {
               hmi_tx_data[3] =
                  (uint8_t) DB_Read_Boolean(DB_TUNER_FMHDICONVISIBLE);
            }
            else if (ADAPTOR_BAND_AM ==
                     DB_Read_Integer(DB_TUNER_ADAPTORREPORTEDBAND))
            {
               hmi_tx_data[3] =
                  (uint8_t) DB_Read_Boolean(DB_TUNER_AMHDICONVISIBLE);
            }
            else
            {
               /*do nothing */
            }
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_hmi_get_number_of_preset_pages
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = Number of favourite pages
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_number_of_fav_pages_req(const
                                                               PITS_Message_T *
                                                               message)
{

   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_TOTAL_PRESET_PAGE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = (uint8_t) DB_Read_Integer(DB_TUNER_NUMBERFAVPAGES);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_current_preset_page
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = Current preset page
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_current_fav_page_req(const PITS_Message_T
                                                            * message)
{

   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_CURRENT_PRESET_PAGE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = (uint8_t) DB_Read_Integer(DB_TUNER_CURRENTFAVPAGE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_current_highlighted_preset_number
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = zone
 * @param [out] tuner_tx_data[2] = highlighted preset numbers
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T
pits_hmi_get_current_highlighted_preset_number_req(const PITS_Message_T *
                                                   message)
{

   Sys_Zone_T zone;
   uint8_t count;
   uint8_t value = 0;
   uint8_t preset_selection[6];
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_HIGHLIGHTED_PRESET_NUMBER_REPORT,
                                      3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         preset_selection[0] = DB_Read_Boolean(DB_TUNER_PRESET1SELECTED);
         preset_selection[1] = DB_Read_Boolean(DB_TUNER_PRESET2SELECTED);
         preset_selection[2] = DB_Read_Boolean(DB_TUNER_PRESET3SELECTED);
         preset_selection[3] = DB_Read_Boolean(DB_TUNER_PRESET4SELECTED);
         preset_selection[4] = DB_Read_Boolean(DB_TUNER_PRESET5SELECTED);
         preset_selection[5] = DB_Read_Boolean(DB_TUNER_PRESET6SELECTED);
         for (count = 0; count <= 5; count++)
         {
            if (true == preset_selection[count])
            {
               value = value | (1 << count);
            }

         }
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = (uint8_t) value;
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}




/*===========================================================================*
 * FUNCTION: pits_hmi_get_XM_category
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Zone
 * @param [out] tuner_tx_data[2] = XM category number
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_XM_category_req(const PITS_Message_T *
                                                       message)
{

   Sys_Zone_T zone;
   char tempCategory_from_db[50];
   char tempCategory[50];
   uint8_t local_index;
   uint8_t value = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_XM_CATEGORY_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         DB_Read_String(DB_XMMODEVIEW_SELECTCATEGORY, tempCategory, 40);
         for (local_index = 0; local_index < 31; local_index++)
         {
            DB_Read_String((DB_ItemID_T) (DB_XM_CATEGORY_NAMES_00 + local_index),
                           tempCategory_from_db, 40);
            if (!strcmp(tempCategory, tempCategory_from_db))
            {
               value = local_index + 1;
            }
         }


         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = (uint8_t) value;
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_volume_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 *  @param [out] pbs_tx_data[2] = Audio Volume level
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_volume_req(const PITS_Message_T *
                                                  message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_VOLUME_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_VOLUME_POPUP_VOLUME_VALUE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}



/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = Audio fade level
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_fade_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_FADE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_AUDIOCONTROLVIEW_FADEVALUE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 *  @param [out] pbs_tx_data[2] = Audio balance level
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_balance_req(const PITS_Message_T *
                                                   message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_BALANCE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_AUDIOCONTROLVIEW_BALANCEVALUE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = ATC value
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_ATC_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_ATC_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_ATCVIEW_CURRENTSELECTION);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = Audio SCV level
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_SCV_req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_SCV_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            if (true == DB_Read_Boolean(DB_MENU_SCVOFFSELECTEDVISIBLE))
            {
               hmi_tx_data[2] = 0x00;

            }
            else if (true == DB_Read_Boolean(DB_MENU_SCVLOWSELECTEDVISIBLE))
            {
               hmi_tx_data[2] = 0x01;

            }
            else if (true == DB_Read_Boolean(DB_MENU_SCVMEDIUMSELECTEDVISIBLE))
            {
               hmi_tx_data[2] = 0x02;

            }
            else if (true == DB_Read_Boolean(DB_MENU_SCVHIGHSELECTEDVISIBLE))
            {
               hmi_tx_data[2] = 0x03;
            }
            else
            {
               /*do nothing */
            }

         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = tone values
 *
 * @pre message->data_size = 5
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_tone_settings_req(const PITS_Message_T *
                                                         message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_TONE_SETTINGS_REPORT, 5);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_AUDIOCONTROLVIEW_BASSVALUE);
            hmi_tx_data[3] = DB_Read_Integer(DB_AUDIOCONTROLVIEW_MIDVALUE);
            hmi_tx_data[4] = DB_Read_Integer(DB_AUDIOCONTROLVIEW_TREBLEVALUE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = primary source
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_primary_src_req(const PITS_Message_T *
                                                       message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_PRIMARY_SRC_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_SYSTEM_ADAPTORREPORTEDSOURCE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
 * @param [out] pbs_tx_data[2] = CD load type
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_CD_load_type_req(const PITS_Message_T *
                                                        message)
{
   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_CDLOAD_TYPE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            hmi_tx_data[2] = DB_Read_Integer(DB_MEDIA_CDLOADTYPE);
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_CD_media_type
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = zone
 * @param [out] tuner_tx_data[2] = CD media type
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_CD_media_type_req(const PITS_Message_T *
                                                         message)
{

   Sys_Zone_T zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_CD_MEDIA_TYPE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            if (DB_Read_Boolean(DB_MEDIA_MP3CDPRESENT))
            {
               hmi_tx_data[2] = (uint8_t) MEDIA_TYPE_CDROM;
            }
            else if (DB_Read_Boolean(DB_MEDIA_AUDIOCDPRESENT))
            {
               hmi_tx_data[2] = (uint8_t) MEDIA_TYPE_CDDA;
            }
            else
            {
               /*wrong cd media type */
            }
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_hmi_get_CD_file_type
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = zone
 * @param [out] tuner_tx_data[2] = CD file type
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_CD_file_type_req(const PITS_Message_T *
                                                        message)
{

   Sys_Zone_T zone;
   char tempString[35];
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_CD_FILE_TYPE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            DB_Read_String(DB_CDMP3MODEVIEW_CDFILETYPE, tempString, 30);
            if (!strcmp("MP3", tempString))
            {
               hmi_tx_data[2] = (uint8_t) MP3_SRC;
            }
            else if (!strcmp("WMA", tempString))
            {
               hmi_tx_data[2] = (uint8_t) WMA_SRC;
            }
            else
            {
               /*wrong usb file type */
            }
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}





/*===========================================================================*
 * FUNCTION: pits_hmi_get_USB_file_type
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = zone
 * @param [out] tuner_tx_data[2] = USB file type
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_hmi_get_USB_file_type_req(const PITS_Message_T *
                                                         message)
{

   Sys_Zone_T zone;
   char tempString[35];
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_USB_FILE_TYPE_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            DB_Read_String(DB_USBMODEVIEW_USBFILETYPE, tempString, 30);
            if (!strcmp("MP3", tempString))
            {
               hmi_tx_data[2] = (uint8_t) MP3_SRC;
            }
            else if (!strcmp("WMA", tempString))
            {
               hmi_tx_data[2] = (uint8_t) WMA_SRC;
            }
            else
            {
               /*wrong usb file type */
            }
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_hmi_get_clock_data
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = zone
 * @param [out] tuner_tx_data[2] = clock data
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_clock_data_req(const PITS_Message_T *
                                                      message)
{

   Sys_Zone_T zone;
   char tempClock[15];
   char tempMin[15];
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_CLOCK_DATA_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            if (DB_Read_Boolean(DB_SYSTEM_CLOCKMODE12))
            {
               hmi_tx_data[2] = (uint8_t) 0x01;
            }
            else
            {
               hmi_tx_data[2] = (uint8_t) 0x02;

            }
            DB_Read_String(DB_SYSTEM_TIME_HOURS, tempClock, 10);
            DB_Read_String(DB_SYSTEM_TIME_MINUTES, tempMin, 10);

            hmi_tx_data[3] = (uint8_t) atoi(tempClock);
            hmi_tx_data[4] = (uint8_t) atoi(tempMin);


         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_hmi_get_fade_req
 *===========================================================================*
 * @brief Receive a Request to Get the audio volume level.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = zone
  * @param [out] pbs_tx_data[2] = HMI view id
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_hmi_get_view_id_req(const PITS_Message_T *
                                                   message)
{
   Sys_Zone_T zone;
   View_Id_T view_id;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      hmi_tx_bus_id = message->bus;
      pits_hmi_compose_message_header(MID_HMI_VIEW_ID_REPORT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("HMI Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         hmi_tx_data[1] = zone;
         if (SYS_ZONE_MAIN == zone)
         {
            hmi_tx_data[0] = (uint8_t) SUCCESS;
            view_id = HMI_Get_Current_View();
            hmi_tx_data[2] = view_id;
         }
         else
         {
            hmi_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&hmi_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*/
/*!
 * @file pits_hmi_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 7
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 1-May-2012 Darinka Lopez  Rev 6
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 03-Ago-2010 Miguel Garcia
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 05 Mar2010 Natesh 
 * kok_basa : added PITS functions for tuner
 *
 * 04 Mar2010 Rashmi Alok
 * kok_basa : added PITS function for audio
 *
 *  Created initial file.
 */
/*===========================================================================*/
