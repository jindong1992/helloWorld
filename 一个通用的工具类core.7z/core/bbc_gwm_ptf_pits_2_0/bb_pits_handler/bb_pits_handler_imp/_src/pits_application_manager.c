/*===========================================================================*/
/**
 * @file pits_application_manager.c
 *
 * @brief This module is responsible for routing received messages to the appropriate application(s).
 *
 * %full_filespec:pits_application_manager.c~1:csrc:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by: vzm576 %
 * @date    %date_modified:Mon May 23 14:10:11 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module is responsible for routing received PITS messages to any and 
 *    all PITS application modules which implement the MSID/MID contained in
 *    the PITS message. In order to accomplish this task, this module will 
 *    search through all registered PITS application interfaces for a matching
 *    MSID/MID pair. For each match that is found, the message will be passed to
 *    the function provided by that PITS application interface.
 *
 *    This module is also responsible for allowing the state machine of each 
 *    PITS application to run. If a PITS application is unable to fully complete
 *    all necessary actions upon first receiving a message, the state machine for
 *    that PITS application will be placed into queue to be re-executed later. Once
 *    the PITS application has finished all necessary actions, it will be removed
 *    from the queue.
 *
 *    This module also handles transmission of PITS messages from a PITS application
 *    to the PITS Message Handler. <Future improvement> If the PITS message is 
 *    unable to be transmitted at this time for any reason, it will be placed into
 *    queue for a later attempt at transmission.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
/* Dependent "compile.cmd"                                                   */
/*===========================================================================*/

#   include "pits_application_manager.h"
#   include "pits_configuration.h"
#   include "pits_message_handler.h"

#   include "em.h"
#   include "ring_buffer.h"
#   include <string.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID, 2);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/** Structure containing the interface for every registered PITS application */
static PITS_Application_Interface_T **interfaces;

/** Variable that contains the number of registered PITS applications        */
static uint8_t num_interfaces;

/** Array used as a circular buffer for receive operations to be completed   */
static recv_func receive_function_queue[PITS_TASK_QUEUE_SIZE];

/** Ring buffer manager for receive_function_queue                           */
static Ring_Buf_Ctrl_T Active_Receive_State_Machines;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Send_Message
 *===========================================================================
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Send_Message(const PITS_Message_T * message)
{
   return (PITS_Message_Handler_Send_Message(message));
}

/*===========================================================================*
 * FUNCTION: PITS_Route_Receive_Message
 *===========================================================================
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Route_Receive_Message(PITS_Message_T * message)
{
   uint8_t interface_index;
   uint8_t MSID_index;
   uint8_t MID_index;
   uint8_t size;
   PITS_Message_T TX_Message;
   uint8_t TX_Data[PITS_MAX_MESSAGE_SIZE];
   PITS_Application_Interface_T *app_interface;
   const PITS_MSID_T *MSID;
   const PITS_MID_T *MID;


   if ( (PITS_Get_MSID(message->MSID))
                  &&(PITS_Get_MID(message->MSID, message->MID)))
   {
      /*MSID and MID exists continue with operation*/

      for (interface_index = 0; interface_index < num_interfaces; interface_index++)
      {
         app_interface = &(*interfaces[interface_index]);
         for (MSID_index = 0; MSID_index < app_interface->rx_message_set_count; MSID_index++)
         {
            /* Is this the MSID we're looking for? */
            MSID = &(app_interface->rx_message_sets[MSID_index]);
            if (MSID->MSID == message->MSID)
            {
               /* This is the correct MSID, look for matching MID */
               for (MID_index = 0; MID_index < MSID->message_count; MID_index++)
               {
                  MID = &(MSID->message_ids[MID_index]);
                  if (MID->MID == message->MID)
                  {
                     switch (MID->rx_state_machine(message))
                     {
                        case DONE:
                           /* do not queue for this interface because it is done */
                           break;
                        case NOT_DONE:
                           /* queue the function pointer for calling in the task */
                           receive_function_queue[Active_Receive_State_Machines.in] = (MID->rx_state_machine);
                           Ring_Buf_Add(&Active_Receive_State_Machines);   /* Handle return value */
                           break;
                        default:
                           (void)PITS_PBS_Error_Report("Unknown return value from ptr_msg->rx_state_machine");
                           break;
                     }
                     break;        /* MID found, stop search within this MSID. They are unique within an MSID. */
                  }
               }
               break;              /* MSID found, stop search within this interface. They are unique within an interface. */
            }
            /* allow continuation of loop to find ALL interfaces that implement this message. */
         }
      }
   }
   else
   {
      /*MSID or MID does not exist*/
      size = 3;
      TX_Message.bus = 0;
      TX_Message.data = TX_Data;
      TX_Message.data_size = size;
      memset(&TX_Data[0], 0x00, size);
      TX_Data[0] = (uint8_t) SUCCESS;
      TX_Data[1] = message->MSID;
      TX_Data[2] = message->MID;
      TX_Message.MSID = MSID_MISC_SERVICES;
      TX_Message.MID = 0x01;
      (void)PITS_Send_Message(&TX_Message);
   }
}

/*===========================================================================*
 * FUNCTION: PITS_Response_Command_No_Supported
 *===========================================================================
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Response_Command_No_Supported(const PITS_Message_T * message)
{
   uint8_t pit_get_mid;
   PITS_Message_T TX_Message;
   uint8_t TX_Data[PITS_MAX_MESSAGE_SIZE];
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pit_get_mid = message->MID;
      pit_get_mid++;

      TX_Message.bus = message->bus;
      TX_Message.data = TX_Data;
      TX_Message.MSID = message->MSID;
      TX_Message.MID = pit_get_mid;
      TX_Message.data_size = 1;
      memset(&TX_Data[0], 0x00, TX_Message.data_size);
   
      /* Compose Message Data */
      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message));
}

/*===========================================================================*
 * FUNCTION: PITS_Configure_Receive_Routing
 *===========================================================================
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
extern void PITS_Configure_Receive_Routing(PITS_Application_Interface_T * record[], uint8_t count)
{
   uint8_t interface_num = 0;

   /* Loop through all interfaces and initialize them */
   for (interface_num = 0; interface_num < count; interface_num++)
   {
/*      (*record)[interface_num].initialize(); */
      (record[interface_num])->initialize();
   }
   interfaces = record;
   num_interfaces = count;
   Ring_Buf_Init(&Active_Receive_State_Machines, PITS_TASK_QUEUE_SIZE);
}

/*===========================================================================*
 * FUNCTION: PITS_Application_Manager
 *===========================================================================
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Application_Manager(void)
{
   recv_func rx_state_machine;
   /* if the return value is DONE, then remove it from the stack/queue, otherwise keep it in the queue */
   /* be sure removal of DONE items and preservation of NOT done items does not screw up traversal */
   /* i.e. don't skip items, don't repeat items, and don't follow obsolete pointers */
   if (Ring_Buf_Is_Empty(&Active_Receive_State_Machines))
   {
      /* TODO:  eventually should return a value */
   }
   else
   {
      rx_state_machine = receive_function_queue[Active_Receive_State_Machines.out];
      Ring_Buf_Remove(&Active_Receive_State_Machines);
      if (NOT_DONE == rx_state_machine(NULL))
      {
         /* place function back in queue */
         receive_function_queue[Active_Receive_State_Machines.in] = rx_state_machine;
         Ring_Buf_Add(&Active_Receive_State_Machines);  /* Handle return value */
      }
   }
}

/*===========================================================================*/
/*!
 * @file pits_application_manager.c
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 6
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 13 Jan 2011 Miguel Garcia
 * Include Invalid Pits Mode 1A
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-06-02  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-08  Mike Gerig/Kris Boultbee 
 *    - Created initial file.
 */
/*===========================================================================*/
