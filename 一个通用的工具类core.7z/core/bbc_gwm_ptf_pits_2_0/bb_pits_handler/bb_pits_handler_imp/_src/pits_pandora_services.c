/*===========================================================================*/
/**
 * @file pits_pandora_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_pandora_services.c~1:csrc:ctc_ec#21 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:38 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_pandora_services.h"
#include "pits_pandora_services_cbk.h"
#include "reuse.h"
#include <string.h>
#include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 28);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

typedef enum PITS_Pandora_Apple_Auth_Process_Tag
{
   PITS_APPLE_AUTH_GET_STATUS,
   PITS_APPLE_AUTH_BEGIN_TEST,
   PITS_APPLE_AUTH_ABORT_TEST,
} PITS_Pandora_Apple_Auth_Process_T;

typedef enum PITS_Pandora_Apple_Auth_Status_Tag
{
   PITS_AUTHENTICATION_NOT_STARTED,
   PITS_AUTHENTICATION_IN_PROCESS,
   PITS_AUTHENTICATION_FAILED,
   PITS_AUTHENTICATION_PASS,
} PITS_Pandora_Apple_Auth_Status_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_pandora_initialize(void);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PANDORA_RX_INDEX

#define MID_PANDORA_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_pandora_rx_messages[] = {
   MID_PANDORA_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PANDORA_TX_INDEX

#define MID_PANDORA_TX_INDEX(name, mid) (mid),

static const uint8_t pits_pandora_tx_messages[] = {
   MID_PANDORA_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PANDORA_RX_INDEX
#define MSID_PANDORA_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_pandora_rx_message_sets[] = {
   MSID_PANDORA_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PANDORA_TX_INDEX
#define MSID_PANDORA_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_pandora_tx_message_sets[] = {
   MSID_PANDORA_TX_TABLE
};

static uint8_t pandora_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T  pandora_message;      /* for construction of a  Pandora service message to be transmitted */

static uint8_t pandora_tx_data[PITS_MAX_MESSAGE_SIZE];

static PITS_Pandora_Apple_Auth_Status_T pits_authentication_status = PITS_AUTHENTICATION_NOT_STARTED;
static bool_t  pits_authentication_result = false;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Pandora_Services_Interface = {
   pits_pandora_initialize,
   pits_pandora_rx_message_sets,
   Num_Elems(pits_pandora_rx_message_sets),
   pits_pandora_tx_message_sets,
   Num_Elems(pits_pandora_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_pandora_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_pandora_initialize(void)
{
   pandora_tx_bus_id = 0;
   memset(&pandora_message, 0x00, sizeof(PITS_Message_T));
   memset(pandora_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

/*===========================================================================*
 * FUNCTION: pits_pandora_compose_message_header
 *===========================================================================*
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
/*===========================================================================*/
static void pits_pandora_compose_message_header(uint8_t mid, uint8_t size)
{
   pandora_message.bus  = pandora_tx_bus_id;
   pandora_message.data = pandora_tx_data;
   pandora_message.MSID = MSID_PANDORA_SERVICES;
   pandora_message.MID  = mid;
   pandora_message.data_size = size;
   memset(pandora_tx_data, 0x00, size);

}

/*===========================================================================*
 * FUNCTION: Pits_Pandora_Apple_Authentication_Req
 *===========================================================================*
 * @brief Receive a Request for Apple Authentication
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - n] = md5 information
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T Pits_Pandora_Apple_Authentication_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Compose Message Header */
      pandora_tx_bus_id    = message->bus;
      pits_pandora_compose_message_header(MID_PANDORA_APPLE_AUTHENTICATION_RPT, 2);

      /* Compose Message Data */
      pandora_tx_data[0] = (uint8_t) FAIL;
      if (0x01 != message->data_size)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Pandora Apple Authentication Request: Message Data Error");
      }
      else
      {
         pandora_tx_data[0] = (uint8_t) SUCCESS;
         switch(message->data[0])
         {
            case PITS_APPLE_AUTH_GET_STATUS:
            {   
               if (pits_authentication_status == PITS_AUTHENTICATION_IN_PROCESS)
               {
                  if (pits_authentication_result)
                  {
                     pits_authentication_status = PITS_AUTHENTICATION_PASS;
                  }
                  else
                  {
                     pits_authentication_status = PITS_AUTHENTICATION_FAILED;
                  }
               }
               pandora_tx_data[1] = pits_authentication_status;
               break;
            }
            case PITS_APPLE_AUTH_BEGIN_TEST:
            {   
               pits_authentication_result = DAG_Apple_ACP_Self_Test();
               pits_authentication_status = PITS_AUTHENTICATION_IN_PROCESS;
               pandora_tx_data[1] = pits_authentication_status;
               break;
            }
            case PITS_APPLE_AUTH_ABORT_TEST:
            {
               pits_authentication_status = PITS_AUTHENTICATION_NOT_STARTED;
               pandora_tx_data[1] = PITS_AUTHENTICATION_FAILED;
               break;
            }
            default:
            {
               pandora_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
               break;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pandora_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*/
/*!
 * @file pits_pandora_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 30 0ct 2012 Miguel Garcia Rev 4
 * Task kok_basa#126309. Remove unused session timeout functions
 *
 *  06-Sep-2012 Darinka L�pez Rev 3
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 *   30-May-2012 Mario Castro  Rev 2
 *   Task kok_basa#100068: Implement Authentication Pandora MID pits 2_0
 *
 *   28-May-2012 Mario Castro  Rev 1
 *   Task kok_basa#98503: Create Pandora Services Handler
 *   Initial version.
 *
 */
/*===========================================================================*/
