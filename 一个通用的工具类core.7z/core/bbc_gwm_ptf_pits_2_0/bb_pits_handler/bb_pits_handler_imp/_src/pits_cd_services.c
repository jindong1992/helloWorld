/*===========================================================================*/
/**
 * @file pits_cd_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_cd_services.c~1:csrc:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:35 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_cd_services.h"
#include "pits_cd_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 21);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MAX_CD_ELAPSED_TIME_SECONDS 5999

#define PITS_NEXT   01
#define PITS_PREV   02
#define PITS_GO_TO_POSITION   03
#define PITS_DEV_NOT_PRESENT   0xFF
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

typedef enum PITS_CD_Mech_Status_Tag
{
   PITS_CD_MECH_UNKNOWN = 0x00,
   PITS_CD_MECH_EMPTY,
   PITS_CD_MECH_IN_RELOAD,
   PITS_CD_MECH_INSERTING,
   PITS_CD_MECH_LOADED,
   PITS_CD_MECH_EJECTING,
   PITS_CD_MECH_BLOCKED,
   PITS_CD_MECH_ERROR,
   PITS_CD_MECH_INIT,
   PITS_CD_MECH_DISC_INIT,
   PITS_CD_MECH_STOP,  
   PITS_CD_MECH_PLAY,                   
} PITS_CD_Mech_Status_T;

typedef enum PITS_DVD_Mech_Status_Tag
{
   PITS_DVD_MECH_EMPTY = 0x00,
   PITS_DVD_MECH_PAUSE,
   PITS_DVD_MECH_PLAY,
} PITS_DVD_Mech_Status_T;

typedef enum PITS_CD_Media_Status_Tag
{
   PITS_CD_MEDIA_UNKNOWN = 0x00,
   PITS_CD_MEDIA_NO_MEDIA,
   PITS_CD_MEDIA_EJECTED,
   PITS_CD_MEDIA_INSERTING,
   PITS_CD_MEDIA_INSERTED,
   PITS_CD_MEDIA_EJECTING,
   PITS_CD_MEDIA_BLOCKED,
   PITS_CD_MEDIA_AUTO_RELOADING,
   PITS_CD_MEDIA_USER_RELOADING,
   PITS_CD_MEDIA_EJECT_ERROR,
   PITS_CD_MEDIA_LOAD_ERROR,  
} PITS_CD_Media_Status_T;

typedef enum PITS_DVD_Media_Status_Tag
{
   PITS_DVD_MEDIA_DEFAULT     = 0x00,
} PITS_DVD_Media_Status_T;

typedef enum PITS_CD_Playback_Status_Tag
{
   PITS_CD_PLBK_UNKNOWN = 0x00,
   PITS_CD_PLBK_STOP,
   PITS_CD_PLBK_PLAY,
   PITS_CD_PLBK_PAUSE,
   PITS_CD_PLBK_FAST_FWD,
   PITS_CD_PLBK_FAST_REV,
   PITS_CD_PLBK_SCAN,
   PITS_CD_PLBK_SEEK,
   PITS_CD_PLBK_BUILDING_DB,
   PITS_CD_PLBK_ERROR,
} PITS_CD_Playback_Status_T;

typedef enum PITS_DVD_Playback_Status_Tag
{
   PITS_DVD_PLBK_DEFAULT     = 0x00,
} PITS_DVD_Playback_Status_T;


typedef struct Band_Translation_Tag
{
   uint8_t  plybk_status;
   uint8_t  pits_status;
} PITS_Status_Translation_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_CD_initialize(void);
static void pits_CD_compose_message_header(uint8_t mid, uint8_t size);

static bool_t pits_cd_map_status(PITS_CD_DVD_Status_T cd_status, PITS_CD_DVD_Status_T *pits_cd_status);
static bool_t pits_dvd_map_status(PITS_CD_DVD_Status_T dvd_status, PITS_CD_DVD_Status_T *pits_dvd_status);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_CD_RX_INDEX
#define MID_CD_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_CD_rx_messages[] = {
   MID_CD_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_CD_TX_INDEX
#define MID_CD_TX_INDEX(name, mid) (mid),

static const uint8_t pits_CD_tx_messages[] = {
   MID_CD_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_CD_RX_INDEX
#define MSID_CD_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_CD_rx_message_sets[] = {
   MSID_CD_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_CD_TX_INDEX
#define MSID_CD_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_CD_tx_message_sets[] = {
   MSID_CD_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the cd/dvd status translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_CD_Mech_Translation[] =
{
   PITS_CD_MECH_TABLE
};

#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_DVD_Mech_Translation[] =
{
   PITS_DVD_MECH_TABLE
};

#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_CD_Media_Translation[] =
{
   PITS_CD_MEDIA_TABLE
};

#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_DVD_Media_Translation[] =
{
   PITS_DVD_MEDIA_TABLE
};

#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_CD_Plbk_Translation[] =
{
   PITS_CD_PLBK_TABLE
};

#undef PITS_CD_DVD_STATUS
#define PITS_CD_DVD_STATUS(cd_dvd_status, pits_status) {cd_dvd_status, pits_status},

static const PITS_Status_Translation_T Pits_DVD_Plbk_Translation[] =
{
   PITS_DVD_PLBK_TABLE
};


static uint8_t CD_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T CD_message;      /* for construction of a CD service message to be transmitted */

static uint8_t CD_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t CD_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T CD_session_state;

/**
 * Stores Timer ID for CD Services Session
 */
static SAL_Timer_Id_T pits_CD_session_timer_id;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_CD_Services_Interface = {
   pits_CD_initialize,
   pits_CD_rx_message_sets,
   Num_Elems(pits_CD_rx_message_sets),
   pits_CD_tx_message_sets,
   Num_Elems(pits_CD_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_CD_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_CD_initialize(void)
{
   CD_tx_bus_id = 0;
   memset(&CD_message, 0x00, sizeof(PITS_Message_T));
   memset(CD_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   CD_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   CD_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that CD Session is closed? */
}

/*===========================================================================*
 * FUNCTION: pits_cd_map_status
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *    TRURE = Data found correctly
 *    FALSE = Data found incorrectly
 *
 * @param [in] cd_status = CD status
 * @param [in] pits_cd_status = translation on pits_cd_status
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
 bool_t pits_cd_map_status(PITS_CD_DVD_Status_T cd_status, PITS_CD_DVD_Status_T *pits_cd_status)
{
   uint8_t i;
   bool_t pits_mech_status_found = false;
   bool_t pits_media_status_found = false;
   bool_t pits_plbk_status_found = false;   

   for (i = 0; i < Num_Elems(Pits_CD_Mech_Translation); i++)
   {
      if (Pits_CD_Mech_Translation[i].plybk_status == cd_status.mech)
      {
         pits_cd_status->mech = Pits_CD_Mech_Translation[i].pits_status;
         pits_mech_status_found = true;
         break;
      }
   }
   for (i = 0; i < Num_Elems(Pits_CD_Media_Translation); i++)
   {
      if (Pits_CD_Media_Translation[i].plybk_status == cd_status.media)
      {
         pits_cd_status->media = Pits_CD_Media_Translation[i].pits_status;
         pits_media_status_found = true;
         break;
      }
   }

   for (i = 0; i < Num_Elems(Pits_CD_Plbk_Translation); i++)
   {
      if (Pits_CD_Plbk_Translation[i].plybk_status == cd_status.playback)
      {
         pits_cd_status->playback = Pits_CD_Plbk_Translation[i].pits_status;
         pits_plbk_status_found = true;
         break;
      }
   }

   return(pits_mech_status_found & pits_media_status_found & pits_plbk_status_found);
}

/*===========================================================================*
 * FUNCTION: pits_dvd_map_status
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *    TRURE = Data found correctly
 *    FALSE = Data found incorrectly
 *
 * @param [in] dvd_status = DVD status
 * @param [in] pits_dvd_status = translation on pits_dvd_status
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/

bool_t pits_dvd_map_status(PITS_CD_DVD_Status_T dvd_status, PITS_CD_DVD_Status_T *pits_dvd_status)
{
   uint8_t i;
   bool_t pits_mech_status_found = false;
   bool_t pits_media_status_found = false;
   bool_t pits_plbk_status_found = false;   

   for (i = 0; i < Num_Elems(Pits_DVD_Mech_Translation); i++)
   {
      if (Pits_DVD_Mech_Translation[i].plybk_status == dvd_status.mech)
      {
         pits_dvd_status->mech = Pits_DVD_Mech_Translation[i].pits_status;
         pits_mech_status_found = true;
         break;
      }
   }
   for (i = 0; i < Num_Elems(Pits_DVD_Media_Translation); i++)
   {
      if (Pits_DVD_Media_Translation[i].plybk_status == dvd_status.media)
      {
         pits_dvd_status->media = Pits_DVD_Media_Translation[i].pits_status;
         pits_media_status_found = true;
         break;
      }
   }

   for (i = 0; i < Num_Elems(Pits_DVD_Plbk_Translation); i++)
   {
      if (Pits_DVD_Plbk_Translation[i].plybk_status == dvd_status.playback)
      {
         pits_dvd_status->playback = Pits_DVD_Plbk_Translation[i].pits_status;
         pits_plbk_status_found = true;
         break;
      }
   }

   return(pits_mech_status_found & pits_media_status_found & pits_plbk_status_found);
}

/*===========================================================================*
 * FUNCTION: pits_CD_compose_message_header
 *===========================================================================*
 * @brief This function compose the buffer structure
 *
 * @returns
 * @param [in] mid = Response MID
 * @param [in] size = cd tx data size
 *
 * @pre
 *
 * @post
 *
 * This function is executed in each pit response */
/*===========================================================================*/

static void pits_CD_compose_message_header(uint8_t mid, uint8_t size)
{
   CD_message.bus = CD_tx_bus_id;
   CD_message.data = CD_tx_data;
   CD_message.MSID = MSID_CD_SERVICES;
   CD_message.MID = mid;
   CD_message.data_size = size;
   memset(CD_tx_data, 0x00, size);
}

/*===========================================================================*
 * FUNCTION: pits_CD_get_playback_status_req
 *===========================================================================*
 * @brief Receive a Request to get the CD status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = CD Mech Status
 * @param [out] CD_tx_data[2] = CD Media Status
 * @param [out] CD_tx_data[3] = CD Playback Status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_CD_get_playback_status_req(const PITS_Message_T * message)
{
   PITS_CD_DVD_Status_T  cd_dvd_status;
   PITS_CD_DVD_Status_T  pits_cd_dvd_status = {0};
   bool_t  pits_cd_status_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_PLAYBACK_STATUS_RPT, 4);

      CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (PITS_CD_DEVICE == PITS_Device_Type())
         {
            PITS_Get_CD_Status(&cd_dvd_status);           
            pits_cd_status_found = pits_cd_map_status(cd_dvd_status, &pits_cd_dvd_status);
            
            if (pits_cd_status_found)
            {
               CD_tx_data[0] = (uint8_t) SUCCESS;            
               CD_tx_data[1] = pits_cd_dvd_status.mech;        /*Mechanical Status*/
               CD_tx_data[2] = pits_cd_dvd_status.media;       /*Media Status*/
               CD_tx_data[3] = pits_cd_dvd_status.playback;    /*Play back status*/
            }
         }
         else if (PITS_DVD_DEVICE == PITS_Device_Type())
         {
            PITS_Get_DVD_Status(&cd_dvd_status);
            pits_cd_status_found = pits_dvd_map_status(cd_dvd_status, &pits_cd_dvd_status);
            
            if (pits_cd_status_found)
            {
               CD_tx_data[0] = (uint8_t) SUCCESS;            
               CD_tx_data[1] = pits_cd_dvd_status.mech;        /*Mechanical Status*/
               CD_tx_data[2] = pits_cd_dvd_status.media;       /*Media Status*/
               CD_tx_data[3] = pits_cd_dvd_status.playback;    /*Play back status*/
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_CD_get_position_req
 *===========================================================================*
 * @brief Receive a Request to get the CD position
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Device:
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = Disc Number
 * @param [out] CD_tx_data[2] = Track Number
 * @param [out] CD_tx_data[3] = Elapsed Time, Minutes, BCD
 * @param [out] CD_tx_data[4] = Elapsed Time, Seconds, BCD
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_CD_get_position_req(const PITS_Message_T * message)
{
   PITS_CD_DVD_Media_Pos_T  cd_dvd_positions;
   PITS_DEVICE_TYPES_T   mech_data;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_POSITION_RPT, 7);

      CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("CD Request: Message Data Error");
      }
      else
      {
         mech_data = (PITS_DEVICE_TYPES_T) message->data[0];
         if (PITS_CD_DEVICE == mech_data)
         {
             PITS_Get_CD_Media_Position(&cd_dvd_positions);

             CD_tx_data[0] = (uint8_t) SUCCESS;             
             CD_tx_data[1] = cd_dvd_positions.disc_number;
             CD_tx_data[2] = cd_dvd_positions.disc_type;
             CD_tx_data[3] = (uint8_t)((cd_dvd_positions.track_title)>>8);
             CD_tx_data[4] = (uint8_t)(cd_dvd_positions.track_title);
             CD_tx_data[5] = (uint8_t)((cd_dvd_positions.chapter)>>8);
             CD_tx_data[6] = (uint8_t)(cd_dvd_positions.chapter);
         }
         else if (PITS_DVD_DEVICE == mech_data)
         {
             PITS_Get_DVD_Media_Position(&cd_dvd_positions);

             CD_tx_data[0] = (uint8_t) SUCCESS;             
             CD_tx_data[1] = cd_dvd_positions.disc_number;
             CD_tx_data[2] = cd_dvd_positions.disc_type;
             CD_tx_data[3] = (uint8_t)((cd_dvd_positions.track_title)>>8);
             CD_tx_data[4] = (uint8_t)(cd_dvd_positions.track_title);
             CD_tx_data[5] = (uint8_t)((cd_dvd_positions.chapter)>>8);
             CD_tx_data[6] = (uint8_t)(cd_dvd_positions.chapter);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_CD_set_position_req
 *===========================================================================*
 * @brief Receive a Request to set the CD position
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Device:
 * @param [in] (message->data)[1] = Track Next or Previous:
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = Disc Number
 * @param [out] CD_tx_data[2] = Track Number
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_CD_set_position_req(const PITS_Message_T * message)
{
   PITS_CD_DVD_Media_Pos_T  cd_dvd_positions = {0, 0, 0, 0, 0, 0, 0};
   PITS_DEVICE_TYPES_T   mech_data;
   uint16_t  new_track;
   uint16_t  new_chapter;
   bool_t    pits_enable_set = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_POSITION_SET_ACK, 7);

      CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("CD Request: Message Data Error");
      }
      else if(message->data[0] < PITS_MAX_NUM_DEVICE)
      {
         mech_data = (PITS_DEVICE_TYPES_T) message->data[0];

         if (PITS_CD_DEVICE == mech_data)
         {
             PITS_Get_CD_Media_Position(&cd_dvd_positions);
             if ((cd_dvd_positions.disc_number == 0) || (cd_dvd_positions.disc_number == PITS_DEV_NOT_PRESENT))
             {
                CD_tx_data[0] = (uint8_t) FAIL;
                pits_enable_set = false;
             }
             else
             {
                if (PITS_Valid_CD_Type(cd_dvd_positions.disc_type))
                {
                   CD_tx_data[0] = (uint8_t) SUCCESS;
                   pits_enable_set = true;
                }
                else
                {
                   CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                   pits_enable_set = false;
                }
             }
         }
         else if (PITS_DVD_DEVICE == mech_data)
         {
             PITS_Get_DVD_Media_Position(&cd_dvd_positions);
             if ((cd_dvd_positions.disc_number == 0) || (cd_dvd_positions.disc_number == PITS_DEV_NOT_PRESENT))
             {
                CD_tx_data[0] = (uint8_t) FAIL;
                pits_enable_set = false;
             }
             else
             {
                if (PITS_Valid_DVD_Type(cd_dvd_positions.disc_type))
                {
                   CD_tx_data[0] = (uint8_t) SUCCESS;
                   pits_enable_set = true;
                }
                else
                {
                   CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                   pits_enable_set = false;
                }
             }
         }

         CD_tx_data[1] = cd_dvd_positions.disc_number;
         CD_tx_data[2] = cd_dvd_positions.disc_type;

         if (pits_enable_set)
         {
            switch (message->data[1])
            {
               case PITS_NEXT:
               {
                  new_track = cd_dvd_positions.track_title;
                  new_track++;
                  PITS_Set_Next_Track(mech_data, new_track);
                  /* TODO
                  if (new_track > cd_dvd_positions.total_tracks)
                  {
                    new_track = 1;
                  }
                  */
                  CD_tx_data[3] = (uint8_t)((new_track)>>8);
                  CD_tx_data[4] = (uint8_t)(new_track);
                  CD_tx_data[5] = message->data[4];
                  CD_tx_data[6] = message->data[5];
                  break;
               }
               case PITS_PREV:
               {
                  new_track = cd_dvd_positions.track_title;
                  new_track--;
                  PITS_Set_Prev_Track(mech_data, new_track);
                  /* TODO
                  if (new_track < 1)
                  {new_chapter
                    new_track = cd_dvd_positions.total_tracks;
                  } */
                  CD_tx_data[3] = (uint8_t)((new_track)>>8);
                  CD_tx_data[4] = (uint8_t)(new_track);
                  CD_tx_data[5] = message->data[4];
                  CD_tx_data[6] = message->data[5];
                  break;
               }
               case PITS_GO_TO_POSITION:
               {
                  CD_tx_data[3] = message->data[2];
                  CD_tx_data[4] = message->data[3];
                  CD_tx_data[5] = message->data[4];
                  CD_tx_data[6] = message->data[5];
                  new_track = message->data[2];
                  new_track = ((new_track << 8) & 0xFF00) + message->data[3];
                  new_chapter = message->data[4];
                  new_chapter = ((new_chapter << 8) & 0xFF00) + message->data[5];
                  if (cd_dvd_positions.total_tracks >= new_track)
                  {
                     PITS_Set_Go_To_Track (mech_data, new_track, new_chapter);
                  }
                  else
                  {
                     CD_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
                  }
                  break;
               }
               default:
                  CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                  break; 
               }
           }                  
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
       }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_CD_eject_req
 *===========================================================================*
 * @brief Receive a Request to eject the CD
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Device:
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = Status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_CD_eject_req(const PITS_Message_T * message)
{
   PITS_CD_DVD_Status_T  cd_dvd_status;
   PITS_CD_DVD_Status_T  pits_cd_dvd_status = {0};
   PITS_DEVICE_TYPES_T   mech_data;
   bool_t  pits_cd_status_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_EJECT_ACK, 2);

      CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("CD Request: Message Data Error");
      }
      else
      {
         mech_data = (PITS_DEVICE_TYPES_T) message->data[0];
         if (PITS_CD_DEVICE == mech_data)
         {
            PITS_Get_CD_Status(&cd_dvd_status);           
            pits_cd_status_found = pits_cd_map_status(cd_dvd_status, &pits_cd_dvd_status);           
         }
         else if (PITS_DVD_DEVICE == mech_data)
         {
            PITS_Get_DVD_Status(&cd_dvd_status);
            pits_cd_status_found = pits_dvd_map_status(cd_dvd_status, &pits_cd_dvd_status);
         }

         if (pits_cd_status_found)
         {
            CD_tx_data[0] = (uint8_t) SUCCESS;            
            if (PITS_Verify_No_Media_Available(mech_data, pits_cd_dvd_status.media))
            {
               /*do nothing no media inserted*/
               CD_tx_data[1] = 0x00;
            }
            else
            {
               PITS_Disc_Eject(mech_data);
               CD_tx_data[1] = 0x01;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_CD_eject_req
 *===========================================================================*
 * @brief Receive a Request to eject the CD
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Device:
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = Status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_CD_insert_req(const PITS_Message_T * message)
{
   PITS_CD_DVD_Status_T  cd_dvd_status;
   PITS_CD_DVD_Status_T  pits_cd_dvd_status = {0};
   PITS_DEVICE_TYPES_T   mech_data;
   bool_t  pits_cd_status_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_INSERT_ACK, 2);

      CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("CD Request: Message Data Error");
      }
      else
      {
         mech_data = (PITS_DEVICE_TYPES_T) message->data[0];
         if (PITS_CD_DEVICE == mech_data)
         {
            PITS_Get_CD_Status(&cd_dvd_status);           
            pits_cd_status_found = pits_cd_map_status(cd_dvd_status, &pits_cd_dvd_status);           
         }
         else if (PITS_DVD_DEVICE == mech_data)
         {
            PITS_Get_DVD_Status(&cd_dvd_status);
            pits_cd_status_found = pits_dvd_map_status(cd_dvd_status, &pits_cd_dvd_status);
         }

         if (pits_cd_status_found)
         {
            CD_tx_data[0] = (uint8_t) SUCCESS;
            if (PITS_Verify_No_Media_Available(mech_data, pits_cd_dvd_status.media))
            {
               /*Do nothing No media present*/
               CD_tx_data[1] = 0x00;
            }
            else if (PITS_Verify_Ejected_Status(mech_data, pits_cd_dvd_status.media))
            {
               PITS_Disc_Insert(mech_data);
               CD_tx_data[1] = 0x01;
            }
            else
            {
               /*Inserted Fail*/
               CD_tx_data[1] = 0x02;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_CD_DVD_set_req
 *===========================================================================*
 * @brief Receive a Request to eject the CD
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Device:
 * @param [out] CD_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] CD_tx_data[1] = Status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
#if PITS_DVD_IS
Done_Or_Not_Done_T pits_CD_DVD_set_req(const PITS_Message_T * message)
{
   uint8_t set_value_cd_dvd;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      CD_tx_bus_id = message->bus;
      pits_CD_compose_message_header(MID_CD_DVD_SET_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("CD Request: Message Data Error");
      }
      else
      {
          set_value_cd_dvd = message->data[0];
         CD_tx_data[0] = (uint8_t) SUCCESS;
         if (set_value_cd_dvd < 3)
         {
            if (set_value_cd_dvd > 0)
            {
               DPPH_PS_Put_Mech(set_value_cd_dvd);
            }
            CD_tx_data[1] = DPPH_PS_Get_Mech();
         }
         else
         {
            CD_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&CD_message);             
      }
   }
   return (pits_status);
}

#endif /*PITS_DVD_IS*/

/*===========================================================================*
 * FUNCTION: PITS_Set_CD_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_CD_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (CD_session_state != session)   /* Session State change? */
   {
      CD_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_CD_SESSION, &CD_session_state, sizeof(CD_session_state));   /* Publish new Session State */
      if (CD_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_CD_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_CD_session_timer_id, CD_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}


/*===========================================================================*
 * FUNCTION: PITS_Get_CD_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_CD_Session(void)
{
   return (CD_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_CD_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_CD_Timer(void)
{
   SAL_Create_Timer(PITS_EV_CD_SESSION_TIMEOUT, &pits_CD_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_CD_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_CD_Timer(void)
{
   SAL_Destroy_Timer(pits_CD_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_CD_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_CD_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_CD_SESSION_TIMEOUT)
   {
      if (PITS_Set_CD_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS CD SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_CD_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_CD_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &CD_session_state, sizeof(CD_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_CD_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_CD_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_CD_SESSION,NULL,0,PITS_EVG_CD_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_CD_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*/
/*!
 * @file pits_cd_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS CD Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 27
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * - 05-jun-2012 Kris Boultbee
 *   Task kok_basa#101287 Revision 26
 *   - Addressed the following Klocwork defect reported in the function pits_CD_set_position_req():
 *     'cd_dvd_positions.disc_type' might be used uninitialized in this function.
 *
 * 1-May-2012 Darinka Lopez  Rev 25
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 23 Mar 2012 Miguel Garcia Rev 23
 * Include read mech status cd dvd
 *
 * 20 Dec 2011 Miguel Garcia Rev 22
 * Include updates for get and set media.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 20
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 19
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 28 Nov 2011 Oscar Vega Rev 18
 * Rename files to pits_cd_services_cfg to avoid borke builds
 *
 * 22-Nov-2011 Darinka Lopez  Rev 17
 * SCR kok_basa#16242: Implement MSID(15h) - CD/DVD Services.
 * Fix: Make changes in CD Services BB to support SBX program.
 *
 * 07 Sep 2011 Miguel Garcia
 * Insert CD function
 *
 * 13 Apr 2011 Miguel Garcia
 * Include CD\DVD put in PS
 *
 * 01 Feb 2011 Miguel Garcia Rev 9
 * Include CD Eject service
 *
 * 13 Jan 2011 Miguel Garcia Rev 8
 * Remove unused Pits
 *
 * 03-Ago-2010 Miguel Garcia  Rev 7
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 08-Jul-2010 Miguel Garcia  Rev 5, 6
 * SCR kok_basa#1674: Implement Diagnostic Services PITS for CPIDs and DPIDs.
 *
 * 11-Mar-2010 Pramod N K  Rev 4
 * SCR kok_basa#685: Remove references to old header files and API related to MH
 *
 * 2-Oct-2009 David Mooar  Rev 3
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * 10-Sept-2009 David Mooar  Rev 2
 * SCR kok_aud#62403: Implement PITS CD messages.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
