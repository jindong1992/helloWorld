/*===========================================================================*/
/**
 * @file pits_misc_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_misc_services.c~7:csrc:ctc_ec#22 %
 * @version %version:7 %
 * @author  %derived_by:vj430z %
 * @date    %date_modified:Tue Jun 20 20:25:50 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_configuration.h"
#include "pits_misc_services.h"
#include "pits_misc_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "vip_proxy.h"
#include "vip_desip.h"
#include "faceplate_key_enum.h"
#include "dbg_trace.h"
#include "pcan_appl_proxy.h"
#include "pits_processing_misc.h"
#include "hmi_ps.h"
#include "board_config.h"

EM_FILENUM(PITS_MODULE_ID_5, 26);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

#define PITS_PWM_AMP_FREQUENCY (200)
#define PITS_PWM_AMP_MAX_VALUE (3)

#define PITS_SLEW_INPUTS       (0x08)
#define PITS_IGNORE_INPUTS     (0x02)

#define PITS_REAR_DISPLAY_1    (0x01)
#define PITS_REAR_DISPLAY_2    (0x02)

#define PITS_REAR_DISPLAY_CHANNEL      (0x03)
#define PITS_REAR_DISPLAY_2_CHANNEL    (0x05)
#define PITS_REAR_DISPLAY_FREC         (0xC8)
#define PITS_REAR_DISPLAY_2_FREC       (0xC8)
#define PITS_REAR_BRIGHT_CHANNEL       (0x02)

#define HMI_Touch_X_Min 0   /** This is the minimum possible value returned by the touch screen. This is the left edge. The theoretical value is 0 */
#define HMI_Touch_X_Max 3950 /** This is the minimum possible value returned by the touch screen. This is the right edge. The theoretical value is 4095 */
#define HMI_LCD_Width   800  /** This is the number of pixels across the LCD Screen. */

#define HMI_Touch_Y_Min 0 /** This is the minimum possible value returned by the touch screen. This is the bottom edge. The theoretical value is 0 */
#define HMI_Touch_Y_Max 3800 /** This is the minimum possible value returned by the touch screen. This is the top edge. The theoretical value is 4095 */
#define HMI_LCD_Height  480  /** This is the number of pixels vertically on the LCD Screen. */

/**
 * use the same as the one in Input Handler.
 */
#define TSC_X_Min         (HMI_Touch_X_Min)
#define TSC_X_Max         (HMI_Touch_X_Max)
#define TSC_LCD_Width     (HMI_LCD_Width)

#define TSC_Y_Min         (HMI_Touch_Y_Min)
#define TSC_Y_Max         (HMI_Touch_Y_Max)
#define TSC_LCD_Height    (HMI_LCD_Height)

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#ifndef PITS_VIP_BOOT_SWID_LENGHT
#define PITS_VIP_BOOT_SWID_LENGHT            8
#endif

#ifndef PITS_VIP_APP_SWID_LENGHT
#define PITS_VIP_APP_SWID_LENGHT             8
#endif

#ifndef PITS_APP_SWID_LENGHT
#define PITS_APP_SWID_LENGHT                 8
#endif

#ifndef PITS_BOOT_SWID_LENGHT
#define PITS_BOOT_SWID_LENGHT                8
#endif

#ifndef PITS_PLBK_SWID_LENGHT
#define PITS_PLBK_SWID_LENGHT                2
#endif

#ifndef PITS_RTD_SWID_LENGHT
#define  PITS_RTD_SWID_LENGHT             8
#endif

#ifndef PITS_RTD_CHECKSUM_LENGHT
#define  PITS_RTD_CHECKSUM_LENGHT         4
#endif


#define PITS_Get_VR_NAV_MAP_DATABASE_Lenght  8

#define TS_DATA_SIZE_WORD     5       /* Touch screen data size in words*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * Subservices Enumeration  MSID 1A - MID E0 Subservice XX.
 *---------------------------------------------------------------------------*/

typedef enum PITS_SW_HW_ID_Tag
{
   VIP_BOOT_SWID_DEVICE_NUMBER         = 0x01,
   VIP_APP_SWID_DEVICE_NUMBER          = 0x02,
   AP_BOOT_SWID_DEVICE_NUMBER          = 0x11,
   AP_APPLICATION_SWID_DEVICE_NUMBER   = 0x12,
   BLUE_TOOTH_SWID_DEVICE_NUMBER       = 0x20,
   WIFI_BUILD_ID_DEVICE_NUMBER         = 0x21,
   WIFI_CHIP_REV_DEVICE_NUMBER         = 0x22,
   WIFI_ROM_NAME_DEVICE_NUMBER         = 0x23,
   WIFI_FIRMWARE_ID_DEVICE_NUMBER      = 0x24,
   TMC_TUNER_DEVICE_NUMBER             = 0x25,
   DAB_SW_DEVICE_NUMBER                = 0x28,
   DAB_HW_DEVICE_NUMBER                = 0x29,
   INIC_SW_DEVICE_NUMBER               = 0x2C,
   INIC_HW_DEVICE_NUMBER               = 0x2D,
   INIC_FW_DEVICE_NUMBER               = 0x2E,
   INIC_NS_DEVICE_NUMBER               = 0x2F,
   BT_BC6_FIRMWARE_NUMBER              = 0x30,
   BT_CHIP_VERSION_NUMBER              = 0x31,
   BT_CHIP_REVISION_NUMBER	          = 0x32,
   BT_STACK_SWID_NUMBER                = 0x33,
   NAV_FRIMWARE_SWID_DEVICE_NUMBER     = 0x40,
   NAV_FRIMWARE_HWID_DEVICE_NUMBER     = 0x41,
   NAV_FRIMWARE_ROMVID_DEVICE_NUMBER   = 0x42,
   NAV_MAP_DATABASEID_DEVICE_NUMBER    = 0x43,
   NAV_GPS_DEVICE_NUMBER               = 0x45,
   VR_VOCALIZER_SWID_DEVICE_NUMBER     = 0x50,
   VR_SAMANTHA_SWID_DEVICE_NUMBER      = 0x51,
   VR_JULIE_SWID_DEVICE_NUMBER         = 0x52,
   VR_PAULINA_SWID_DEVICE_NUMBER       = 0x53,
   VR_ENGLISH_SWID_DEVICE_NUMBER       = 0x54,
   VR_FRENCH_SWID_DEVICE_NUMBER        = 0x55,
   VR_MEXICAN_SWID_DEVICE_NUMBER       = 0x56,
   SPEECH_REC_SWID_DEVICE_NUMBER       = 0x57,
   CAPSENSE_SWID_DEVICE_NUMBER         = 0x60,
   PLAYBACK_SWID_DEVICE_NUMBER         = 0x70,
   RTD_SWID_DEVICE_NUMBER                    = 0x80,

}PITS_SW_HW_ID_T;

typedef enum PITS_KNOB_Tag
{
   PITS_VOLUME_KNOB = 0,
   PITS_TUNE_KNOB,
   PITS_INVALID_KNOB,
}PITS_KNOB_T;


typedef struct User_Input_Translation_Tag
{
   PITS_User_Input_T   pits_user_input;
   PITS_System_Input_T diag_keypress;
} User_Input_Translation_T;

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
typedef struct Key_ID_Translation_Tag
{
   PITS_KEY_ID_T   pits_key_id;
   uint32_t phy_id;
} Key_ID_Translation_T;
#endif

/*GPIO Set Table*/
/*PIN                     PORT           MASK CODE */
static const VIP_GPIO_PINS_ITEM_T gpio_pins_tab[] =
{
   {DVD_EN,                                VIP_P4,    0x20},     /*P45*/
   {DISP_REMOTE_EN,              VIP_P4,    0x10},     /*P44*/
   {REAR_DVD_REMOTE_EN,  VIP_P1,    0x04},     /*P12*/
};

static const VIP_DIP_PIN_ITEM_T dip_pins_tab[] =
{
   {REVERSE,   VIP_P7,    0x10},       /*P74*/
   {ILL,       VIP_P7,    0x02},       /*P71*/
   {ACC,       VIP_P7,    0x01},       /*P70*/
   {P7_5,      VIP_P7,    0x20},       /*P75*/
   {P7_6,      VIP_P7,    0x40},       /*P76*/
   {P7_7,      VIP_P7,    0x80}        /*P77*/
};

/* static variable to read rtc values from VIP */
static SIP_Date_Time_T rtc_date_time;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void PITS_Misc_Initialize(void);
static void PITS_Misc_Compose_Message_Header(uint8_t mid, uint8_t size);
static bool_t map_pits_user_input_to_kb_btn(PITS_User_Input_T pits_user_input, PITS_System_Input_T *diag_keypress);
static bool_t map_pits_kb_btn_to_user_input(PITS_System_Input_T diag_keypress, PITS_User_Input_T *pits_user_input);
static uint16_t TSC_Convert_X_Touch_To_Pixels(uint16_t touch_x);
static uint16_t TSC_Convert_Y_Touch_To_Pixels(uint16_t touch_y);

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
static bool_t phy_key_id_to_pits_key_id(uint32_t phy_key_id, PITS_KEY_ID_T *pits_key_id);
static bool_t pits_key_id_to_phy_key_id(PITS_KEY_ID_T pits_key_id, uint32_t *phy_key_id);

#endif

static ExtenalFaceplateFrameDef_T key_input = {KEY_CODE_UNKNOWN, 0, 0};

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_MISC_RX_INDEX

#define MID_MISC_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T PITS_Misc_RX_Messages[] = {
   MID_MISC_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_MISC_TX_INDEX

#define MID_MISC_TX_INDEX(name, mid) (mid),

static const uint8_t PITS_Misc_TX_Messages[] = {
   MID_MISC_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_MISC_RX_INDEX
#define MSID_MISC_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T PITS_Misc_RX_Message_Sets[] = {
   MSID_MISC_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_MISC_TX_INDEX
#define MSID_MISC_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T PITS_Misc_TX_Message_Sets[] = {
   MSID_MISC_TX_TABLE
};

static uint8_t TX_Bus_ID;   /* ID of the bearing bus on which to send response */

static PITS_Message_T TX_Message;      /* for construction of a misc service message to be transmitted */

static uint8_t TX_Data[PITS_MAX_MESSAGE_SIZE];

static uint8_t PWM_Amp_Duty_Index;
static const uint16_t PITS_PWM_Amp_Duty_Cycles[] = {0x0000, 0x8000, 0xC000, 0xFFFF};

static uint8_t PITS_Test_Flags;
static AuMgr_DO_Enable_T Audio_Overrides;

static int16_t ts_data_info[TS_DATA_SIZE_WORD];

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
static bool_t knob_test_flag = false;                    /*Volume and Tune knob test flag of CHK NE*/
static int8_t vol_knob_test_offset = 0;
static int8_t tune_knob_test_offset = 0;

static const Key_ID_Translation_T key_id_translation[] =
{
   {PITS_NO_PRESS,      KB_MSG_MASK},
   {PITS_POWER,            KEY_CODE_CD_POWER},
   {PITS_BAND,              KEY_CODE_PCAN_RADIO},
   {PITS_EJECT,              KEY_CODE_CD_EJECT},
   {PITS_NEXT,               KEY_CODE_CD_NEXTTRACK},
   {PITS_PREVIOUS,      KEY_CODE_CD_LASTTRACK},
   {PITS_SOURCE,         KEY_CODE_PCAN_MEDIA},
   {PITS_PHONE,           KEY_CODE_PCAN_TEL},
   {PITS_MUTE,             KEY_MUTE_KEY},
   {PITS_NAVI,               KEY_CODE_PCAN_SETUP},
   {PITS_MENU,            KEY_TUNE_KEY},
   {PITS_DEST,              KEY_CODE_PCAN_BACK},
   {PITS_MENU_SET,   KEY_CODE_PCAN_MENU},
};
#endif

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_user_input, diag_keypress) {pits_user_input, diag_keypress},

static const User_Input_Translation_T User_Input_Translation[] =
{
   PITS_USER_INPUT_TO_DIAG_KEYPRESS_TABLE
};


/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Misc_Services_Interface = {
   PITS_Misc_Initialize,
   PITS_Misc_RX_Message_Sets,
   Num_Elems(PITS_Misc_RX_Message_Sets),
   PITS_Misc_TX_Message_Sets,
   Num_Elems(PITS_Misc_TX_Message_Sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Misc_Initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
static void PITS_Misc_Initialize(void)
{
   TX_Bus_ID = 0;
   memset(&TX_Message, 0x00, sizeof(PITS_Message_T));
   memset(TX_Data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

void PITS_Misc_Clear_Overrides(void)
{
   PITS_Test_Flags = 0;
   PITS_Enable_Misc_Override();
   PITS_Set_Remote_Enabled_Status(1);
}

static void PITS_Misc_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   TX_Message.bus = TX_Bus_ID;
   TX_Message.data = TX_Data;
   TX_Message.MSID = MSID_MISC_SERVICES;
   TX_Message.MID = mid;
   TX_Message.data_size = size;
   memset(&TX_Data[0], 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Clear_Override_Controls_Req
 *===========================================================================*
 * @brief Receive a Request to clear all override controls
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Clear_Override_Controls_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_CLEAR_OVERRIDES_ACK, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         PITS_Misc_Clear_Overrides();
         PITS_Audio_Clear_Overrides();
         PITS_Tuner_Clear_Overrides();
         PITS_Audio_Clear_Source_Override();
         TX_Data[0] = (uint8_t) SUCCESS;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Exit_Diagnostics_Mode_Req
 *===========================================================================*
 * @brief Receive a Request to module reset
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Exit_Diagnostics_Mode_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_EXIT_DIAGNOSTICS_MODE_ACK, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         PITS_Exit_Manufacturing_Mode();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}



/*===========================================================================*
 * FUNCTION: PITS_Misc_Enter_Sleep_Mode_Req
 *===========================================================================*
 * @brief Receive a Request to enter sleep mode
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Enter_Sleep_Mode_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         PITS_Module_Enter_Sleep_Mode();
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Module_Reset_Req
 *===========================================================================*
 * @brief Receive a Request to module reset
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Module_Reset_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         PITS_Module_Reset();
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Power_Antenna
 *===========================================================================*
 * @brief Request the power antenna status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Power_Antenna (const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_POWER_ANTENNA_RPT, 2);

      /* Compose Message Data */
      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if(message->data[0] < PITS_NUM_ANTENNA)
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = PITS_Get_Power_Antenna_Status(0);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Power_Antenna
 *===========================================================================*
 * @brief Set power Antenna state
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Power_Antenna (const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_POWER_ANTENNA_RPT, 2);

      /* Compose Message Data */
      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if(message->data[0] < PITS_NUM_ANTENNA)
         {
            PITS_Put_Power_Antenna_Status(0, message->data[0]);
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = message->data[0];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Radio_Status_Req
 *===========================================================================*
 * @brief Receive a Request to get radio status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Radio Status:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Radio_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_RADIO_STATUS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = PITS_Get_Radio_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Radio_Status_Req
 *===========================================================================*
 * @brief Receive a Request to get radio status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Radio Status:
 *                                  0x00 = Off
 *                                  0x01 = On
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Radio Status:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Radio_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   bool_t send_pit_message = true;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_RADIO_STATUS_SET_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[1] = message->data[0];
         if (2 > message->data[0])
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            if (Pits_Misc_Display_Status())
            {
               TX_Data[1] = 1; /*If display override on does not send power*/
            }
            else
            {
               send_pit_message = PIT_Set_Radio_Power(message->data[0]);
            }
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         if (send_pit_message)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
         }
      }
   }


   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_AD_Ports
 *===========================================================================*
 * @brief Receive a Request to get ad ports status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_AD_Ports (const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_AD_PORTS_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = DATA_OUT_OF_RANGE;
         TX_Data[1] = message->data[0];
         if(PITS_Get_AD_Port_Available(message->data[0]))
         {
            TX_Data[0] = SUCCESS;
            Util_Put_Big_Endian_U16(&TX_Data[2], PITS_Get_AD_Port_Status(message->data[0]));
         }

         /*Kwyboard AD value for CHK NE project*/
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
         if (message->data[0] >= 0xA0 && message->data[0] <= 0xA7)
         {
            TX_Data[0] = SUCCESS;
            Util_Put_Little_Endian_U16(&TX_Data[2], PITS_Get_KB_AD_Port_Status(message->data[0]));
         }
#endif

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_IO_Ports
 *===========================================================================*
 * @brief Receive a Request to get i/o ports status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_IO_Ports (const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_IO_PORTS_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = DATA_OUT_OF_RANGE;
         TX_Data[1] = message->data[0];
         if(PITS_Get_IO_Port_Available(message->data[0]))
         {
            TX_Data[0] = SUCCESS;
            TX_Data[2] = PITS_Get_IO_Port_Status(message->data[0]);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_ClkOut_Status_Req
 *===========================================================================*
 * @brief Receive a Request to get clkout pin status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] =  ClkOut Status:
 *                               0x00 = Disable
 *                               0x01 = Enable
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_ClkOut_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_CLKOUT_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = PITS_Get_ClkOut_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_ClkOut_Status_Req
 *===========================================================================*
 * @brief Receive a Request to set clkout pin status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Clkout pin Status:
 *                                  0x00 = Disable
 *                                  0x01 = Enable
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Radio Status:
 *                               0x00 = Disabled
 *                               0x01 = Enabled
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_ClkOut_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_CLKOUT_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         TX_Data[1] = message->data[0];
         if (2 > message->data[0])
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            PIT_Set_ClkOut(message->data[0]);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#if 0
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Microphone_AD_Value_Req
 *===========================================================================*
 * @brief Receive a Request to Get Microphone_AD_Value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] message->data[0] = Microphone Signal Mic+ / Mic-
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Mic Terminal:
 *                              0x00 = Unable to read Microphone
 *                              0x01 = Mic(+)
 *                              0x02 = Mic(+)
 * @param [out] TX_Message[2] = AD Value MSB *
 * @param [out] TX_Message[3] = AD Value LSB
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Microphone_AD_Value_Req (const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   bool_t nonzero_mic_ad_value = false;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_MIC_AD_VALUE_RPT,4);

      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      TX_Data[1] = message->data[0];
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if ((0x01 == message->data[0])||(0x02 == message->data[0]))
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            nonzero_mic_ad_value = PIT_Get_Microphone_AD_Value (message->data[0], &TX_Data[2]);
            if(!nonzero_mic_ad_value)
            {
               TX_Data[1] = 0x00;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#endif
/*===========================================================================*
 * FUNCTION: map_pits_user_input_to_kb_btn
 *===========================================================================*
 * @brief Map pit key definition with diag key.
 *
 * @returns
 *    bool_t  make executed correctly.
 *
 * @param [in] pits_user_input = Pit key
 * @param [in] diag_keypress = Pit key
 */
/*===========================================================================*/
bool_t map_pits_user_input_to_kb_btn(PITS_User_Input_T pits_user_input, PITS_System_Input_T *diag_keypress)
{
   uint8_t i;
   bool_t diag_keypress_found = false;

   for (i = 0; i < Num_Elems(User_Input_Translation); i++)
   {
      if (pits_user_input == User_Input_Translation[i].pits_user_input)
      {
         (*diag_keypress) = User_Input_Translation[i].diag_keypress;
         diag_keypress_found = true;
         break;
      }
   }

   return(diag_keypress_found);
}

/*===========================================================================*
 * FUNCTION: map_pits_kb_btn_to_user_input
 *===========================================================================*
 * @brief Map diag key definition with pits key.
 *
 * @returns
 *    bool_t  make executed correctly.
 *
 * @param [in] pits_user_input = Pit key
 * @param [in] diag_keypress = Pit key
 */
/*===========================================================================*/
bool_t map_pits_kb_btn_to_user_input(PITS_System_Input_T diag_keypress, PITS_User_Input_T *pits_user_input)
{
   uint8_t i;
   bool_t diag_keypress_found = false;

   for (i = 0; i < Num_Elems(User_Input_Translation); i++)
   {
      if (diag_keypress == User_Input_Translation[i].diag_keypress)
      {
         (*pits_user_input) = User_Input_Translation[i].pits_user_input;
         diag_keypress_found = true;
         break;
      }
   }

   return(diag_keypress_found);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Standardized_Input_Req
 *===========================================================================*
 * @brief Receive a Request to get the standardized input (hard keys)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Standardized Input
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Standardized_Input_Req(const PITS_Message_T * message)
{
   PITS_User_Input_T pits_user_input = 0;
   bool_t diag_keypress_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_STANDARDIZED_INPUT_RPT, 2);

      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         diag_keypress_found = map_pits_kb_btn_to_user_input((PITS_System_Input_T)key_input.KeyCode, &pits_user_input);
         if (diag_keypress_found)
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = (uint8_t) pits_user_input;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }

   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Standardized_Input_Req
 *===========================================================================*
 * @brief Receive a Request to set the standardized input (hard keys)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Standardized Input
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Standardized Input
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Standardized_Input_Req(const PITS_Message_T * message)
{
   PITS_User_Input_T pits_user_input = 0;
   PITS_System_Input_T diag_keypress = 0;
   bool_t diag_keypress_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_STANDARDIZED_INPUT_SET_ACK, 2);


      /* Compose Message Data */
      TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[1] = message->data[0];
         pits_user_input = (PITS_User_Input_T) message->data[0];
         diag_keypress_found = map_pits_user_input_to_kb_btn(pits_user_input, &diag_keypress);
         if (diag_keypress_found)
         {
            PITS_Key_Press(diag_keypress);
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Test_Flags_Req
 *===========================================================================*
 * @brief Receive a Request to get test flags
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Test Flags Mask (Mutually exclusive bits):
 *                               0x00 = Normal Mode (Can't be read if in Normal)
 *                               0x01 = Ignore User Controls
 *                               0x02 = Test Loop (Not used)
 *                               0x04 = Slew Inputs
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Test_Flags_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_TEST_FLAGS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t) PITS_Test_Flags;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Test_Flags_Req
 *===========================================================================*
 * @brief Receive a Request to set test flags
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Test Flags Mask (Mutually exclusive bits):
 *                                  0x00 = Normal Mode (Can't be read if in Normal)
 *                                  0x01 = Ignore User Controls
 *                                  0x02 = Test Loop (Not used)
 *                                  0x04 = Slew Inputs
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Test Flags Mask (Mutually exclusive bits):
 *                               0x00 = Normal Mode (Can't be read if in Normal)
 *                               0x01 = Ignore User Controls
 *                               0x02 = Test Loop (Not used)
 *                               0x04 = Slew Inputs
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Test_Flags_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_TEST_FLAGS_SET_ACK, 2);

      /* Compose Message Data */
      TX_Message.data_size = 2;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if ((message->data[0] & PITS_IGNORE_INPUTS) != 0)
         {
            if ((PITS_Test_Flags & PITS_IGNORE_INPUTS) == 0)
            {
               PITS_Disable_Misc_Override();
            }
         }
         else
         {
            if ((PITS_Test_Flags & PITS_IGNORE_INPUTS) != 0)
            {
               PITS_Enable_Misc_Override();
            }
         }
         TX_Data[1] = message->data[0];
         PITS_Test_Flags = message->data[0];
         TX_Data[0] = (uint8_t) SUCCESS;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Remote_Enable_Req
 *===========================================================================*
 * @brief Receive a Request to get the Remote Enable state
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Remote Enable:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Remote_Enable_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_REMOTE_ENABLE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t) PITS_Get_Remote_Enabled_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Remote_Enable_Req
 *===========================================================================*
 * @brief Receive a Request to set the Remote Enable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Remote Enable:
 *                                  0x00 = Off
 *                                  0x01 = On
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Remote Enable:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Remote_Enable_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_REMOTE_ENABLE_SET_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[1] = message->data[0];
         if (MAX_RMT_ENABLE_VALID >= message->data[0])
         {
            PITS_Set_Remote_Enabled_Status(TX_Data[1]);
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Remote_Enable_Req
 *===========================================================================*
 * @brief Receive a Request to set the Remote Enable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Remote Enable:
 *                                  0x00 = Off
 *                                  0x01 = On
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Remote Enable:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Remote_Enable_Diag_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_REMOTE_ENABLE_SET_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[1] = message->data[0];
         if (1 >= message->data[0])
         {
            PITS_Set_Remote_Enabled_Status(TX_Data[1]);
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = DONE;
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Amp_Control_Req
 *===========================================================================*
 * @brief Receive a Request to get the Amp Control state
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Amp Control:
 *                               0x00 = 0%
 *                               0x01 = 50%
 *                               0x02 = 75%
 *                               0x03 = 100%
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Amp_Control_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_AMP_CONTROL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = PWM_Amp_Duty_Index;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Amp_Control_Req
 *===========================================================================*
 * @brief Receive a Request to set the Amp Control state
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Amp Control:
 *                                  0x00 = 0%
 *                                  0x01 = 50%
 *                                  0x02 = 75%
 *                                  0x03 = 100%
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Amp Control:
 *                               0x00 = 0%
 *                               0x01 = 50%
 *                               0x02 = 75%
 *                               0x03 = 100%
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Amp_Control_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   printf("##############################reset RTD\n");
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_AMP_CONTROL_SET_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         printf("##############################reset RTD action\n");
         RTD_Reset();
         SAL_Sleep(50);
         RTD_Release();
         TX_Data[1] = message->data[0];
         if (PITS_PWM_AMP_MAX_VALUE >= message->data[0])
         {
            PWM_Amp_Duty_Index = message->data[0];
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_RTD_Checksum_Req
 *===========================================================================*
 * @brief Receive a Request to get the RTD checksum
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = dummy data:
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = RTD checksum first byte
 * @param [out] TX_Message[2] = RTD checksum second byte
 * @param [out] TX_Message[3] = RTD checksum third byte
 * @param [out] TX_Message[4] = RTD checksum fourth byte
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_RTD_Checksum_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_RTD_CHECKSUM_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if(0 == message->data[0])
         {
            TX_Data[0] = PITS_Misc_Get_RTD_Checksum(&TX_Data[2]);
            TX_Data[1] = PITS_RTD_CHECKSUM_LENGHT;
         }
         else if(1 == message->data[0])
         {
            /* EEPROM data section*/
            Tr_Warn("pits get EEPROM data section");
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            TX_Data[1] = 0;
         }
         TX_Message.data_size = TX_Data[1] + 2;        /* Restore size according the lenght info in tx_data[2]*/

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Rtd_AD_Temp_Req
 *===========================================================================*
 * @brief Receive a Request to get the RTD AD Temp count value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = dummy data:
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = RTD temperature display format (C / F)
 * @param [out] TX_Message[2] = RTD temperature display value (N*0.5 -40 / N*0.9 -40)

 *
 * @pre message->data_size = 0
 *
 * @post
 *
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T PITS_Misc_Get_Rtd_AD_Temp_Req(const PITS_Message_T * message)
{

    Done_Or_Not_Done_T pits_status = NOT_DONE;
    uint16_t AD_Value = 0;
    int8_t temperature = 0;

    if (NULL != message)
    {
       /* Initial call (new message received -- first call for this message) */

       /* Compose Message Header */
       TX_Bus_ID = message->bus;
       PITS_Misc_Compose_Message_Header(MID_MISC_GET_RTD_AD_TEMP_RPT, 3);

       /* Compose Message Data */
       if (message->data_size != 0)
       {
          pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
       }
       else
       {

           TX_Data[0] = PITS_Misc_Get_RTD_Temperature(&TX_Data[1]);
           if(TX_Data[0])
           {
                AD_Value =  ((uint16_t )TX_Data[2] << 8 ) + TX_Data[1];

                temperature = Pits_RTD_Convert_AD_2_Temperature(AD_Value);
                TX_Data[1] = 0;/*0x00 C, 0x01 F */
                TX_Data[2] = (temperature + 40) * 2 ; /*C  E = N/2-40 ; F E =N * 0.9 -40*/
           }
           else
           {
                Tr_Info_Mid("Fail to get temperature from rtd.");
                TX_Data[1] = 0;
                TX_Data[2] = 0;
           }

          Tr_Info_Mid_2("RTD temperature is %d  centigrade. AD : %d ",temperature,AD_Value);
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
       }

    }
    return (pits_status);

}



/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_SWID_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = SWID Type:
 *                                  0x00 = Unused
 *                                  0x01 = V850 boot SWID
 *                                  0x02 = V850 application SWID
 *                                  0x12 = J2 AP application SWID
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = SWID Type:
 *                                  0x00 = Unused
 *                                  0x01 = V850 boot SWID
 *                                  0x02 = V850 application SWID
 *                                  0x12 = J2 AP application SWID
 * @param [out] TX_Message[2] = Number of bytes in SWID
 * @param [out] TX_Message[3] = SWID
 *                          .
 *                          .
 *                          .
 * @param [out] TX_Message[n] = SWID
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_SWID_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t data_len = 0;

#if PITS_BLUETOOTH_IS
   uint16_t bt_swid = 0;
#endif

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SWID_RPT, 11);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[1] = message->data[0]; /* device number*/

         switch (message->data[0])  /* device number*/
         {
            case VIP_BOOT_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VIP_Boot_SWID(&TX_Data[3], &data_len);
               TX_Data[2] = PITS_VIP_BOOT_SWID_LENGHT;
               break;
            }
            case VIP_APP_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VIP_App_SWID(&TX_Data[3], &data_len);
               TX_Data[2] = PITS_VIP_APP_SWID_LENGHT;
               break;
            }
            case AP_APPLICATION_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_App_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_APP_SWID_LENGHT;
               break;
            }
            case AP_BOOT_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_Boot_SWID(&TX_Data[3], &data_len);
               TX_Data[2] = PITS_BOOT_SWID_LENGHT;
               break;
            }
#if PITS_PLAYBACK_IS
            case PLAYBACK_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_PLBK_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_PLBK_SWID_LENGHT;
               break;
            }
#endif

#if PITS_NAV_IS
            case NAV_MAP_DATABASEID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Get_NAV_MAP_DATABASE_Info(&TX_Data[3], &data_len);
               TX_Data[2] = data_len;
               break;
            }
#endif

#if PITS_BLUETOOTH_IS
            case BLUE_TOOTH_SWID_DEVICE_NUMBER:
            case BT_BC6_FIRMWARE_NUMBER:
            {
               TX_Data[0] = PITS_BT_CM_PS_Get_FW_Revision(&bt_swid);
               TX_Data[2] = 2;
               TX_Data[3] = (uint8_t)((bt_swid & 0xFF00) >> 8);
               TX_Data[4] = (uint8_t)(bt_swid & 0x00FF);
               break;
            }
            case BT_CHIP_VERSION_NUMBER:
            {
               TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
               TX_Data[2] = 0;
               break;
            }
            case BT_CHIP_REVISION_NUMBER:
            {
               TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
               TX_Data[2] = 0;
               break;
            }
            case BT_STACK_SWID_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_BT_Stack_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_BT_Stack_Lenght();
               break;
            }
#endif

#if PITS_WIFI_IS
            case WIFI_BUILD_ID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_WIFI_Build_ID(&TX_Data[3], &TX_Data[2]);
               break;
            }
            case WIFI_CHIP_REV_DEVICE_NUMBER:
            {
                TX_Data[0] = PITS_Misc_Get_WIFI_Chip_Rev(&TX_Data[3], &TX_Data[2]);
                break;
            }
            case WIFI_ROM_NAME_DEVICE_NUMBER:
            {
                TX_Data[0] = PITS_Misc_Get_WIFI_Rom_Name(&TX_Data[3], &TX_Data[2]);
                break;
            }
            case WIFI_FIRMWARE_ID_DEVICE_NUMBER:
            {
                TX_Data[0] = PITS_Misc_Get_WIFI_Firmware_ID(&TX_Data[3], &TX_Data[2]);
                break;
            }
#endif

#if PITS_VR_IS
            case VR_VOCALIZER_SWID_DEVICE_NUMBER:
            {
#if 0
               TX_Data[0] = PITS_Misc_Get_VR_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_SWID_Lenght();
#endif
               TX_Data[0] = PITS_Misc_Get_VR_SWID(&TX_Data[3], &TX_Data[2]);
               break;
            }
            case VR_SAMANTHA_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_Samantha_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_Samantha_SWID_Lenght();
                break;
            }
            case VR_JULIE_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_Julie_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_Julie_SWID_Lenght();
               break;
            }
            case VR_PAULINA_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_Paulina_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_Paulina_SWID_Lenght();
               break;
            }
            case VR_ENGLISH_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_English_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_English_SWID_Lenght();
               break;
            }
            case VR_FRENCH_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_French_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_French_SWID_Lenght();
               break;
            }
            case VR_MEXICAN_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_Mexican_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_Mexican_SWID_Lenght();
               break;
            }
            case SPEECH_REC_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_VR_Speech_Rec_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_Get_VR_Speech_Rec_SWID_Lenght();
               break;
            }
#endif

#if PITS_TMC_IS
            case TMC_TUNER_DEVICE_NUMBER:
            {
               if(PITS_TMC_Ready())
               {
                  TX_Data[0] = (uint8_t) SUCCESS;
                  TX_Data[2] = PITS_Get_TMC_Revision_Lenght();
                  memcpy(&TX_Data[3], PITS_Get_TMC_Revision(), TX_Data[2]);
               }
               else
               {
                  TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                  TX_Data[2] = 0;
               }
               break;
            }
#endif /*PITS_TMC_IS*/

#if PITS_DAB_IS
            case DAB_SW_DEVICE_NUMBER:
               TX_Data[0] = PITS_Get_DAB_SWID(&TX_Data[2]);
               break;
            case DAB_HW_DEVICE_NUMBER:
               TX_Data[0] = PITS_Get_DAB_HWID(&TX_Data[2]);
               break;
#endif

#if PITS_INIC_IS
            case INIC_SW_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Get_INIC_SWID(&TX_Data[2]);
               break;
            }
            case INIC_HW_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Get_INIC_HWID(&TX_Data[2]);
               break;
            }
            case INIC_FW_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Get_INIC_FWID(&TX_Data[2]);
               break;
            }
            case INIC_NS_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Get_INIC_NSID(&TX_Data[2]);
               break;
            }
#endif
            case NAV_FRIMWARE_SWID_DEVICE_NUMBER:
               TX_Data[0] = PITS_Misc_GPS_SWID(&TX_Data[3], &TX_Data[2]);
               break;
            case NAV_FRIMWARE_HWID_DEVICE_NUMBER:
               TX_Data[0] = PITS_Misc_GPS_HWID(&TX_Data[3], &TX_Data[2]);
               break;
            case NAV_FRIMWARE_ROMVID_DEVICE_NUMBER:

               break;
            case NAV_GPS_DEVICE_NUMBER:
               TX_Data[0] = PITS_Misc_GPS_SWID(&TX_Data[3], &TX_Data[2]);
               break;
            case RTD_SWID_DEVICE_NUMBER:
            {
               TX_Data[0] = PITS_Misc_Get_RTD_SWID(&TX_Data[3]);
               TX_Data[2] = PITS_RTD_SWID_LENGHT;
               break;
            }
            default:
               TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                TX_Data[2] = 0;
                break;
            }

         TX_Message.data_size = TX_Data[2] + 3;        /* Restore size according the lenght info in tx_data[2]*/
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Part_Number_Req
 *===========================================================================*
 * @brief Receive a Request to get the Part Number
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Part Number Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Part Number Type:

 * @param [out] TX_Message[2] = Number of bytes in Part Number
 * @param [out] TX_Message[3] = Part Number
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Part_Number_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_PART_NUMBER_RPT, 6);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         uint8_t * pits_sw_identifier = PITS_SW_Identifier();

         if (pits_sw_identifier != NULL)
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = SIZE_PART_NUMBER;

            memcpy(&TX_Data[2], pits_sw_identifier, SIZE_PART_NUMBER);
         }
         else
         {
            Tr_Warn("Unable to retrieve the PITS Software Identifier.");
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Part_Number_Req
 *===========================================================================*
 * @brief Receive a Request to get the Part Number
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Part Number Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Part Number Type:

 * @param [out] TX_Message[2] = Number of bytes in Part Number
 * @param [out] TX_Message[3] = Part Number
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_VIN_Number_Req(const PITS_Message_T * message)
{
   Whole_Vin_T    vin_number = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE;


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_VIN_NUMBER_RPT, sizeof(vin_number)+2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         PITS_Theft_PS_Get_Whole_VIN(vin_number);
         TX_Data[1] = sizeof(vin_number);
         memcpy (&TX_Data[2], &vin_number[0], sizeof(vin_number));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Part_Number_Req
 *===========================================================================*
 * @brief Receive a Request to get the Part Number
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Part Number Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Part Number Type:

 * @param [out] TX_Message[2] = Number of bytes in Part Number
 * @param [out] TX_Message[3] = Part Number
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_VIN_Number_Req(const PITS_Message_T * message)
{
   Whole_Vin_T    vin_number = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE;


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_VIN_NUMBER_RPT, (sizeof(vin_number) + 2));

      /* Compose Message Data */
      if (message->data_size != (message->data[0] + 1))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         if (message->data[0] == sizeof(vin_number))
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = message->data[0];
            memcpy (&vin_number[0], &message->data[1],  sizeof(vin_number));
            memcpy (&TX_Data[2], &vin_number[0], sizeof(vin_number));
            PITS_Theft_PS_Put_Whole_VIN(vin_number);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_DVD_Status_Req
 *===========================================================================*
 * @brief Receive a Request to get DVD Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = length:

 * @param [out] TX_Message[2-7] = monitor 1 status
 * @param [out] TX_Message[8-13] = monitor 2 status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_DVD_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   SAL_Message_T const * msg;
   int find = false;
   uint8_t DVD_staus[2]={0, 0};
   uint8_t monitor_id;
   int count = 0;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_DVD_STS_RPT, 14);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
		TX_Data[0] = (uint8_t) SUCCESS;
		TX_Data[1] = 14;

		while( find == false)
		{
			msg = SAL_Receive_Timeout(DVD_RECIEVE_TIMEOUT_MS);

			count ++;

			if(msg != NULL)
			{
				switch (msg->event_id)
				{
					case EVG_RSE_STATUS:

					PBC_Require(msg->data != NULL, "msg->data cannot be NULL");

					TX_Data[0] = (uint8_t) SUCCESS;

					memcpy (&monitor_id, msg->data, 1);

					if(1 == monitor_id)
					{
					memcpy (&TX_Data[2], msg->data, 6);
					DVD_staus[0] = 1;
					Tr_Info_Lo_4("get dvd status***%d %d %d %d ***", TX_Data[1], TX_Data[2], TX_Data[3], TX_Data[4]);
					}
					else if(2 == monitor_id)
					{
					memcpy (&TX_Data[8], msg->data, 6);
					DVD_staus[1] = 1;
					Tr_Info_Lo_4("get dvd status***%d %d %d %d ***", TX_Data[7], TX_Data[8], TX_Data[9], TX_Data[10]);
					}

               if(DVD_staus[0] & DVD_staus[1])
					find = true;
					break;
					default:
					Tr_Info_Lo_1("DVD pits do not decode this event %d!",  msg->event_id);
					break;
				}
			}
			else
			{
				Tr_Info_Lo("wait DVD status msg null");
			}

			if (count > DVD_RECIEVE_TRY_MAX)
			{
				find = true;

            TX_Data[0] = (uint8_t) FAIL;

				memset(&TX_Data[2], 0xff, 12);
			}
		}


         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_DVD_Status_Req
 *===========================================================================*
 * @brief request to set DVD play/stop
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = set DVD play/stop:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = set status:


 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_DVD_Status_Req(const PITS_Message_T * message)
{
   /*Whole_Vin_T    vin_number = {0};*/
   Done_Or_Not_Done_T pits_status = NOT_DONE;
    SIP_RSE_Status_T RSE_Status;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_DVD_ACC_RPT, 2);

      /* Compose Message Data */

		if(message->data[0] == 1)
		RSE_Status.data[0] = 0x03;
		else if(message->data[0] == 0)
		RSE_Status.data[0] = 0x02;
		else
		RSE_Status.data[0] = 0xFF;

		Tr_Info_Lo_2(" set dvd status %d-%d**\n", RSE_Status.data[0], message->data[0]);

		if(message->data[0] == 1 || message->data[0] == 0)
		{
		 VIP_Send(VIPP_EV_RSE_COMMAND,&RSE_Status,sizeof(SIP_RSE_Status_T));
		 TX_Data[0] = (uint8_t) SUCCESS;
		 TX_Data[1] = message->data[0];
		}
		else
		{
		TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
		TX_Data[1] = RSE_Status.data[0];
		}

		pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);

   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Rear_Display_Req
 *===========================================================================*
 * @brief Request Message: Set the Rear Display mode level of the PWM output
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * ICR (GMNA)
 * @param [in] (message->data)[0] = Rear Display Mode
 *                                  0x00 - 0xFF = PWM
 *
 * @param [out] TX_Message[0] = Rear Display Mode
 *                                  0x00 - 0xFF = PWM
 *
 * CCR (GMB)
 * @param [in] (message->data)[0] = Display Number
 *                                  0x01 = Display 1
 *                                  0x02 = Display 2
 *                                  Others = Not Supported
 *
 * @param [in] (message->data)[1] = Rear Display Mode
 *                                  0x00 - 0xFF = PWM
 *
 * @param [out] TX_Message[0] = Display Number
 *                                  0x01 = Display 1
 *                                  0x02 = Display 2
 *                                  Others = Not Supported
 *
 * @param [out] TX_Message[1] = Rear Display Mode
 *                                  0x00 - 0xFF = PWM
 *
 * @pre message->data_size = 1 (ICR) 2(CCR)
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Rear_Display_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t PWM_Pits_Duty = 0;
   #ifdef PITS_CCR_IS
   uint8_t Display_Number = 1;
   #endif
   uint32_t PWM_Pits_Duty_Send = 0;
   uint16_t New_Pits_Duty = 0;
   if (NULL != message)
   {
      #ifdef PITS_CCR_IS
      if (PITS_Get_Sw_Setting() == SIP_SW_ICR)
      {
      #endif
         /* Initial call (new message received -- first call for this message) */

         /* Compose Message Header */
         TX_Bus_ID = message->bus;
         PITS_Misc_Compose_Message_Header(MID_MISC_SET_REAR_DISPLAY_ACK, 2);

         /* Compose Message Data */
         if (message->data_size != 1)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         }
         else
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = message->data[0];

            PWM_Pits_Duty = message->data[0];
            PWM_Pits_Duty_Send = PWM_Pits_Duty * 0x0102;
            if (PWM_Pits_Duty_Send > 0xFFFF)
            {
               New_Pits_Duty = 0xFFFF;
            }
            else
            {
               New_Pits_Duty = (uint16_t) PWM_Pits_Duty_Send;
            }
            PITS_PWM_Set_Output(PITS_REAR_DISPLAY_CHANNEL,
               PITS_REAR_DISPLAY_FREC, New_Pits_Duty);
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
         }
      #ifdef PITS_CCR_IS
      }
      else           /* SIP_SW_GMB */
      {
         /* Initial call (new message received -- first call for this message) */

         /* Compose Message Header */
         TX_Bus_ID = message->bus;
         PITS_Misc_Compose_Message_Header(MID_MISC_SET_REAR_DISPLAY_ACK, 3);

         /* Compose Message Data */
         if (message->data_size != 2)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         }
         else
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            Display_Number = message->data[0];

            PWM_Pits_Duty = message->data[1];
            PWM_Pits_Duty_Send = PWM_Pits_Duty * 0x0102;  /* FIXME Introduce magic number as an appropiate constant */
            if (PWM_Pits_Duty_Send > 0xFFFF)
            {
               New_Pits_Duty = 0xFFFF;
            }
            else
            {
               New_Pits_Duty = (uint16_t) PWM_Pits_Duty_Send;
            }
            if (PITS_REAR_DISPLAY_1 == Display_Number)
            {
               PITS_PWM_Set_Output(PITS_REAR_DISPLAY_CHANNEL,PITS_REAR_DISPLAY_FREC, New_Pits_Duty);
            }
            else
            {
               PITS_PWM_Set_Output(PITS_REAR_DISPLAY_2_CHANNEL,PITS_REAR_DISPLAY_2_FREC, New_Pits_Duty);
            }

            TX_Data[1] = Display_Number;
            TX_Data[2] = message->data[1];
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
         }
      }
      #endif
   }
   return (pits_status);
}


Done_Or_Not_Done_T PITS_Misc_Set_Rear_Bright_Req(const PITS_Message_T * message)
{
   uint8_t PWM_Pits_Duty = 0;
   uint32_t PWM_Pits_Duty_Send = 0;
   uint16_t New_Pits_Duty = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_REAR_BRIGHT_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = message->data[0];

            PWM_Pits_Duty = message->data[0];
            PWM_Pits_Duty_Send = PWM_Pits_Duty * 0x0102;
            if (PWM_Pits_Duty_Send > 0xFFFF)
            {
               New_Pits_Duty = 0xFFFF;
            }
            else
            {
               New_Pits_Duty = (uint16_t)PWM_Pits_Duty_Send;
            }
            PITS_PWM_Set_Output(PITS_REAR_BRIGHT_CHANNEL,
                           PITS_REAR_DISPLAY_FREC,
                           New_Pits_Duty);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
Done_Or_Not_Done_T PITS_Misc_Set_Rearaux_Req(const PITS_Message_T * message)
{
   uint8_t PWM_Channel= 0x03;
   uint32_t PWM_frec = 0xC8;
   uint16_t PWM_duty = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_REARAUX_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = message->data[0];
         if (message->data[0] == 0)
         {
            PWM_duty = 0xE665;
            PITS_PWM_Set_Output(PWM_Channel, PWM_frec,PWM_duty );
         }
         if (message->data[0] == 1)
         {
            PWM_duty = 0x2E14;
            PITS_PWM_Set_Output(PWM_Channel, PWM_frec,PWM_duty );
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Headphone_Req
 *===========================================================================*
 * @brief Receive a Request to set Headphone Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Headphone_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = 0;
   Sys_Audio_Bus_T bus = 0;
   Audio_Detent_T fade = 0x80;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_HEADPHONE_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = message->data[0];
         if (message->data[0] == 0)
         {
            fade = (Audio_Detent_T)Scale(0xFF, 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
         }
         if (message->data[0] == 1)
         {
            fade = (Audio_Detent_T)Scale(0x80, 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
         }
         Audio_Overrides.Fade = true;
         PITS_AU_Enable_Overrides(Audio_Overrides);
         PITS_AU_Set_Fade(zone, bus, fade);

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Headphone_Req
 *===========================================================================*
 * @brief Receive a Request to get Headphone Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Headphone_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = 0;
   Sys_Audio_Bus_T bus = 0;
   uint8_t balance = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_HEADPHONE_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         balance = (uint8_t) Scale(PITS_AU_Get_Fade(zone, bus),
                         FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);
         if (balance >= 0xBB)
         {
            TX_Data[1] = 0;
         }
         else
         {
            TX_Data[1] = 1;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_VIP_Key_Req
 *===========================================================================*
 * @brief Receive a Request to set Headphone Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_VIP_Key_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   PITS_KEY_ID_T pits_key_id = PITS_INVALID_KEY;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_VIP_KEY_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Get VIP Key Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) FAIL;

         if (phy_key_id_to_pits_key_id(key_input.KeyCode, &pits_key_id))
         {
            TX_Data[0] = SUCCESS;
            TX_Data[1] = pits_key_id;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Key_Req
 *===========================================================================*
 * @brief Receive a Request to set Headphone Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Key_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint32_t phy_key_id;
   PITS_KEY_ID_T pits_key_id;
   ExtenalFaceplateFrameDef_T ext_key_frame = {0};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_KEY_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Set Key Request: Message Data Error");
      }
      else
      {
         pits_key_id = message->data[0];
         TX_Data[0] = (uint8_t) FAIL;
         if (pits_key_id_to_phy_key_id(pits_key_id, &phy_key_id))
         {
            TX_Data[0] = SUCCESS;
            TX_Data[1] = pits_key_id;

            if (pits_key_id == 0x0B)
            {
               ext_key_frame.KeyAction = eExternalFaceplateKeyOpt_KeyDown;
               ext_key_frame.KeyCode = phy_key_id;
               ext_key_frame.Rotary_Enc_Tics = 0;
               SAL_Publish(FACEPLATE_KEY_DATA, &ext_key_frame, sizeof(ExtenalFaceplateFrameDef_T));
            }

            ext_key_frame.KeyAction = eExternalFaceplateKeyOpt_KeyShort;
            ext_key_frame.KeyCode = phy_key_id;
            ext_key_frame.Rotary_Enc_Tics = 0;
            Tr_Info_Lo_3("publish key code = %d, action = %d, data = %d\n", ext_key_frame.KeyCode, ext_key_frame.KeyAction, ext_key_frame.Rotary_Enc_Tics);
            SAL_Publish(FACEPLATE_KEY_DATA, &ext_key_frame, sizeof(ExtenalFaceplateFrameDef_T));
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#endif
#if 0
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Ir_Touchscreen_Key_Req
 *===========================================================================*
 * @brief Receive a Request to get Touch screen key
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Ir_Touchscreen_Key_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_IR_TS_KEY_ACK, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Get Touch Screen Key Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t)((uint16_t)ts_data_info[1] >> 8);
         TX_Data[2] = (uint8_t)((uint16_t)ts_data_info[1]);
         TX_Data[3] = (uint8_t)((uint16_t)ts_data_info[2] >> 8);
         TX_Data[4] = (uint8_t)((uint16_t)ts_data_info[2]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#endif
#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Knob_Req
 *===========================================================================*
 * @brief Receive a Request to Add PITS command to override knobs (volume, tune)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Knob Type:
 *                                  0x00   = Volume
 *                                  0x01   = Select (Tune)
 *                                  Others = Not supported
 * @param [in] (message->data)[1] = Knob Delta (from 0x00 to 0xFF)
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Knob Type:
 *                              0x00 = Volume
 *                              0x01 = Select (Tune)
 *
 * @param [out] TX_Message[2] = Knob Delta (from 0x00 to 0xFF)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Knob_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   int8_t knob_offset = 0;
   PITS_KNOB_T pits_knob_type = PITS_INVALID_KNOB;
   ExtenalFaceplateFrameDef_T ext_key_frame = {0};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_VIP_KNOB_RPT, 3);

      TX_Data[0] = FAIL;

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = SUCCESS;
         TX_Data[1] = message->data[0];
         TX_Data[2] = message->data[1];

         pits_knob_type = (PITS_KNOB_T)message->data[0];
         knob_offset = (int8_t)message->data[1];

         if (knob_offset >= 0)
         {
            if (pits_knob_type == PITS_VOLUME_KNOB)
            {
               ext_key_frame.KeyCode = KEY_CODE_CD_KNOB_CW;
            }
            else if (pits_knob_type == PITS_TUNE_KNOB)
            {
               ext_key_frame.KeyCode = KEY_TUNE_KNOB_UP_KEY;
            }
            else
            {
            }

            ext_key_frame.Rotary_Enc_Tics = knob_offset;
         }
         else
         {
            if (pits_knob_type == PITS_VOLUME_KNOB)
            {
               ext_key_frame.KeyCode = KEY_CODE_CD_KNOB_CCW;
            }
            else if (pits_knob_type == PITS_TUNE_KNOB)
            {
               ext_key_frame.KeyCode = KEY_TUNE_KNOB_DOWN_KEY;
            }
            else
            {
            }

            ext_key_frame.Rotary_Enc_Tics = 255 - (uint8_t)knob_offset;
         }
         ext_key_frame.KeyAction = eExternalFaceplateKeyOpt_Rotate;
         Tr_Info_Lo_3("publish key code = %d, action = %d, data = %d\n", ext_key_frame.KeyCode, ext_key_frame.KeyAction, ext_key_frame.Rotary_Enc_Tics);
         SAL_Publish(FACEPLATE_KEY_DATA, &ext_key_frame, sizeof(ExtenalFaceplateFrameDef_T));

         status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
       }
   }

   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Knob_Req
 *===========================================================================*
 * @brief Receive a Request to Add PITS command to override knobs (volume, tune)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Knob Type:
 *                                  0x00   = Volume
 *                                  0x01   = Select (Tune)
 *                                  Others = Not supported
 * @param [in] (message->data)[1] = Knob Delta (from 0x00 to 0xFF)
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Knob Type:
 *                              0x00 = Volume
 *                              0x01 = Select (Tune)
 *
 * @param [out] TX_Message[2] = Knob Delta (from 0x00 to 0xFF)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Knob_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_VIP_KNOB_RPT, 3);

      TX_Data[0] = FAIL;

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = SUCCESS;
         TX_Data[1] = message->data[0];

         /*Power knob*/
         if (message->data[0] == PITS_VOLUME_KNOB)
         {
            TX_Data[2] = vol_knob_test_offset;
         }
         else if (message->data[0] == PITS_TUNE_KNOB)
         {
            TX_Data[2] = tune_knob_test_offset;
         }
         else
         {
             /*nothing to do*/
         }

         status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
       }
   }

   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Knob_Test_Req
 *===========================================================================*
 * @brief Receive a Request to start/stop knob test
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Knob_Test_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_KNOB_TEST_RPT, 2);
      TX_Data[0] = FAIL;

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = SUCCESS;
         TX_Data[1] = message->data[0];
         if (message->data[0] == 1)
         {
            knob_test_flag = 1;
            vol_knob_test_offset = 0;
            tune_knob_test_offset = 0;
         }
         else if (message->data[0] == 2)
         {
            knob_test_flag = 0;
         }
         else
         {
            PITS_PBS_Error_Report("Misc Request: Invalid Message Parameter!");
         }

         status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }

   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_RSE_Ctrl_Req
 *===========================================================================*
 * @brief request to power on/off RSE
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = set RSE power on/off:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = set status:


 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_RSE_Ctrl_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
    SIP_Bool_T RSE_Status = 0x00;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_RSE_CTRL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc RSE Control Requestt: Message Data Error");
      }
      else
      {
         TX_Data[0] = FAIL;
         RSE_Status = (SIP_Bool_T)message->data[0];

         if (RSE_Status == 1 || RSE_Status == 0)
         {
            TX_Data[0] = SUCCESS;
            VIP_Send(VIPP_EV_RSE_EN_CTRL, &RSE_Status, sizeof(SIP_Bool_T));
         }
         else
         {
            TX_Data[0] = (uint8_t)DATA_OUT_OF_RANGE;
         }

         TX_Data[1] = RSE_Status;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Coordinate_Req
 *===========================================================================*
 * @brief Receive a Request to get Realign coordinate.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Coordinate_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint16_t tmp = 0;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_IR_TS_KEY_ACK, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Get Realign Coordinate: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) FAIL;

         if (PITS_Misc_Get_Align_Coordinate(&TX_Data[1]))
         {
            TX_Data[0] = SUCCESS;

            tmp = Util_Get_Big_Endian_U16(&TX_Data[1]);
            Util_Put_Little_Endian_U16(&TX_Data[1], tmp);
            tmp = Util_Get_Big_Endian_U16(&TX_Data[3]);
            Util_Put_Little_Endian_U16(&TX_Data[3], tmp);
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#endif
#if 0
/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Func_Cfg_Req
 *===========================================================================*
 * @brief Receive a Request to get system configuration information
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Function
 * @param [out] TX_Message[2] = Status
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Func_Cfg_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   NP_Vehicle_Configure_T vehicle_cfg = {0};

   if(NULL != message)
   {
      /* Evaluate PITS request data length */
      if (1 != message->data_size)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         /* Compose Message Header */
         TX_Bus_ID = message->bus;
         PITS_Misc_Compose_Message_Header(MID_MISC_GET_FUNC_CFG_RPT, 3);

         /* Update PITS response data */
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         TX_Data[1] = message->data[0];

         if(0x00 == message->data[0])
         {
            /* Get vehicle configuration data from HMI PS */
            vehicle_cfg = HMI_PS_Get_NP_Vehicle_Configure();

            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[2] = (uint8_t) vehicle_cfg.TboxStatus;
         }

         /* Send PITS response message */
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);

      }
   }

   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Func_Cfg_Req
 *===========================================================================*
 * @brief Receive a Request to set system configuration
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Function
 * @param [out] TX_Message[2] = Status
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Func_Cfg_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   NP_Vehicle_Configure_T vehicle_cfg = {0};

   if(NULL != message)
   {
      /* Evaluate PITS request data length */
      if (2 != message->data_size)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         /* Compose Message Header */
         TX_Bus_ID = message->bus;
         PITS_Misc_Compose_Message_Header(MID_MISC_SET_FUNC_CFG_RPT, 3);

         /* Update PITS response data */
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         TX_Data[1] = message->data[0];
         TX_Data[2] = message->data[1];

         if(0x00 == message->data[0])
         {
            if((0x00 == message->data[1]) || (0x01 == message->data[1]))
            {
               TX_Data[0] = (uint8_t) SUCCESS;

               /* Get vehicle configuration data from HMI PS */
               vehicle_cfg = HMI_PS_Get_NP_Vehicle_Configure();

               vehicle_cfg.TboxStatus = message->data[1];

               /* Set vehicle configuration data to HMI PS */
               HMI_PS_Set_NP_Vehicle_Configure(vehicle_cfg);
            }
         }
         /* Send PITS response message */
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);

         if(SUCCESS == TX_Data[0])
         {
            /* Give 6 seconds delay */
            SAL_Sleep(6000);
            /* Execute cold start */
            PITS_Module_Reset();
         }
      }
   }
   return (pits_status);
}
#endif
/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Sw_Setting_Req
 *===========================================================================*
 * @brief Receive a Request to set or query the model configuration variable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Model Configuration:
 *                                  0x00 = Status request
 *                                  0x01 = ICR
 *                                  0x02 = GMB
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Status report:
 *                               0x01 = ICR
 *                               0x02 = GMB
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Di_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   SIP_VIP_Ports_T vip_port;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_DI_STATUS_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (message->data[0] <= 2)
         {
            SAL_Message_T const *msg = NULL;
            SAL_Event_Id_T subscribe_list[] = {EVG_VIP_GPIO_PORT};

            TX_Data[0] = FAIL;
            TX_Data[1] = message->data[0];
            vip_port = message->data[0];
            if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
            {
               VIP_Get_GPIO_Port_Status(gpio_pins_tab[vip_port].port);
               msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

               if((NULL != msg) && (EVG_VIP_GPIO_PORT == msg->event_id))
               {
                  TX_Data[2] = ((uint8_t *)message->data)[0]& gpio_pins_tab[vip_port].mask_code;
               }
            }
            SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
          }
         else
          {
             (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Range Error");
          }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Do_Status_Req
 *===========================================================================*
 * @brief Receive a Request to set or query the model configuration variable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Model Configuration:
 *                                  0x00 = Status request
 *                                  0x01 = ICR
 *                                  0x02 = GMB
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Status report:
 *                               0x01 = ICR
 *                               0x02 = GMB
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Do_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   SIP_VIP_Ports_T vip_port;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_Do_STATUS_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Set Do Status Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = FAIL;
         /*K0R PIN Set*/
         if (message->data[0] <= 2)
         {
            SIP_Set_VIP_Port_T port_status = {0};
	    vip_port = message->data[0];

            port_status.port = gpio_pins_tab[vip_port].port;
            if (message->data[1] == 0 || message->data[1] == 1)
            {
               TX_Data[0] = SUCCESS;
               TX_Data[1] = message->data[0];
               TX_Data[2] = message->data[1];

	       if (message->data[1] == 0)
               {
                  port_status.pin_clear |= gpio_pins_tab[vip_port].mask_code;
               }
               else
               {
                  port_status.pin_set |= gpio_pins_tab[vip_port].mask_code;
               }

               VIP_Set_GPIO_Port_Status(port_status);
               pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
            }
            else
            {
               pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Set Do Status Request: Invalid pin status");
            }
         }
	/*iMX PIN Set*/
         else if (message->data[0] == 7)
         {

         }
         else
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Set Do Status Request: Invalid ID");
         }
      }

   }
   return (pits_status);
}

#ifdef PITS_CCR_IS
/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Sw_Setting_Req
 *===========================================================================*
 * @brief Receive a Request to set or query the model configuration variable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Model Configuration:
 *                                  0x00 = Status request
 *                                  0x01 = ICR
 *                                  0x02 = GMB
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Status report:
 *                               0x01 = ICR
 *                               0x02 = GMB
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Set_Sw_Setting_Req(const PITS_Message_T * message)
{
   uint8_t model_config_req;
   Done_Or_Not_Done_T pits_status = NOT_DONE;


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_SET_SW_SETTING_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else if(message->data[0] > 02){     /* 02 = current max valid PITS model
                                            configuration value -GMB PITS PDD 16.3.90*/

         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data out of range");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         model_config_req =  message->data[0];

         if (model_config_req)      /* if received model config request = 0, it is status request*/
         {
            /* Persistent variable expects ICR = 00 and GMB = 01 (received value - 1)*/
            PITS_Set_Sw_Setting((SIP_Set_Software_Project_T)(model_config_req-1));
         }

         /* Per pits requirement ICR = 01 and GMB = 02 (Persistent value +1)*/
         TX_Data[1] = (uint8_t)(PITS_Get_Sw_Setting()+1);

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}
#endif

/*===========================================================================*
 * FUNCTION: PITS_Get_Touchscreen_Info
 *===========================================================================*
 * @brief Update touch screen information.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
void PITS_Get_Touchscreen_Info (const uint8_t * data, size_t length)
{
   ts_data_info[0] = (uint16_t)Util_Get_Little_Endian_U16(data);
   ts_data_info[1] = (uint16_t)Util_Get_Little_Endian_U16(data + 2);
   ts_data_info[2] = (uint16_t)Util_Get_Little_Endian_U16(data + 4);
   ts_data_info[3] = (uint16_t)Util_Get_Little_Endian_U16(data + 6);
   ts_data_info[4] = (uint16_t)Util_Get_Little_Endian_U16(data + 8);

   ts_data_info[3]  = TSC_Convert_X_Touch_To_Pixels(ts_data_info[3]);
   ts_data_info[4]  = TSC_Convert_Y_Touch_To_Pixels(ts_data_info[4]);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Rtc_Req
 *===========================================================================*
 * @brief Get RTC info
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Rtc_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T   pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_RTC_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Get RTC Request: Message Data Error");
      }
      else
      {
	     SAL_Message_T const  *msg             = NULL;
         SAL_Event_Id_T       subscribe_list[] = {EVG_DATE_TIME};

		 TX_Data[0] = FAIL;
		 if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 5000);

            if((NULL != msg) && (EVG_DATE_TIME == msg->event_id))
            {
               rtc_date_time = *((SIP_Date_Time_T*) msg->data);
               TX_Data[0] = SUCCESS;
			   TX_Data[1] = rtc_date_time.time.hour;
			   TX_Data[2] = rtc_date_time.time.minute;
			   TX_Data[3] = rtc_date_time.time.second;
            }
		 }
         SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Dip_Status_Req
 *===========================================================================*
 * @brief Get RTC info
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Dip_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   SIP_VIP_Ports_T vip_port;

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_DIP_STATUS_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (message->data[0] <= 5)
         {
            SAL_Message_T const *msg = NULL;
            SAL_Event_Id_T subscribe_list[] = {EVG_VIP_GPIO_PORT};

            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = message->data[0];
            vip_port = message->data[0];
            if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
            {
               VIP_Get_GPIO_Port_Status(dip_pins_tab[vip_port].port);
               msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list), 50);

               if((NULL != msg) && (EVG_VIP_GPIO_PORT == msg->event_id))
               {
                  if(((uint8_t *)msg->data)[1] & dip_pins_tab[vip_port].mask_code)
                  {
                     TX_Data[2]  = 0x01;
                  }
                  else
                  {
                     TX_Data[2]  = 0x00;
                  }
               }
            }
            SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
          }
         else
         {
          (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Range Error");
         }
      }
   }
   return (pits_status);
}

/**
 * Convert touch A/D X coordinates to pixel coordinates
 *
 * @param touch_x touch coordinate X location
 * @return X pixel position
 */
static uint16_t TSC_Convert_X_Touch_To_Pixels(uint16_t touch_x)
{
#if 0
   if (touch_x < TSC_X_Min)
   {
      touch_x = TSC_X_Min;
   }
#endif
   if (touch_x > TSC_X_Max)
   {
      touch_x = TSC_X_Max;
   }
   return ((touch_x - TSC_X_Min) * TSC_LCD_Width) / (TSC_X_Max - TSC_X_Min + 1);
}


/**
 * Convert touch A/D Y coordinates to pixel coordinates
 *
 * @param touch_y touch coordinate Y location
 * @return Y pixel position
 */
static uint16_t TSC_Convert_Y_Touch_To_Pixels(uint16_t touch_y)
{
#if 0
   if (touch_y < TSC_Y_Min)
   {
      touch_y = TSC_Y_Min;
   }
#endif
   if (touch_y > TSC_Y_Max)
   {
      touch_y = TSC_Y_Max;
   }
   return ((touch_y - TSC_Y_Min) * TSC_LCD_Height) / (TSC_Y_Max - TSC_Y_Min + 1);
}

#if defined (GWM_CHB041)
/*
 * Please refer to the detailed description in pits_misc_services.h.
 */
void PITS_Get_Key_Pressed(const uint8_t * data, size_t length)
{
   ExtenalFaceplateFrameDef_T* key_data;
   key_data = (ExtenalFaceplateFrameDef_T*)data;

   key_input.KeyAction = key_data->KeyAction;
   key_input.KeyCode = key_data->KeyCode;
   key_input.Rotary_Enc_Tics = key_data->Rotary_Enc_Tics;
}
#endif

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
/*
 * Please refer to the detailed description in pits_misc_services.h.
 */
void PITS_Get_Key_Pressed(const uint8_t * data, size_t length)
{
   ExtenalFaceplateFrameDef_T* key_data;
   key_data = (ExtenalFaceplateFrameDef_T*)data;

   if ((key_data->KeyAction == eExternalFaceplateKeyOpt_Rotate) && (key_data->Rotary_Enc_Tics == 0))
   {
      /*ignore knob release info*/
   }
   else
   {
      key_input.KeyAction = key_data->KeyAction;
      key_input.KeyCode = key_data->KeyCode;
      key_input.Rotary_Enc_Tics = key_data->Rotary_Enc_Tics;

      /*Record knob test info*/
      if (knob_test_flag)
      {
         switch (key_input.KeyCode)
         {
            case KEY_CODE_CD_KNOB_CW:
               vol_knob_test_offset += key_input.Rotary_Enc_Tics;
               break;
            case KEY_CODE_CD_KNOB_CCW:
               vol_knob_test_offset-= key_input.Rotary_Enc_Tics;
               break;
            case KEY_TUNE_KNOB_UP_KEY:
               tune_knob_test_offset += key_input.Rotary_Enc_Tics;
               break;
            case KEY_TUNE_KNOB_DOWN_KEY:
               tune_knob_test_offset -= key_input.Rotary_Enc_Tics;
               break;
            default:
               break;
         }
      }
   }
}

/**
 * Map from phy key id to the pits key id.
 */
bool_t phy_key_id_to_pits_key_id(uint32_t phy_key_id, PITS_KEY_ID_T *pits_key_id)
{
   int8_t i;
   PITS_KEY_ID_T key = (*pits_key_id);
   bool_t ret = false;

   for (i = (Num_Elems(key_id_translation) - 1); i >= 0; i--)
   {
      if (key_id_translation[i].phy_id == phy_key_id)
      {
         key = key_id_translation[i].pits_key_id;
         ret = true;
         break;
      }
   }

   (*pits_key_id) = key;

   return(ret);
}

/**
 * Map from the pits key id to  phy key id.
 */
bool_t pits_key_id_to_phy_key_id(PITS_KEY_ID_T pits_key_id, uint32_t *phy_key_id)
{
   int8_t i;
   SIP_Key_Msgs_IDs_T key = (*phy_key_id);
   bool_t ret = false;

   for (i = (Num_Elems(key_id_translation) - 1); i >= 0; i--)
   {
      if (key_id_translation[i].pits_key_id == pits_key_id)
      {
         key = key_id_translation[i].phy_id;
         ret = true;
         break;
      }
   }

   (*phy_key_id) = key;

   return(ret);
}


#endif


/*===========================================================================*
 * FUNCTION: PITS_Misc_Get_Board_Type_Req
 *===========================================================================*
 * @brief Request the board type
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Misc_Get_Board_Type_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   Board_Type_Config_T board_config = {false, BOARD_TYPE_UNKNOWN};

   if (NULL != message)
   {
      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_Misc_Compose_Message_Header(MID_MISC_GET_BOARD_TYPE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         Get_Board_Type(&board_config);
         if(board_config.valid)
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            TX_Data[1] = board_config.type + 1;
         }
         else
         {
            TX_Data[0] = (uint8_t) FAIL;
            TX_Data[1] = BOARD_TYPE_UNKNOWN;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);
      }

   }
   return (pits_status);
}
/*===========================================================================*/
/*!
 * @file pits_misc_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 20June2017 Sunil G (vj430z) Rev.7
 * ctc_ec#:186708: Coverity warnings fix.
 *
 * 04May2017  Sunil G (vj430z) Rev. 6
 * ctc_ec#182828: Impl change in PITS\MISC RTC service by getting RTC values from VIP
 *
 * 03Apr2017  Sunil G (vj430z) Rev. 5
 * ctc_ec#180296: Implement Get Board type status command for PITS.
 *
 * 09Jan2017  Mandar Bhat (tzl4my) Rev. 4
 * ctc_ec#172934: Vehicle Configuration's Read and Write Parameter for PITS.
 *
 * 15July2016 Rahul Chirayil (vzm576) Rev.3
 * ctc_ec#157983: Implement function configuration services for T-Box.
 *
 * 20June2016 Rahul Chirayil (vzm576) - Rev 2
 * ctc_ec#156521: Update Get Discrete Input Status service (1A F8) for Board type verification.
 *
 * 31-May-2012 Marco Castillo Rev 55
 * Task kok_basa#100232:  Request Microphone Status 1A90/91
 *
 * 29-May-2012 Juan Carlos Castillo  Rev 54
 * Task kok_basa#99843: CLKOUT pin enable/disable PIT
 *
 * 23-May-2012 Darinka Lopez  Rev 53
 * Task kok_basa#96579 - Update VIN message
 *
 * 16-May-2012 Oscar Vega  Rev 52
 * Task kok_basa#96906 - MID E0 - SW/HW ID Version
 *
 * 04 May 2012 Miguel Garcia Rev 51
 * Include new Swids
 *
 * 1-May-2012 Darinka Lopez  Rev 50
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 10 Apr 2012 Miguel Garcia Rev 49
 * Fix Set power function
 *
 * 14-Mar-2012 Darinka Lopez  Rev 48
 * Task kok_basa#82581: Update part number lenght for SBX program
 * Fix lenght in SWIDs for SBX program.
 *
 * 29-Jan-2012 Darinka Lopez  Rev 47
 * Task kok_basa#79858: Update SWID function for K0R Boot ID.
 * Remove warning issue.
 *
 * 29-Jan-2012 Darinka Lopez  Rev 46
 * Task kok_basa#79858: Update SWID function for K0R Boot ID.
 * Add callouts functions for swids..
 *
 * 31-Jan-2012 Erick Sanchez Rev 45
 * SCR kok_basa#20751: PITS: PIT MSID 1A - MID E0 subservice 20
 * Fix: Add  Command not supported to the subservice.
 *
 * 27 Jan 2012 Miguel Garcia Rev 44
 * Fix safe strncpy issue
 *
 * 25-Jan-2012 Erick Sanchez Rev 43
 * SCR kok_basa#19539: PITS: MSID 1A - MID 12 - Exit Diagnostics Mode
 * Fix: Implement PITS (MSID 1A - MID 12) to Exit Diagnostics Mode
 *
 * 19-Jan-2012 Oscar Vega  Rev 42
 * SCR kok_basa#19539: PITS: MSID 1A - MID 16 - Module Reset (cold start)
 * SCR kok_basa#19537: PITS: MSID 1A - MID 14 -  Enter Sleep Mode
 * Fix: Implement desip messages to reset and enter sleep mode.
 *
 * 17-Jan-2012 Erick Sanchez  Rev 41
 * SCR kok_basa#17788 PITs: SWID hw/sw version shall be according to each project
 * Fix: remove include file called #include "betula_sdk_version.h"
 *
 * 16-Jan-2012 Erick Sanchez  Rev 40
 * SCR kok_basa#17788 PITs: SWID hw/sw version shall be according to each project
 * Fix: Create an enumeration of PITS MISC Servces MSID 1A MID E0 subservices 11, 12, 20, 21, 25,
 * 50, 51 52, 53, 54, 55, 56, 57.
 *
 * 13-Jan-2012 Chris Baker    Rev 38
 * SCR kok_basa#20129: PITS Bluetooth Software ID's Getter Functions needed
 *  - Implement SW ID $30 and $33
 *  - Return errors for unsupported SW ID $20, $31, $32
 *
 * 13-Jan-2012 Darinka Lopez  Rev 37
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move specific functions for TMC.
 *
 * 06-Jan-2012 Erick Sanchez  Rev 34
 * SCR kok_basa#18683 PITS MSID 1A - MID E0 - Subservice $25 (TMC)
 * Fix: Change Subservice TMC 70 by 25.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 33
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 32
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 08-Dic-2011 Erick Sanchez Rev 31
 * SCR kok_basa#17782: Implement PIT part number (MSID=1A, MID=E2).
 * Fix: Implement changes to get PIT part number.
 *
 * 23 Nov 2011 Miguel Garcia
 * Include FBL Swid
 *
 * 18 Nov 2011 Miguel Garcia 24
 * Include ICR power on.
 *
 * 08-Nov-2011 Juan Carlos Castillo  Rev 28
 * SCR kok_basa#17470: Create PIT to support TMC HW/SW message manufacturing test
 * Fix: add local variable declaration for tmc_revision.
 *
 * 07-Nov-2011 Juan Carlos Castillo  Rev 27
 * SCR kok_basa#17470: Create PIT to support TMC HW/SW message manufacturing test
 * Fix: add local variable declaration for tmc_revision.
 *
 * 07-Nov-2011 Juan Carlos Castillo  Rev 26
 * SCR kok_basa#17470: Create PIT to support TMC HW/SW message manufacturing test
 * Fix: add local variable declaration for tmc_revision.
 *
 * 07-Nov-2011 Juan Carlos Castillo  Rev 25
 * SCR kok_basa#17470: Create PIT to support TMC HW/SW message manufacturing test
 * Fix: Include PIT to request TMC revision information.
 *
 * 31 Oct 2011 Miguel Garcia Rev 24
 * Include voice swids
 *
 * 26 Oct 2011 Oscar Vega Rev 23
 * kok_basa#16264: Implement MSID(1Ah) - Other Misc. Services.
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 19 May 2011 Miguel Garcia
 * Remove GM_PWM_Amp_Channel
 *
 * 12 May 2011 Miguel Garcia
 * Remove GM_PWM_Amp_Channel
 *
 * 18 Mar 2011 Miguel Garcia Rev13
 * Include cpid services
 *
 * 13-Jan-2011 Miguel Garcia  Rev 12
 * Remove unused Pits Services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 8
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 7
 *  Merged: Fix parallel versions
 *
 * 08-Jul-2010 Miguel Garcia  Rev 6
 * SCR kok_basa#1674: Implement Diagnostic Services PITS for CPIDs and DPIDs.
 *
 * 12-May-2010 Pramod N K  Rev 5
 * Shaoli needs this update for her flash cal changes.
 * This update is not tested.
 *
 * 06-May-2010 Jorge I. Castanon  Rev 4
 * SCR kok_basa#1457: Add PITS E2/E3 to respond to request from GM Diag DIDs CX & DX.
 *
 * 04-May-2010 Miguel Garcia  Rev 3
 * SCR kok_basa#1397: Implement High Priority CPIDs and DPIDs.
 *
 * 20-Oct-2009 David Mooar  Rev 2
 * SCR kok_aud#63562: Move PITS Read SWID to Misc Services.
 *
 * 10-Sept-2009 David Mooar  Rev 1
 * SCR kok_aud#62401/62406/62439/62488: Implement Misc Services.
 */
/*===========================================================================*/
