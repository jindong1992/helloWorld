/*===========================================================================*/
/**
 * @file pits_configuration.c
 *
 * Product Specific Configuration for PITS.
 *
 * %full_filespec:pits_configuration.c~1:csrc:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:39 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    Product Specific Configuration for PITS,
 *    includes all busses and applications supported.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS - Product Integrated Test Strategy.
 *    - MSID - Message Set Identifier
 *    - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/**
 * Common configuration headers. DO NOT TOUCH!!!
 */
#   include "pits_application_manager.h"
#   include "pits_configuration.h"
#   include "pits_manager_cfg.h"
#   include "pits_message_handler.h"

/**
 * Miscellaneous header
 */
#   include <string.h>
#   include "string_res.h"
#   include "em.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID, 0);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * List of the interfaces to all applications (standard and project specific)
 * supported by this PITS implementation. There must be an entry into this table of
 * the type PITS_Application_Interface_T for each application that you wish to support.
 */

#undef PITS_INTERFACE_INDEX

#define PITS_INTERFACE_INDEX(index) (index),

static PITS_Application_Interface_T *PITS_Interfaces[] = {
   PITS_INTERFACE_TABLE
};

#undef PITS_INTERFACE_INDEX

/**
 * List of Bearing Busses to be supported by this PITS implementation.
 * There must be an entry of the type PITS_Bearing_Bus_T for each bus to
 * be supported.
 */
#undef PITS_BUS_INDEX

#define PITS_BUS_INDEX(index, interface)  (interface),

static PITS_Bearing_Bus_T *const Bearing_Busses[] = {
   PITS_BUS_TABLE
};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Configuration_Initialize
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Configuration_Initialize(void)
{
   PITS_Configure_Bearing_Busses(Bearing_Busses, Num_Elems(Bearing_Busses));
   PITS_Configure_Receive_Routing(PITS_Interfaces, Num_Elems(PITS_Interfaces));
}

/*===========================================================================*
 * FUNCTION: PITS_Get_MSID_Name
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Success_Or_Fail_T PITS_Get_MSID_Name(const uint8_t msid, uint8_t * data)
{
   uint8_t name_index = 0;
   uint8_t msid_max = 0;
   uint8_t msid_num = 0;

   /* Loop through all interfaces */
   for (name_index = 0; name_index < Num_Elems(PITS_Interfaces); name_index++)
   {
      /* A PITS Application may have multiple MSIDs, ensure all MSIDs are accounted for */
      msid_max = (PITS_Interfaces[name_index])->rx_message_set_count;
      for (msid_num = 0; msid_num < msid_max; msid_num++)
      {
         if (msid == ((PITS_Interfaces[name_index])->rx_message_sets)[msid_num].MSID)    /* MSID found */
         {
            data[0] = (uint8_t) (strlen(((PITS_Interfaces[name_index])->rx_message_sets)[msid_num].MSID_Name));
            memcpy(&data[1],
                    &((((PITS_Interfaces[name_index])->rx_message_sets)[msid_num].MSID_Name)[0]),
                    ((size_t) data[0])+1);
            return (SUCCESS);   /* MSID found string name copied, so exit */
         }
      }
   }
   /* Loop through all interfaces, and MSID not found */
   return (FAIL);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_MSID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Success_Or_Fail_T PITS_Get_MSID(const uint8_t msid)
{
   uint8_t local_index;
   uint8_t msid_max;
   uint8_t msid_num;

   /* Loop through all interfaces */
   for (local_index = 0; local_index < Num_Elems(PITS_Interfaces); local_index++)
   {
      /* A PITS Application may have multiple MSIDs, ensure all MSIDs are accounted for */
      msid_max = (PITS_Interfaces[local_index])->rx_message_set_count;
      for (msid_num = 0; msid_num < msid_max; msid_num++)
      {
         if (msid == ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].MSID)    /* MSID found */
         {
            return (SUCCESS);     /* MSID found, return 'SUCCESS' */
         }
      }
   }
   /* Loop through all interfaces, and MSID not found */
   return (FAIL);
}
/*===========================================================================*
 * FUNCTION: PITS_Get_MID
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Success_Or_Fail_T PITS_Get_MID(const uint8_t msid, const uint8_t mid)
{
   uint8_t local_index;
   uint8_t msid_max;
   uint8_t msid_num;
   uint8_t mid_max;
   uint8_t mid_num;

   /* Loop through all interfaces */
   for (local_index = 0; local_index < Num_Elems(PITS_Interfaces); local_index++)
   {
      /* A PITS Application may have multiple MSIDs, ensure all MSIDs are accounted for */
      msid_max = (PITS_Interfaces[local_index])->rx_message_set_count;
      for (msid_num = 0; msid_num < msid_max; msid_num++)
      {
         if (msid == ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].MSID)    /* MSID found */
         {
            /* Search for MIDs in the Receive table */
            mid_max = ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].message_count;
            for (mid_num = 0; mid_num < mid_max; mid_num++)
            {
               if (mid == ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].message_ids[mid_num].MID)
               {
                  return (SUCCESS);     /* MID found, return 'SUCCESS' */
               }
            }

            /* Search for MIDs in the Transmit table */
            if (NULL != ((PITS_Interfaces[local_index])->tx_message_sets))
            {
               mid_max = ((PITS_Interfaces[local_index])->tx_message_sets)[msid_num].message_count;
               for (mid_num = 0; mid_num < mid_max; mid_num++)
               {
                  if (mid == ((PITS_Interfaces[local_index])->tx_message_sets)[msid_num].MID[mid_num])
                  {
                     return (SUCCESS);  /* MID found, return 'SUCCESS' */
                  }
               }
            }
            return (FAIL);      /* MSID found, but MID not found, return 'FAIL' */
         }
      }
   }
   /* Loop through all interfaces, and MSID not found */
   return (FAIL);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_MSID_List
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Get_MSID_List(uint8_t * message_id_bits)
{
   uint8_t local_index;
   uint8_t msid_max;
   uint8_t msid_num;
   uint8_t msid;

   /* Loop through all interfaces */
   for (local_index = 0; local_index < Num_Elems(PITS_Interfaces); local_index++)
   {
      /* A PITS Application may have multiple MSIDs, ensure all MSIDs are accounted for */
      msid_max = (PITS_Interfaces[local_index])->rx_message_set_count;
      for (msid_num = 0; msid_num < msid_max; msid_num++)
      {
         msid = ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].MSID;
         message_id_bits[msid / 8] |= (uint8_t) (0x01 << (7 - msid % 8));
      }
   }
}

/*===========================================================================*
 * FUNCTION: PITS_Get_MID_List
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Success_Or_Fail_T PITS_Get_MID_List(const uint8_t msid, uint8_t * message_id_bits)
{
   uint8_t local_index;
   uint8_t msid_max;
   uint8_t msid_num;
   uint8_t mid_max;
   uint8_t mid_num;
   uint8_t mid;

   /* Loop through all interfaces */
   for (local_index = 0; local_index < Num_Elems(PITS_Interfaces); local_index++)
   {
      /* A PITS Application may have multiple MSIDs, ensure all MSIDs are accounted for */
      msid_max = (PITS_Interfaces[local_index])->rx_message_set_count;
      for (msid_num = 0; msid_num < msid_max; msid_num++)
      {
         if (msid == ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].MSID)    /* MSID found */
         {
            /* Search for MIDs in the Receive table */
            mid_max = ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].message_count;
            for (mid_num = 0; mid_num < mid_max; mid_num++)
            {
               mid = ((PITS_Interfaces[local_index])->rx_message_sets)[msid_num].message_ids[mid_num].MID;
               message_id_bits[mid / 8] |= (uint8_t) (0x01 << (7 - mid % 8));
            }

            /* Search for MIDs in the Transmit table */
            if (NULL != ((PITS_Interfaces[local_index])->tx_message_sets))
            {
               mid_max = ((PITS_Interfaces[local_index])->tx_message_sets)[msid_num].message_count;
               for (mid_num = 0; mid_num < mid_max; mid_num++)
               {
                  mid = ((PITS_Interfaces[local_index])->tx_message_sets)[msid_num].MID[mid_num];
                  message_id_bits[mid / 8] |= (uint8_t) (0x01 << (7 - mid % 8));
               }
            }
            return (SUCCESS);   /* MSID found and array filled, so exit */
         }
      }
   }
   /* Loop through all interfaces, and MSID not found */
   return (FAIL);
}

void RemRcvr_Enable_Override(void)
{
   /*Todo Not used on ICR*/
}

void RemRcvr_Disable_Override(void)
{
   /*Todo Not used on ICR*/
}
/*===========================================================================*/
/*!
 * @file pits_configuration.c
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 10
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 9
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 27 Jan 2012 Miguel Garcia
 * Fix Strcpy issue
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 13 Jan 2011 Miguel Garcia
 * Remove unused Pits
 *
 * + 2009-06-10  Larry Ong
 *    - Decouple application interfaces from MSID definitions. 
 *    - Seperate standard MSIDs (0 - 16) from project specific MSIDs (17 - 155).
 *    - Move standard MSIDs definition to pits_configuration.h.
 *
 * - 2008-06-05  Larry Ong
 *    - Added MSID string name.
 *
 * - 2008-05-13  Larry Ong
 *    - Used X-macro to define the MSIDs and Application Interfaces.
 *    - Used X-macro to define the Bearing Busses.
 *    - Moved pits_configuration.c file into the bb_pits_core block.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo list.
 *
 * - 2007-10-31  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-10-01  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-07  Larry Ong
 *    - Added PITS Control Services.
 *
 * - 2007-06-02  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-08  Mike Gerig
 *    - Created initial file.
 */
/*===========================================================================*/
