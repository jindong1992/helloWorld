/*===========================================================================*/
/**
 * @file pits_soh_services.c
 *
 * PITS Service Function Definitions
 *
 * %full_filespec:pits_soh_services.c~1:csrc:ctc_ec#21 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:55 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module defines the PITS Basic Service DTC messages.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS - Product Integrated Test Strategy.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "convert_endian.h"
#   include "dbg_trace.h"
#   include "diag_ps.h"
#   include "dtc_handler.h"
#   include "em.h"
#   include "pits_soh_services.h"
#   include "pits_soh_services_cbk.h"
#   include <string.h>
#   include "utilities.h"
#   include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 4);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_pss_initialize(void);
static void pits_pss_compose_message_header(uint8_t mid, uint16_t size);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PSS_RX_INDEX
#define MID_PSS_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_pss_rx_messages[] = {
   MID_PSS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PSS_TX_INDEX
#define MID_PSS_TX_INDEX(name, mid) (mid),

static const uint8_t pits_pss_tx_messages[] = {
   MID_PSS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PSS_RX_INDEX
#define MSID_PSS_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_pss_rx_message_sets[] = {
   MSID_PSS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PSS_TX_INDEX
#define MSID_PSS_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_pss_tx_message_sets[] = {
   MSID_PSS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/

static uint8_t pss_tx_bus_id;                  /* ID of the bearing bus on which to send response */
static PITS_Message_T pss_message;             /* for construction of a pbs message to be transmitted */
static uint8_t pss_tx_data[PITS_MAX_MESSAGE_SIZE];

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_PSS_Interface = {
   pits_pss_initialize,
   pits_pss_rx_message_sets,
   Num_Elems(pits_pss_rx_message_sets),
   pits_pss_tx_message_sets,
   Num_Elems(pits_pss_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: pits_pss_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_pss_initialize(void)
{
   pss_tx_bus_id = 0;
   memset(&pss_message, 0x00, sizeof(PITS_Message_T));
   memset(pss_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
}


/*===========================================================================*
 * FUNCTION: PITS_PSS_All_DTC_Status_Req
 *===========================================================================*
 * @brief Receive a Request For all DTCs
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pss_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pss_tx_data[1] = number of DTCs
 * @param [out] pss_tx_data[2, 4, ..., n] = dtc id
 * @param [out] pss_tx_data[3, 5, ..., n+1] = dtc status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_PSS_All_DTC_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   DTC_T dtcData;
   uint16_t txDataIndex = 0;
   uint8_t dtcIndex = 0;

   memset(&dtcData, 0, sizeof(dtcData));

   if (NULL != message)
   {
      /* Compose Message Header */
      pss_tx_bus_id = message->bus;
      pits_pss_compose_message_header(MID_PSS_SOH_DTC_ALL_RPT, ((NUM_FIXED_DTCS * 4) + 2));

      /* Compose Message Data */
      pss_tx_data[0] = (uint8_t)COMMAND_NOT_SUPPORTED;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PSS SOH DTC ALL REQUEST: Message Data Error");
      }
      else
      {
         pss_tx_data[txDataIndex++] = (uint8_t)SUCCESS;
         pss_tx_data[txDataIndex++] = (uint8_t) NUM_FIXED_DTCS;

         for (dtcIndex = 0; dtcIndex < NUM_FIXED_DTCS; dtcIndex++)
         {
            PS_Get_DTC_Info(dtcIndex, &dtcData);

            Util_Put_Big_Endian_U24(&pss_tx_data[txDataIndex], dtcData.id.number);
            txDataIndex = txDataIndex + 3;

            pss_tx_data[txDataIndex++] = (uint8_t) dtcData.status.dtcStatusByte;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pss_message);
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PSS_Clear_All_DTC_Req
 *===========================================================================*
 * @brief Receive a Request for clear all dtc
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pss_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pss_tx_data[1] = number of DTCs
 * @param [out] pss_tx_data[2, 4, ..., n] = dtc id
 * @param [out] pss_tx_data[3, 5, ..., n+1] = dtc status
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_PSS_Clear_All_DTC_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   DTC_T dtcData;
   uint16_t txDataIndex = 0;
   uint8_t dtcIndex = 0;

   memset(&dtcData, 0, sizeof(dtcData));

   if (NULL != message)
   {
      /* Compose Message Header */
      pss_tx_bus_id = message->bus;
      pits_pss_compose_message_header(MID_PSS_SOH_CLEAR_ALL_DTC_STATUS_RPT, ((NUM_FIXED_DTCS * 4) + 2));

      /* Compose Message Data */
      pss_tx_data[txDataIndex] = (uint8_t)COMMAND_NOT_SUPPORTED;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PSS SOH DTC CLEAR ALL DTC REQUEST: Message Data Error");
      }
      else
      {
         pss_tx_data[txDataIndex++] = (uint8_t)SUCCESS;
         pss_tx_data[txDataIndex++] = (uint8_t) NUM_FIXED_DTCS;

         /* Clear all DTC */
         Dg_Clear_All_DTC();

         for(dtcIndex = 0; dtcIndex < NUM_FIXED_DTCS; dtcIndex++)
         {
            PS_Get_DTC_Info(dtcIndex, &dtcData);
            Util_Put_Big_Endian_U24(&pss_tx_data[txDataIndex], dtcData.id.number);
            txDataIndex = txDataIndex + 3;

            pss_tx_data[txDataIndex++] = (uint8_t) dtcData.status.dtcStatusByte;
         }
         /* Sent PITS message */
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pss_message);
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PSS_compose_message_header
 *===========================================================================*
 * @brief Fill the message transmit buffer with the DTC Status Array data
 * @returns
 * @param
 * @pre
 * @post
 */
/*===========================================================================*/
void pits_pss_compose_message_header(uint8_t mid, uint16_t size)
{
   /* Compose Message Header */
   pss_message.bus = pss_tx_bus_id;
   pss_message.data = pss_tx_data;
   pss_message.MSID = MSID_SOH_SERVICES;
   pss_message.MID = mid;
   pss_message.data_size = size;
   /* Compose Message Data */
   memset(&pss_tx_data[0], 0, size);
}
/*===========================================================================*/
/*!
 * @file pits_soh_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 30 0ct 2012 Miguel Garcia Rev 11
 * Task kok_basa#126309. Remove unused session timeout functions
 *
 *  06-Sep-2012 Darinka L�pez Rev 10
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 23-Aug-2012 Miguel Garcia 9
 * Task kok_basa#115924 - Update Pits_soh_services for SBX
 *
 * 1-May-2012 Darinka Lopez  Rev 8
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 31-Mar-2012 Oscar Vega 7
 * Task kok_basa#86597 - MID 1A/1B - Clear all DTCs.
 *
 * 30-Mar-2012 Oscar Vega 6
 * Task kok_basa#86394 - MID 1C/1D - Request/Report reset enable bits to Default State.
 *
 * 16-Jan-2012 Oscar Vega  Rev 5
 * SCR kok_basa#19527: PITS: MSID 05 - MID 16 - Get Enable Status
 * SCR kok_basa#19528: PITS: MSID 05 - MID 18 - Set enable status (Single DTC)
 * Fix: Function to set and get enable status from DTCs.
 *
 * 11-Jan-2012 Oscar Vega  Rev 4
 * SCR kok_basa#18348: Update dtc enum in soh services
 * Fix: DTC enum was updated accordign with supoprted DTCs.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 23-Nov-2011 Oscar Vega  Rev 1
 * SCR kok_basa#17216 :  Implement MSID(05h) - SOH Services.
 * Implement PITS SOH services.
 * Initial Revision
 *    - Created initial file.
 */
/*===========================================================================*/
