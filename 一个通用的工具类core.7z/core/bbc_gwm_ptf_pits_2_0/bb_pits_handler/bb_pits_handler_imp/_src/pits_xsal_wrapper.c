/*===========================================================================*/
/**
 * @file pits_xsal_wrapper.c
 *
 * PITs Bearing Bus Wrapper for the XSAL protocol.
 *
 * %full_filespec:pits_xsal_wrapper.c~2:csrc:ctc_ec#18 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Wed Feb  8 17:14:38 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "pits_desip_wrapper.h"
#   include "pits_message_handler_cbk.h"
#   include "em.h"
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
#include "can_interface.h"
#endif
#ifdef FORD_C490
#include "pcan_appl_proxy.h"
#endif
#include <string.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID_XSAL, 1);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_SERVICE_31                   0x31
#define PITS_SERVICE_31_MASK      0x40

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint8_t tx_buffer[PITS_MAX_MESSAGE_SIZE];
static uint8_t rx_buffer[PITS_MAX_MESSAGE_SIZE];
/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
PITS_Bearing_Bus_T GM_Diag_Bearing_Bus = {
   0,
   PITS_MAX_MESSAGE_SIZE,
   PITS_MAX_PACKET_SIZE,
   {0, 0, 0, 0, tx_buffer},
   {0, 0, 0, 0, rx_buffer},
   {(Packetization_Stage_T) 0, 0, false, 0},
   {(Packetization_Stage_T) 0, 0, false, 0},
   &send_function,
};

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_DESIP_Receive_Function
 *===========================================================================
 *
 * Called by the Bearing Bus when a message is received for PITS.
 *
 * Please refer to the header file for more detailed information.
 *
 *===========================================================================*/
void PITS_DESIP_Receive_Function(const uint8_t * data, uint16_t length)
{
   PITS_Message_Handler_Receive_Packet(&GM_Diag_Bearing_Bus, data, length);
}

/*===========================================================================*/
/**
 *===========================================================================
 * FUNCTION: send_function
 *===========================================================================
 * @brief Called by the PITS Message Handler to transmit a PITS packet/message.
 *
 * @returns 
 *    true - if message transmit request was accepted.
 *    false - if message transmit request was rejected or input parameter is invalid.
 *
 * @param
 *    *data - pointer to a received message to be handled by PITS.
 *    length - received message length.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * @param length
 *   Number of data bytes included in *data.
 *
 */
/*===========================================================================*/
bool_t send_function(uint8_t * data, uint16_t length)
{
   bool_t status = true;
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT)
   CAN_PITS_MSG_T respond_buffer;

   respond_buffer.buf[0] = length + 1;
   respond_buffer.buf[1] = PITS_SERVICE_31 | PITS_SERVICE_31_MASK;
   memcpy(&(respond_buffer.buf[2]), data, length);

   CAN_Manf_Diagnostics_Tx_Msg(respond_buffer);
   /* 50ms Delay added after sending each packet to ensure CAN send the packet successfully */
   SAL_Sleep(50);
#endif

#ifdef FORD_C490
   uint8_t respond_buffer[8] = {0};

   respond_buffer[0] = length + 1;
   respond_buffer[1] = PITS_SERVICE_31 | PITS_SERVICE_31_MASK;
   memcpy(&respond_buffer[2], data, length);
   PCAN_Set_PITS_Response(respond_buffer, length + 2);   
#endif

   return (status);
}

/*===========================================================================*/
/*!
 * @file pits_xsal_WRAPPER.C
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 08-Feb-2017  Rahul Chirayil (vzm576) Rev 4
 * ctc_ec#174798: Add 50msc delay between data packets send from PITS to CAN
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 3
 *  Merged: Fix parallel versions
 *
 * 25-May-2010 Miguel Garcia  Rev 2
 * SCR kok_basa#1674: Change Bearing Bus name to GM_Diag_Bearing_Bus.
 *
 * - 2008-10-09  Yi Liu
 *    - Created initial file.
 */
/*===========================================================================*/
