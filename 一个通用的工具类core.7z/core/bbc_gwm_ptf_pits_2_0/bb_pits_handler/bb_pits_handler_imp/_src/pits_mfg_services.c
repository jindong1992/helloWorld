/*===========================================================================*/
/**
 * @file pits_mfg_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_mfg_services.c~2:csrc:ctc_ec#7 %
 * @version %version:2 %
 * @author  %derived_by:vj430z %
 * @date    %date_modified:Tue Mar 28 15:06:07 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_configuration.h"
#include "pits_mfg_services.h"
#include "pits_mfg_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "vip_proxy.h"
#include "pbc_trace.h"
#include "pits_programming_services.h"
#include "pits_programming_services_cbk.h"
#include "pits_processing_manufacturing.h"
#include "pits_processing_manager.h"
#include "ps_ds_friend.h"

EM_FILENUM(PITS_MODULE_ID_5, 20);   /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define MAX_IGNITION_CYCLE    100

#define PITS_MD5_HEADER_SIZE 10

#define PITS_MD5_CHECKSUM_SIZE 16

#define PITS_MD5_CONFIRMATION    1

#define PITS_MD5_NO_BYTES_CHKSUM   1

#define PITS_GET_PARTITION_STATUS      0
#define PITS_SET_RW_PARTITION_STATUS   1
#define PITS_SET_RO_PARTITION_STATUS   2

#define PITS_REFLASH_STATUS            0
#define PITS_START_REFLASH             1

#define PITS_MD5_CONFIRMATION_RESP     3
#define PITS_MD5_HEADER_CALC_SIZE      11
#define PITS_MD5_ALGORITHM_INDEX       5


/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum mds_state_bytes_tag
{
   MDS_NOT_STARTED,
   MDS_IN_PROGRESS,
   MDS_COMPLETE,
   MDS_ERROR,
   MDS_NUM_BYTES
} mds_state_bytes_type;

typedef enum aux_jack_state_pit_Tag
{
   PITS_AUX_JACK_UNKNOWN,
   PITS_JACK_NOT_PRESENT,
   PITS_AUX_JACK_PRESENT
} aux_jack_state_pit_type;

#ifndef GMB_CCR_IS
typedef struct key_to_set_vss_tag
{
   uint16_t             set_value;
   uint16_t             set_percentage;
} key_to_set_vss_type;

static const key_to_set_vss_type Set_Vss_Table[] =
{  /* index         byte*/
 { 1030,      18 },
 { 980,      17 },
 { 920,      16 },
 { 870,      15 },
 { 810,      14 },
 { 760,      13 },
 { 710,      12 },
 { 650,      11 },
 { 600,      10 },
 { 540,      9 },
 { 490,      8 },
 { 430,      7 },
 { 370,      6 },
 { 310,      5 },
 { 250,      4 },
 { 190,      3 },
 { 110,      2 },
 {  20,      1 },

};

static const key_to_set_vss_type Set_Vss_Freq_Table[] =
{  /* index         byte*/
 { 540,      1 },
 { 620,      2 },
 { 700,      3 },
 { 780,      4 },
 { 850,      5 },
 { 880,      6 },
 { 950,      7 },
 { 990,      8 },
 { 1020,      9 },
 { 2000,      10 },

};
#endif

typedef enum pits_checksum_status_Tag
{
   CHKSUM_UNABLE_TO_CALC,
   CHKSUM_IN_PROGRESS,
   CHKSUM_COMPLETE,
   CHKSUM_FAIL_TO_CALC,
   CHKSUM_RESERVED
} pits_checksum_status_type;

typedef struct mds_status_tag
{
   uint8_t        md_active;
   uint8_t        md_number;
   uint8_t        md_state;
   uint32_t       md_block;
} mds_status_type;

typedef struct PITS_MTD_Sections_Tag
{
   uint_least64_t    block_size;
   uint8_t           status;
   bool              pending_result_response;
} PITS_MTD_Sections_T;

typedef struct PITS_Man_Queue_MD5_Tag
{
   uint8_t           queue_mtd[PITS_MD5_TOTAL_PARTITIONS*2];
   uint8_t           fill_index;
   uint8_t           empty_index;

} PITS_Man_Queue_MD5_T;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static mds_status_type mds_chksum_table[10] = {{0, 0, 0, 0}};
static bool mds_calc_flag = false;

static void PITS_Mfg_Initialize(void);
static void PITS_Mfg_Compose_Message_Header(uint8_t mid, uint8_t size);
#if 0
static Done_Or_Not_Done_T PITS_Mfg_Start_Reflash_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Jump_To_FBL_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_Set_FCID(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Load_Defaults_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_DTC_Ign_Cntr_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Set_DTC_Ign_Cntr_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_Ign_Cntr_Cal_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Partition_Req(const PITS_Message_T * message);

static Done_Or_Not_Done_T PITS_Mfg_Set_Irr_Pwm_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_Irr_Pwm_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_Front_Aux_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Eng_Menus_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Set_Vss_Pwm_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Get_Vss_Pwm_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Partition_Diag_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Default_Resp_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Bt_Clear_Dev_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Mpi_Checksums_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Checksum_Crc_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Enable_FM_Blend_Mode_Req(const PITS_Message_T * message);
static Done_Or_Not_Done_T PITS_Mfg_Manifest_Version_Req(const PITS_Message_T * message);
#endif
static void PITS_Read_VSS_PWM_From_VIP(PITS_VSS_INPUT_CONFIG_REP_T * VSS_PWM_Info);
static void PITS_Man_Test_Clean_MD5_Information(uint8_t mtd_number);
static uint_least64_t Util_Get_Big_Endian_U64(const uint8_t * src);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_MFG_RX_INDEX

#define MID_MFG_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T PITS_Mfg_RX_Messages[] = {
   MID_MFG_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_MFG_TX_INDEX

#define MID_MFG_TX_INDEX(name, mid) (mid),

static const uint8_t PITS_Mfg_TX_Messages[] = {
   MID_MFG_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_MFG_RX_INDEX
#define MSID_MFG_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T PITS_Mfg_RX_Message_Sets[] = {
   MSID_MFG_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_MFG_TX_INDEX
#define MSID_MFG_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T PITS_Mfg_TX_Message_Sets[] = {
   MSID_MFG_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static uint8_t mfg_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T mfg_message;      /* for construction of a misc service message to be transmitted */

static uint8_t mfg_tx_data[PITS_MAX_MESSAGE_SIZE];
#if 0
static bool ir_pwm_current_pit = false;

static uint16_t pits_test_adjuste = 0;

static uint8_t pit_load_default = 3;

static bool pits_partition_state = false;

static bool pits_load_def_progress = false;

static pits_checksum_status_type pits_crc_status = CHKSUM_UNABLE_TO_CALC;

static uint8_t pits_enable_fm_blend_mode = 0;
#endif
static SAL_Timer_Id_T MAN_Test_MD5_Timer;

#undef PITS_MAN_TEST_MD5_NAMES_INDEX
#define PITS_MAN_TEST_MD5_NAMES_INDEX(name, value)    (name),
static const char *pits_man_md5_names[] =  {
   PITS_MAN_TEST_MD5_NAMES_TABLE
};

static PITS_MTD_Sections_T   MAN_Test_MD5_Status[PITS_MD5_TOTAL_PARTITIONS];
static PITS_Man_Queue_MD5_T  MAN_Test_Queue_List;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Mfg_Services_Interface = {
   PITS_Mfg_Initialize,
   PITS_Mfg_RX_Message_Sets,
   Num_Elems(PITS_Mfg_RX_Message_Sets),
   PITS_Mfg_TX_Message_Sets,
   Num_Elems(PITS_Mfg_TX_Message_Sets),
};
/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Soh_Initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
static void PITS_Mfg_Initialize(void)
{
   mfg_tx_bus_id = 0;
   memset(&mfg_message, 0x00, sizeof(PITS_Message_T));
   memset(mfg_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   memset(&MAN_Test_MD5_Status, 0x00, sizeof(MAN_Test_MD5_Status));
   memset(&MAN_Test_Queue_List, 0x00, sizeof(MAN_Test_Queue_List));
}

/**
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
static void PITS_Mfg_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   mfg_message.bus = mfg_tx_bus_id;
   mfg_message.data = mfg_tx_data;
   mfg_message.MSID = MSID_MFG_SERVICES;
   mfg_message.MID = mid;
   mfg_message.data_size = size;
   memset(&mfg_tx_data[0], 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_MD5_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_MD5_Timer(void)
{
   bool ok;
   ok = SAL_Create_Timer(PITS_EV_MAN_TEST_MD5_TIMEOUT, &MAN_Test_MD5_Timer);
   PBC_Ensure(ok, "Failed to create MAN_Test_MD5_Timer");
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_MD5_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_MD5_Timer (void)
{
   SAL_Destroy_Timer(MAN_Test_MD5_Timer);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_MD5_Status
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_MD5_Status(const SAL_Event_Id_T event_id)
{
   uint8_t mtd_number =  MAN_Test_Queue_List.queue_mtd[MAN_Test_Queue_List.empty_index];
   uint8_t status = PITS_MAN_CHKSUM_PROCESS;
   
   status = PITS_MAN_Test_Get_MD5_Calc_Status(mtd_number);
   MAN_Test_MD5_Status[mtd_number].status = status;
   
   if ((PITS_MAN_CHKSUM_SUCCESS == status) || (PITS_MAN_CHKSUM_ERROR == status))
   {  
      MAN_Test_Queue_List.empty_index++;
      if(MAN_Test_Queue_List.empty_index >= Num_Elems(MAN_Test_Queue_List.queue_mtd))
      {
        MAN_Test_Queue_List.empty_index = 0;
      }
      
      if (MAN_Test_Queue_List.empty_index == MAN_Test_Queue_List.fill_index)
      {
         SAL_Stop_Timer(MAN_Test_MD5_Timer);      
      }
      else
      {
         mtd_number =  MAN_Test_Queue_List.queue_mtd[MAN_Test_Queue_List.empty_index];
         MAN_Test_MD5_Status[mtd_number].status = PITS_MAN_CHKSUM_PROCESS;
         PITS_Man_Test_Request_MD5_Calc(mtd_number, MAN_Test_MD5_Status[mtd_number].block_size);
      }    
   }

   return status;
}

void Pits_Start_Mds_Calculation (uint8_t mds_value, uint32_t mds_block)
{
   uint8_t md_index = 0;
   mds_calc_flag = true;
   for (md_index = 0; md_index < 10; md_index++)
   {
      if (mds_chksum_table[md_index].md_active == 0)
      {
         mds_chksum_table[md_index].md_active = 1; 
         mds_chksum_table[md_index].md_number = mds_value;
         mds_chksum_table[md_index].md_state = MDS_NOT_STARTED;
         mds_chksum_table[md_index].md_block = mds_block;
         break;
      }
   }
}

uint8_t Pits_Get_Mds_Calc_Status (uint8_t mds_value)
{
   uint8_t md_index = 0;
   uint8_t md_result = 0;
   for (md_index = 0; md_index < 10; md_index++)
   {
      if (mds_chksum_table[md_index].md_number == mds_value)
      {
         md_result = mds_chksum_table[md_index].md_state;
         break;
      }
   }
   return (md_result);
}

#if 0
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Mec_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Start_Reflash_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_START_REFLASH_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] < 2)
         {
            if ((message->data[0] == 0x01)&&(!pits_partition_state))
            {
               mfg_tx_data[0] = (uint8_t) FAIL;
               mfg_tx_data[1] = 0;
            }
            else
            {
               pit_buff[0]= 0x00;    /* Bus ID */
               pit_buff[1]= 0x02;    /* MSID */
               pit_buff[2]= 0xD8;    /* MID */
               pit_buff[3]= message->data[0];
               PITS_GM_Diag_Services_Request(&pit_buff[0], 4);
               status = DONE;
            }
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Jump_To_FBL_Req
 *===========================================================================*
 * @brief Req to jump to FBL
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Jump_To_FBL_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[4];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_JUMP_FBL_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pit_buff[0]= 0x00;    /* Bus ID */
         pit_buff[1]= 0x02;    /* MSID */
         pit_buff[2]= 0xCC;    /* MID */
         pit_buff[3]= 0x00;    /* MID */
         PITS_GM_Diag_Services_Request(&pit_buff[0], 4);
         status = DONE;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Set_FCID
 *===========================================================================*
 * @brief Receive a Request to Set Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_Set_FCID(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[6];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_SET_FCID_ACK, 2);

      /* Compose Message Data */
      if (message->data_size < 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pit_buff[0]= 0x00;    /* Bus ID */
         pit_buff[1]= 0x02;    /* MSID */
         pit_buff[2]= 0xCE;    /* MID */
         pit_buff[3]= message->data[0];   /* R/W */
         pit_buff[4]= message->data[1];   /* SET DATA 0 */
         pit_buff[5]= message->data[2];   /* SET DATA 1 */
         PITS_GM_Diag_Services_Request(&pit_buff[0], 6);
         status = DONE;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Move_Cals_Req
 *===========================================================================*
 * @brief Receive a Request to Move Cals to Persistent Storage
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Calibration
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Load_Defaults_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t dpid_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_LOAD_DEFAULTS_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (!pits_load_def_progress)
         {
            pits_load_def_progress = false; //remove true
            pit_load_default = message->data[0];
            PITS_Set_PPS_Session(SESSION_CLOSE);
            if (message->data[0] < 0x06)
            {

               dpid_buff[0]= 0x00;    /* Bus ID */
               dpid_buff[1]= 0x02;    /* MSID */
               dpid_buff[2]= 0xE6;    /* MID */
               dpid_buff[3]= message->data[0];
               PITS_GM_Diag_Services_Request(&dpid_buff[0], 4);

               if (message->data[0] < 0x04)
               {
                  status = DONE;
               }

            }
            else
            {
               mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            }
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) FAIL;
         }
         mfg_tx_data[1] = message->data[0];
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Move_Cals_Req
 *===========================================================================*
 * @brief Receive a Request to Move Cals to Persistent Storage
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Calibration
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Default_Resp_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_LOAD_DEFAULTS_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         mfg_tx_data[1] = pit_load_default;
         pits_load_def_progress = false;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

extern uint8_t DG_Receive_Pit_Load_Def (void)
{
   return (pit_load_default);
}
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_DTC_Ign_Cntr_Req
 *===========================================================================*
 * @brief Receive a Request to single DTC counter
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = DTC code ID
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = DTC code ID
 * @param [out] TX_Message[2] = DTC counter Status
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_DTC_Ign_Cntr_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   SIP_GM_DTC_T dtc_index;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_DTC_IGN_CNTR_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         dtc_index.dtc_code = 0;
         mfg_tx_data[1] = DG_Ignition_Cycle_Counter(dtc_index.dtc_code);
      }
   }
   if (NOT_DONE == status)
   {
      status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);
   }
   return (status);
}
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Set_DTC_Ign_Cntr_Req
 *===========================================================================*
 * @brief Receive a Request to single DTC counter
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = DTC code ID
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = DTC code ID
 * @param [out] TX_Message[2] = DTC counter Status
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Set_DTC_Ign_Cntr_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   SIP_GM_DTC_T dtc_index;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_SET_DTC_IGN_CNTR_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] > 0x63)
         {
            message->data[0] = 0x63;
         }
         DG_Put_Ignition_Cycle_Counter(0, message->data[0]);
         dtc_index.dtc_code = 0;
         mfg_tx_data[1] = DG_Ignition_Cycle_Counter(dtc_index.dtc_code);
      }
   }
   if (NOT_DONE == status)
   {
      status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);
   }
   return (status);
}
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Ign_Cntr_Cal_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_Ign_Cntr_Cal_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_IGN_CNTR_CAL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         mfg_tx_data[1] = MAX_IGNITION_CYCLE;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}
/*===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Mec_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Set_Irr_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_SET_IRR_PWM_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;

         if (message->data[0] > 0x01)
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         else
         {
            if (message->data[0] == 0x01)
            {
               IR_ENABLE_MFG_PWM();
               ir_pwm_current_pit = true;
            }
            else
            {
               IR_DISABLE_MFG_PWM();
               #ifndef GMB_CCR_IS
               VSS_IRR_DISABLE_MFG_PWM();
               #endif
               ir_pwm_current_pit = false;
            }
            mfg_tx_data[1] = message->data[0];
         }

      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Mec_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_Irr_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   uint32_t msctest;
   uint8_t  dutytest;
   uint8_t  duytajd = 0;
   bool   dutypos;
   uint8_t  ovftest;
   uint16_t freq;
   uint16_t freqtest;
   uint16_t rise;
   uint16_t fall;
   uint16_t dutysum;
   uint16_t dutyout;
   uint16_t  frecadj = 155;
   uint8_t  frecindex = 0;
   float freqflot;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_IRR_PWM_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         rise = IR_GET_MFG_PWM_RISE();
         fall = IR_GET_MFG_PWM_FALL();

         if (ir_pwm_current_pit)
         {
            mfg_tx_data[1] = 0x01;
            msctest = rise + fall;
            freqtest = (rise + fall)/4;
            freqflot = (1.0/(freqtest*1.0));
            freq = (uint16_t)(freqflot*(1000));
            dutytest = (fall*100)/ (rise + fall);

            if (freq <= 250)
            {
               mfg_tx_data[2] = (uint8_t)(freq>>8);
               mfg_tx_data[3] = (uint8_t)freq;
               mfg_tx_data[4] = dutytest;
            }
            else
            {

               IR_DISABLE_MFG_PWM();

               #ifndef GMB_CCR_IS
               VSS_IRR_ENABLE_MFG_PWM(0);
               OS_Sleep(MSec_To_Ticks(10));
               rise = VSS_IRR_GET_MFG_PWM_DUTY();
               fall = VSS_IRR_GET_MFG_PWM_DUTYTWO();
               #endif

               msctest = rise + fall;
               freqtest = ((((msctest*31)/10000)+4)*10)+1;
               freqflot = (1.0/(freqtest*1.0));
               freq = (uint16_t)(freqflot*(1000000));
               mfg_tx_data[2] = (uint8_t)(freq>>8);
               mfg_tx_data[3] = (uint8_t)freq;
               dutysum = (((rise+fall)*1)/1000);
               //mfg_tx_data[4] = ((rise + dutysum)*100) / (dutytest+dutytestwo);
               mfg_tx_data[4] = ((rise + dutysum)*100) / (rise+fall);
               IR_DISABLE_MFG_PWM();
               #ifndef GMB_CCR_IS
               VSS_IRR_DISABLE_MFG_PWM();
               #endif
               IR_ENABLE_MFG_PWM();

            }

            if ((mfg_tx_data[2] == 0)&&(mfg_tx_data[3] == 0)&&(mfg_tx_data[4] > 0))
            {
               mfg_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
               mfg_tx_data[2] = 0;
               mfg_tx_data[3] = 0;
               mfg_tx_data[4] = 0;
            }
         }
         else
         {

            mfg_tx_data[1] = 0x00;
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Get_Ign_Cntr_Cal_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_Front_Aux_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   aux_jack_state_pit_type aux_jack_dpid_state;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_FRONT_AUX_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;

            /*Check aux jack present*/
               aux_jack_dpid_state = (aux_jack_state_pit_type)Aux_Device_State();
               if (aux_jack_dpid_state == PITS_AUX_JACK_PRESENT)
               {
                  mfg_tx_data[1] = 0x01;
               }
               if (aux_jack_dpid_state == PITS_JACK_NOT_PRESENT)
               {
                  mfg_tx_data[1] = 0x02;
               }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Partition_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Partition_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_PARTITION_ACK, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[1]<0x03)
         {
            if (message->data[1] == 0x01)
            {
                if (PITS_Get_PPS_Session()== SESSION_CLOSE)
                {
                   pit_buff[0]= 0x00;    /* Bus ID */
                   pit_buff[1]= 0x02;    /* MSID */
                   pit_buff[2]= 0xEA;    /* MID */
                   pit_buff[3]= message->data[0];
                   pit_buff[4]= message->data[1];
                   PITS_GM_Diag_Services_Request(&pit_buff[0], 5);
                   DG_Set_Partition_Actual_State(0x01);
                   pits_partition_state = true;
                   status = DONE;
                }
                else
                {
                   mfg_tx_data[0] = (uint8_t) FAIL;
                }
            }
            else
            {
               pit_buff[0]= 0x00;    /* Bus ID */
               pit_buff[1]= 0x02;    /* MSID */
               pit_buff[2]= 0xEA;    /* MID */
               pit_buff[3]= message->data[0];
               pit_buff[4]= message->data[1];
               PITS_GM_Diag_Services_Request(&pit_buff[0], 5);
               if (message->data[1] == 0x02)
               {
                  DG_Set_Partition_Actual_State(0x02);
                  pits_partition_state = false;
               }
               status = DONE;
            }
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Eng_Menus_Req
 *===========================================================================*
 * @brief Receive a Request to single DTC counter
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = DTC code ID
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = DTC code ID
 * @param [out] TX_Message[2] = DTC counter Status
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Eng_Menus_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_ENG_MENUS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         mfg_tx_data[1] = message->data[0];
         if (message->data[0]< 0x03)
         {
            pit_buff[0]= 0x00;    /* Bus ID */
            pit_buff[1]= 0x02;    /* MSID */
            pit_buff[2]= 0xE8;    /* MID */
            pit_buff[3]= message->data[0];
            PITS_GM_Diag_Services_Request(&pit_buff[0], 4);
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);
   }
   return (status);
}

/*===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Set_Vss_Pwm_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Set_Vss_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_SET_VSS_PWM_RPT, 2);

      #ifndef GMB_CCR_IS
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] > 0x01)
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         else
         {
            if (message->data[0] == 0x01)
            {
               VSS_ENABLE_MFG_PWM(3);
            }
            else
            {
               VSS_DISABLE_MFG_PWM();
            }
            mfg_tx_data[1] = message->data[0];
         }
      }
      #else
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      #endif
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Set_Vss_Pwm_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Get_Vss_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint32_t msctest;
   uint32_t  dutytest;
   uint32_t  dutytestwo;
   uint8_t  duytajd = 0;
   bool   dutypos;
   uint8_t  ovftest;
   bool  ovftestwo = false;
   uint8_t  dutylow;
   bool  dutylowin = false;
   uint16_t freq;
   uint16_t freq2;
   uint16_t freqtest;
   uint16_t dutysum;
   uint16_t dutyout;
   uint8_t  frecadj = 0;
   uint8_t  frecindex = 0;
   uint16_t rise;
   uint16_t fall;
   uint16_t freq_original;
   uint8_t  duty_original;
   float freqflot;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_VSS_PWM_RPT, 5);

      #ifndef GMB_CCR_IS
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         rise = VSS_GET_MFG_PWM_DUTY_RISE();
         fall = VSS_GET_MFG_PWM_DUTYTWO_FALL();
         //rise = IR_GET_MFG_PWM_RISE();
         //fall = IR_GET_MFG_PWM_FALL();

        if (VSS_GET_MFG_PWM_CURRENT()== 0x01)
        {
           mfg_tx_data[1] = 0x01;
           msctest = rise + fall;
           freqtest = (rise + fall)/4;
           freqflot = (1000.0/(freqtest*1.0));
           freq = (uint16_t)(freqflot*(1000));
           freq2 = freq;
           dutytest = (rise*100)/ (rise + fall);
           dutylow = (uint8_t)dutytest;
           if (freq < 20)
           {
              if (freq == 0)
              {
                 mfg_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
              }
              else
              {
                 mfg_tx_data[2] = (uint8_t)(freq>>8);
                 mfg_tx_data[3] = (uint8_t)freq;
                 mfg_tx_data[4] = dutytest;
              }
           }
           else
           {
              dutytest = VSS_GET_MFG_PWM_DUTY();
              dutytestwo =VSS_GET_MFG_PWM_DUTYTWO();
              ovftest = VSS_GET_MFG_PWM_OVF();
              msctest = dutytest + dutytestwo;
              freqtest = ((msctest*2505)/10000);
              freqflot = (1.0/(freqtest*1.0));
              freq = (uint16_t)(freqflot*(1000000));

              for (frecindex = 0; frecindex < 18; frecindex++)
                {
                    if (Set_Vss_Table[frecindex].set_value <= freq)
                    {
                      frecadj = Set_Vss_Table[frecindex].set_percentage;
                      break;
                    }
                }
              if (freq < 180)
              {
                 freq = freq + 1;
              }
              else if (freq < 410)
              {
                 freq = freq + 0;
              }
              else
              {
                 for (frecindex = 0; frecindex < 10; frecindex++)
                 {
                     if (Set_Vss_Freq_Table[frecindex].set_value > freq)
                     {
                        freq = freq - Set_Vss_Freq_Table[frecindex].set_percentage;
                        break;
                     }
                 }
              }

              if ((freq > 1020)||(freq == 0))
              {
                 mfg_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
              }
              else
              {
                 mfg_tx_data[2] = (uint8_t)(freq>>8);
                 mfg_tx_data[3] = (uint8_t)freq;
                 mfg_tx_data[4] = (((dutytestwo)*100) / (dutytest+dutytestwo))+frecadj;
              }
           }
         }
         else
         {

            mfg_tx_data[1] = 0x00;
         }
      }
      #else
         /* Compose Message Data */
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      #endif
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Partition_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Partition_Diag_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = DONE;
   uint8_t pit_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_PARTITION_ACK, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[1]<0x03)
         {
            if (message->data[1] == 0x01)
            {
                if (PITS_Get_PPS_Session()== SESSION_CLOSE)
                {
                   pit_buff[0]= 0x00;    /* Bus ID */
                   pit_buff[1]= 0x02;    /* MSID */
                   pit_buff[2]= 0xEE;    /* MID */
                   pit_buff[3]= message->data[0];
                   pit_buff[4]= message->data[1];
                   PITS_GM_Diag_Services_Request(&pit_buff[0], 5);
                   DG_Set_Partition_Actual_State(0x01);
                   status = DONE;
                }
                else
                {
                   mfg_tx_data[0] = (uint8_t) FAIL;
                }
            }
            else
            {
               pit_buff[0]= 0x00;    /* Bus ID */
               pit_buff[1]= 0x02;    /* MSID */
               pit_buff[2]= 0xEE;    /* MID */
               pit_buff[3]= message->data[0];
               pit_buff[4]= message->data[1];
               PITS_GM_Diag_Services_Request(&pit_buff[0], 5);
               if (message->data[1] == 0x02)
               {
                  DG_Set_Partition_Actual_State(0x02);
               }
               status = DONE;
            }
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Move_Cals_Req
 *===========================================================================*
 * @brief Receive a Request to Move Cals to Persistent Storage
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Calibration
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Bt_Clear_Dev_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = DONE;
   uint8_t pit_buff[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_LOAD_DEFAULTS_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         pit_buff[0]= 0x00;    /* Bus ID */
         pit_buff[1]= 0x18;    /* MSID */
         pit_buff[2]= 0xF2;    /* MID */
         PITS_GM_Diag_Services_Request(&pit_buff[0], 3);
         DG_Respond_Wait_Pit_Bt();
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Move_Cals_Req
 *===========================================================================*
 * @brief Receive a Request to Move Cals to Persistent Storage
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Calibration
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Mpi_Checksums_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t dpid_buff[8];
   uint16_t pit_stub16 = 0;
   uint8_t dtc_code = 0;
   uint8_t mfg_tx_datab[30];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      mfg_message.bus = mfg_tx_bus_id;
      mfg_message.data = mfg_tx_datab;
      mfg_message.MSID = MSID_MFG_SERVICES;
      mfg_message.MID = MID_MFG_MPI_CHECKSUMS_RPT;
      mfg_message.data_size = 23;
      memset(&mfg_tx_datab[0], 0x00, 23);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_datab[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_datab[0] = (uint8_t) SUCCESS;
         if (message->data[0] < 6)
         {
               for( dtc_code = 0; dtc_code < (ECU_MALFUNCTION_EEPROM_DIAG); dtc_code++ )
               {
                  pit_stub16 = pit_stub16 + Self_Di_Get_Fixed_DTC(dtc_code);
               }
               for (dtc_code = MICROPHONE_AMPLITUD; dtc_code < (USB_REPROGRAM_NO_CALS+1); dtc_code++ )
               {
                  pit_stub16 = pit_stub16 + Self_Di_Get_Fixed_DTC(dtc_code);
               }
               mfg_tx_datab[1] = 13;
               /*Write "Block_CRC_DTC" */
               mfg_tx_datab[2] = 0x42;
               mfg_tx_datab[3] = 0x6C;
               mfg_tx_datab[4] = 0x6F;
               mfg_tx_datab[5] = 0x63;
               mfg_tx_datab[6] = 0x6B;
               mfg_tx_datab[7] = 0x5F;
               mfg_tx_datab[8] = 0x43;
               mfg_tx_datab[9] = 0x52;
               mfg_tx_datab[10] = 0x43;
               mfg_tx_datab[11] = 0x5F;
               mfg_tx_datab[12] = 0x44;
               mfg_tx_datab[13] = 0x54;
               mfg_tx_datab[14] = 0x43;

               mfg_tx_datab[15] = 0;
               mfg_tx_datab[16] = 0;
               mfg_tx_datab[17] = 0;
               mfg_tx_datab[18] = 34; /*size of the block*/
               mfg_tx_datab[19] = 0;
               mfg_tx_datab[20] = 2;
               mfg_tx_datab[21] = pit_stub16>>8;
               mfg_tx_datab[22] = pit_stub16;

            if (message->data[0] != 1)
            {
               dpid_buff[0]= 0x00;    /* Bus ID */
               dpid_buff[1]= 0x02;    /* MSID */
               dpid_buff[2]= 0xDC;    /* MID */
               dpid_buff[3]= message->data[0];
               dpid_buff[4]= pit_stub16>>8;
               dpid_buff[5]= pit_stub16;
               PITS_GM_Diag_Services_Request(&dpid_buff[0], 6);
               status = DONE;
            }
         }
         else
         {
            mfg_tx_datab[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Checksum_crc_Req
 *===========================================================================*
 * @brief Receive a Request to Set Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Response
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Checksum_Crc_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_CHECKSUM_CRC_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0]< 2)
         {
            if (message->data[0] == 1)
            {
               Pits_Calculate_All_MPI_CRC_Chksums();
               pits_crc_status = CHKSUM_COMPLETE;
               status = DONE;
            }
            mfg_tx_data[1] = pits_crc_status;
         }
         else
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}


/*===========================================================================*
 * FUNCTION: PITS_Mfg_Enable_FM_Blend_Mode_Req
 *===========================================================================*
 * @brief Receive a Request to Enable FM Blend mode
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Response
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Enable_FM_Blend_Mode_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   bool_t is_fm_blend_mode_ok = true;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_ENABLE_FM_BLEND_ACK, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         if(message->data[0] < 3)
         {
            mfg_tx_data[0] = (uint8_t) SUCCESS;
            if(message->data[0] > 0)
            {
               if(message->data[0] == 2)
               {
                  pits_enable_fm_blend_mode = 0;
               }
               else
               {
                  pits_enable_fm_blend_mode = 1;
               }
               is_fm_blend_mode_ok = Tun_DSP_Control_FM_Fast_Blend_Mode(AM_FM_DRV_TUNER_1,pits_enable_fm_blend_mode);
            }
            mfg_tx_data[1] = pits_enable_fm_blend_mode;
         } 
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Manifest_Version_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 *
 */
/*===========================================================================*/
static Done_Or_Not_Done_T PITS_Mfg_Manifest_Version_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t pit_buff[25];
   if(NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_MNF_VERSION_RPT, 2);

      /* Compose Message Data */
      if(message->data_size < 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_message.data_size = 3;
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         pit_buff[0]= 0x00;    /* Bus ID */
         pit_buff[1]= 0x02;    /* MSID */
         pit_buff[2]= 0xCD;    /* MID */

         memcpy(&pit_buff[3], message->data, 22);
         PITS_GM_Diag_Services_Request(&pit_buff[0], 25);
         status = DONE;
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   return(status);

}
#endif
/*===========================================================================*
 * FUNCTION: Pits_Man_Test_Aux_Jack_Stat_Req
 *===========================================================================*
 * @brief Request the current Aux Jack Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message (No data needed in this case)
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = aux jack status (Error/Inserted/Not Inserted
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Aux_Jack_Stat_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id    = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_AUX_JACK_STAT_RPT, 2);


      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("MAN TEST Request: Message Data Error");
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         mfg_tx_data[1] = PITS_Get_Aux_Jack_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);                      
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: Pits_Man_Reflash_Status_Req
 *===========================================================================*
 * @brief Request Message: Request to get reflash status, or start reflash process.
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message (No data needed in this case)
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T Pits_Man_Reflash_Status_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MAN_REFLASH_STATUS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("MAN TEST Request: Message Data Error");
      }
      else
      {
         switch (message->data[0])
         {
            case PITS_REFLASH_STATUS:
               mfg_tx_data[0] = (uint8_t) SUCCESS;
               mfg_tx_data[1] = PITS_Get_Reflash_Status();
               break;
            case PITS_START_REFLASH:
               if(PITS_Get_Reflash_Mode())
               {
                  mfg_tx_data[0] = (uint8_t) FAIL;
                  mfg_tx_data[1] = PITS_REFLASH_MODE;
               }
               else
               {
                  PITS_Set_Reflash_Mode();
                  mfg_tx_data[0] = (uint8_t) SUCCESS;
                  mfg_tx_data[1] = PITS_Get_Reflash_Status();
               }
               break;
            default:
               mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
               mfg_tx_data[1] = message->data[0];
               break;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Unlock_Lock_Data_Partition_Req
 *===========================================================================*
 * @brief Request to update the state of the data partian for either 
 *        lock (Read only) or unlocked (Read/Write) access.
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message (No data needed in this case)
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = aux jack status (Error/Inserted/Not Inserted
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Unlock_Lock_Data_Partition_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   int status;

   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_UNLOCK_LOCK_DATA_PARTITION_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("MAN TEST Request: Message Data Error");
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) FAIL;
         mfg_tx_data[1] = message->data[0];
         if(PITS_GET_PARTITION_STATUS == message->data[1])
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            if((message->data[0] != 0xFF) && (message->data[0] < NUM_SEGMENTS))
            {
               mfg_tx_data[0] = (uint8_t) SUCCESS;
               mfg_tx_data[2] = PITS_Get_Partition_Status(message->data[0]);
            }
         }
         else if((message->data[0] == 0xFF) || (message->data[0] < NUM_SEGMENTS))
         {
            if((PITS_SET_RW_PARTITION_STATUS == message->data[1]) && (PITS_Get_Session_Close_State()))
            {
               PITS_Set_Partition_Status(message->data[0], message->data[1]);
               status = system("mount -o remount,rw /factory_data");
               Tr_Info_Lo_1("'mount -o remount,rw /factory_data' returned status=%d", status);
               mfg_tx_data[0] = (uint8_t) SUCCESS;
               mfg_tx_data[2] = message->data[1];
            }         
            else if(PITS_SET_RO_PARTITION_STATUS == message->data[1])
            {
               PITS_Set_Partition_Status(message->data[0], message->data[1]);
               PS_Save_Now();
               mfg_tx_data[0] = (uint8_t) SUCCESS;
               mfg_tx_data[2] = message->data[1];
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);                      
      }
   }
   
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: Pits_Man_Load_Defaults_Req
 *===========================================================================*
 * @brief Request the Engineering Menus Override
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = 0 normal operation, 1 base menu, 2 advance menu
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = 0 normal operation, 1 base menu, 2 advance menu
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Man_Load_Defaults_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_LOAD_DEFAULTS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("MAN TEST Request: Message Data Error");
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         if (message->data[0] < NUM_DEFAULT_OPTIONS)
         {
            mfg_tx_data[0] = (uint8_t) PITS_Set_Load_Defaults(message->data[0]);
            mfg_tx_data[1] = message->data[0];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);
      }
   }

   return (pits_status);
}

/*===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Set_Vss_Pwm_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Set_Vss_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_SET_VSS_PWM_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] > PITS_INPUT_CONFIG_DIAG)
         {
            mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         else
         {
            VIP_PITS_Sent_VSS_Config_To_VIP((SIP_PITS_VSS_INPUT_CONFIG_T)message->data[0]);
            mfg_tx_data[1] = message->data[0];
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   
   return (status);
}

/*===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Mfg_Set_Vss_Pwm_Req
 *===========================================================================*
 * @brief Receive a Request to get Mec
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = MEC value
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Get_Vss_Pwm_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   PITS_VSS_INPUT_CONFIG_REP_T VSS_PWM_Infomation;
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      mfg_tx_bus_id = message->bus;
      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_VSS_PWM_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         PITS_PBS_Error_Report("Mfg Request: Message Data Error");
         mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         PITS_Read_VSS_PWM_From_VIP(&VSS_PWM_Infomation);
         mfg_tx_data[0] = (uint8_t) SUCCESS;
         mfg_tx_data[1] = VSS_PWM_Infomation.VSS_Config_type;
         if (PITS_INPUT_CONFIG_VSS == mfg_tx_data[1])
         {
            mfg_tx_data[2] = (uint8_t)0;
            mfg_tx_data[3] = (uint8_t)0;
            mfg_tx_data[4] = (uint8_t)0;
         }
         else
         {
            Util_Put_Big_Endian_U16(&mfg_tx_data[2], VSS_PWM_Infomation.PWM_Freq);
            mfg_tx_data[4] = VSS_PWM_Infomation.Duty_Cycle;
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message));
   }
   
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Req_Md5_Calc_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Req_Md5_Calc_Req(const PITS_Message_T * message)
{
   uint8_t md5_name_size = 0;
   uint8_t msg_index = 0;
   uint16_t mtd_number = 0;
   uint8_t md5_name_limit = 0;
   char_t md5_name[PITS_MAX_MD5_NAME_SIZE];
   bool_t ret_value = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id    = message->bus;
      md5_name_size = message->data[0];
      PITS_Mfg_Compose_Message_Header(MID_MFG_REQ_MD5_CALC_RPT, (PITS_MD5_CONFIRMATION_RESP + md5_name_size));

      /* Compose Message Data */
      mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

      if (message->data_size != (md5_name_size + PITS_MD5_HEADER_CALC_SIZE))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Manufacturing Test Request: Message Data Error");
      }
      else
      {
         md5_name_limit = md5_name_size;
         if (md5_name_limit > PITS_MAX_MD5_NAME_SIZE) 
         {
           md5_name_limit = PITS_MAX_MD5_NAME_SIZE;
         }
         /* Verify section name */
         memcpy(&md5_name, &message->data[1], md5_name_limit);

         for (mtd_number = 0; mtd_number < PITS_MD5_TOTAL_PARTITIONS; mtd_number ++)
         {
           if (0 == memcmp(&md5_name, pits_man_md5_names[mtd_number], md5_name_limit)) 
           {
             ret_value = true;
             break; 
           }
         }

         memcpy(&mfg_tx_data[1], &message->data[0], (md5_name_size + 1 ));
         msg_index = md5_name_size + PITS_MD5_ALGORITHM_INDEX + 4;
         if ((ret_value) && (0 == message->data[msg_index]))
         {
            MAN_Test_MD5_Status[mtd_number].block_size = Util_Get_Big_Endian_U64(&message->data[md5_name_size + 1]);

            switch(message->data[msg_index+1])
            {
               case PITS_MD5_STATUS:
               {
                    mfg_tx_data[0] = (uint8_t) SUCCESS;
                    mfg_tx_data[md5_name_size + 2] = MAN_Test_MD5_Status[mtd_number].status;
                    Tr_Info_Lo_3("enter md5 status mtd number = %x, status = %d, size %d", mtd_number, MAN_Test_MD5_Status[mtd_number].status, md5_name_size);
                    if(PITS_MAN_CHKSUM_ERROR == MAN_Test_MD5_Status[mtd_number].status)
                    {
                       PITS_Man_Test_Clean_MD5_Information(mtd_number);
                       Tr_Notify("PITS 10 FC MD5 calc req: Status = PITS_MAN_CHKSUM_ERROR, clear MD5 info");
                    }
                    break;
               }
               case PITS_MD5_CALC:
               {
                    if(!MAN_Test_MD5_Status[mtd_number].pending_result_response)
                    {
                       MAN_Test_MD5_Status[mtd_number].pending_result_response = true;
                       Tr_Info_Lo_3("cal enter mtd number = %x, fill = %d, empty = %d", mtd_number, MAN_Test_Queue_List.fill_index, MAN_Test_Queue_List.empty_index);

                       if(MAN_Test_Queue_List.fill_index == MAN_Test_Queue_List.empty_index)
                       {
                          MAN_Test_MD5_Status[mtd_number].status = PITS_MAN_CHKSUM_PROCESS;
                          PITS_Man_Test_Request_MD5_Calc(mtd_number, MAN_Test_MD5_Status[mtd_number].block_size);
                          SAL_Start_Timer(MAN_Test_MD5_Timer, PITS_MAN_TEST_MD5_TIMEOUT, true);
                          Tr_Info_Lo_2("cal check mtd number = %x, status = %d", mtd_number, MAN_Test_MD5_Status[mtd_number].status);
                       }   
                       
                       /* Fill queue md5 request list */
                       MAN_Test_Queue_List.queue_mtd[MAN_Test_Queue_List.fill_index] = mtd_number;
                       MAN_Test_Queue_List.fill_index++;
                       if(MAN_Test_Queue_List.fill_index >= Num_Elems(MAN_Test_Queue_List.queue_mtd))
                       {
                         MAN_Test_Queue_List.fill_index = 0;
                       }      
                       /* Fill PIT response */                        
                       mfg_tx_data[0] = (uint8_t) SUCCESS;
                       mfg_tx_data[md5_name_size + 2] = MAN_Test_MD5_Status[mtd_number].status;
                                               
                    }
                    else
                    {
                       mfg_tx_data[0] = (uint8_t) FAIL;
                       mfg_tx_data[md5_name_size + 2] = MAN_Test_MD5_Status[mtd_number].status;                     
                       Tr_Warn_2("FAIL - mtd number = %x, status = %d", mtd_number, MAN_Test_MD5_Status[mtd_number].status);
                    } 
                    break;
               }
               
               default:
                    break;
            }
               
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Mfg_Partition_Req
 *===========================================================================*
 * @brief Receive a Request Ignition Counter Cal
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Ignition Counter Cal value
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Mfg_Get_Md5_Part_Req(const PITS_Message_T * message)
{
   uint8_t md5_name_size = 0;
   uint8_t md5_msg_size = 0;
   uint8_t md5_name_limit = 0;
   char_t md5_name[PITS_MAX_MD5_NAME_SIZE];
   bool_t ret_value = false;
   uint_least64_t block_size_rec = 0;
   uint8_t mtd_number = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
  
   if (NULL != message)
   {
      /* Compose Message Header */
      mfg_tx_bus_id    = message->bus;
      md5_name_size = message->data[0];
      md5_msg_size = PITS_MD5_HEADER_SIZE + md5_name_size; 

      PITS_Mfg_Compose_Message_Header(MID_MFG_GET_MD5_PART_RPT, (PITS_MD5_CONFIRMATION + md5_msg_size
                                                                    + PITS_MD5_NO_BYTES_CHKSUM + PITS_MD5_CHECKSUM_SIZE));

      /* Compose Message Data */
      mfg_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

      if (message->data_size != md5_msg_size)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Manufacturing Test Request: Message Data Error");
      }
      else
      {
         
         md5_name_limit = md5_name_size;
         if (md5_name_limit > PITS_MAX_MD5_NAME_SIZE) 
         {
           md5_name_limit = PITS_MAX_MD5_NAME_SIZE;
         }
         /* Verify section name */
         memcpy(&md5_name, &message->data[1], md5_name_limit);

         for (mtd_number = 0; mtd_number < PITS_MD5_TOTAL_PARTITIONS; mtd_number ++)
         {
           if (0 == memcmp(&md5_name, pits_man_md5_names[mtd_number], md5_name_limit)) 
           {
             ret_value = true;
             break; 
           }
         }

         memcpy(&mfg_tx_data[1], &message->data[0], md5_msg_size);
         block_size_rec = Util_Get_Big_Endian_U64(&message->data[md5_name_size + 1]);
         mfg_tx_data[md5_msg_size + 1] = PITS_MD5_CHECKSUM_SIZE;     /*lenght byte */
         if ((ret_value) && (0 == mfg_tx_data[md5_msg_size]))/* Algorithm: MD5 Checksum = 0 */
         {
            mfg_tx_data[0] = (uint8_t)DATA_OUT_OF_RANGE;
            if (block_size_rec == MAN_Test_MD5_Status[mtd_number].block_size)
            {
               if(PITS_MAN_CHKSUM_SUCCESS == MAN_Test_MD5_Status[mtd_number].status)
               {
                   mfg_tx_data[0] = (uint8_t) SUCCESS;
                   PITS_Man_Test_Clean_MD5_Information(mtd_number);
                   PITS_Man_Test_Get_MD5_Checksum(mtd_number, &mfg_tx_data[PITS_MD5_CONFIRMATION + md5_msg_size + PITS_MD5_NO_BYTES_CHKSUM]);          
               }
               else
               {
                   mfg_tx_data[0] = (uint8_t)FAIL;
                   Tr_Warn_1("10 FE request MD5 Status != success, Status = %d ",MAN_Test_MD5_Status[mtd_number].status);
               }
            }
            else
            {
               Tr_Warn_2("10 FE request MD5 block_size error, block_size_rec = %lld, block_size = %lld ",block_size_rec,MAN_Test_MD5_Status[mtd_number].block_size);
            }
         }
         else
         {
            Tr_Warn_2("10 FE request MD5 Error, ret_value = %d, Algorithm = %d",ret_value,mfg_tx_data[md5_msg_size]);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&mfg_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Read_VSS_PWM_From_VIP
 *===========================================================================*
 * @brief Read VSS PWM infomation from VIP 
 *
 * @returns
 *    void
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = VSS_PWM_Info
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
static void PITS_Read_VSS_PWM_From_VIP(PITS_VSS_INPUT_CONFIG_REP_T * VSS_PWM_Info)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] =
   {
      EVG_PITS_VSS_INPUT_REPORT,
   };

   if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
   {  
      VIP_PITS_VSS_PWM_Get_Req();
      response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 100);
      if(NULL != response_message)
      {
         if (EVG_PITS_VSS_INPUT_REPORT == response_message->event_id)
         {
            if(NULL != response_message->data)
            {
               memcpy(VSS_PWM_Info, response_message->data, sizeof(PITS_VSS_INPUT_CONFIG_REP_T));
            }
            else
            {
               Tr_Warn("PITS Read VSS PWM Request: got event but no data !!");
            }
         }
         else
         {
            Tr_Warn("PITS Read VSS PWM Request: invalid event!!");
         }
      }
      else
      {
         Tr_Warn("PITS Read VSS PWM Request: no response for vip!!");
      }
      SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
   }
} 

/*===========================================================================*
 * FUNCTION: PITS_Man_Test_Clean_MD5_Information
 *===========================================================================*
 * @brief Static function to clean up all the MD5 Information when is required.
 *
 * @returns
 *    none
 *
 * @param [in] mtd_number = mtd section to clean.
 *
 */
/*===========================================================================*/
void PITS_Man_Test_Clean_MD5_Information(uint8_t mtd_number)
{
  MAN_Test_MD5_Status[mtd_number].pending_result_response = false;
  MAN_Test_MD5_Status[mtd_number].status = PITS_MAN_CHKSUM_NONE;
  MAN_Test_MD5_Status[mtd_number].block_size = 0;
}


/*===========================================================================*
 * FUNCTION: PITS_Man_Test_Clean_MD5_Information
 *===========================================================================*
 * @brief Returns Big Endian data in native endian unsigned 64 bit format
 *
 * @returns
 *    none
 *
 * @param [in] pointer to incoming data stream
 *
 */
/*===========================================================================*/
/*
 * 
 */
uint_least64_t Util_Get_Big_Endian_U64(const uint8_t * src)
{
   PBC_Require(src != NULL, "Util_Get_Big_Endian_U64 cannot be called with a NULL pointer");

   return ((uint_least64_t)
           ((((uint_least64_t) src[0]) << 56) | (((uint_least64_t) src[1]) << 48) | (((uint_least64_t) src[2]) << 40) |
              ((uint_least64_t) src[3]<<32) | ((uint_least64_t) src[4]<<24) | (((uint_least64_t) src[5]) << 16) |
              (((uint_least64_t) src[6]) << 8) | ((uint_least64_t) src[7])));
}
/*===========================================================================*/
/*!
 * @file pits_mfg_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 *  19April2017 Sunil G(vj430z)
 *  ctc_ec#179701: Checksum Calculation for mmcblk0p7
 *
 * - 24-jun-2014 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
