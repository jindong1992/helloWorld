/*===========================================================================*/
/**
 * @file pits_desip_wrapper.c
 *
 * PITs Bearing Bus Wrapper for the DESIP protocol.
 *
 * %full_filespec:pits_desip_wrapper.c~1:csrc:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:52 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "pits_desip_wrapper.h"
#   include "pits_message_handler_cbk.h"
#   include "em.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(PITS_MODULE_ID_2, 1);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
static uint8_t tx_buffer[PITS_MAX_MESSAGE_SIZE];
static uint8_t rx_buffer[PITS_MAX_MESSAGE_SIZE];

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
PITS_Bearing_Bus_T DESIP_Bearing_Bus = {
   0,
   PITS_MAX_MESSAGE_SIZE,
   PITS_MAX_PACKET_SIZE,
   {0, 0, 0, 0, tx_buffer},
   {0, 0, 0, 0, rx_buffer},
   {(Packetization_Stage_T) 0, 0, false, 0},
   {(Packetization_Stage_T) 0, 0, false, 0},
   &send_function,
};

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_DESIP_Receive_Function
 *===========================================================================
 *
 * Called by the Bearing Bus when a message is received for PITS.
 *
 * Please refer to the header file for more detailed information.
 *
 *===========================================================================*/
void PITS_DESIP_Receive_Function(const uint8_t * data, uint16_t length)
{
   PITS_Message_Handler_Receive_Packet(&DESIP_Bearing_Bus, data, length);
}

/*===========================================================================*/
/*!
 * @file pits_desip_WRAPPER.C
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-05-30  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
