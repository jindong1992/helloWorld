/**********************************************************************
 *
 *               (c) Delphi Delco Electronics Systems (unpub.)
 *        All Rights Reserved. Delphi Delco Electronics Confidential
 *
 **********************************************************************
 **********************************************************************
 * %full_filespec:pits_can.c~3:csrc:ctc_ec#3 %
 * @version %version:3 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Thu Jun 23 17:09:07 2016 %
 *
 * Title               : pits_can.c
 *
 * Description         : This file is the source code for pits and can interfacing.
 *
 * Configuration ID    :
 *
 *********************************************************************/
#include "state_of_health.h"
#include "pbc_trace.h"
#include "em.h"
#include "xsal.h"
#include "xsal_thread_id.h"
#include "pits_can_cfg.h"
#include "pits_can_cbk.h"
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT) /* add NE by zengliangqian */
#include "can_interface.h"
#include "can_diagserv.h"
#endif
#ifdef FORD_C490
#include "pcan_appl_event_id.h"
#endif
#include "pcan_appl_proxy.h"
#include <string.h>
#include "diag_handler_api.h"

EM_FILENUM(PITS_CAN_MODULE_ID, 1);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/* If the SOH_TIMEOUT is not defined in the cfg file, then default value will be taken */
#ifndef  PITS_SOH_CAN_TIMEOUT_MS
#define  PITS_SOH_CAN_TIMEOUT_MS  SOH_DEFAULT_TIMEOUT_MS
#endif

#define MDG_DIAG_TIMEOUT_MS      300000

#define SEVEN_BYTE_LEN  7

#define SERVICE_31           0x31

/* Preallocated message data buffer size */
#define PITS_CAN_MSG_SIZE                   (16)

typedef uint8_t GM_DIAG_EVG_USDT_PHYS_RESPONSE_T[USDT_PHYS_MAX_LENGTH];

SAL_Timer_Id_T mdg_timeout;

bool_t mdg_diag_enable = false;

static const SAL_Event_Id_T pits_can_events[] = {
   PITS_CAN_EVG_SHUTDOWN,
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT) /* add NE by zengliangqian */
   CAN_EVG_CAN_RX_PITS_MSG,
#endif   

#ifdef FORD_C490
   PCAN_APPL_EV_PITS_RX,
#endif
};

static const uint8_t mdg_enter_diag_code[] =
{
   0xF0,
   0xC0,
   0xE0,
   0xF0,
   0xF8,
   0xFC,
};

/**
 * Stores thread ID for MODULE, initialized to SAL_UNKNOWN_THREAD_ID
 */
static SAL_Thread_Id_T PITS_Can_Thread_Id = SAL_UNKNOWN_THREAD_ID;

static void DG_Cancellation_Message_To_PITS(void);

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_can_manager(void *param);

/**
 * Send enter diagnostics mode response.
 */
static void mdg_positive_response (uint8_t * buffer, uint16_t length);

/**
 * Enter Diagnostics process function
 *
 *  Start diagnostics timer.
 *  Create enter diagnotics response.
 */
static uint8_t DG_Process_MDG_Service (uint8_t *data, size_t data_size);

/**
 * Get current status, if current status is diagnostics mode return true, or return false.
 */
static bool_t MDG_Diagnostics_Enable (void);

/* Initialise the module
 *
 *===========================================================================*/
void PITS_Can_Initialize(void)
{
   SAL_Thread_Attr_T thread_attr;
   SAL_Thread_Id_T tid;

   PITS_Can_Get_Thread_Attr(&thread_attr);
   tid = SAL_Create_Thread(pits_can_manager, NULL, &thread_attr);
   PBC_Ensure(PITS_CAN_THREAD_ID == tid, "Error creating PITS can manager Thread");
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
void PITS_Can_Shutdown(void)
{
   SAL_Send(PITS_CAN_APP_ID, PITS_CAN_THREAD_ID, PITS_CAN_EVG_SHUTDOWN, NULL, 0); 
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
void Create_MDG_Timer (void)
{
   bool ok;
   ok = SAL_Create_Timer(MDG_DIAG_EVT_TIMEOUT, &mdg_timeout);
   PBC_Ensure(ok, "Failed to create Manufacturing timer");
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
void Destroy_MDG_Timer (void)
{
   SAL_Destroy_Timer(mdg_timeout);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
void Exit_Manufacturing_Mode (void)
{
   Tr_Info_Hi("Exit Manufacturing Mode");

   SAL_Stop_Timer(mdg_timeout);
   mdg_diag_enable = false;
   /* Stop IFCAN test once exit from manufacturing diagnostic mode */
   PCAN_PITS_Test(false);
   DG_Cancellation_Message_To_PITS(); 
}

/**
 * MODULE Task
 *
 *  Creates a message queue
 *  Enter endless loop waiting for messages
 *    - Update a task's alive time
 *    - Mark a task as dormant (i.e., stop monitoring)
 *    - Get pits message from CAN, then transmit it to pits module
 */
static void pits_can_manager(void *param)
{
   /** pointer to current receive message */
   const SAL_Message_T *message;
   bool_t    ok;
   bool thread_alive = true;
   
   (void)(param);

   Tr_Fault("PITS CAN interfacing Thread: start!");

   ok = SAL_Create_Queue(PITS_CAN_QUEUE_SIZE, PITS_CAN_MSG_SIZE, SAL_Alloc, SAL_Free);
   PBC_Ensure(ok, "SAL_Create_Queue() failed");

   /* store own thread ID for communication if not stored yet */
   if (PITS_Can_Thread_Id == SAL_UNKNOWN_THREAD_ID)
   {
      PITS_Can_Thread_Id = SAL_Get_Thread_Id();
   }

   /* Signal ready to receive messages */
   SAL_Signal_Ready();
   PITS_Can_Activated();

   SAL_Subscribe(pits_can_events, Num_Elems(pits_can_events)); 

   /*   pits_can_create_timers(); */
   /*Create diagnosis timer*/
   Create_MDG_Timer();
   SOH_Register(PITS_SOH_CAN_TIMEOUT_MS);

   while (thread_alive)
   {
      SOH_Alive(PITS_SOH_CAN_TIMEOUT_MS);

      message = SAL_Receive_Timeout(PITS_CAN_MSG_WAIT_TIMEOUT_MS);

      if (NULL != message)
      {
         Tr_Info_Lo("PITS CAN recieve a message......");
         switch (message->event_id)
         {
            case PITS_CAN_EVG_SHUTDOWN:
               thread_alive = false;
               break;
	        case MDG_DIAG_EVT_TIMEOUT:
               Exit_Manufacturing_Mode();
               break;
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT) /* add NE by zengliangqian */
            case CAN_EVG_CAN_RX_PITS_MSG:
	       if (((uint8_t *)message->data)[1] == SERVICE_31)
	       {
	          DG_Process_MDG_Service(&((uint8_t *)message->data)[1], ((uint8_t *)message->data)[0]);
	       }
	       else
	       {
	          Tr_Warn("Inavlid Bearing Bus ID!");
	       }
               break; 
#endif		

#ifdef FORD_C490
            case PCAN_APPL_EV_PITS_RX:
	       if (((uint8_t *)message->data)[1] == SERVICE_31)
	       {
	          DG_Process_MDG_Service(&((uint8_t *)message->data)[1], ((uint8_t *)message->data)[0]);
	       }
	       else
	       {
	          Tr_Warn("Inavlid Bearing Bus ID!");
	       }
               break; 
#endif
	    default:
               break;
         }
      }
   }
   
   /*Thread cleanup*/
   /*pits_can_destroy_timers();*/
   Destroy_MDG_Timer();
   SOH_Dormant();

   ok = SAL_Unsubscribe(pits_can_events, Num_Elems(pits_can_events));
   PBC_Ensure(ok, "SAL_Unsubscribe: error");
   PITS_Can_Terminated();

   if(false == ok)
   {
      Tr_Warn("SAL_Unsubcribe Failed");
   }
   Tr_Info_Hi("PITS CAN interfacing Task Stopped");
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
static void mdg_positive_response (uint8_t * buffer, uint16_t length)
{
#if defined(GWM_CHB041) || defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT) /* add NE by zengliangqian */   
   CAN_PITS_MSG_T respond_buffer;

   buffer[0] |= 0x40; 
   respond_buffer.buf[0] = length;
   memcpy(&(respond_buffer.buf[1]), buffer, length);

   CAN_Manf_Diagnostics_Tx_Msg(respond_buffer);
#endif   

#ifdef FORD_C490
   uint8_t respond_buffer[8];

   buffer[0] |= 0x40; 
   respond_buffer[0] = length;
   memcpy(&(respond_buffer[1]), buffer, length);
   
   PCAN_Set_PITS_Response(respond_buffer, length + 1);
#endif
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
static uint8_t DG_Process_MDG_Service (uint8_t *data, size_t data_size)
{
   GM_DIAG_EVG_USDT_PHYS_RESPONSE_T response_buffer;
   bool msg_message_is_correct = false;

   msg_message_is_correct = (0 == memcmp(mdg_enter_diag_code, &data[1], sizeof(mdg_enter_diag_code)));

   if (msg_message_is_correct)
   {
         SAL_Start_Timer(mdg_timeout, MDG_DIAG_TIMEOUT_MS, false);
         mdg_diag_enable = true;
         Tr_Info_Lo("Enable Manufacturing Mode");

         response_buffer[0] = SERVICE_31;
         response_buffer[1] = data[1];
         response_buffer[2] = data[2];
         response_buffer[3] = data[3];
         response_buffer[4] = data[4];
         response_buffer[5] = data[5];
         response_buffer[6] = data[6];

         /* Enable IF CAN test once enter in to manufacturing diagnostic mode */
         PCAN_PITS_Test(true);

         mdg_positive_response(response_buffer, SEVEN_BYTE_LEN);
   }
   else if (MDG_Diagnostics_Enable())
   {
      /*Reset diagnostics timer.*/
      SAL_Start_Timer(mdg_timeout, MDG_DIAG_TIMEOUT_MS, false);
		   
      SAL_Send(PITS_APP_ID, PITS_THREAD_ID, EVG_PITS_COMMAND, &data[1], (data_size - 1));
   }
   else
   {
      Tr_Warn("Enter diagnostics first!");
   }

   return(true);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
static bool_t MDG_Diagnostics_Enable (void)
{
   return(mdg_diag_enable);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in pits_can.h.
 *
 *===========================================================================*/
static void DG_Cancellation_Message_To_PITS(void)
{
#if 0
   PITS_Disconnect_Sources();
   PITS_Clear_PPS_Timer_Session();
#endif   
}

/*===========================================================================*/
/*!
 * @file pits_can.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 3
 * ctc_ec#156415: Remove build warnings.
 *
 * - 2014-06-11  Tim Wang
 *    - Created initial file.
 */
/*===========================================================================*/