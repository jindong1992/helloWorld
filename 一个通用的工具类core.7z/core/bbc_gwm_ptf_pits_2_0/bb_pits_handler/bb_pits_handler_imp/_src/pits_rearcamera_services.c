/*===========================================================================*/
/**
 * @file pits_rearcamera_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_rearcamera_services.c~2:csrc:ctc_ec#18 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Wed Jun  8 10:52:04 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_rearcamera_services.h"
#include "pits_rearcamera_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 23);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_camera_initialize(void);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_CAMERA_RX_INDEX

#define MID_CAMERA_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_camera_rx_messages[] = {
   MID_CAMERA_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_CAMERA_TX_INDEX

#define MID_CAMERA_TX_INDEX(name, mid) (mid),

static const uint8_t pits_camera_tx_messages[] = {
   MID_CAMERA_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_CAMERA_RX_INDEX
#define MSID_CAMERA_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_camera_rx_message_sets[] = {
   MSID_CAMERA_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_CAMERA_TX_INDEX
#define MSID_CAMERA_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_camera_tx_message_sets[] = {
   MSID_CAMERA_TX_TABLE
};

static uint8_t camera_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T camera_message;      /* for construction of a camera service message to be transmitted */

static uint8_t camera_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t camera_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T camera_session_state;

/**
 * Stores Timer ID for camera Services Session
 */
static SAL_Timer_Id_T pits_camera_session_timer_id;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Camera_Services_Interface = {
   pits_camera_initialize,
   pits_camera_rx_message_sets,
   Num_Elems(pits_camera_rx_message_sets),
   pits_camera_tx_message_sets,
   Num_Elems(pits_camera_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_camera_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_camera_initialize(void)
{
   camera_tx_bus_id = 0;
   memset(&camera_message, 0x00, sizeof(PITS_Message_T));
   memset(camera_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   camera_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   camera_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that camera Session is closed? */
}

/*===========================================================================*
 * FUNCTION: pits_camera_compose_message_header
 *===========================================================================*
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
/*===========================================================================*/
static void pits_camera_compose_message_header(uint8_t mid, uint8_t size)
{
   camera_message.bus  = camera_tx_bus_id;
   camera_message.data = camera_tx_data;
   camera_message.MSID = MSID_CAMERA_SERVICES;
   camera_message.MID  = mid;
   camera_message.data_size = size;
   memset(camera_tx_data, 0x00, size);

}

/*===========================================================================*
 * FUNCTION: pits_camera_session_get_state_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] camera_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] camera_tx_data[1] = Session State (CLOSE, OPEN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_camera_state_req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      camera_tx_bus_id    = message->bus;
      pits_camera_compose_message_header(MID_CAMERA_SESSION_STATE_RPT, 2);

      /* Compose Message Data */
      camera_tx_data[0]   = (uint8_t)SUCCESS;
      camera_tx_data[1]   = (uint8_t)camera_session_state;
      if (message->data_size != 0)
      {
         camera_tx_data[0] = (uint8_t)FAIL;

      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&camera_message));
}

/*===========================================================================*
 * FUNCTION: pits_camera_get_status_req
 *===========================================================================*
 * @brief Receive a Request for Camera Status.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] camera_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] camera_tx_data[1] = Camera Status (off, on)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_camera_get_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      camera_tx_bus_id    = message->bus;
      pits_camera_compose_message_header(MID_CAMERA_SESSION_STATE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Camera Request: Message Data Error");
      }
      else
      {
         camera_tx_data[0]   = (uint8_t)SUCCESS;
         camera_tx_data[1]   = PITS_RVC_Get_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&camera_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_front_camera_get_status_req
 *===========================================================================*
 * @brief Receive a Request for front Camera Status.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] camera_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] camera_tx_data[1] = Camera Status (off, on)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_front_camera_get_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      camera_tx_bus_id    = message->bus;
      pits_camera_compose_message_header(MID_FRONT_CAMERA_SESSION_STATE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Camera Request: Message Data Error");
      }
      else
      {
         camera_tx_data[0]   = (uint8_t)SUCCESS;
         camera_tx_data[1]   = PITS_SVC_Get_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&camera_message);
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_camera_set_status_req
 *===========================================================================*
 * @brief Request the Camera be set to either on or off based upon the request message
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message =Camera Status (off, on)
 * @param [out] camera_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] camera_tx_data[1] = Camera Status (off, on)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_camera_set_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      camera_tx_bus_id    = message->bus;
      pits_camera_compose_message_header(MID_CAMERA_SET_STATUS_RPT, 2);

      /* Compose Message Data */
      camera_tx_data[0]   = (uint8_t)COMMAND_NOT_SUPPORTED;
      
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Camera Request: Message Data Error");
      }
      else
      {
         if ((0x00 == message->data[0]) || (0x01 == message->data[0]))
         {
            PITS_RVC_Set_Status(message->data[0]);
            
            camera_tx_data[0]   = (uint8_t)SUCCESS;
            camera_tx_data[1]   = message->data[0];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&camera_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_front_camera_set_status_req
 *===========================================================================*
 * @brief Request the front Camera be set to either on or off based upon the request message
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message =Camera Status (off, on)
 * @param [out] camera_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] camera_tx_data[1] = Camera Status (off, on)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/

Done_Or_Not_Done_T pits_front_camera_set_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      camera_tx_bus_id    = message->bus;
      pits_camera_compose_message_header(MID_FRONT_CAMERA_SET_STATUS_RPT, 2);

      /* Compose Message Data */
      camera_tx_data[0]   = (uint8_t)COMMAND_NOT_SUPPORTED;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Camera Request: Message Data Error");
      }
      else
      {
         if ((0x00 == message->data[0]) || (0x01 == message->data[0]))
         {
            PITS_SVC_Set_Status(message->data[0]);

            camera_tx_data[0]   = (uint8_t)SUCCESS;
            camera_tx_data[1]   = message->data[0];
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&camera_message);
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_Set_Camera_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_Camera_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (camera_session_state != session)   /* Session State change? */
   {
      camera_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_CAMERA_SESSION, &camera_session_state, sizeof(camera_session_state));   /* Publish new Session State */
      if (camera_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_camera_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_camera_session_timer_id, camera_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Camera_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_Camera_Session(void)
{
   return (camera_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_Camera_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_Camera_Timer(void)
{
   SAL_Create_Timer(PITS_EV_CAMERA_SESSION_TIMEOUT, &pits_camera_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Camera_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_Camera_Timer(void)
{
   SAL_Destroy_Timer(pits_camera_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_Camera_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_Camera_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_CAMERA_SESSION_TIMEOUT)
   {
      if (PITS_Set_Camera_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS CAMERA SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Camera_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Camera_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &camera_session_state, sizeof(camera_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Camera_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_Camera_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_CAMERA_SESSION,NULL,0,PITS_EVG_CAMERA_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_CAMERA_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;
   send_reply.send_id = 0;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*/
/*!
 * @file pits_rearcamera_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Camera Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 11
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 1-May-2012 Darinka Lopez  Rev 10
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 18-Jan-2012 Darinka Lopez  Rev 9
 * SCR kok_basa#19047: Implement MSID(17h)- RearCamera Services Handler 
 * Update rear camera handler for SBX.
 *
 * 5-Jan-2012 Darinka Lopez  Rev 8
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 6
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 13 Jan 2011 Miguel Garcia
 * Remove unused Pits
 *
 * 03-Ago-2010 Miguel Garcia  Rev 3
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 2-Oct-2009 David Mooar  Rev 2
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
