/*===========================================================================*/
/**
 * @file pits_misc_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_gmdiag_services.c~2:csrc:ctc_ec#8 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Wed Jul  6 17:26:42 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "am_fm_tuner_driver.h"
#include "amfm_manager.h"
#include "app_header.h"
#include "audio_drvr_mgr.h"
#include "audio_mgr.h"
#include "audio_mgr_diag_ovrd.h"
#if defined(GWM_CHB041)|| defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT)
#include "backup_camera_gwm.h"
#endif
#ifdef FORD_C490
#include "backup_camera.h"
#endif
#include "cals_ps.h"
#include "disc_pbk_diag_proxy.h"
#include "disc_playback_ps.h"
#include "disc_pbk_hdlr_ps.h"
#include "hd_radio.h"
#include "hd_radio_common_types.h"
#include "hmi_ps.h"
#include "persistent_storage.h"
#include "pits_audio_services_cfg.h"
#include "pits_display_services.h"
#include "pits_display_services_cfg.h"
#include "pits_gmdiag_services.h"
#include "pits_gmdiag_services_cbk.h"
#include "pits_programming_services.h"
#include "pits_mfg_parameters_ps.h"
#include "pits_misc_services.h"
#include "pits_processing_filesys.h"
#include "pits_tuner_services.h"
#include "pits_tuner_services_cbk.h"
#include "playback_plugin_engine_event_types.h"
#include "preset_mgr.h"
#include "preset_mgr_ps.h"
#include "preset_mgr_cbk.h"
#include "reuse.h"
#include "rds_dec.h"
#include "rds_dec_cbk.h"
#include "rds_foreground_tuner.h"
#include "rds_pl.h"
#include "source_manager_helper.h"
#include "source_manager_acfg.h"
#include "source_manager_ps.h"
#include "theft_lock.h"
#include "theft_lock_ps.h"
#include "theft_lock_cfg.h"
#include "tuner_manager.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "utilities.h"
#include "vip_pits.h"
#include "vui_diag_oats.h"
#include "vui_diag_srdl.h"
#include "version_tracking.h"
#include "xsal_util.h"
#include "cal_info.h"
#include "cal_rearcam.h"
#include "cal_tune.h"
#include "playback_plugin_engine.h"
#include "betula_bluetooth_diag.h"
#include "bt_diag_event_decode.h"
#include "bt_connection_manager_decode.h"
#include "bt_hfp_event_decode.h"
#include "bt_as_types.h"
#include "bt_as_event_decode.h"
#include "betula_types.h"
#include "audio_facade_ps.h"
#include "audio_focus_mgr_ps.h"
#include "tuner_manager_cbk.h"
#include "pits_pandora_services.h"
#include "mfg_parameters_ps.h"

EM_FILENUM(PITS_MODULE_ID_5, 28);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define AM_LOW_FREC                        (0x0212)
#define AM_SPACE_FREC_CONST                (0x0A)
#define FM_LOW_FREC                        (0x2242)
#define FM_SPACE_FREC_CONST                (0xC8)
#define PRESET_CERO_SELECTED               (0x00)
#define NO_PRESET_SELECTED                 (0xFF)
#define BASE_CONSTANT_TO_CHANNEL           (0x0A)

#define TOTAL_VINS           (16)

#define PITS_NEW_BAND_ONE      (0x01)
#define PITS_NEW_BAND_TWO      (0x02)
#define PITS_NEW_BAND_THREE    (0x03)

#define NEW_BAND_AM            (0x01)
#define NEW_BAND_FM            (0x02)
#define NEW_BAND_XM            (0x03)
#define AM_CHANNEL_SPACE       (0x0A)
#define FM_CHANNEL_SPACE       (0xC8)
#define FM_BASE_CONST          (0x0A)

#define PITS_PRESET_MGR_MAX_LABEL_SIZE   (16+1)
/* need replace with TUNER_SERVICE_NAME_MAX +1
assume TUNER_SERVICE_NAME_MAX may not include '\0'*/

#define PITS_PRESET_MGR_NUM_ZONES        (SYS_NUM_ZONES)
#define PITS_PRESET_MGR_NUM_PAGES        6
#define PITS_PRESET_MGR_NUM_PRESETS      5
#define PITS_PRESET_MGR_ALL_PRESET   (PITS_PRESET_MGR_NUM_PAGES * PITS_PRESET_MGR_NUM_PRESETS)

#define Max_Dynamic_DPID       0x05
#define SINGLE_FRAME 0x00
#define FIRST_MULTIPLE_FRAME 0x01
#define INTERMEDIATE_FRAME 0x02
#define LAST_FRAME 0x03
#define PITBTL_AS_OP_SET_SETTINGS                        4
#define PITBTL_AS_OP_SELECT_PLAYER                       9
#define PITBTL_AS_OP_PLAY_ITEM_UID                       15
#define PITBTL_AS_OP_CHANGE_PATH                      13
#define PITBTL_AS_OP_SET_WINDOW                       10

char Pits_Preset_Page_Info[PITS_PRESET_MGR_NUM_PRESETS][PITS_PRESET_MGR_MAX_LABEL_SIZE];
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum PITS_Band_DPID_Tag
{
   PITS_BAND_XM     = 0x00,
   PITS_BAND_FM1    = 0x01,
   PITS_BAND_AM     = 0x02,
} PITS_Band_DPID_T;

typedef struct Band_Translation_Tag
{
   PITS_Band_DPID_T  pits_band;
   PITS_Tuner_Band_T tuner_band;
} Band_Translation_T;

typedef enum PITS_Band_CPID_Tag
{
   PITC_BAND_AM     = 0x00,
   PITC_BAND_FM1    = 0x01,
   PITC_BAND_XM     = 0x30,
} PITS_Band_CPID_T;

typedef struct Band_Translation_CPID_Tag
{
   PITS_Band_CPID_T  pits_band_cpid;
   PITS_Tuner_Band_T tuner_band_cpid;
} Band_Translation_CPID_T;

typedef enum PITS_Source_DPID_Tag
{
   PITS_SOURCE_NONE          = 0x00,
   PITS_SOURCE_OFF           = 0x00,
   PITS_SOURCE_TUNER_AM      = 0x01,
   PITS_SOURCE_TUNER_FM      = 0X03,
   PITS_SOURCE_CD            = 0x04,
   PITS_SOURCE_SDAR          = 0x18,
   PITS_SOURCE_DVD           = 0x1A,
   PITS_SOURCE_DVD2          = 0x1B,
   PITS_SOURCE_PHONE         = 0x1C,
   PITS_SOURCE_REAR_AUX      = 0x1D,
   PITS_SOURCE_FRONT_AUX     = 0x1F,
   PITS_SOURCE_USB           = 0x24,
   PITS_SOURCE_SD         = 0x25,
} PITS_Source_DPID_T;

typedef enum PITS_Source_CPID_Tag
{
   PITC_SOURCE_NONE          = 0x00,
   PITC_SOURCE_OFF           = 0x00,
   PITC_SOURCE_TUNER         = 0x01,
   PITC_SOURCE_RADIO_MONITOR = 0x02,
   PITC_SOURCE_CD            = 0x04,
   PITC_SOURCE_TUNER_AM      = 0x06,
   PITC_SOURCE_TUNER_FM1     = 0x07,
   PITC_SOURCE_TUNER_FM2     = 0x08,
   PITC_SOURCE_DVD           = 0x09,
   PITC_SOURCE_DVD2          = 0x0A,
   PITC_SOURCE_USB1          = 0x0B,
   PITC_SOURCE_USB2          = 0x0C,
   PITC_SOURCE_USB3          = 0x0D,
   PITC_SOURCE_BLUETOOT      = 0x0F,
   PITC_SOURCE_FRONT_AUX     = 0x70,
   PITC_SOURCE_REAR_AUX      = 0x71,
   PITC_SOURCE_PHONE         = 0x83,
   PITC_SOURCE_SDAR          = 0x85,
   PITC_SOURCE_SD     = 0x86,
} PITS_Source_CPID_T;

typedef struct Source_Translation_Tag
{
   PITS_Source_DPID_T       pits_source;
   Audio_Logical_Src_T logical_source;
} Source_Translation_T;

typedef struct Source_Translation_CPID_Tag
{
   PITS_Source_CPID_T       pits_source_cpid;
   Audio_Logical_Src_T logical_source_cpid;
} Source_Translation_CPID_T;

typedef struct Source_Translation_SSM_Tag
{
   PITS_Source_CPID_T       pits_source;
   SSM_Source_Type_T   logical_source_ssm;
} Source_Translation_SSM_T;

static const Source_Translation_SSM_T Set_Source_SSM_Table[] =
{
   {PITC_SOURCE_NONE, SSM_SRC_NONE},
   {PITC_SOURCE_TUNER, SSM_SRC_FM},
   {PITC_SOURCE_RADIO_MONITOR, SSM_SRC_NONE},
   {PITC_SOURCE_CD, SSM_SRC_AUDIO_DISC},
   {PITC_SOURCE_OFF, SSM_SRC_NONE},
   {PITC_SOURCE_TUNER_AM, SSM_SRC_AM},
   {PITC_SOURCE_TUNER_FM1, SSM_SRC_FM},
   {PITC_SOURCE_TUNER_FM2, SSM_SRC_FM},
   {PITC_SOURCE_DVD, SSM_SRC_VIDEO_DISC},
   {PITC_SOURCE_DVD2, SSM_SRC_VIDEO_DISC},
   {PITC_SOURCE_USB1, SSM_SRC_IPOD},
   {PITC_SOURCE_USB2, SSM_SRC_MSD},
   {PITC_SOURCE_USB3, SSM_SRC_MTP},
   {PITC_SOURCE_BLUETOOT, SSM_SRC_PHONE},
   {PITC_SOURCE_FRONT_AUX, SSM_SRC_AUX_FRONT},
   {PITC_SOURCE_REAR_AUX, SSM_SRC_AUX_REAR},
   {PITC_SOURCE_PHONE, SSM_SRC_ONSTAR},
   {PITC_SOURCE_SDAR, SSM_SRC_XM},
};

typedef enum Pitsgm_Tuner_Band_Tag
{
   PTUNER_BAND_FM,
   PTUNER_BAND_AM,
   PTUNER_BAND_LW,
   PTUNER_BAND_WX,
   PTUNER_BAND_XM,
} Pitsgm_Tuner_Band_T;

typedef struct PITSGM_TUNER_EVG_CHANNEL_Tag
{
   Sys_Zone_T zone;
   Pitsgm_Tuner_Band_T band;
   uint32_t channel_number;
   uint16_t service_identifier;
} PITSGM_TUNER_EVG_CHANNEL_T;
/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void PITS_GMdiag_Initialize(void);
static void PITS_GMdiag_Compose_Message_Header(uint8_t mid, uint8_t size);

static bool pits_dpid_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_DPID_T *pits_band);
static bool pits_dpid_audio_map_logical_src_to_pits_src(Audio_Logical_Src_T logical_source, PITS_Source_DPID_T *pits_source);
static bool pits_cpid_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_CPID_T *pits_band);
static bool pits_cpid_audio_map_logical_src_to_pits_src(Audio_Logical_Src_T logical_source, PITS_Source_CPID_T *pits_source);
static uint8_t Diagnostics_Get_Page(preset_mgr_zone_t zone);
static uint8_t Diagnostics_Get_Preset(preset_mgr_zone_t zone);
static bool_t pits_cpid_tuner_map_pits_band_to_band(PITS_Band_CPID_T pits_band, PITS_Tuner_Band_T *tuner_band);
static bool_t pits_cpid_tuner_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel);
/*static bool_t pits_cpid_audio_map_pits_src_to_logical_src(PITS_Source_CPID_T pits_source, Audio_Logical_Src_T *logical_source);*/
static void Pits_Preset_Update_HMI_Display_Info(preset_mgr_zone_t zone);
static PRESET_EVG_LOOKUP_RESULT_T Pits_Preset_Mgr_Lookup_Preset(preset_mgr_zone_t zone, SSM_Source_Type_T band, uint32_t ch_id, uint16_t pi);
void PITS_Get_Source_Hours (void);
PITS_Source_CPID_T PITS_Get_Source_DPID10 (void);
static bool_t pits_gmdiag_map_pits_band_to_band(PITS_Band_CPID_T pits_band, PITS_Tuner_Band_T *tuner_band);
static bool_t pits_gmdiag_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel);
static void Pits_Preset_Update_HMI_Highlights(preset_mgr_zone_t zone);
static void Pits_Preset_Get_HMI_Highlights(preset_mgr_zone_t zone);
void Pits_Default_Backup_Camera_Load (void);
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_GMDIAG_RX_INDEX

#define MID_GMDIAG_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T PITS_GMdiag_RX_Messages[] = {
   MID_GMDIAG_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_GMDIAG_TX_INDEX

#define MID_GMDIAG_TX_INDEX(name, mid) (mid),

static const uint8_t PITS_GMdiag_TX_Messages[] = {
   MID_GMDIAG_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_GMDIAG_RX_INDEX
#define MSID_GMDIAG_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T PITS_GMdiag_RX_Message_Sets[] = {
   MSID_GMDIAG_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_GMDIAG_TX_INDEX
#define MSID_GMDIAG_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T PITS_GMdiag_TX_Message_Sets[] = {
   MSID_GMDIAG_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static uint8_t TX_Bus_ID;   /* ID of the bearing bus on which to send response */

static PITS_Message_T TX_Message;      /* for construction of a misc service message to be transmitted */

static uint8_t TX_Data[PITS_MAX_MESSAGE_SIZE];

#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static const Band_Translation_T Band_Translation[] =
{
   PITS_BAND_TO_TUNER_BAND_TABLE_DPID
};

#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static const Source_Translation_T Source_Translation[] =
{
   PITS_SRC_TO_LOGICAL_SRC_TABLE_DPID
};

#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static const Band_Translation_CPID_T Band_Translation_Cpid[] =
{
   PITS_BAND_TO_TUNER_BAND_TABLE_CPID
};

#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static const Source_Translation_CPID_T Source_Translation_Cpid[] =
{
   PITS_SRC_TO_LOGICAL_SRC_TABLE_CPID
};
static preset_mgr_page_num_type diag_current_page;
preset_mgr_page_num_type diag_current_preset;

static AuMgr_DO_Enable_T Audio_Overrides;

static PITS_Source_CPID_T pits_source_cd = PITC_SOURCE_NONE;
static uint8_t diag_bass;
static uint8_t diag_mid;
static uint8_t diag_treble;
static uint8_t dyn_dpid_support_table[Max_Dynamic_DPID*15];
static uint8_t pit_time_rpt[16];
static uint16_t pit_time_length;
static uint8_t diag_fade;
static uint8_t diag_balance;
static uint8_t get_page_num_fav;
static uint8_t get_page_num_fav_write;
PITS_TUNER_EVG_CHANNEL_T     Current_Tuner_Data;
PRESET_EVG_LOOKUP_RESULT_T Preset_Highlights;
static uint8_t diag_fast_volume;
static uint8_t didE1_cal_state = 0;
static uint8_t pit_time_cpid[16];
static SSM_Source_Type_T pit_source_prev_to_xm = SSM_SRC_FM;
static uint8_t pits_init_volume;
static BT_CM_Module_State_T statusconnected = BT_CM_STATE_INITIALIZING;
static uint8_t pits_call_count;
static BT_AS_Playback_State_T pits_bt_playback = BT_AS_PLAY_STATUS_STOPPED;
static uint8_t pits_bt_avrcp = 0;
static bool_t pits_srdl = false;
static bool_t pits_oats = false;
static Tuner_Mgr_Target_T pit_last_target_am;
static Tuner_Mgr_Target_T pit_last_target_fm;
static Tuner_Mgr_Target_T pit_last_target_xm;
static uint8_t pits_quality_report = 0;
/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_GMdiag_Services_Interface = {
   PITS_GMdiag_Initialize,
   PITS_GMdiag_RX_Message_Sets,
   Num_Elems(PITS_GMdiag_RX_Message_Sets),
   PITS_GMdiag_TX_Message_Sets,
   Num_Elems(PITS_GMdiag_TX_Message_Sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Misc_Initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
static void PITS_GMdiag_Initialize(void)
{
   TX_Bus_ID = 0;
   memset(&TX_Message, 0x00, sizeof(PITS_Message_T));
   memset(TX_Data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

static void PITS_GMdiag_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   TX_Message.bus = TX_Bus_ID;
   TX_Message.data = TX_Data;
   TX_Message.MSID = MSID_GMDIAG_SERVICES;
   TX_Message.MID = mid;
   TX_Message.data_size = size;
   memset(&TX_Data[0], 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID02
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID02 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID02 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID02_Req(const PITS_Message_T * message)
{
    Sys_Zone_T zone = SYS_ZONE_MAIN;
    PITS_Band_DPID_T pits_band = PITS_BAND_XM;
    bool pits_band_found = false;
    PITS_TUNER_EVG_CHANNEL_T tune_band_info_dpid;
    uint8_t dpid_channel = 0x00;
    uint8_t get_page_num = Diagnostics_Get_Page(zone);
    uint8_t get_preset_num = Diagnostics_Get_Preset(zone);
    Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
    Audio_Logical_Src_T logical_source;
    PITS_Source_DPID_T source = PITS_SOURCE_NONE;
    PRESET_EVG_LOOKUP_RESULT_T lookup_result;
    bool source_found = false;
    bool vin_learnt = false;
    Theft_Handler_Mode_T ps_mode = NORMAL;
    Disc_Pbk_Diag_DVD_Slot_Media_t dvd_slot_media = Disc_Pbk_Diag_Get_DVD_Slot_Media();
    Tuner_Mgr_Dev_Type_T pit_tun_device = TUNER_MGR_DEV_AM;
    Tuner_Mgr_Target_T pit_last_target;
    uint32_t limit_frecfminf = Pits_Get_FM_Freq_Low();
    uint32_t limit_frecaminf = Pits_Get_AM_Freq_Low();
    uint8_t  fm_step_const = 10*(Pits_Get_FM_Freq_Step());
    uint8_t  am_step_const = Pits_Get_AM_Freq_Step();
    Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID02_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          /* VIP bytes info */
          TX_Data[1] = message->data[0];
          TX_Data[3] = message->data[1];
          TX_Data[7] = message->data[2];

          tune_band_info_dpid.zone = SYS_ZONE_MAIN;
          tune_band_info_dpid.channel_number = PITS_Get_AMFM_Tuner_Frequency();
          tune_band_info_dpid.band = PITS_Get_Tuner_Source_Type();
          tune_band_info_dpid.service_identifier = 0;
          pits_band_found = pits_dpid_tuner_map_band_to_pits_band(tune_band_info_dpid.band, &pits_band);
          if (pits_band_found)
          {
             TX_Data[1] |= (uint8_t) (pits_band & 0x0F);
             /* Byte2 DPID02 */
             if (pits_band == PITS_BAND_AM)
             {
                dpid_channel = (uint8_t)((tune_band_info_dpid.channel_number - limit_frecaminf)/am_step_const);
             }
             if (pits_band == PITS_BAND_FM1)
             {
                dpid_channel = (uint8_t)(((tune_band_info_dpid.channel_number - limit_frecfminf)*BASE_CONSTANT_TO_CHANNEL)/fm_step_const);
             }
             else if (pits_band == PITS_BAND_XM)
             {
                dpid_channel = (uint8_t) tune_band_info_dpid.channel_number;
                tune_band_info_dpid.service_identifier = PITS_Get_XM_Tuner_SID();
             }
             TX_Data[2] = dpid_channel;
          }

          logical_source = AuMgr_Get_Source(zone, bus);
          source_found = pits_dpid_audio_map_logical_src_to_pits_src(logical_source, &source);
          if (source_found)
          {
             if (source == PITS_SOURCE_TUNER_AM)
             {
                pit_tun_device = TUNER_MGR_DEV_AM;
                Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
                pits_band = PITS_BAND_AM;
                TX_Data[1] |= (uint8_t) (pits_band & 0x0F);
                dpid_channel = (uint8_t)((((pit_last_target.target_value)&0x0000FFFF) - limit_frecaminf)/am_step_const);
                TX_Data[2] = dpid_channel;
                tune_band_info_dpid.band = SSM_SRC_AM;
                tune_band_info_dpid.channel_number = (pit_last_target.target_value)&0x0000FFFF;
             }
             if (source == PITS_SOURCE_TUNER_FM)
             {
                pit_tun_device = TUNER_MGR_DEV_FM;
                Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
                pits_band = PITS_BAND_FM1;
                TX_Data[1] |= (uint8_t) (pits_band & 0x0F);
                dpid_channel = (uint8_t)(((((pit_last_target.target_value)&0x0000FFFF) - limit_frecfminf)*BASE_CONSTANT_TO_CHANNEL)/fm_step_const);
                TX_Data[2] = dpid_channel;
                tune_band_info_dpid.band = SSM_SRC_FM;
                tune_band_info_dpid.channel_number = (pit_last_target.target_value)&0x0000FFFF;
             }
             if (source == PITS_SOURCE_SDAR)
             {
                pit_tun_device = TUNER_MGR_DEV_XM;
                Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
                pits_band = PITS_BAND_XM;
                TX_Data[1] |= (uint8_t) (pits_band & 0x0F);
                tune_band_info_dpid.band = SSM_SRC_XM;
                dpid_channel = (uint8_t) tune_band_info_dpid.channel_number;
                TX_Data[2] = dpid_channel;
                tune_band_info_dpid.service_identifier = PITS_Get_XM_Tuner_SID();
             }

          }
          /* Byte3 DPID02 */
          vin_learnt = Theft_PS_Get_VIN_Learnt();
          if (vin_learnt)
          {
             TX_Data[3] |= BIT5;
          }
          ps_mode = Theft_PS_Get_Mode();
          if (ps_mode == LOCKED)
          {
             TX_Data[3] |= BIT4;
          }
          /* Byte4 DPID02 */
          TX_Data[4] = Theft_PS_Get_VIN_Learnt_Count();
          /* Byte5 DPID02 */
          lookup_result = Pits_Preset_Mgr_Lookup_Preset(zone,
                                          tune_band_info_dpid.band,
                                          tune_band_info_dpid.channel_number,
                                          tune_band_info_dpid.service_identifier);
          if (!lookup_result.match_status)
          {
             get_preset_num = 0x00;
          }
          else
          {
             get_preset_num = lookup_result.active_preset;
          }

          TX_Data[5] = (get_page_num << 4) + get_preset_num;

          /*logical_source = AuMgr_Get_Source(zone, bus);
          source_found = pits_dpid_audio_map_logical_src_to_pits_src(logical_source, &pits_source);*/
          /* Byte6 DPID02 */
          if (source_found)
          {
             if (source == PITS_SOURCE_TUNER_FM)
             {
                source = PITS_SOURCE_TUNER_AM;
             }
             if (source == PITS_SOURCE_DVD)
             {
                source = PITS_SOURCE_DVD2;
             }

             TX_Data[6] = (uint8_t) source;
          }
          /* Byte7 DPID02 */
          TX_Data[7] |= ((dvd_slot_media.media) & 0x0F);

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID04
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID04_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   /*Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Tone_T tone_settings;*/
   uint8_t adjust_tone;
   uint8_t adjust_vol;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID04_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          /* Decode received messages  */
          TX_Data[0] = (uint8_t) SUCCESS;
          /* Byte 1 */
          /*adjust_vol = (uint8_t) Scale(AuMgr_Get_Volume(zone, bus),
                             VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);*/
          adjust_vol = (uint8_t) Scale(Audio_PS_Get_Volume(zone),
             VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
          if ((adjust_vol == 0x00) && (diag_fast_volume > 0x07))
          {
             /*adjust_vol = diag_fast_volume;*/
          }
          diag_fast_volume = adjust_vol;
          TX_Data[1] = adjust_vol;
          /* Byte 2 */
          /*tone_settings = AuMgr_Get_All_Tone_Bands(zone, bus);Audio_PS_Get_Tone_Band
          TX_Data[2] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_BASS_BAND],
                                    TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);*/
          TX_Data[2] = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_BASS_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
          /* Byte 3 */
          /*TX_Data[3] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_MID_BAND],
                                    TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);*/
          TX_Data[3] = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_MID_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
          /* Byte 4 */
          /*TX_Data[4] = (uint8_t) Scale(tone_settings.absolute_detent[AUDIO_TREBLE_BAND],
                                    TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);*/
          TX_Data[4] = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_TREBLE_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
          /* Byte 5 */
          /*adjust_tone = (uint8_t) Scale(AuMgr_Get_Fade(zone, bus),
                                    FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);*/
          adjust_tone = (uint8_t) Scale(Audio_PS_Get_Fade(zone),
                                              FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);
          TX_Data[5] = (0xFF - (((adjust_tone - 0x44)*0xFF)/0x77));
          if (TX_Data[5] == 0x12)
                    {
                       TX_Data[5] = 0x13;
                    }
          if (TX_Data[5] == 0x25)
                    {
                       TX_Data[5] = 0x24;
                    }
          if (TX_Data[5] == 0x36)
                    {
                       TX_Data[5] = 0x37;
                    }
          if (TX_Data[5] == 0x49)
                    {
                       TX_Data[5] = 0x48;
                    }
          if (TX_Data[5] == 0x5A)
                    {
                       TX_Data[5] = 0x5C;
                    }
          if (TX_Data[5] == 0x6E)
                    {
                       TX_Data[5] = 0x6D;
                    }
          if (TX_Data[5] == 0x7F)
                    {
                       TX_Data[5] = 0x80;
                    }
          if (TX_Data[5] == 0x92)
                    {
                       TX_Data[5] = 0x91;
                    }
          if (TX_Data[5] == 0xA3)
                    {
                       TX_Data[5] = 0xA5;
                    }
          if (TX_Data[5] == 0xB7)
                    {
                       TX_Data[5] = 0xB6;
                    }
          if (TX_Data[5] == 0xC8)
                    {
                       TX_Data[5] = 0xC9;
                    }
          if (TX_Data[5] == 0xDB)
                    {
                       TX_Data[5] = 0xDA;
                    }
          if (TX_Data[5] == 0xEC)
                    {
                       TX_Data[5] = 0xED;
                    }
          /* Byte 6 */
          /*adjust_tone = (uint8_t) Scale(AuMgr_Get_Balance(zone, bus),
                                    BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);*/
          adjust_tone = (uint8_t) Scale(Audio_PS_Get_Balance(zone),
                                              BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);
          TX_Data[6] = (((adjust_tone - 0x44)*0xFF)/0x77);
          /* Byte 7 */
          TX_Data[7] = 0;
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID07
 *===========================================================================*
 * @brief Receive a Request to get DPID07
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID07 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID07 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID07_Req(const PITS_Message_T * message)
{
   Disc_Pbk_Diag_Playback_Levels_t playback_levels = Disc_Pbk_Diag_Get_Playback_Levels();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID07_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          if ((DPPH_PS_Get_Mech())== 1)
          {
             /* Byte 1  CD Deck HW Level*/
             TX_Data[1] = playback_levels.hw_level;
             /* Byte 2  CD Deck SW Level*/
             TX_Data[2] = playback_levels.sw_level;
          }
          else
          {
             /* Byte 3  DVD Deck HW Level*/
             TX_Data[3] = playback_levels.hw_level;
             /* Byte 4  DVD Deck SW Level*/
             TX_Data[4] = playback_levels.sw_level;
          }
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID08
 *===========================================================================*
 * @brief Receive a Request to get DPID08
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID08 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID08 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID08_Req(const PITS_Message_T * message)
{
   Disc_Pbk_Diag_Playback_Error_t dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID08_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          TX_Data[1] = dpid8_errors.error_count.cd_focus;
          TX_Data[2] = dpid8_errors.error_count.cd_tracking;
          TX_Data[3] = dpid8_errors.error_count.cd_load_eject;
          TX_Data[4] = dpid8_errors.error_count.dvd_play;
          TX_Data[5] = dpid8_errors.error_count.dvd_region_code;
          TX_Data[6] = dpid8_errors.error_count.dvd_load_eject;
          TX_Data[7] = dpid8_errors.error_count.dvd_format;
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID09
 *===========================================================================*
 * @brief Receive a Request to get DPID09
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID09 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID09 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID09_Req(const PITS_Message_T * message)
{
   RDS_Pi_T received_pi = RD_PI();
   RDS_Pi_T current_pi = RDS_Get_Current_PI();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID09_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          /* Byte 1 Received PI MSB*/
          TX_Data[1] = (uint8_t) (received_pi >> 8);
          /* Byte 2 Received PI LSB*/
          TX_Data[2] = (uint8_t) received_pi;
          /* Byte 1 Current PI MSB*/
          TX_Data[3] = (uint8_t) (current_pi >> 8);
          /* Byte 2 Current PI LSB*/
          TX_Data[4] =(uint8_t) current_pi;
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID10
 *===========================================================================*
 * @brief Receive a Request to get DPID10
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID10 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID10 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID10_Req(const PITS_Message_T * message)
{
   PITS_Source_CPID_T source;
   bool is_center = AM_FM_Drv_Is_Center(AM_FM_DRV_TUNER_1);
   uint8_t is_quality = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID10_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          source = PITS_Get_Source_DPID10();
          if ((source == PITC_SOURCE_TUNER_FM1)||(source == PITC_SOURCE_TUNER_AM))
          {
             is_quality = pits_quality_report;
             TX_Data[1] = is_quality;


             /* Byte 5 */
             if (source == PITC_SOURCE_TUNER_FM1)
             {
                if ((is_center)&&(is_quality>0x15))
                {
                   TX_Data[5] |= BIT5;
                }
             }
             else
             {
                if(is_center)
                {
                   TX_Data[5] |= BIT5;
                }
             }

          }
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

void Pits_Set_Gmdiag_Quality (uint8_t quality)
{
   pits_quality_report = quality;
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID11
 *===========================================================================*
 * @brief Receive a Request to get DPID11
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID11 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID11 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID11_Req(const PITS_Message_T * message)
{
   Disc_Pbk_Diag_Media_Pos_t media_position = Disc_Playback_Get_Media_Position();
   Disc_Pbk_Diag_CD_Status_t  cd_status = Disc_Pbk_Diag_Get_CD_Status();
   uint32_t new_time_elap = 0;
   uint32_t  pit_seconds;
   uint8_t   pit_hours;
   uint32_t   pit_time_rpt12 = pit_time_rpt[12];
   uint32_t   pit_time_rpt13 = pit_time_rpt[13];
   uint32_t   pit_time_rpt14 = pit_time_rpt[14];
   uint32_t   pit_time_rpt15 = pit_time_rpt[15];
   uint8_t  pit_tot_hours;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID11_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          new_time_elap = pit_time_rpt12 + ((pit_time_rpt13 & 0x000000FF)<<8) + ((pit_time_rpt14 & 0x000000FF)<<16) + ((pit_time_rpt15 & 0x000000FF)<<24);
          pit_seconds = new_time_elap / 0x3E8;
          pit_hours =  pit_seconds / 3600;
          /*TX_Data[1] =  pit_time_rpt[0];source*/

          TX_Data[0] = (uint8_t) SUCCESS;
          /*CD Position, Track Number*/
          TX_Data[1] = (uint8_t) (media_position.track_number >> 8);
          TX_Data[2] = (uint8_t) media_position.track_number;
          TX_Data[3] = 0;/*Tot track not available*/
          TX_Data[4] = 0;/*Tot track not available*/
          /*CD Position, Minutes of Elapsed Time*/
          TX_Data[5] = (uint8_t) BCD_To_Hex (media_position.minutes,2);
          /*CD Position, Seconds of Elapsed Time*/
          TX_Data[6] = (uint8_t) BCD_To_Hex (media_position.seconds,2);
          /*CD Inserted*/
          if (cd_status.media.CD_Pbk_Diag_Media_Status_data == CD_PBK_DIAG_MEDIA_STATUS_INSERTED)
          {
          TX_Data[7] |= BIT7;
          }
          if (pit_hours > 0x7F)
          {
             pit_hours = 0x7F;
          }
          pit_tot_hours = (uint8_t) Hex_To_BCD (pit_hours,2);
          TX_Data[7] |= pit_tot_hours;

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID14
 *===========================================================================*
 * @brief Receive a Request to get DPID14
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID14 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID14 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID14_Req(const PITS_Message_T * message)
{
   Whole_Vin_T    vin_number = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID14_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          Theft_PS_Get_Whole_VIN(vin_number);

          TX_Data[1] = vin_number[10];
          TX_Data[2] = vin_number[11];
          TX_Data[3] = vin_number[12];
          TX_Data[4] = vin_number[13];
          TX_Data[5] = vin_number[14];
          TX_Data[6] = vin_number[15];
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID15
 *===========================================================================*
 * @brief Receive a Request to get DPID15
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID15 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID15 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID15_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   AM_FM_Qual_T     qual1;
   AM_FM_Drv_Get_Quality(AM_FM_DRV_TUNER_1, &qual1);

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID15_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          TX_Data[1] = 0;
          TX_Data[2] = (uint8_t) qual1.usn;
          TX_Data[3] = 0;
          TX_Data[4] = (uint8_t) qual1.wbam;
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID16
 *===========================================================================*
 * @brief Receive a Request to get DPID16
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID16 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID16 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID16_Req(const PITS_Message_T * message)
{
   uint32_t new_time_elap = 0;
   uint32_t  pit_seconds;
   uint8_t   pit_minutes;
   uint8_t   pit_out_sec;
   uint8_t   pit_hours;
   uint32_t   pit_time_rpt12 = pit_time_rpt[12];
   uint32_t   pit_time_rpt13 = pit_time_rpt[13];
   uint32_t   pit_time_rpt14 = pit_time_rpt[14];
   uint32_t   pit_time_rpt15 = pit_time_rpt[15];
   uint8_t  pit_tot_hours;
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID16_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          logical_source = AuMgr_Get_Source(zone, bus);
          pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
          if ((source == PITC_SOURCE_USB1)||(source == PITC_SOURCE_USB2)||(source == PITC_SOURCE_USB3))
          {
             new_time_elap = pit_time_rpt12 + ((pit_time_rpt13 & 0x000000FF)<<8) + ((pit_time_rpt14 & 0x000000FF)<<16) + ((pit_time_rpt15 & 0x000000FF)<<24);
             pit_seconds = new_time_elap / 0x3E8;
             pit_out_sec = pit_seconds % 60;
             pit_minutes = (pit_seconds / 60) % 60;
             pit_hours =  pit_seconds / 3600;
             TX_Data[0] = (uint8_t) SUCCESS;
             /*CD MP3/WMA Directory*/
             /*CD Position, Track Number*/
             TX_Data[1] = 0;/*Fix usb track number*/
             TX_Data[2] = 0;/*Fix usb track number*/
             TX_Data[3] = 0;/*Tot track not available*/
             TX_Data[4] = 0;/*Tot track not available*/
             /*CD Position, Minutes of Elapsed Time*/
             TX_Data[5] = (uint8_t) BCD_To_Hex (pit_minutes,2);
             /*CD Position, Seconds of Elapsed Time*/
             TX_Data[6] = (uint8_t) BCD_To_Hex (pit_out_sec,2);
             /*USB Inserted*/
             TX_Data[7] |= BIT7;
             if (pit_hours > 0x7F)
             {
                pit_hours = 0x7F;
             }
             pit_tot_hours = (uint8_t) Hex_To_BCD (pit_hours,2);
             TX_Data[7] |= pit_tot_hours;
          }

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DPID17
 *===========================================================================*
 * @brief Receive a Request to get DPID17
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID17 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID17 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DPID17_Req(const PITS_Message_T * message)
{
   Disc_Pbk_Diag_Integral_Info_t dvd_integral = Disc_Pbk_Diag_Get_Integral_Info();
   PITS_Source_CPID_T source;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID17_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          source = PITS_Get_Source_DPID10();
          if ((source == PITC_SOURCE_DVD2)||(source == PITC_SOURCE_DVD))
          {
             /*DVD-V/A Title Number*/
             TX_Data[1] = dvd_integral.dvdv_title;
             /*DVD-V/A Chapter Number*/
             TX_Data[2] = dvd_integral.dvdv_chapter;
             /*DVD-V/A Minutes of Elapsed Time*/
             TX_Data[3] = dvd_integral.minutes;
             /*DVD-V/A Seconds of Elapsed Time  E=N*/
             TX_Data[4] = dvd_integral.seconds;
             /*DVD MP3/WMA Directory */
             TX_Data[5] = dvd_integral.rom_directory;
             /*DVD MP3/WMA File Number  E=N */
             TX_Data[6] = (uint8_t) (dvd_integral.rom_filenumber >> 8);
             /*DVD MP3/WMA File Number  E=N */
             TX_Data[7] = (uint8_t) dvd_integral.rom_filenumber;
          }

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Set_CPID3_Req
 *===========================================================================*
 * @brief Receive a Request to get CPID3
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = CPID3 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = CPID3 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_CPID3_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   uint8_t event_speaker;
   Audio_Detent_T balance;
   Audio_Detent_T fade;
   uint8_t data_balance;
   uint8_t data_fade;
   Audio_Mute_State_T mute_state = AUDIO_UNMUTE;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DPID17_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          zone = (Sys_Zone_T) message->data[0];
          bus  = (Sys_Audio_Bus_T) message->data[1];
          TX_Data[1] = zone;
          TX_Data[2] = bus;
          TX_Data[3] = message->data[2];
          if (message->data[3] == 0x01)
          {
             mute_state = AUDIO_MUTE;
          }
          else
          {
             mute_state = AUDIO_UNMUTE;
          }
          AuMgr_Set_Mute_State_Bus(zone, bus, mute_state);
          if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
               (SYS_ZONE_MAIN == zone))
          {
              TX_Data[0] = (uint8_t) SUCCESS;
              event_speaker = message->data[2] & 0xF0;
              switch ( event_speaker )
              {
                  case 0x10:
                  {
                     data_balance = 0xFF;
                     data_fade = 0x00;
                     break;
                  }
                  case 0x20:
                  {
                     data_balance = 0x00;
                     data_fade = 0xFF;
                     break;
                  }
                  case 0x40:
                  {
                     data_balance = 0xFF;
                     data_fade = 0xFF;
                     break;
                  }
                  case 0x50:
                  {
                      data_balance = 0xFF;
                      data_fade = 0x80;
                      break;
                  }
                  case 0x60:
                  {
                      data_balance = 0x80;
                      data_fade = 0xFF;
                      break;
                  }
                  case 0x80:
                  {
                      data_balance = 0x00;
                      data_fade = 0x00;
                      break;
                  }
                  case 0x90:
                  {
                      data_balance = 0x80;
                      data_fade = 0x00;
                      break;
                  }
                  case 0xA0:
                  {
                      data_balance = 0x00;
                      data_fade = 0x80;
                      break;
                  }
                  default:
                  {
                     data_balance = 0x80;
                     data_fade = 0x80;
                     break;
                   }
                }
             /* Set Balance */
             Audio_Overrides.Balance = true;
             AuMgr_DO_Enable(Audio_Overrides);
             balance = (Audio_Detent_T) Scale(data_balance, 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
             AuMgr_DO_Set_Balance(zone, bus, balance);
             /* Set Fade */
             Audio_Overrides.Fade = true;
             AuMgr_DO_Enable(Audio_Overrides);
             fade = (Audio_Detent_T) Scale(data_fade, 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
             AuMgr_DO_Set_Fade(zone, bus, fade);
           }
           else
           {
               TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
           }
          pits_status = DONE;                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Cancel0_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returnsSys_Zone_T zone = SYS_ZONE_MAIN;
    PITS_Band_CPID_T pits_band = PITC_BAND_FM1;
    bool pits_band_found = false;
    PITS_TUNER_EVG_CHANNEL_T tune_band_info_dpid;
    Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
    Audio_Logical_Src_T logical_source;
    PITS_Source_CPID_T pits_source = PITC_SOURCE_NONE;
    Disc_Pbk_Diag_Media_Pos_t media_position = Disc_Playback_Get_Media_Position();
    bool source_found = false;
    Audio_Tone_T tone_settings;
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID02 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID02 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel0_Req(const PITS_Message_T * message)
{
    Sys_Zone_T zone = SYS_ZONE_MAIN;
    PITS_Band_CPID_T pits_band = PITC_BAND_FM1;
    bool pits_band_found = false;
    PITS_TUNER_EVG_CHANNEL_T tune_band_info_dpid;
    Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
    Audio_Logical_Src_T logical_source;
    PITS_Source_CPID_T source = PITC_SOURCE_NONE;
    Disc_Pbk_Diag_Media_Pos_t media_position = Disc_Playback_Get_Media_Position();
    bool source_found = false;
    /*Audio_Tone_T tone_settings;*/
    SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
    uint8_t pits_mech_available = Disc_Pbk_Diag_Get_Mech_Present();
    Tuner_Mgr_Dev_Type_T pit_tun_device = TUNER_MGR_DEV_AM;
    Tuner_Mgr_Target_T pit_last_target;
    Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_CANCEL0_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          tune_band_info_dpid.zone = SYS_ZONE_MAIN;
          tune_band_info_dpid.channel_number = PITS_Get_AMFM_Tuner_Frequency();
          tune_band_info_dpid.band = PITS_Get_Tuner_Source_Type();
          pits_band_found = pits_cpid_tuner_map_band_to_pits_band(tune_band_info_dpid.band, &pits_band);
          if (pits_band_found)
          {
             if (pits_band == PITC_BAND_XM)
             {
                TX_Data[0] = (uint8_t) PITS_Get_XM_Tuner_Channel();
                TX_Data[1] = (uint8_t) PITS_Get_XM_Tuner_SID();
             }
             else
             {
                TX_Data[0] = (uint8_t) ((tune_band_info_dpid.channel_number)>>8);
                TX_Data[1] = (uint8_t) tune_band_info_dpid.channel_number;
             }
          }

          logical_source = AuMgr_Get_Source(zone, bus);
          source_found = pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);

          if (source_found)
          {
             if(source == PITC_SOURCE_DVD)
              {
                 source = PITC_SOURCE_DVD2;
              }
             TX_Data[2] = (uint8_t) source;
          }

          if ((source == PITC_SOURCE_CD)||(source == PITC_SOURCE_DVD)||(source == PITC_SOURCE_DVD2))
          {
              TX_Data[0] = (uint8_t) (media_position.track_number >> 8);
              TX_Data[1] = (uint8_t) (media_position.track_number);
          }
          pits_source_cd = source;
          get_page_num_fav = Diagnostics_Get_Page(zone);
          /*tone_settings = AuMgr_Get_All_Tone_Bands(zone, bus);*/
          diag_bass = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_BASS_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);

          diag_mid = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_MID_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);

          diag_treble = (uint8_t) Scale(Audio_PS_Get_Tone_Band(zone, AUDIO_TREBLE_BAND),
                                              TONE_MIN_LIM, TONE_MAX_LIM, 0x00, 0xFF);
          diag_fade = (uint8_t) Scale(Audio_PS_Get_Fade(zone),
                  FADE_MIN_LIM, FADE_MAX_LIM, 0x00, 0xFF);
          diag_balance = (uint8_t) Scale(Audio_PS_Get_Balance(zone),
                  BALANCE_MIN_LIM, BALANCE_MAX_LIM, 0x00, 0xFF);
          memcpy(&pit_time_cpid[0],&pit_time_rpt[0],16);

          pits_init_volume = (uint8_t) Scale(Audio_PS_Get_Volume(zone),
                                       VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);;

             PITs_GM_Set_DID (0,6);
             PITs_GM_Set_DID(1, TX_Data[0]);
             PITs_GM_Set_DID(2, TX_Data[1]);
             PITs_GM_Set_DID(3, TX_Data[2]);
             PITs_GM_Set_DID(4, diag_bass);
             PITs_GM_Set_DID(5, diag_mid);
             PITs_GM_Set_DID(6, diag_treble);
             PITs_GM_Set_DID(7,pits_mech_available);

             PITs_GM_DTC_Set(pits_dtc_code_send, false, true);

             Pits_Preset_Get_HMI_Highlights(SYS_ZONE_MAIN);

             pit_tun_device = TUNER_MGR_DEV_AM;
             Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
             pit_last_target_am.target_type = pit_last_target.target_type;
             pit_last_target_am.target_value = pit_last_target.target_value;

             pit_tun_device = TUNER_MGR_DEV_FM;
             Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
             pit_last_target_fm.target_type = pit_last_target.target_type;
             pit_last_target_fm.target_value = pit_last_target.target_value;

             pit_tun_device = TUNER_MGR_DEV_XM;
             Tuner_Mgr_Get_Last_Target(pit_tun_device, &pit_last_target);
             pit_last_target_xm.target_type = pit_last_target.target_type;
             pit_last_target_xm.target_value = pit_last_target.target_value;
          pits_status = DONE;                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Cancel1_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel1_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   uint16_t track_number_cpid;
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   SSM_Source_T my_source;
   PPE_Instance_Id_T my_instance = 0;
   uint32_t new_time_elap = 0;
   uint32_t   pit_time_rpt12 = pit_time_cpid[12];
   uint32_t   pit_time_rpt13 = pit_time_cpid[13];
   uint32_t   pit_time_rpt14 = pit_time_cpid[14];
   uint32_t   pit_time_rpt15 = pit_time_cpid[15];
   Disc_Pbk_Diag_Media_Pos_t  playback_info = Disc_Playback_Get_Media_Position();
   my_source.type = SSM_SRC_AUDIO_DISC;
   my_source.device = 262661;
   new_time_elap = pit_time_rpt12 + ((pit_time_rpt13 & 0x000000FF)<<8) + ((pit_time_rpt14 & 0x000000FF)<<16) + ((pit_time_rpt15 & 0x000000FF)<<24);

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_CANCEL1_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         track_number_cpid = message->data[0];
         track_number_cpid = ((track_number_cpid<<8) & 0xFF00)+(message->data[1]);
         logical_source = AuMgr_Get_Source(zone, bus);
         pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
         if(source == PITC_SOURCE_DVD)
         {
            source = PITC_SOURCE_DVD2;
         }

         if (pits_source_cd == source)
         {
            if (playback_info.track_number == track_number_cpid)
            {

            }
            else
            {
               track_number_cpid = track_number_cpid - 1;
               Disc_Pbk_Diag_Set_Track(track_number_cpid);
               usleep(1000*1000);
            }
         }
         else
         {
            Disc_Pbk_Diag_Set_Track(track_number_cpid);
            usleep(1000*1000);
         }

         PPE_Go_To_Time_Position(&my_source, my_instance, new_time_elap,true);
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Cancel2_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel2_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_CANCEL2_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
            PITS_Get_Source_Hours();
            TX_Data[0] = (uint8_t) SUCCESS;

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Limits_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Limits_Req(const PITS_Message_T * message)
{
   AM_FM_Drv_Tuner_Band_T band = FM_BAND;
   uint16_t limit_band;
   AMFM_Mode_T tuner_play_status = AMFM_Get_Mode();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_LIMITS_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {

          /* Byte 2 */
          limit_band = AM_FM_Drv_Get_Upper_Band_Limit(band);
          TX_Data[0] = (uint8_t) (limit_band >> 8);
          /* Byte 3 */
          TX_Data[1] = (uint8_t) (limit_band);
          /* Byte 4 */
          TX_Data[2] =(uint8_t) tuner_play_status;

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_LimitsAM_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel4_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Tone_T tone_settings;
   Audio_Detent_T fade;
   Audio_Detent_T balance;
   uint8_t adjust_vol;
   Audio_Detent_T volume;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   Tuner_Mgr_Dev_Type_T pit_tun_device = TUNER_MGR_DEV_AM;
   Tuner_Mgr_Target_T pit_last_target;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_CANCEL4_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         adjust_vol = (uint8_t) Scale(Audio_PS_Get_Volume(zone),
                               VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
         PITS_Misc_Clear_Overrides();
         PITS_Tuner_Clear_Overrides();
         TX_Data[0] = (uint8_t) SUCCESS;
         volume = (Audio_Detent_T) Scale(pits_init_volume, 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);
         Audio_Overrides.Volume = true;
         Audio_Overrides.Fade = true;
         Audio_Overrides.Balance = true;
         Audio_Overrides.Tone = true;
         AuMgr_DO_Enable(Audio_Overrides);
         if (adjust_vol == 0)
         {
            if (volume == 0)
            {
               AuMgr_DO_Set_Volume(zone, bus, volume);
            }
            else
            {
               AuMgr_DO_Set_Volume(zone, bus, (volume-1));
               PITs_GM_Set_DID (0,12);
               PITs_GM_Set_DID(1, 1);
               PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
            }
         }
         else
         {
            AuMgr_DO_Set_Volume(zone, bus, volume);
         }
         fade = (Audio_Detent_T) Scale(diag_fade, 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
         AuMgr_DO_Set_Fade(zone, bus, fade);
         balance = (Audio_Detent_T) Scale(diag_balance, 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
         AuMgr_DO_Set_Balance(zone, bus, balance);
         tone_settings.absolute_detent[AUDIO_BASS_BAND] =
              (Audio_Detent_T) Scale(diag_bass, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_MID_BAND] =
              (Audio_Detent_T) Scale(diag_mid, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
              (Audio_Detent_T) Scale(diag_treble, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         AuMgr_DO_Set_All_Tone_Bands(zone, bus, tone_settings);
         logical_source = AuMgr_Get_Source(zone, bus);
         pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
         if((source == PITC_SOURCE_TUNER_AM)||(source == PITC_SOURCE_TUNER_FM1)||(source == PITC_SOURCE_SDAR))
         {
            Preset_PS_Put_Current_Page(zone, get_page_num_fav);
            Pits_Preset_Update_HMI_Display_Info2(zone, get_page_num_fav);
            Pits_Preset_Update_HMI_Highlights(zone);
         }
         PITS_Audio_Clear_Overrides();

         pit_tun_device = TUNER_MGR_DEV_FM;
         pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
         pit_last_target.target_value = pit_last_target_fm.target_value;
         pit_last_target.target_last_known_freq = pit_last_target_fm.target_value;
         pit_last_target.target_is_primary = 0;
         pit_last_target.target_scid = 0;
         pit_last_target.target_service_id = 0;
         pit_last_target.target_subchannel = 0;
         Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);

         pit_tun_device = TUNER_MGR_DEV_AM;
         pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
         pit_last_target.target_value = pit_last_target_am.target_value;
         pit_last_target.target_last_known_freq = pit_last_target_am.target_value;
         pit_last_target.target_is_primary = 0;
         pit_last_target.target_scid = 0;
         pit_last_target.target_service_id = 0;
         pit_last_target.target_subchannel = 0;
         Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);

         pit_tun_device = TUNER_MGR_DEV_XM;
         pit_last_target.target_type = TUNER_MGR_TARGET_TYPE_SERVICE_ID;
         pit_last_target.target_value = pit_last_target_xm.target_value;
         pit_last_target.target_last_known_freq =pit_last_target_xm.target_value;
         pit_last_target.target_is_primary = 0;
         pit_last_target.target_scid = 0;
         pit_last_target.target_service_id = 0;
         pit_last_target.target_subchannel = 0;
         Tuner_Mgr_Set_Last_Target (pit_tun_device, pit_last_target);

          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Source_Only_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returnsstatic uint8_t diag_bass;
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_Source_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   bool source_found = false;
   AMFM_Mode_T tuner_play_status = AMFM_Get_Mode();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_SOURCE_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         logical_source = AuMgr_Get_Source(zone, bus);
         source_found = pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);

         if (source_found)
         {
            if(source == PITC_SOURCE_DVD)
            {
               source = PITC_SOURCE_DVD2;
            }
            TX_Data[1] = (uint8_t) source;
         }

         TX_Data[2] =(uint8_t) tuner_play_status;

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Set_Cancel_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_Cancel_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source = AUDIO_LOGICAL_SRC_NULL;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_CANCEL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         logical_source = AuMgr_Get_Source(zone, bus);
         source_found = pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
         if (source_found)
         {
            if(source == PITC_SOURCE_DVD)
            {
               source = PITC_SOURCE_DVD2;
            }
            TX_Data[1] = (uint8_t) source;
         }
         PITS_Audio_Clear_Overrides();

        pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID90_Req(const PITS_Message_T * message)
{
   Whole_Vin_T    vin_number = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID90_RPT, 18);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         Theft_PS_Get_Whole_VIN(vin_number);
         TX_Data[1] = 0;
         TX_Data[2] = vin_number[0];
         TX_Data[3] = vin_number[1];
         TX_Data[4] = vin_number[2];
         TX_Data[5] = vin_number[3];
         TX_Data[6] = vin_number[4];
         TX_Data[7] = vin_number[5];
         TX_Data[8] = vin_number[6];
         TX_Data[9] = vin_number[7];
         TX_Data[10] = vin_number[8];
         TX_Data[11] = vin_number[9];
         TX_Data[12] = vin_number[10];
         TX_Data[13] = vin_number[11];
         TX_Data[14] = vin_number[12];
         TX_Data[15] = vin_number[13];
         TX_Data[16] = vin_number[14];
         TX_Data[17] = vin_number[15];

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Set_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_DID90_Req(const PITS_Message_T * message)
{
   Whole_Vin_T    vin_number = {0};
   uint8_t    vin_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_DID90_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != TOTAL_VINS)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         for(vin_index = 0; vin_index < TOTAL_VINS; vin_index++)
         {
            vin_number[vin_index] = message->data[vin_index];
         }

         Theft_PS_Put_Whole_VIN(vin_number);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 

      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Get_DID53_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
#if 0
    Sys_Zone_T zone = SYS_ZONE_MAIN;
    Preset_Type_T presets;
    PITS_TUNER_EVG_CHANNEL_T tune_band_info = {0};
    uint8_t page_select = message->data[0];
    uint8_t page_cnt;
    uint8_t page_index;
    uint8_t page_cnt_end;
    uint8_t preset_index;
    preset_mgr_zone_num_type zone_index = SYS_ZONE_TO_INDEX(zone);
    uint8_t new_band = PITS_NEW_BAND_ONE;
    uint8_t next_preset_send = 0;
    SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID53_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         if (page_select == 1)
         {
            page_cnt = 0;
            page_cnt_end = 3;
            PITs_GM_Set_DID (next_preset_send,page_select);
         }
         else
         {
            page_cnt = 3;
            page_cnt_end = 6;
            PITs_GM_Set_DID (next_preset_send,page_select);
         }
         for(page_index = page_cnt; page_index < page_cnt_end; page_index++)
         {
            for (preset_index = 0; preset_index < 5; preset_index++)
            {

               presets = Preset_PS_Get_Preset_Data(zone_index, page_index, preset_index);
               if (presets.tuner_info.band == PRESET_MGR_DEV_AM)
               {
                  tune_band_info.band = SSM_SRC_AM;
               }
               if (presets.tuner_info.band == PRESET_MGR_DEV_FM)
               {
                  tune_band_info.band = SSM_SRC_FM;
               }
               if (presets.tuner_info.band == PRESET_MGR_DEV_XM)
               {
                  tune_band_info.band = SSM_SRC_XM;
               }
               /*tune_band_info.band = presets.tuner_info.band;*/
               tune_band_info.channel_number = presets.tuner_info.idd;
               tune_band_info.service_identifier = presets.tuner_info.pi;
               if (tune_band_info.band == SSM_SRC_AM)
               {
                  new_band = PITS_NEW_BAND_ONE;
                  tune_band_info.service_identifier = 0;
               }
               if (tune_band_info.band == SSM_SRC_FM)
               {
                  new_band = PITS_NEW_BAND_TWO;
                  tune_band_info.channel_number = (presets.tuner_info.idd)/10;
                  tune_band_info.service_identifier = 0;
               }
               if (tune_band_info.band == SSM_SRC_XM)
               {
                  new_band = PITS_NEW_BAND_THREE;
                  tune_band_info.channel_number = presets.tuner_info.idd;
               }

               PITs_GM_Set_DID ((next_preset_send + 1), new_band);
               PITs_GM_Set_DID ((next_preset_send + 2), (((uint8_t) (tune_band_info.channel_number >> 16)) & 0xFF));
               PITs_GM_Set_DID ((next_preset_send + 3), (((uint8_t) (tune_band_info.channel_number >> 8)) & 0xFF));
               PITs_GM_Set_DID ((next_preset_send + 4), (uint8_t) tune_band_info.channel_number);
               PITs_GM_Set_DID ((next_preset_send + 5), (uint8_t) tune_band_info.service_identifier);
               next_preset_send = next_preset_send + 5;
            }

         }
         PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }

   }
#endif
   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Set_DID53_Req(const PITS_Message_T * message)
{
   char id[30];
   Tuner_Info_T tuner_info = {0x00};
   preset_mgr_zone_num_type zone_index = 0;
   preset_mgr_page_num_type page_index = 0;
   preset_mgr_preset_num_type preset_index;
   uint32_t new_channel = 0;
   uint32_t new_bcd_string = 0;
   uint8_t  new_string1;
   uint8_t  new_string2;
   uint8_t  new_string3;
   uint8_t  new_string4;
   uint8_t  new_string5;
   uint8_t next_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      page_index = message->data[25];
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_DID53_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 26)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {

            TX_Data[0] = (uint8_t) SUCCESS;
            if (page_index == 0)
            {
               get_page_num_fav_write = Diagnostics_Get_Page(SYS_ZONE_MAIN);
               Pits_Preset_Get_HMI_Highlights(SYS_ZONE_MAIN);
            }

            for (preset_index=0; preset_index < PITS_PRESET_MGR_NUM_PRESETS; preset_index++)
            {
               if (preset_index > 0)
               {
                  next_index = preset_index * 5;
               }
               new_channel = message->data[next_index+1];
               new_channel = ((new_channel<<8) & 0xFFF0) | message->data[next_index+2];
               new_channel = ((new_channel<<8) & 0xFFF0) | message->data[next_index+3];
               if (((message->data[next_index] )& 0x0F) == NEW_BAND_FM)
               {
                  new_bcd_string = Hex_To_BCD((new_channel*10),5);
               }
               else
               {
                  new_bcd_string = Hex_To_BCD(new_channel,5);
               }

               new_string5 = (new_bcd_string) & 0x0F;
               new_string4 = (new_bcd_string>>4) & 0x0F;
               new_string3 = (new_bcd_string>>8) & 0x0F;
               new_string2 = (new_bcd_string>>12) & 0x0F;
               new_string1 = (new_bcd_string>>16) & 0x0F;

                  if (((message->data[next_index] )& 0x0F) == NEW_BAND_AM)
                  {
                     tuner_info.band = PRESET_MGR_DEV_AM;
                     tuner_info.idd =  new_channel;
                     tuner_info.pi = 0;
                     tuner_info.subchannel = message->data[next_index+4];
                     if (new_string2 == 0)
                     {
                        snprintf(id, sizeof(id), "AM %d%d%d", new_string3, new_string4, new_string5);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }
                     else
                     {
                         snprintf(id, sizeof(id), "AM %d%d%d%d",new_string2, new_string3, new_string4, new_string5);
                         Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }

                  }
                  else if (((message->data[next_index] )& 0x0F) == NEW_BAND_FM)
                  {
                     tuner_info.band = PRESET_MGR_DEV_FM;
                     tuner_info.idd =  new_channel*10;
                     tuner_info.pi = 0;
                     tuner_info.subchannel = message->data[next_index+4];
                     if (new_string1 == 0)
                     {
                        snprintf(id, sizeof(id), "FM %d%d.%d", new_string2, new_string3, new_string4);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }
                     else
                     {
                        snprintf(id, sizeof(id), "FM %d%d%d.%d",new_string1, new_string2, new_string3, new_string4);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }

                  }
                  else if (((message->data[next_index] )& 0x0F) == NEW_BAND_XM)
                  {
                     tuner_info.band = PRESET_MGR_DEV_XM;
                     tuner_info.idd = new_channel;
                     tuner_info.subchannel = 0;
                     tuner_info.pi = message->data[next_index+4];

                     if ((new_string2 == 0) && (new_string3 == 0))
                     {
                        snprintf(id, sizeof(id), "XM %d%d", new_string4, new_string5);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }
                     else if (new_string2 == 0)
                     {
                        snprintf(id, sizeof(id), "XM %d%d%d", new_string3, new_string4, new_string5);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }
                     else
                     {
                        snprintf(id, sizeof(id), "XM %d%d%d%d",new_string1, new_string2, new_string3, new_string4);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }

                  }
                  else
                  {
                     tuner_info.band = PRESET_MGR_DEV_FM;
                     tuner_info.idd =  new_channel;
                     tuner_info.pi = 0;
                     tuner_info.subchannel = message->data[next_index+4];
                     if (new_string1 == 0)
                     {
                        snprintf(id, sizeof(id), "FM %d%d.%d", new_string2, new_string3, new_string4);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }
                     else
                     {
                        snprintf(id, sizeof(id), "FM %d%d%d.%d",new_string1, new_string2, new_string3, new_string4);
                        Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                     }

                  }
                   #ifdef FEATURE_EMPTY_PRESET
                    if(tuner_info.idd == 0xfff)
                    {
                      tuner_info.empty_flag = true;
                    }
                   #endif
                  
                  Preset_PS_Put_Preset_Data(tuner_info, zone_index, page_index, preset_index);
                  new_channel = 0;
               }

               /*Pits_Preset_Update_HMI_Display_Info(SYS_ZONE_MAIN);*/
                 Preset_PS_Put_Current_Page(SYS_ZONE_MAIN, (page_index+1));
                 Pits_Preset_Update_HMI_Display_Info2(SYS_ZONE_MAIN, (page_index+1));
                 Pits_Preset_Update_HMI_Highlights2(SYS_ZONE_MAIN);
               if (page_index == 0x05)
               {
                  Preset_PS_Put_Current_Page(SYS_ZONE_MAIN, get_page_num_fav_write);
                  Pits_Preset_Update_HMI_Display_Info2(SYS_ZONE_MAIN, get_page_num_fav_write);
                  Pits_Preset_Update_HMI_Highlights(SYS_ZONE_MAIN);
               }
          pits_status = DONE; 
      }
   }

   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Get_DID53X_Req(const PITS_Message_T * message)
{
    Sys_Zone_T zone = SYS_ZONE_MAIN;
    Preset_Type_T presets;
    PITS_TUNER_EVG_CHANNEL_T tune_band_info = {0};
    uint8_t page_cnt = 0;
    uint8_t page_index;
    uint8_t preset_cnt= 0;
    uint8_t preset_index;
    preset_mgr_zone_num_type zone_index = SYS_ZONE_TO_INDEX(zone);
    uint8_t new_band = PITS_NEW_BAND_ONE;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      page_cnt = message->data[0];
      preset_cnt= message->data[1];

      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID53X_RPT, 6);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;


            page_index = page_cnt;

               preset_index = preset_cnt;

               presets = Preset_PS_Get_Preset_Data(zone_index, page_index, preset_index);
               if (presets.tuner_info.band == PRESET_MGR_DEV_AM)
               {
                  tune_band_info.band = SSM_SRC_AM;
               }
               if (presets.tuner_info.band == PRESET_MGR_DEV_FM)
               {
                  tune_band_info.band = SSM_SRC_FM;
               }
               if (presets.tuner_info.band == PRESET_MGR_DEV_XM)
               {
                  tune_band_info.band = SSM_SRC_XM;
               }
               /*tune_band_info.band = presets.tuner_info.band;*/
               tune_band_info.channel_number = presets.tuner_info.idd;
               tune_band_info.service_identifier = presets.tuner_info.pi;
               if (tune_band_info.band == SSM_SRC_AM)
               {
                  new_band = PITS_NEW_BAND_ONE;
                  tune_band_info.service_identifier = 0;
               }
               if (tune_band_info.band == SSM_SRC_FM)
               {
                  new_band = PITS_NEW_BAND_TWO;
                  tune_band_info.channel_number = (presets.tuner_info.idd)/10;
                  tune_band_info.service_identifier = 0;
               }
               if (tune_band_info.band == SSM_SRC_XM)
               {
                  new_band = PITS_NEW_BAND_THREE;
                  tune_band_info.channel_number = presets.tuner_info.idd;
               }
               TX_Data[1] = new_band;
               TX_Data[2] =  (((uint8_t) (tune_band_info.channel_number >> 16)) & 0xFF);
               TX_Data[3] =  (((uint8_t) (tune_band_info.channel_number >> 8)) & 0xFF);
               TX_Data[4] = (uint8_t) tune_band_info.channel_number;
               TX_Data[5] = (uint8_t) tune_band_info.service_identifier;
               new_band = PITS_NEW_BAND_ONE;


          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 

      }

   }
   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Set_DID53X_Req(const PITS_Message_T * message)
{
   char id[30];
   Tuner_Info_T tuner_info = {0x00};
   preset_mgr_zone_num_type zone_index = 0;
   preset_mgr_page_num_type page_index = 0;
   preset_mgr_preset_num_type preset_index = 0;
   uint32_t new_channel = 0;
   uint32_t new_bcd_string = 0;
   uint8_t  new_string1;
   uint8_t  new_string2;
   uint8_t  new_string3;
   uint8_t  new_string4;
   uint8_t  new_string5;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      zone_index = message->data[0];
      page_index = (message->data[1])-1;
      preset_index = (message->data[2])-1;
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_DID53X_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 8)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (message->data[3] == 0)
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         else
         {
            TX_Data[0] = (uint8_t) SUCCESS;
            new_channel = message->data[4];
            new_channel = ((new_channel<<8) & 0xFFF0) | message->data[5];
            new_channel = ((new_channel<<8) & 0xFFF0) | message->data[6];
            new_bcd_string = Hex_To_BCD(new_channel,5);
            new_string5 = (new_bcd_string) & 0x0F;
            new_string4 = (new_bcd_string>>4) & 0x0F;
            new_string3 = (new_bcd_string>>8) & 0x0F;
            new_string2 = (new_bcd_string>>12) & 0x0F;
            new_string1 = (new_bcd_string>>16) & 0x0F;

               if (message->data[3] == NEW_BAND_AM)
               {
                  tuner_info.band = PRESET_MGR_DEV_AM;
                  tuner_info.idd =  new_channel;
                  tuner_info.pi = 0;
                  if (new_string2 == 0)
                  {
                     snprintf(id, sizeof(id), "AM %d%d%d", new_string3, new_string4, new_string5);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }
                  else
                  {
                      snprintf(id, sizeof(id), "AM %d%d%d%d",new_string2, new_string3, new_string4, new_string5);
                      Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }

               }
               else if (message->data[3] == NEW_BAND_FM)
               {
                  tuner_info.band = PRESET_MGR_DEV_FM;
                  tuner_info.idd =  new_channel*10;
                  tuner_info.pi = 0;
                  if (new_string1 == 0)
                  {
                     snprintf(id, sizeof(id), "FM %d%d.%d", new_string2, new_string3, new_string4);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }
                  else
                  {
                     snprintf(id, sizeof(id), "FM %d%d%d.%d",new_string1, new_string2, new_string3, new_string4);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }

               }
               else if (message->data[3] == NEW_BAND_XM)
               {
                  tuner_info.band = PRESET_MGR_DEV_XM;
                  tuner_info.idd = new_channel;
                  tuner_info.pi = message->data[7];

                  if ((new_string2 == 0) && (new_string3 == 0))
                  {
                     snprintf(id, sizeof(id), "XM %d%d", new_string4, new_string5);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }
                  else if (new_string2 == 0)
                  {
                     snprintf(id, sizeof(id), "XM %d%d%d", new_string3, new_string4, new_string5);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }
                  else
                  {
                     snprintf(id, sizeof(id), "XM %d%d%d%d",new_string1, new_string2, new_string3, new_string4);
                     Safe_Strncpy(tuner_info.station_name,id, sizeof(tuner_info.station_name));
                  }

               }

               #ifdef FEATURE_EMPTY_PRESET
               if( 0xffff == tuner_info.idd)
               {
                    tuner_info.empty_flag = true;
               }
               #endif
               Preset_PS_Put_Preset_Data(tuner_info, zone_index, page_index, preset_index);
               Pits_Preset_Update_HMI_Display_Info(SYS_ZONE_MAIN);

         }

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Test_Dpid08_Req
 *===========================================================================*
 * @brief Receive a Request to get DPID08
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID08 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID08 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Test_Dpid08_Req(const PITS_Message_T * message)
{
   uint32_t new_time_elap = 0;
   uint32_t  pit_seconds;
   uint8_t   pit_minutes;
   uint8_t   pit_out_sec;
   uint8_t   pit_hours;
   uint32_t   pit_time_rpt12 = pit_time_rpt[12];
   uint32_t   pit_time_rpt13 = pit_time_rpt[13];
   uint32_t   pit_time_rpt14 = pit_time_rpt[14];
   uint32_t   pit_time_rpt15 = pit_time_rpt[15];
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_TEST_DPID08_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          new_time_elap = pit_time_rpt12 + ((pit_time_rpt13 & 0x000000FF)<<8) + ((pit_time_rpt14 & 0x000000FF)<<16) + ((pit_time_rpt15 & 0x000000FF)<<24);
          pit_seconds = new_time_elap / 0x3E8;
          pit_out_sec = pit_seconds % 60;
          pit_minutes = (pit_seconds / 60) % 60;
          pit_hours =  pit_seconds / 3600;
          TX_Data[1] =  pit_time_rpt[0];/*source*/
          TX_Data[2] = (uint8_t) Hex_To_BCD (pit_hours,2);
          TX_Data[3] = (uint8_t) Hex_To_BCD (pit_minutes,2);
          TX_Data[4] = (uint8_t) Hex_To_BCD (pit_out_sec,2);

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Preset_Default_Req(const PITS_Message_T * message)
{
   SSM_Source_T quality_source;
   PITS_Source_CPID_T source;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_PRESET_DEFAULT_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;

         source = PITS_Get_Source_DPID10();
         if ((source == PITC_SOURCE_TUNER_FM1)||(source == PITC_SOURCE_TUNER_AM))
         {
            /* Byte 1 Signal Strength*/
            quality_source.device = 1;
            if (source == PITC_SOURCE_TUNER_AM)
            {
               quality_source.type = SSM_SRC_AM;
            }
            else
            {
               quality_source.type = SSM_SRC_FM;
            }
            Tuner_Mgr_Request_Current_Station_Info(quality_source);
         }

          pits_status = DONE; 

      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Test_Dpid08_Req
 *===========================================================================*
 * @brief Receive a Request to get DPID08
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID08 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID08 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_DYN_PID_Req(const PITS_Message_T * message)
{
   uint8_t message_length = 0;
   uint8_t DPID =  0;
   uint8_t dpid_index;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      message_length = message->data[0];
      DPID =  message->data[1];

      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_DYN_PID_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != message_length+1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          TX_Data[1] = DPID;
          for(dpid_index=0;dpid_index<Max_Dynamic_DPID;dpid_index++)
          {
             if((0x00 == dyn_dpid_support_table[dpid_index*15])||(dyn_dpid_support_table[dpid_index*15] == DPID))
             {
                memset(&dyn_dpid_support_table[dpid_index*15], 0, 15);/* clear last define */
                memcpy(&dyn_dpid_support_table[dpid_index*15], &message->data[1], message_length);
                break;
             }
          }
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Test_Dpid08_Req
 *===========================================================================*
 * @brief Receive a Request to get DPID08
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID08 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID08 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DYN_PID_Req(const PITS_Message_T * message)
{
   uint8_t i = 0;
   uint8_t id = 0;
   uint8_t pid_index = 0;
   bool_t pid_found = false;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      id = message->data[0];
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DYN_PID_RPT, 6);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          PITs_GM_Set_DID (0,4);
          for (i = 0; i < Max_Dynamic_DPID; i++)
          {
             if(dyn_dpid_support_table[i*15] == id)
             {
                pid_found = true;
                for(pid_index = 0; pid_index < 15; pid_index++)
                {
                   PITs_GM_Set_DID (pid_index+1,dyn_dpid_support_table[(i*15)+pid_index]);
                }
                break;

             }
          }
          if (pid_found)
          {
             PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
          }

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_First_Tones_Req(const PITS_Message_T * message)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Tone_T tone_settings;
   Audio_Detent_T fade;
   Audio_Detent_T balance;
   uint8_t adjust_vol;
   Audio_Detent_T volume;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_FIRST_TONES_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         adjust_vol = (uint8_t) Scale(Audio_PS_Get_Volume(zone),
                                        VOLUME_MIN_LIM, VOLUME_MAX_LIM, 0x00, 0xFF);
         volume = (Audio_Detent_T) Scale(pits_init_volume, 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);
         Audio_Overrides.Volume = true;
         Audio_Overrides.Fade = true;
         Audio_Overrides.Balance = true;
         Audio_Overrides.Tone = true;
         AuMgr_DO_Enable(Audio_Overrides);
         if (adjust_vol == 0)
         {
            if (volume == 0)
            {
               AuMgr_DO_Set_Volume(zone, bus, volume);
            }
            else
            {
               AuMgr_DO_Set_Volume(zone, bus, (volume-1));
               PITs_GM_Set_DID (0,12);
               PITs_GM_Set_DID(1, 1);
               PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
            }
         }
         else
         {
            AuMgr_DO_Set_Volume(zone, bus, volume);
         }
         fade = (Audio_Detent_T) Scale(diag_fade, 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
         AuMgr_DO_Set_Fade(zone, bus, fade);
         balance = (Audio_Detent_T) Scale(diag_balance, 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
         AuMgr_DO_Set_Balance(zone, bus, balance);

         tone_settings.absolute_detent[AUDIO_BASS_BAND] =
              (Audio_Detent_T) Scale(diag_bass, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_MID_BAND] =
              (Audio_Detent_T) Scale(diag_mid, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
              (Audio_Detent_T) Scale(diag_treble, 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
         AuMgr_DO_Set_All_Tone_Bands(zone, bus, tone_settings);
         usleep(150*1000);
         PITS_Audio_Clear_Overrides();
         /*Audio_Overrides.Tone = false;
         AuMgr_DO_Enable(Audio_Overrides);*/
        pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID17_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID17_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t)  PS_DVD_region_Get();/*Region DVD*/

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_App_Swid_Req(const PITS_Message_T * message)
{
   uint8_t errors_index = 0;
   uint8_t cd_errors[8] = {0,0,0,0,0,0,0,0};
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_APP_SWID_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         PITs_GM_Set_DID (0,5);
         Util_Put_Big_Endian_U32(&cd_errors[0], VT_SOFTWARE_ID);
         Util_Put_Big_Endian_U32(&cd_errors[4], VT_SOFTWARE_VERSION);
         for (errors_index = 0; errors_index < 0x08; errors_index++)
         {
            PITs_GM_Set_DID(errors_index + 1, cd_errors[errors_index]);
            TX_Data[errors_index + 1] = cd_errors[errors_index];
         }
         PITs_GM_DTC_Set(pits_dtc_code_send, false, true);

          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_set_band_and_freq_req
 *===========================================================================*
 * @brief Receive a Request to Set the Tuner Band
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Tuner ID
 * @param [in] (message->data)[1] = Tuner Band
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_Cpid1a_Req(const PITS_Message_T * message)
{
   PITS_Band_CPID_T pits_band = PITC_BAND_FM1;
   bool pits_band_found = false;
   PITS_SSM_Src_T src_band;
   Tuner_Mgr_Target_T tune_band_info = {0x00};
   bool_t valid_channel = false;
   PITS_Source_CPID_T source;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_CPID1A_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         memcpy(&TX_Data[1], message->data, 4);
         /* Decode received messages  */
         pits_band = (PITS_Band_CPID_T)message->data[1];
         pits_band_found = pits_gmdiag_map_pits_band_to_band(pits_band, (PITS_Tuner_Band_T*) &src_band.type);

         if (((SYS_ZONE_MAIN == (Sys_Zone_T)message->data[0]) && pits_band_found))
         {
            tune_band_info.target_value= (uint32_t) (((uint16_t)(message->data[2]) << 8) + message->data[3]);
            tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
            tune_band_info.target_subchannel = 0;
            src_band.device = 1;
            if (PITC_BAND_FM1 == pits_band)
            {
               if (pits_gmdiag_amfm_channel_is_valid(FM_BAND, tune_band_info.target_value))
               {
                  valid_channel = true;
               }
            }
            if (PITC_BAND_AM == pits_band)
            {
               if (pits_gmdiag_amfm_channel_is_valid(AM_BAND, tune_band_info.target_value))
               {
                  valid_channel = true;
               }
            }
            else if (PITC_BAND_XM == pits_band)
            {
               tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               tune_band_info.target_value = message->data[2];
               tune_band_info.target_subchannel =  message->data[3];
               valid_channel = true;
            }

            source = PITS_Get_Source_DPID10();
            if ((source == PITC_SOURCE_TUNER_AM)||(source == PITC_SOURCE_TUNER_FM1))
            {
               if (valid_channel)
               {
                  RemRcvr_Enable_Override();
                  Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);
                  TX_Data[0] = (uint8_t) SUCCESS;
               }
            }

         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_source_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Source
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio source
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_Cpid2a_Req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   PITS_Source_CPID_T source;
   uint8_t source_index = 0;
   bool_t source_found = false;
   SSM_Source_T pits_ssm_source;
   PITS_Source_CPID_T pits_sourcexm = PITC_SOURCE_NONE;
   Audio_Logical_Src_T logical_source;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_CPID2A_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         TX_Data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         TX_Data[1] = zone;
         TX_Data[2] = bus;
         source = (PITS_Source_CPID_T) message->data[2];
         for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
         {
            if( Set_Source_SSM_Table[source_index].pits_source == source )
            {
               new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
               source_found = true;
               break;
            }
         }
         if (new_source_ssm == SSM_SRC_XM)
         {
            logical_source = AuMgr_Get_Source(zone, bus);
            source_found = pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &pits_sourcexm);
            if (pits_sourcexm == PITC_SOURCE_TUNER_AM)
            {
               pit_source_prev_to_xm = SSM_SRC_AM;
            }
            else if (pits_sourcexm == PITC_SOURCE_TUNER_FM1)
            {
               pit_source_prev_to_xm = SSM_SRC_FM;
            }
            else
            {
               SSM_Get_Last_Tuner_Source(zone, &pits_ssm_source);
               pit_source_prev_to_xm = pits_ssm_source.type;
            }
         }
         if (new_source_ssm == SSM_SRC_FM)
         {
            SSM_Get_Last_Tuner_Source(zone, &pits_ssm_source);
            new_source_ssm = pits_ssm_source.type;
            if(pits_ssm_source.type == SSM_SRC_XM)
            {
               new_source_ssm = pit_source_prev_to_xm;
            }
         }
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) &&
             source_found)
         {
            /*PITS_Audio_Connect_Src_To_Zone(zone, bus, logical_source);*/
            SSM_Select_Source_Type(new_source_ssm, new_zone_ssm);
            TX_Data[3] = message->data[2];
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            TX_Data[3] = message->data[2];
         }
          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_source_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Source
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio source
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Source
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Set_Audio_Source_Req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   PITS_Source_CPID_T source;
   uint8_t source_index = 0;
   bool_t source_found = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_AUDIO_SOURCE_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("AUDIO Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         TX_Data[0] = (uint8_t) SUCCESS;
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         TX_Data[1] = zone;
         TX_Data[2] = bus;
         source = (PITS_Source_CPID_T) message->data[2];
         for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
         {
            if( Set_Source_SSM_Table[source_index].pits_source == source )
            {
               new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
               source_found = true;
            }
         }

         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) &&
             source_found)
         {
            SSM_Select_Source_Type(new_source_ssm, new_zone_ssm);
            TX_Data[3] = message->data[2];
            TX_Data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            TX_Data[3] = message->data[2];
         }
          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Cancel1_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Oats_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_OATS_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0x01)
         {
            if (!pits_oats)
            {
               VUI_Diag_OATS_Start();
               TX_Data[1] = 0x01;
               pits_oats = true;
            }
         }
         else
         {
            if (pits_oats)
            {
               VUI_Diag_OATS_Stop();
               TX_Data[1] = 0x02;
               pits_oats = false;
            }
         }
          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_Cancel1_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Srdl_Req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SRDL_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0x01)
         {
            if (!pits_srdl)
            {
               VUI_Diag_SRDL_Enable_USB_Upload();
               TX_Data[1] = 0x01;
               pits_srdl = true;
            }
         }
         else
         {
            if (pits_srdl)
            {
               VUI_Diag_SRDL_Disable_USB_Upload();
               TX_Data[1] = 0x02;
               pits_srdl = false;
            }
         }
          pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Param_Test_Req(const PITS_Message_T * message)
{
   Whole_Param_T    param_number = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_PARAM_TEST_RPT, 8);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (message->data[0] == 0x01)
         {
            Mfg_PS_Get_Whole_Param(param_number);
            TX_Data[0] = param_number[0];
            TX_Data[1] = param_number[1];
            TX_Data[2] = param_number[2];
            TX_Data[3] = param_number[3];
            TX_Data[4] = param_number[4];
            TX_Data[5] = param_number[5];
            TX_Data[6] = param_number[6];
            TX_Data[7] = param_number[7];
         }
         else
         {
            param_number[0] = 0xFF;
            param_number[1] = 0xFF;
            param_number[2] = message->data[1];
            param_number[3] = 0xFF;
            param_number[4] = message->data[2];
            param_number[5] = 0xFF;
            param_number[6] = 0xFF;
            param_number[7] = 0xFF;
            Mfg_PS_Put_Whole_Param(param_number);
         }
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE1_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE1_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        didex[0] = 0xE1;
        didex[1] = message->data[1];
        if(message->data[0] == 0x01)
        {
           if (message->data[1] == 0x00)
           {
              didE1_cal_state = 0;/* No write*/
              BUC_Set_DID_Data(&didex[0]);
           }
           if (message->data[1] == 0x01)
           {
              didE1_cal_state = 0x01; /* Enable write*/
              BUC_Set_DID_Data(&didex[0]);
           }
           if (message->data[1] == 0x02)
           {
              /*Reload Cal default values function*/
              didE1_cal_state = 0x02;
              BUC_Set_DID_Data(&didex[0]);
              /*Pits_Default_Backup_Camera_Load();*/
           }
        }
        else
        {
           TX_Data[1] = didE1_cal_state;
        }
        if (NOT_DONE == status)
        {
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE2_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE2_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE2;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE2;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

           /*TX_Data[1] = Cal_RVS_Guidelines_Width;
           TX_Data[2] = Cal_RVS_Steer_Saturation_Angle;
           TX_Data[3] = (uint8_t) (Cal_RVS_Steer_Wheelbase>>8);
           TX_Data[4] = (uint8_t) Cal_RVS_Steer_Wheelbase;*/
        }
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE3_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE3_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE3;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE3;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
        /*TX_Data[1] = (uint8_t) (Cal_RVS_Steer_Inverse_Rear_Ratio>>8);
        TX_Data[2] = (uint8_t) Cal_RVS_Steer_Inverse_Rear_Ratio;
        TX_Data[3] = (uint8_t) (Cal_RVS_Steer_Inverse_Front_Ratio>>8);
        TX_Data[4] = (uint8_t) Cal_RVS_Steer_Inverse_Front_Ratio;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE4_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE4_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE4;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE4;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) Cal_RVS_Steer_Rear_Axle_Offset;
        TX_Data[2] = (uint8_t) Cal_RVS_Ovlay_Num_Dist_Marks;
        TX_Data[3] = (uint8_t) Cal_RVS_Ovlay_Delta_Dist_Marks;
        TX_Data[4] = (uint8_t) Cal_RVS_Ovlay_Track_Width;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE5_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE5_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE5;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE5;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) Cal_RVS_Camera_Optical_Offset_V;
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Optical_Offset_U;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE6_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE6_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE6;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE6;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) (Cal_RVS_Camera_Distort_Coef_2>>8);
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Distort_Coef_2;
        TX_Data[3] = (uint8_t) (Cal_RVS_Camera_Distort_Coef_1>>8);
        TX_Data[4] = (uint8_t) Cal_RVS_Camera_Distort_Coef_1;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE7_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE7_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
                {
                   if (didE1_cal_state == 0x01)
                   {
                      didex[0] = 0xE7;
                      didex[1] = message->data[1];
                      didex[2] = message->data[2];
                      didex[3] = message->data[3];
                      didex[4] = message->data[4];
                      BUC_Set_DID_Data(&didex[0]);
                   }

                }
                else
                {
                   didex[0] = 0xE7;
                   BUC_Get_DID_Data(&didex[0]);
                   TX_Data[1] = didex[1];
                   TX_Data[2] = didex[2];
                   TX_Data[3] = didex[3];
                   TX_Data[4] = didex[4];

                }
      /*TX_Data[1] = (uint8_t) (Cal_RVS_Camera_Focal_Lenght_V>>8);
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Focal_Lenght_V;
        TX_Data[3] = (uint8_t) (Cal_RVS_Camera_Focal_Lenght_U>>8);
        TX_Data[4] = (uint8_t) Cal_RVS_Camera_Focal_Lenght_U;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE8_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE8_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE8;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE8;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) Cal_RVS_Camera_Offset_Z;
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Offset_Y;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDE9_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDE9_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xE9;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xE9;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) (Cal_RVS_Camera_Rotation_Z>>8);
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Rotation_Z;
        TX_Data[3] = (uint8_t) (Cal_RVS_Camera_Rotation_Y>>8);
        TX_Data[4] = (uint8_t) Cal_RVS_Camera_Rotation_Y;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DidE1_Req
 *===========================================================================*
 * @brief Receive a Request to get the Dpid20
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = Dpid20 bytes:
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_DIDEA_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   uint8_t didex[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DIDEA_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
        TX_Data[0] = (uint8_t) SUCCESS;
        if(message->data[0] == 0x01)
        {
           if (didE1_cal_state == 0x01)
           {
              didex[0] = 0xEA;
              didex[1] = message->data[1];
              didex[2] = message->data[2];
              didex[3] = message->data[3];
              didex[4] = message->data[4];
              BUC_Set_DID_Data(&didex[0]);
           }

        }
        else
        {
           didex[0] = 0xEA;
           BUC_Get_DID_Data(&didex[0]);
           TX_Data[1] = didex[1];
           TX_Data[2] = didex[2];
           TX_Data[3] = didex[3];
           TX_Data[4] = didex[4];

        }
      /*TX_Data[1] = (uint8_t) (uint8_t) (Cal_RVS_Camera_Rotation_X>>8);
        TX_Data[2] = (uint8_t) Cal_RVS_Camera_Rotation_X;*/
        if (NOT_DONE == status)
        {
           pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
        }
      }
   }

   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_LimitsAM_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_Gmdiag_Cpid5_Screen_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_SET_CPID5_SCREEN_RPT, 1);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         if (message->data[0] == 0x01)
         {

         }
         if (message->data[0] == 0x00)
         {

         }
         pits_status = DONE; 
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID0B_Req(const PITS_Message_T * message)
{
   IDM_Software_Version_Info_T pits_diag_hdswid = HDR_Get_IDM_Software_Version_Information();
   char ver[8] = {0};
   char id[2] = {0};
   long int li1;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0B_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         memcpy(&ver[0],&pits_diag_hdswid.data[18],8);
         id[0] = ver[0];
         id[1] = ver[1];
         li1 = strtol (id,0,16);
         TX_Data[1] = (uint8_t) li1;

         id[0] = ver[2];
         id[1] = ver[3];
         li1 = strtol (id,0,16);
         TX_Data[2] = (uint8_t) li1;

         id[0] = ver[4];
         id[1] = ver[5];
         li1 = strtol (id,0,16);
         TX_Data[3] = (uint8_t) li1;

         id[0] = ver[6];
         id[1] = ver[7];
         li1 = strtol (id,0,16);
         TX_Data[4] = (uint8_t) li1;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID0C_Req(const PITS_Message_T * message)
{
   IDM_Software_Version_Info_T pits_diag_hdswid = HDR_Get_IDM_Software_Version_Information();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0C_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = 0;
         TX_Data[2] = pits_diag_hdswid.data[27];

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID0D_Req(const PITS_Message_T * message)
{
   IDM_Software_Version_Info_T pits_diag_hdswid = HDR_Get_IDM_Software_Version_Information();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0D_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = pits_diag_hdswid.data[28];
         TX_Data[2] = pits_diag_hdswid.data[29];
         TX_Data[3] = pits_diag_hdswid.data[30];
         TX_Data[4] = pits_diag_hdswid.data[31];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_DID0E_Req(const PITS_Message_T * message)
{
   IDM_Software_Version_Info_T pits_diag_hdswid = HDR_Get_IDM_Software_Version_Information();
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0E_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = pits_diag_hdswid.data[33];
         TX_Data[2] = pits_diag_hdswid.data[34];
         TX_Data[3] = pits_diag_hdswid.data[35];
         TX_Data[4] = 0;
         TX_Data[5] = 0;
         TX_Data[6] = 0;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC430_Req(const PITS_Message_T * message)
{
   HDR_Diagnostics_Information_T hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC430_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         if (hd_diagnostics.station_info.digital_signal_acquired)
         {
            TX_Data[1] |= BIT7;
         }
         if (hd_diagnostics.status_info.digital_audio_acquired)
         {
            TX_Data[1] |= BIT6;
         }
         if (hd_diagnostics.tx_blend_enabled)
         {
            TX_Data[1] |= BIT5;
         }
         TX_Data[2] = 0;
         TX_Data[3] = hd_diagnostics.status_info.primary_service_mode;
         TX_Data[4] = 0;
         TX_Data[5] = hd_diagnostics.station_info.band;

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC431_Req(const PITS_Message_T * message)
{
   HDR_Diagnostics_Information_T hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC431_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = 0;
         TX_Data[2] = hd_diagnostics.codec_mode;

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC433_Req(const PITS_Message_T * message)
{
   HDR_Diagnostics_Information_T hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC433_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t)((hd_diagnostics.frame_count)>>24);
         TX_Data[2] = (uint8_t)((hd_diagnostics.frame_count)>>16);
         TX_Data[3] = (uint8_t)((hd_diagnostics.frame_count)>>8);
         TX_Data[4] = (uint8_t)(hd_diagnostics.frame_count);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC434_Req(const PITS_Message_T * message)
{
   HDR_Diagnostics_Information_T hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC434_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t)((hd_diagnostics.enhanced_frame_errors)>>24);
         TX_Data[2] = (uint8_t)((hd_diagnostics.enhanced_frame_errors)>>16);
         TX_Data[3] = (uint8_t)((hd_diagnostics.enhanced_frame_errors)>>8);
         TX_Data[4] = (uint8_t)(hd_diagnostics.enhanced_frame_errors);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC435_Req(const PITS_Message_T * message)
{
   HDR_Diagnostics_Information_T hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = (uint8_t)((hd_diagnostics.core_frame_count)>>24);
         TX_Data[2] = (uint8_t)((hd_diagnostics.core_frame_count)>>16);
         TX_Data[3] = (uint8_t)((hd_diagnostics.core_frame_count)>>8);
         TX_Data[4] = (uint8_t)(hd_diagnostics.core_frame_count);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_volume_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Volume Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio volume level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Volume level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_volume_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T volume;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            Audio_Overrides.Volume = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            volume = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, VOLUME_MIN_LIM, VOLUME_MAX_LIM);
            PITS_AU_Set_Volume(zone, bus, volume);
         }

         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_fade_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Fade Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio fade level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Fade level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_fade_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T fade;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            Audio_Overrides.Fade = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            fade = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, FADE_MIN_LIM, FADE_MAX_LIM);
            PITS_AU_Set_Fade(zone, bus, fade);
         }

         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_balance_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Balance Level
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Balance level
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Balance level
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_balance_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Detent_T balance;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
         TX_Message.data_size = 3;
         TX_Data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            Audio_Overrides.Balance = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            balance = (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF,BALANCE_MIN_LIM, BALANCE_MAX_LIM);
            PITS_AU_Set_Balance(zone, bus, balance);

         }

         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_session_set_mute_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Mute Status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Audio Mute Status
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pbs_tx_data[1] = Audio Mute Status
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_mute_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Mute_State_T mute_state = AUDIO_UNMUTE;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 4);

      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         zone = (Sys_Zone_T)message->data[0];
         bus  = (Sys_Audio_Bus_T)message->data[1];
         if(message->data[2] == 0)
         {
            mute_state = AUDIO_UNMUTE;
         }
         if(message->data[2] == 1)
         {
            mute_state = AUDIO_MUTE;
         }
         PITS_AU_Set_Mute_State_Bus(zone, bus, mute_state);
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_audio_set_tone_req
 *===========================================================================*
 * @brief Receive a Request to Set the Audio Tone Control
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = zone
 * @param [in] (message->data)[1] = bus
 * @param [in] (message->data)[2] = Base settings
 * @param [in] (message->data)[4] = Mid settings
 * @param [in] (message->data)[6] = Trebel settings
 * @param [out] pbs_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_tone_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   Audio_Tone_T tone_settings;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC435_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone))
         {
            Audio_Overrides.Tone = true;
            PITS_AU_Enable_Overrides(Audio_Overrides);
            tone_settings.absolute_detent[AUDIO_BASS_BAND] =
                (Audio_Detent_T) Scale(message->data[2], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_MID_BAND] =
                (Audio_Detent_T) Scale(message->data[3], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            tone_settings.absolute_detent[AUDIO_TREBLE_BAND] =
                (Audio_Detent_T) Scale(message->data[4], 0x00, 0xFF, TONE_MIN_LIM, TONE_MAX_LIM);
            PITS_AU_Set_All_Tone_Bands(zone, bus, tone_settings);
            Audio_Overrides.Tone = false;
            PITS_AU_Enable_Overrides(Audio_Overrides);

         }
         pits_status = DONE; 

      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_tuner_set_band_and_freq_req
 *===========================================================================*
 * @brief Receive a Request to Set the Tuner Band
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Tuner ID
 * @param [in] (message->data)[1] = Tuner Band
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_band_and_freq_diag_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   PITS_Band_CPID_T pits_band;
   bool_t band_found = false;
   PITS_SSM_Src_T src_band;
   Tuner_Mgr_Target_T tune_band_info = {0x00};
   uint32_t tune_band_adjust;
   bool_t valid_channel = false;
   uint8_t dpid_channel = 0x00;
   uint32_t limit_frecfminf = Pits_Get_FM_Freq_Low();
   uint8_t  fm_step_const = 10*(Pits_Get_FM_Freq_Step());

   if (NULL != message)
   {

      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         pits_band = (PITS_Band_CPID_T)message->data[1];
         band_found = pits_cpid_tuner_map_pits_band_to_band(pits_band, (PITS_Tuner_Band_T*) &src_band.type);
         if (((SYS_ZONE_MAIN == (Sys_Zone_T)message->data[0]) && band_found))
         {
            tune_band_info.target_value= (uint32_t) (((uint16_t)(message->data[2]) << 8) + message->data[3]);
            tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
            tune_band_info.target_subchannel = 0;
            src_band.device = 1;
            if (PITC_BAND_FM1 == pits_band)
            {
               dpid_channel = (uint8_t)(((tune_band_info.target_value - limit_frecfminf)*FM_BASE_CONST)/fm_step_const);
               tune_band_adjust = ((fm_step_const * dpid_channel)/FM_BASE_CONST)+ limit_frecfminf;
               tune_band_info.target_subchannel = (uint8_t) (tune_band_info.target_value - tune_band_adjust);
               if (pits_cpid_tuner_amfm_channel_is_valid(FM_BAND, tune_band_info.target_value))
               {
                  valid_channel = true;
               }
            }
            if (PITC_BAND_AM == pits_band)
            {
               if (pits_cpid_tuner_amfm_channel_is_valid(AM_BAND, tune_band_info.target_value))
               {
                  valid_channel = true;
               }
            }
            else if (PITC_BAND_XM == pits_band)
            {
               tune_band_info.target_type = TUNER_MGR_TARGET_TYPE_CHANNEL;
               tune_band_info.target_value = message->data[2];
               tune_band_info.target_subchannel =  message->data[3];
               valid_channel = true;
            }
            if (valid_channel)
            {
               RemRcvr_Enable_Override();
               Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);

            }

         }
         pits_status = DONE; 

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_Misc_Set_Remote_Enable_Req
 *===========================================================================*
 * @brief Receive a Request to set the Remote Enable
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Remote Enable:
 *                                  0x00 = Off
 *                                  0x01 = On
 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[1] = Remote Enable:
 *                               0x00 = Off
 *                               0x01 = On
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_Set_Remote_Enable_Diag_Req(const PITS_Message_T * message)
{
   bool_t Pit_GPWM_Remote_Enabled = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         if (1 >= message->data[0])
         {
            Pit_GPWM_Remote_Enabled = (bool_t) message->data[0];
            Set_Remote_Enable(Pit_GPWM_Remote_Enabled);
         }
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

static bool_t pits_cpid_tuner_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel)
{
   uint16_t lower_band_limit = AM_FM_Drv_Get_Lower_Band_Limit(band);
   uint16_t upper_band_limit = AM_FM_Drv_Get_Upper_Band_Limit(band);
   uint16_t band_step_size = AM_FM_Drv_Get_Tune_Step_Size(band);

   return ( (upper_band_limit >= channel) &&
            (lower_band_limit <= channel) &&
            (((channel - lower_band_limit) % band_step_size) == 0) );
}

static bool_t pits_gmdiag_map_pits_band_to_band(PITS_Band_CPID_T pits_band, PITS_Tuner_Band_T *tuner_band)
{
   uint8_t i;
   bool_t tuner_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation_Cpid); i++)
   {
      if (Band_Translation_Cpid[i].pits_band_cpid == pits_band)
      {
         (*tuner_band) = Band_Translation_Cpid[i].tuner_band_cpid;
         tuner_band_found = true;
         break;
      }
   }

   return(tuner_band_found);
}

static bool_t pits_gmdiag_amfm_channel_is_valid(AM_FM_Drv_Tuner_Band_T band, uint16_t channel)
{
   uint16_t lower_band_limit = AM_FM_Drv_Get_Lower_Band_Limit(band);
   uint16_t upper_band_limit = AM_FM_Drv_Get_Upper_Band_Limit(band);
   uint16_t band_step_size = AM_FM_Drv_Get_Tune_Step_Size(band);

   return ( (upper_band_limit >= channel) &&
            (lower_band_limit <= channel) &&
            (((channel - lower_band_limit) % band_step_size) == 0) );
}
/**
 * Map from logical source to the appropriate PITS source ID.
 *
 * @param [in] tuner_band - Tuner Band from tuner manager
 * @param [in] pits_band - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
static bool pits_dpid_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_DPID_T *pits_band)
{
   int8_t i;
   bool pits_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation); i++)
   {
      if (Band_Translation[i].tuner_band == tuner_band)
      {
         (*pits_band) = Band_Translation[i].pits_band;
         pits_band_found = true;
         break;
      }
   }

   return(pits_band_found);
}
/**
 * Map from logical source to the appropriate PITS source ID.
 *
 * @param [in] logical_source - Logical source from audio manager
 * @param [in] pits_source - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
static bool pits_dpid_audio_map_logical_src_to_pits_src(Audio_Logical_Src_T logical_source, PITS_Source_DPID_T *source)
{
   int8_t i;
   PITS_Source_DPID_T new_pits_source = (*source);
   bool pits_source_found = false;

   for (i = (Num_Elems(Source_Translation) - 1); i >= 0; i--)
   {
      if (Source_Translation[i].logical_source == logical_source)
      {
         pits_source_found = true;
         if (Source_Translation[i].pits_source == new_pits_source)
         {
            break;
         }
         new_pits_source = Source_Translation[i].pits_source;
      }
   }

   (*source) = new_pits_source;

   return(pits_source_found);
}

/**
 * Map from logical source to the appropriate PITS source ID.
 *
 * @param [in] tuner_band - Tuner Band from tuner manager
 * @param [in] pits_band - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
static bool pits_cpid_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_CPID_T *pits_band)
{
   int8_t i;
   bool pits_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation_Cpid); i++)
   {
      if (Band_Translation_Cpid[i].tuner_band_cpid == tuner_band)
      {
         (*pits_band) = Band_Translation_Cpid[i].pits_band_cpid;
         pits_band_found = true;
         break;
      }
   }

   return(pits_band_found);
}
/**
 * Map from logical source to the appropriate PITS source ID.
 *
 * @param [in] logical_source - Logical source from audio manager
 * @param [in] pits_source - pointer to data, to supply the PITS source ID
 *                           back to the calling function
 */
static bool pits_cpid_audio_map_logical_src_to_pits_src(Audio_Logical_Src_T logical_source, PITS_Source_CPID_T *source)
{
   int8_t i;
   PITS_Source_CPID_T new_pits_source = (*source);
   bool pits_source_found = false;

   for (i = (Num_Elems(Source_Translation_Cpid) - 1); i >= 0; i--)
   {
      if (Source_Translation_Cpid[i].logical_source_cpid == logical_source)
      {
         pits_source_found = true;
         if (Source_Translation_Cpid[i].pits_source_cpid == new_pits_source)
         {
            break;
         }
         new_pits_source = Source_Translation_Cpid[i].pits_source_cpid;
      }
   }

   (*source) = new_pits_source;

   return(pits_source_found);
}

static bool_t pits_cpid_tuner_map_pits_band_to_band(PITS_Band_CPID_T pits_band, PITS_Tuner_Band_T *tuner_band)
{
   uint8_t i;
   bool_t tuner_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation_Cpid); i++)
   {
      if (Band_Translation_Cpid[i].pits_band_cpid == pits_band)
      {
         (*tuner_band) = Band_Translation_Cpid[i].tuner_band_cpid;
         tuner_band_found = true;
         break;
      }
   }

   return(tuner_band_found);
}
/**
 * Map from PITS source ID to the appropriate logical source
 *
 * @param [in] pits_source - PITS source ID from PITS message
 * @param [in] logical_source - pointer to data, to supply the logical source
 *                           back to the calling function
 */

/*static bool_t pits_cpid_audio_map_pits_src_to_logical_src(PITS_Source_CPID_T pits_source, Audio_Logical_Src_T *logical_source)
{
   uint8_t i;
   bool_t logical_source_found = false;

   for (i = 0; i < Num_Elems(Source_Translation_Cpid); i++)
   {
      if (Source_Translation_Cpid[i].pits_source_cpid == pits_source)
      {
         (*logical_source) = Source_Translation_Cpid[i].logical_source_cpid;
         logical_source_found = true;
         break;
      }
   }

   return(logical_source_found);
}*/
/*
 * This function is to Get the Page for diagnostics
 * @param [out] Returns (Actual_Preset_Diag)
 *
 *
 */
static uint8_t Diagnostics_Get_Page(preset_mgr_zone_t zone)
{
   preset_mgr_zone_num_type zone_index = SYS_ZONE_TO_INDEX(zone);
   preset_mgr_page_num_type max_page = Preset_PS_Get_Num_Pages(zone_index);
   diag_current_page = Preset_PS_Get_Current_Page(zone_index);
   diag_current_page = Util_Wrap_Check(++diag_current_page, 1, Preset_PS_Get_Num_Pages(zone_index));
   if (diag_current_page == 1)
   {
      diag_current_page = max_page;
   }
   else
   {
      diag_current_page = diag_current_page - 1;
   }
   return (diag_current_page);
}
/*
 * This function is to Get the Preset for diagnostics
 * @param [out] Returns (Actual_Preset_Diag)
 *
 *
 */
static uint8_t Diagnostics_Get_Preset(preset_mgr_zone_t zone)
{
   preset_mgr_zone_num_type zone_index = SYS_ZONE_TO_INDEX(zone);
   diag_current_preset = Preset_PS_Get_Current_Preset(zone_index);
   return (diag_current_preset);
}

static void Pits_Preset_Update_HMI_Display_Info(preset_mgr_zone_t zone)
{
    Preset_Type_T presets;
    uint8_t preset_cnt;
    preset_mgr_zone_num_type   zone_index   = SYS_ZONE_TO_INDEX(zone);
    preset_mgr_page_num_type   current_page_index   = Preset_PS_Get_Current_Page(zone_index) - 1;
    preset_mgr_page_num_type   current_page = Preset_PS_Get_Current_Page(zone_index);
    preset_mgr_page_num_type   num_pages = Preset_PS_Get_Num_Pages(zone_index);
    uint8_t page_cnt;
    BDB_T bdb;
    BDB_T all_presets_data;

    BDB_Init(&bdb, (num_pages * PRESET_MGR_NUM_PRESETS * PRESET_MGR_MAX_LABEL_SIZE));
    BDB_Init(&all_presets_data, (num_pages * PRESET_MGR_NUM_PRESETS * (sizeof(Tuner_Info_T) - PRESET_MGR_MAX_LABEL_SIZE)));


    for(preset_cnt = 0; preset_cnt<PITS_PRESET_MGR_NUM_PRESETS; preset_cnt++)
    {
        presets = Preset_PS_Get_Preset_Data(zone_index, current_page_index, preset_cnt);
        Safe_Strncpy(Pits_Preset_Page_Info[preset_cnt], presets.tuner_info.station_name, PITS_PRESET_MGR_MAX_LABEL_SIZE);
        Tr_Info_Lo_2("\n\n\n=== Publishing Preset_Page_Info[%d] = %s\n", preset_cnt, Pits_Preset_Page_Info[preset_cnt]);

    }
    for(page_cnt = 0; page_cnt<num_pages; page_cnt++)
    {
       for(preset_cnt = 0; preset_cnt<PRESET_MGR_NUM_PRESETS; preset_cnt++)
        {
          presets = Preset_PS_Get_Preset_Data(zone_index, page_cnt, preset_cnt);

          BDB_Write_U8(&all_presets_data, (uint8_t)presets.tuner_info.band);
          BDB_Write_U32(&all_presets_data, presets.tuner_info.idd);
          BDB_Write_U8(&all_presets_data, presets.tuner_info.subchannel);
          BDB_Write_String(&all_presets_data, presets.tuner_info.station_name);
          BDB_Write_U16(&all_presets_data, presets.tuner_info.pi);
          #ifdef FEATURE_EMPTY_PRESET
          BDB_Write_U8(&all_presets_data, presets.tuner_info.empty_flag);
          #endif
       }
    }


    SAL_Publish(PRESET_EVG_PAGE_NUM, &current_page, sizeof(PRESET_EVG_PAGE_NUM_T));
    SAL_Publish((SAL_Event_Id_T) PRESET_EVG_PAGES_SELECTION_NUM, &num_pages, sizeof(preset_mgr_page_num_type));

    SAL_Publish( PRESET_EVG_PAGE_INFO, &Pits_Preset_Page_Info[0], ((sizeof(char))*PITS_PRESET_MGR_NUM_PRESETS*PITS_PRESET_MGR_MAX_LABEL_SIZE) );
    SAL_Publish( PRESET_EVG_ALL_PRESETS_DATA, BDB_Get_Buffer(&all_presets_data), BDB_Get_Data_Length(&all_presets_data));

    BDB_Free(&bdb);
    BDB_Free(&all_presets_data);
}

/**
 * Lookup presets and msg status for HMI highlights
 *
 * @param [in] zone
 *   - preset_mgr_zone_t.
 *
 * @return void
 *   - none
 */
static void Pits_Preset_Update_HMI_Highlights(preset_mgr_zone_t zone)
{
    PRESET_EVG_LOOKUP_RESULT_T lookup_result;
    PITS_Tuner_Mgr_Target_T tune_band_info;
    bool_t valid_channel = false;
    uint8_t channel1;
    uint8_t channel2;
    Current_Tuner_Data.channel_number = PITS_Get_AMFM_Tuner_Frequency();
    Current_Tuner_Data.band = PITS_Get_Tuner_Source_Type();
    Current_Tuner_Data.service_identifier = 0;
    lookup_result = Pits_Preset_Mgr_Lookup_Preset(zone,
                                Current_Tuner_Data.band,
                                Current_Tuner_Data.channel_number,
                                Current_Tuner_Data.service_identifier);
    if((lookup_result.active_preset == 0x01)&&
                  (lookup_result.match_status == 0xFF)&&
                  (lookup_result.matched_numbers == 0)
                  )
    {
           lookup_result.active_preset = 0xFF;
           lookup_result.match_status = 0x00;
           lookup_result.matched_numbers = 0x00;
    }

       if((lookup_result.active_preset != Preset_Highlights.active_preset)||
          (lookup_result.match_status != Preset_Highlights.match_status)||
          (lookup_result.matched_numbers != Preset_Highlights.matched_numbers)
          )
       {
        SAL_Publish((SAL_Event_Id_T) PRESET_EVG_LOOKUP_RESULT,
        &lookup_result, sizeof(lookup_result));

       }
       Preset_Highlights.active_preset = lookup_result.active_preset;
       Preset_Highlights.match_status = lookup_result.match_status;
       Preset_Highlights.matched_numbers = lookup_result.matched_numbers;
       channel1 = (Current_Tuner_Data.channel_number)>>8;
       channel2 = (Current_Tuner_Data.channel_number);
       if (Current_Tuner_Data.band == SSM_SRC_AM)
       {
          valid_channel = PITS_Tuner_Set_AM_Value(&tune_band_info, channel1, channel2);
       }
       if (Current_Tuner_Data.band == SSM_SRC_FM)
       {
          valid_channel = PITS_Tuner_Set_FM_Value(&tune_band_info, channel1, channel2);
       }
       if (Current_Tuner_Data.band == SSM_SRC_XM)
       {
          channel1 = Current_Tuner_Data.service_identifier;
          channel2 = 0;
          valid_channel = PITS_Tuner_Set_XM_Value(&tune_band_info, channel1, channel2);
       }
       if (valid_channel)
       {
          /*RemRcvr_Enable_Override();
          PITS_Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);*/
       }
}
/**
 * Lookup presets and msg status for HMI highlights
 *
 * @param [in] zone
 *   - preset_mgr_zone_t.
 *
 * @return void
 *   - none
 */
extern void Pits_Preset_Update_HMI_Highlights2(preset_mgr_zone_t zone)
{
    PRESET_EVG_LOOKUP_RESULT_T lookup_result;

    lookup_result.active_preset = 0xFF;
    lookup_result.match_status = 0x00;
    lookup_result.matched_numbers = 0x00;

    {

       SAL_Publish((SAL_Event_Id_T) PRESET_EVG_LOOKUP_RESULT,
               &lookup_result, sizeof(lookup_result));
    }
}

static void Pits_Preset_Get_HMI_Highlights(preset_mgr_zone_t zone)
{
    PRESET_EVG_LOOKUP_RESULT_T lookup_result;
    Current_Tuner_Data.channel_number = PITS_Get_AMFM_Tuner_Frequency();
    Current_Tuner_Data.band = PITS_Get_Tuner_Source_Type();
    Current_Tuner_Data.service_identifier = 0;
    lookup_result = Pits_Preset_Mgr_Lookup_Preset(zone,
                                Current_Tuner_Data.band,
                                Current_Tuner_Data.channel_number,
                                Current_Tuner_Data.service_identifier);
    Preset_Highlights.active_preset = lookup_result.active_preset;
    Preset_Highlights.match_status = lookup_result.match_status;
    Preset_Highlights.matched_numbers = lookup_result.matched_numbers;
}
extern void Pits_Preset_Update_HMI_Display_Info2(preset_mgr_zone_t zone, uint8_t page_number)
{
    Preset_Type_T presets;
    uint8_t preset_cnt;
    preset_mgr_zone_num_type   zone_index   = SYS_ZONE_TO_INDEX(zone);
    preset_mgr_page_num_type   current_page_index   = page_number - 1;
    preset_mgr_page_num_type   current_page = page_number;
    preset_mgr_page_num_type   num_pages = Preset_PS_Get_Num_Pages(zone_index);
    uint8_t page_cnt;
    BDB_T bdb;
    BDB_T all_presets_data;

    BDB_Init(&bdb, (num_pages * PRESET_MGR_NUM_PRESETS * PRESET_MGR_MAX_LABEL_SIZE));
    BDB_Init(&all_presets_data, (num_pages * PRESET_MGR_NUM_PRESETS * (sizeof(Tuner_Info_T) - PRESET_MGR_MAX_LABEL_SIZE)));

    for(preset_cnt = 0; preset_cnt<PITS_PRESET_MGR_NUM_PRESETS; preset_cnt++)
    {
       presets = Preset_PS_Get_Preset_Data(zone_index, current_page_index, preset_cnt);
       Safe_Strncpy(Pits_Preset_Page_Info[preset_cnt], presets.tuner_info.station_name, PITS_PRESET_MGR_MAX_LABEL_SIZE);
       Tr_Info_Lo_2("\n\n\n=== Publishing Preset_Page_Info[%d] = %s\n", preset_cnt, Pits_Preset_Page_Info[preset_cnt]);

    }
    for(page_cnt = 0; page_cnt<num_pages; page_cnt++)
    {
       for(preset_cnt = 0; preset_cnt<PRESET_MGR_NUM_PRESETS; preset_cnt++)
        {
          presets = Preset_PS_Get_Preset_Data(zone_index, page_cnt, preset_cnt);

          BDB_Write_U8(&all_presets_data, (uint8_t)presets.tuner_info.band);
          BDB_Write_U32(&all_presets_data, presets.tuner_info.idd);
          BDB_Write_U8(&all_presets_data, presets.tuner_info.subchannel);
          BDB_Write_String(&all_presets_data, presets.tuner_info.station_name);
          BDB_Write_U16(&all_presets_data, presets.tuner_info.pi);
          #ifdef FEATURE_EMPTY_PRESET
          BDB_Write_U8(&all_presets_data, presets.tuner_info.empty_flag);
          #endif
          Tr_Info_Lo_3("Publishing All_Preset_Page_Info[%d][%d] = %s ", page_cnt, preset_cnt, presets.tuner_info.station_name);
       }
    }
    Tr_Info_Hi_1("Publishing All_Preset_Page_Info, size = %d.", BDB_Get_Data_Length(&bdb));

    SAL_Publish(PRESET_EVG_PAGE_NUM, &current_page, sizeof(PRESET_EVG_PAGE_NUM_T));
    SAL_Publish((SAL_Event_Id_T) PRESET_EVG_PAGES_SELECTION_NUM, &num_pages, sizeof(preset_mgr_page_num_type));

    SAL_Publish( PRESET_EVG_PAGE_INFO, &Pits_Preset_Page_Info[0], ((sizeof(char))*PITS_PRESET_MGR_NUM_PRESETS*PITS_PRESET_MGR_MAX_LABEL_SIZE) );
    SAL_Publish( PRESET_EVG_ALL_PRESETS_DATA, BDB_Get_Buffer(&all_presets_data), BDB_Get_Data_Length(&all_presets_data));

    BDB_Free(&bdb);
    BDB_Free(&all_presets_data);

}
/**
 * 1. only current page search
 * 2. return bit pattern. all 0 means no match. matched preset number is indicated in the bits
 *
 * @param [in] zone, num_pages
 *   - preset_mgr_zone_t, tuner_info_band_type, tuner_info_id_type, tuner_info_pi_type.
 *
 * @return void
 *   - none
 */
static PRESET_EVG_LOOKUP_RESULT_T Pits_Preset_Mgr_Lookup_Preset(preset_mgr_zone_t zone, SSM_Source_Type_T band, uint32_t ch_id, uint16_t pi)
{
   Preset_Type_T presets = {{PRESET_MGR_NUM_DEV_TYPES, 0, 0, "", 0}};
   preset_mgr_page_num_type current_page_index = 0;
   preset_mgr_preset_num_type preset_cnt = 0;
   preset_mgr_zone_num_type zone_index = SYS_ZONE_TO_INDEX(zone);
   PITS_TUNER_EVG_CHANNEL_T tune_band_info = {0};

   uint8_t current_preset_index = 0;
   uint8_t   temp_matched_n=0;
   uint8_t   temp_matched_numbers = 0;
   PRESET_EVG_LOOKUP_RESULT_T ret_val = {SYS_NUM_ZONES, false, 0, 0};

   ret_val.match_status = 0;
   ret_val.matched_numbers = 0;
   ret_val.active_preset = 0xff; /* invalid */
   current_preset_index = Preset_PS_Get_Current_Preset(zone_index)-1;
   current_page_index = Preset_PS_Get_Current_Page(zone_index)-1;
   preset_cnt = 0;

   while ( preset_cnt < PRESET_MGR_NUM_PRESETS )
   {
      presets = Preset_PS_Get_Preset_Data(zone_index, current_page_index, preset_cnt);
      if (presets.tuner_info.band == PRESET_MGR_DEV_AM)
      {
         tune_band_info.band = SSM_SRC_AM;
      }
      if (presets.tuner_info.band == PRESET_MGR_DEV_FM)
      {
         tune_band_info.band = SSM_SRC_FM;
      }
      if (presets.tuner_info.band == PRESET_MGR_DEV_XM)
      {
         tune_band_info.band = SSM_SRC_XM;
      }
      if ( band == tune_band_info.band )
      {
         if ( !pi )  /* non-RDS */
         {
            if ( ch_id == presets.tuner_info.idd )
            {
               ret_val.match_status = true;
               if(preset_cnt == current_preset_index)
               {
                   ret_val.active_preset = preset_cnt+1;
               }
               temp_matched_n = preset_cnt;
               temp_matched_numbers = (1<<preset_cnt);
               ret_val.matched_numbers |= temp_matched_numbers;
/* bit n represets the match status of preset n */
            }
         }
         else  /* RDS */
         {
            if ( pi == presets.tuner_info.pi )
            {
               ret_val.match_status = true;
               if(preset_cnt == current_preset_index)
               {
                   ret_val.active_preset = preset_cnt+1;
               }
               temp_matched_n = preset_cnt;
               temp_matched_numbers = (1<<preset_cnt);
               ret_val.matched_numbers |= temp_matched_numbers;
/* bit   n represets the match status of preset n */
            }
         }
      }
      preset_cnt++;
   }

   if((ret_val.match_status == true)&&
      ret_val.active_preset == 0xff)
   {
      ret_val.active_preset = temp_matched_n+1;
       /* if none of the matched presets matches the last current preset,
          make new matched one the current active preset */
   }
   return( ret_val );
   /* bit n represets the match status of preset n, all 0 means no match */
}

void PITS_Get_Source_Hours (void)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;
   AMFM_Mode_T tuner_play_status = AMFM_Get_Mode();
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Disc_Pbk_Diag_DVD_Slot_Media_t dvd_slot_media = Disc_Pbk_Diag_Get_DVD_Slot_Media();

   PITs_GM_Set_DID (0,3);
   logical_source = AuMgr_Get_Source(zone, bus);
   pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
   if(source == PITC_SOURCE_DVD)
   {
      source = PITC_SOURCE_DVD2;
   }
   PITs_GM_Set_DID_Source(source, tuner_play_status);
   PITs_GM_Set_DID(1,dvd_slot_media.media);

      PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}

PITS_Source_CPID_T PITS_Get_Source_DPID10 (void)
{
   Sys_Zone_T zone = SYS_ZONE_MAIN;
   Sys_Audio_Bus_T bus = SYS_AUDIO_ENTERTAINMENT_BUS;
   Audio_Logical_Src_T logical_source;
   PITS_Source_CPID_T source = PITC_SOURCE_NONE;

   logical_source = AuMgr_Get_Source(zone, bus);
   pits_cpid_audio_map_logical_src_to_pits_src(logical_source, &source);
   if(source == PITC_SOURCE_DVD)
   {
      source = PITC_SOURCE_DVD2;
   }
   return (source);

}

void Pits_Get_Elapsed_Time (const uint8_t * data, size_t length)
{
   memcpy(&pit_time_rpt[0],&data[0],16);
   pit_time_length = length;
   Pits_Filesys_Get_Elapsed_Time(data, length);
}

void PITS_Get_App_SWID (void)
{
   uint8_t errors_index = 0;
   uint8_t cd_errors[8] = {0,0,0,0,0,0,0,0};
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   uint8_t pits_save_power = HMI_PS_Get_Radio_Power();

   PITs_GM_Set_DID (0,5);
   Util_Put_Big_Endian_U32(&cd_errors[0], VT_SOFTWARE_ID);
   Util_Put_Big_Endian_U32(&cd_errors[4], VT_SOFTWARE_VERSION);
   for (errors_index = 0; errors_index < 0x08; errors_index++)
   {
      PITs_GM_Set_DID(errors_index + 1, cd_errors[errors_index]);
   }
   PITs_GM_Set_DID (9,pits_save_power);
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);

}

extern void Send_APP_SWID_To_Vip_Start (void)
{
   uint8_t data_index = 0;
   uint8_t swid_data[8] = {0,0,0,0,0,0,0,0};
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   int16_t ret;

   ret = SAL_Run_Command_L("dd","if=/dev/mmcblk0p2","of=/tmp/swid","bs=8","skip=131073","count=1",NULL);
   PBC_Ensure((ret != -1),"Failed system call");
   
   PITs_GM_Set_DID (0,5);
   Util_Put_Big_Endian_U32(&swid_data[0], VT_SOFTWARE_ID);
   Util_Put_Big_Endian_U32(&swid_data[4], VT_SOFTWARE_VERSION);
   for (data_index = 0; data_index < 0x08; data_index++)
   {
      PITs_GM_Set_DID(data_index + 1, swid_data[data_index]);
   }
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}

void Pits_Default_Backup_Camera_Load (void)
{
   uint8_t didex[5] = {0};

   didex[0] = 0xE2;
   didex[1] = Cal_RVS_Guidelines_Width;
   didex[2] = Cal_RVS_Steer_Saturation_Angle;
   didex[3] = (uint8_t) (Cal_RVS_Steer_Wheelbase>>8);
   didex[4] = (uint8_t) Cal_RVS_Steer_Wheelbase;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE3;
   didex[1] = (uint8_t) (Cal_RVS_Steer_Inverse_Rear_Ratio>>8);
   didex[2] = (uint8_t) Cal_RVS_Steer_Inverse_Rear_Ratio;
   didex[3] = (uint8_t) (Cal_RVS_Steer_Inverse_Front_Ratio>>8);
   didex[4] = (uint8_t) Cal_RVS_Steer_Inverse_Front_Ratio;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE4;
   didex[1] = (uint8_t) Cal_RVS_Steer_Rear_Axle_Offset;
   didex[2] = (uint8_t) Cal_RVS_Ovlay_Num_Dist_Marks;
   didex[3] = (uint8_t) Cal_RVS_Ovlay_Delta_Dist_Marks;
   didex[4] = (uint8_t) Cal_RVS_Ovlay_Track_Width;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE5;
   didex[1] = (uint8_t) Cal_RVS_Camera_Optical_Offset_V;
   didex[2] = (uint8_t) Cal_RVS_Camera_Optical_Offset_U;
   didex[3] = 0;
   didex[4] = 0;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE6;
   didex[1] = (uint8_t) (Cal_RVS_Camera_Distort_Coef_2>>8);
   didex[2] = (uint8_t) Cal_RVS_Camera_Distort_Coef_2;
   didex[3] = (uint8_t) (Cal_RVS_Camera_Distort_Coef_1>>8);
   didex[4] = (uint8_t) Cal_RVS_Camera_Distort_Coef_1;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE7;
   didex[1] = (uint8_t) (Cal_RVS_Camera_Focal_Lenght_V>>8);
   didex[2] = (uint8_t) Cal_RVS_Camera_Focal_Lenght_V;
   didex[3] = (uint8_t) (Cal_RVS_Camera_Focal_Lenght_U>>8);
   didex[4] = (uint8_t) Cal_RVS_Camera_Focal_Lenght_U;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE8;
   didex[1] =TX_Data[1] = (uint8_t) Cal_RVS_Camera_Offset_Z;
   didex[2] =TX_Data[2] = (uint8_t) Cal_RVS_Camera_Offset_Y;
   didex[3] = 0;
   didex[4] = 0;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xE9;
   didex[1] = (uint8_t) (Cal_RVS_Camera_Rotation_Z>>8);
   didex[2] = (uint8_t) Cal_RVS_Camera_Rotation_Z;
   didex[3] = (uint8_t) (Cal_RVS_Camera_Rotation_Y>>8);
   didex[4] = (uint8_t) Cal_RVS_Camera_Rotation_Y;
   BUC_Set_DID_Data(&didex[0]);

   didex[0] = 0xEA;
   didex[1] = TX_Data[1] = (uint8_t) (Cal_RVS_Camera_Rotation_X>>8);
   didex[2] = TX_Data[2] = (uint8_t) Cal_RVS_Camera_Rotation_X;
   didex[3] = 0;
   didex[4] = 0;
   BUC_Set_DID_Data(&didex[0]);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_set_power_diag_req(const PITS_Message_T * message)
{
   char idpower[12];
   Persistent_Section_ID_T section_id_power = PS_SECTION_NONVOL;
   uint8_t read_buffer_power[10];
   uint8_t radio_power_state = 0;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0C_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         snprintf(idpower, sizeof(idpower), "Radio_Power");
         if(PS_Read(section_id_power, (const char *)&idpower[0], &read_buffer_power[0], 1))
         {
            radio_power_state = read_buffer_power[0];
         }
         if ((message->data[0] == 0) && (radio_power_state == 1))
         {
            PITs_GM_Set_DID (0,8);
            PITs_GM_Set_DID(1, message->data[0]);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
         }
         else if ((message->data[0] == 1) && (radio_power_state == 0))
         {
            PITs_GM_Set_DID (0,8);
            PITs_GM_Set_DID(1, message->data[0]);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
         }
         pits_status = DONE; 
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_get_power_diag_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   char idpower[12];
   Persistent_Section_ID_T section_id_power = PS_SECTION_NONVOL;
   uint8_t read_buffer_power[10];
   uint8_t radio_power_state = 0;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0C_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         usleep(500 * 1000);
         snprintf(idpower, sizeof(idpower), "Radio_Power");
         if(PS_Read(section_id_power, (const char *)&idpower[0], &read_buffer_power[0], 1))
         {
            radio_power_state = read_buffer_power[0];
         }
            PITs_GM_Set_DID (0,9);
            PITs_GM_Set_DID(1, radio_power_state);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);

         pits_status = DONE; 
      }
   }

   return (pits_status);
}

Done_Or_Not_Done_T pits_GMdiag_set_source_diag_req(const PITS_Message_T * message)
{

   Sys_Zone_T zone;
   Sys_Audio_Bus_T bus;
   SSM_Source_Type_T new_source_ssm = SSM_SRC_NONE;
   SSM_Channel_T new_zone_ssm = SSM_CHAN_MAIN_AUDIO;
   PITS_Source_CPID_T source;
   uint8_t source_index = 0;
   bool_t source_found = false;

   if (NULL != message)
   {

         /* Decode received messages  */
         zone = (Sys_Zone_T) message->data[0];
         bus  = (Sys_Audio_Bus_T) message->data[1];
         source = (PITS_Source_CPID_T) message->data[2];
         for( source_index = 0; source_index < Num_Elems(Set_Source_SSM_Table); source_index++)
         {
            if( Set_Source_SSM_Table[source_index].pits_source == source )
            {
               new_source_ssm = Set_Source_SSM_Table[source_index].logical_source_ssm;
               source_found = true;
            }
         }
         if ((SYS_AUDIO_ENTERTAINMENT_BUS == bus) &&
             (SYS_ZONE_MAIN == zone) &&
             source_found)
         {
            PITS_AU_Select_Source_Type(new_source_ssm, new_zone_ssm);
         }

   }

   return (DONE);
}

/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID90_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_get_ps_mfg_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_PRESET_DEFAULT_RPT, 15);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 1)
         {
 #if 0        
            PITS_Display_Test_Output(DISPLAY_OVERRIDE);
            PITS_Display_Test_Output(0x13);
            PITS_Display_Test_Output(0x18);
#endif			
         }
         else
         {
#if 0         
            PITS_Display_Test_Output(DISPLAY_EXIT);
#endif
         }
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

void Pits_Get_Server_Data (const uint8_t * data, size_t length)
{
   SAL_Publish(DIAG_EVG_PITS_SERVER_RSP, data, length);
}

Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC753_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC753_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          if (PS_ENABLE_BLUETOOTH_Get())
          {
             TX_Data[1] = Pits_Get_Diag_Btdevices_Number();
          }
          else
          {
             TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
          }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC754_Req(const PITS_Message_T * message)
{
   uint8_t bt_profile[5] = {0};
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC754_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          if (PS_ENABLE_BLUETOOTH_Get())
          {
             if (statusconnected == BT_CM_STATE_CONNECTED)
             {
                TX_Data[1] |= BIT7;
                if (pits_call_count > 0)
                {
                   TX_Data[1] |= BIT6;
                }
                if (pits_bt_playback == BT_AS_PLAY_STATUS_PLAYING)
                {
                   TX_Data[1] |= BIT5;
                }
                Pits_Get_Diag_Btconnected_Profile(&bt_profile[0]);
                if (bt_profile[0]==1)
                {
                   TX_Data[2] |= BIT7;
                }
                if (bt_profile[1]==1)
                {
                   TX_Data[2] |= BIT6;
                }
                if (bt_profile[2]==1)
                {
                   TX_Data[2] |= BIT5;
                }
                if (pits_bt_avrcp == 0)
                {
                   TX_Data[3] |= BIT7;
                }
                if (pits_bt_avrcp == 1)
                {
                   TX_Data[3] |= BIT6;
                }
                if (pits_bt_avrcp == 2)
                {
                   TX_Data[3] |= BIT5;
                }
                if (pits_bt_avrcp == 3)
                {
                   TX_Data[3] |= BIT4;
                }
             }
          }
          else
          {
             TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
          }


         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC751_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] = {BT_DIAG_EVG_LINK_QUALITY_RESULT};

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_PIDC751_RPT, 7);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
          TX_Data[0] = (uint8_t) SUCCESS;
          if (PS_ENABLE_BLUETOOTH_Get())
          {
             if ((statusconnected == BT_CM_STATE_CONNECTED) && (Pits_Get_Diag_Btdevices_Number() > 0))
             {
                /* subscribe to the response event */
                if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
                {
                   Tr_Info_Hi("Requesting Link Quality for ACL 0");

                   /* request the link quality for ACL connection 0 */
                   BT_DIAG_Request_Link_Quality(0);

                   /* wait for the response event */
                   response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 200);

                   if ( (NULL != response_message) && (BT_DIAG_EVG_LINK_QUALITY_RESULT == response_message->event_id) )
                   {
                      /* correct message received, parse the data */
                      BT_DIAG_EVG_LINK_QUALITY_RESULT_T link_quality_result;
                      link_quality_result = BT_DIAG_Get_Link_Quality_Result(response_message->event_id, response_message->data, response_message->data_size);

                      /* check result status */
                      if (BT_DIAG_OK == link_quality_result.result_code)
                      {
                         Tr_Info_Lo_1("Link Quality result = 0x%2.2X", link_quality_result.link_quality);

                         /* success! fill out return message data */
                         TX_Data[0] = (uint8_t) SUCCESS;
                         TX_Data[1] = link_quality_result.link_quality;
                      }
                      else
                      {
                         Tr_Info_Mid("Failed to retrieve link quality"); /* this is normal if there is no device connected */
                         TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
                      }
                   }

                   /* unsubscribe from temporary subscribed events */
                   SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
                }
             }
             else
             {
                TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
             }
          }
          else
          {
             TX_Data[0] = (uint8_t) DATA_OUT_OF_RANGE;
          }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_get_did_xm_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID_XM_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         TX_Data[1] = Mfg_PS_Get_Did_Xm_Enable_Get();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&TX_Message); 
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_GMdiag_put_did_xm_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID_XM_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         Mfg_PS_Put_Did_Xm_Enable(message->data[0]);

         pits_status = DONE; 
      }
   }
   return (pits_status);
}
void Pits_Get_BT_Connected_Status (const uint8_t * data, size_t length)
{
   SAL_Event_Id_T event_id = BT_CM_EVG_MODULE_STATUS;

   statusconnected = BT_CM_Get_Module_State((SAL_Event_Id_T)event_id, data, length);

}

extern uint8_t Pits_Return_BT_Connected_Status (void)
{
   return ((uint8_t)statusconnected);
}

void Pits_Get_Hands_Call_Status (const uint8_t * data, size_t length)
{
   SAL_Event_Id_T event_id = BT_HFP_EVG_CALL_STATUS;
   pits_call_count = BT_HFP_Get_Call_Count((SAL_Event_Id_T)event_id, data, length);
}

void Pits_Get_Btaudio_Stream_Status (const uint8_t * data, size_t length)
{
   BT_AS_EVG_PLAYBACK_STATUS_T  stub_playback;
   SAL_Event_Id_T event_id = BT_AS_EVG_PLAYBACK_STATUS;
   stub_playback = BT_AS_Get_Playback_Status ((SAL_Event_Id_T)event_id, data, length);
   pits_bt_playback = stub_playback.status;
}

void Pits_Get_Bt_Operations_Status (const uint8_t * data, size_t length)
{
   BT_AS_EVG_ENABLED_OPERATIONS_T en_operations;
   SAL_Event_Id_T event_id = BT_AS_EVG_ENABLED_OPERATIONS;
   en_operations = BT_AS_Get_Operations_States(event_id, data, length);
   if (BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_SET_SETTINGS))
   {
      Tr_Info_Lo(" supports audio streaming 1.3");
      pits_bt_avrcp = 1;
   }
   else if(  BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_SELECT_PLAYER)  && BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_PLAY_ITEM_UID) && BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_CHANGE_PATH) && BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_SET_WINDOW))
   {
      Tr_Info_Lo(" supports audio streaming 1.4 Browsing UID persistency");
      pits_bt_avrcp = 3;
   }
   else if(  BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_SELECT_PLAYER)  && BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_CHANGE_PATH)  && BETULA_IS_OP_ENABLED(en_operations, PITBTL_AS_OP_SET_WINDOW))
   {
      Tr_Info_Lo(" supports audio streaming 1.4 Browsing UID no persistency");
      pits_bt_avrcp = 2;
   }
   else
   {
      Tr_Info_Lo(" supports audio streaming 1.0");
      pits_bt_avrcp = 0;
   }

}

extern uint8_t Pits_Get_Diag_Btprofile_stream (void)
{
   return (pits_bt_avrcp);
}

void Pits_Ptt_Pressed_Voice (const uint8_t * data, size_t length)
{
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;

   PITs_GM_Set_DID (0,18);
   PITs_GM_Set_DID (1,1);
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}

void Pits_Ptt_Ended_Voice (const uint8_t * data, size_t lenght)
{
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;

  PITs_GM_Set_DID (0,18);
  PITs_GM_Set_DID (1,0);
  PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}
/*===========================================================================*
 * FUNCTION: PITS_GMdiag_Get_DID0B_Req
 *===========================================================================*
 * @brief Receive a Request to get the SWID
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0-7] = DPID04 from vip Type:

 * @param [out] TX_Message[0] = confirmation (SUCCESS, FAIL)
 * @param [out] TX_Message[n] = DPID04 return
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_GMdiag_get_pwtwo_diag_req(const PITS_Message_T * message)
{
   char idpower[12];
   Persistent_Section_ID_T section_id_power = PS_SECTION_NONVOL;
   uint8_t read_buffer_power[10];
   uint8_t radio_power_state = 0;
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      TX_Bus_ID = message->bus;
      PITS_GMdiag_Compose_Message_Header(MID_GMDIAG_GET_DID0C_RPT, 3);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
      }
      else
      {
         TX_Data[0] = (uint8_t) SUCCESS;
         snprintf(idpower, sizeof(idpower), "Radio_Power");
         if(PS_Read(section_id_power, (const char *)&idpower[0], &read_buffer_power[0], 1))
         {
            radio_power_state = read_buffer_power[0];
         }
            PITs_GM_Set_DID (0,9);
            PITs_GM_Set_DID(1, radio_power_state);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);

         pits_status = DONE; 

      }
   }
   return (pits_status);
}
/*===========================================================================*/
/*!
 * @file pits_gmdiag_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06July2016 Rahul Chiryil (vzm576) Rev.2
 *  ctc_ec#157446: Coverity warning removal
 *
 * - 09 Oct 2014 Ginger Jiang Rev 64.1.13
 *   - Add GWM_CHK011_8AT Macro 
 *
 * 21 Sep 2012 Miguel Garcia
 * Include check valid channel and source to cancel cpids
 *
 *  06-Sep-2012 Darinka L\F3pez Rev 62
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 03 Sep 2012 Miguel Garcia
 * Fix gcc warning in pits_gmdiag_services
 *
 * 31-Aug-2012 Darinka Lopez 60
 * Taks kok_basa#116889 - Change MID 30/32 - Set standarized Input
 * Fix Include issue. *_cbk.h should not be call in *.h files.
 *
 * 15 Aug 2012 Miguel Garcia
 * Include pits gmdiag quality
 *
 * 13 Aug 2012 Miguel Garcia
 * Include pits calls for different regions in dpid2 and dpid10
 *
 * 11 June 2012 Miguel Garcia
 * Remove Linger from cpids after cancel
 *
 * 07 June 2012 Miguel Garcia
 * Update dpid2 to read ps for band and freq for the actual audio source
 *
 * - 06-jun-2012 Kris Boultbee
 *   Task kok_basa#101503 Revision 54
 *   - Initialized ret_val in the function Pits_Preset_Mgr_Lookup_Preset() per the following Klocwork
 *     defect:
 *     'ret_val.zone' is used uninitialized in this function.
 *   - Initialized the remaining variables as a matter of course.
 *
 * 23 May 2012 Miguel Garcia
 * Include get pw diag two
 *
 * 21 May 2012 Miguel Garcia
 * Include call for boot swid in vip send swid
 *
 * 17 May 2012 Miguel Garcia
 * Include center station in fm
 *
 * 11 May 2012 Miguel Garcia
 * Upgrade cpid4 with ps calls instead of getter functions
 *
 * 09 May 2012 Miguel Garcia and Gustavo M Guzman
 * SCR kok_basa#24936 XM setting to 1 the bit 5 of the DID $7C XM
 * Update set for XM settings
 *
 * 27 Apr 2012 Miguel Garcia and Gustave M Guzman
 * Remove label for presets
 *
 * 23 Apr 2012 Miguel Garcia and Gustavo M Guzman
 * SCR kok_basa#24936 XM setting to 1 the bit 5 of the DID $7C XM
 * Update to check the bit 5 and added function to Get value
 *
 * 10 Apr 2012 Miguel Garcia Rev 45
 * Fix HMI set display
 *
 * 21-Mar-2012 Darinka Lopez  Rev 44
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 07 Mar 2012 Miguel Garcia
 * Remove tones overrides at end of cpid
 *
 * 27 Feb 2012 Miguel Garcia
 * Include bt diagnostics
 *
 * 02 Feb 2012 Miguel Garcia
 * Fix volume issue with fade, balance and tone
 *
 * 27 Jan 2012 Miguel Garcia
 * Include pids and BT functions
 *
 * 16 Jan 2012 Miguel Garcia
 * Include cpid5 display green screen
 *
 * 05-Jan-2012 Darinka Lopez  Rev 34
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move tuner specif fuctions to proccesing_tuner file .
 *
 * 14-Dec-2011 Darinka Lopez  Rev 33
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 32
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 28 Nov 2011 Miguel Garcia
 * Include changes for tuner porting
 *
 * 18 Nov 2011 Miguel Garcia
 * Include pits power on diag
 *
 * 18 Jun 2011 Miguel Garcia
 * Include send app swid to vip function
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 22 Jun 2011 Miguel Garcia
 * Include new swids
 *
 * 09 Jun 2011 Miguel Garcia
 * Include did17 fix
 *
 * 08 Jun 2011 Miguel Garcia
 * Fix did90 whole vin function
 *
 * 26 May 2011 Miguel Garcia
 * Include set first tones
 *
 * 12 May 2011 Miguel Garcia
 * Fix Cpid03 speakers not selected
 *
 * 05 May 2011 Miguel Garcia
 * Fix DID90, Dpid14
 * 03 May 2011 Miguel Garcia
 * Fix CPID01, include PIDs
 *
 * 13 Apr 2011 Miguel Garcia
 * Include CD\DVD put in PS
 *
 * 31 Mar 2011 Miguel Garcia
 * Remove VINs functions for enabling theft.cpp
 *
 * 29 Mar 2011 Miguel Garcia
 * Include DID services
 *
 * 18 Mar 2011 Miguel Garcia
 * Include cpid services
 *
 * 04 Mar 2011 Miguel Garcia
 * Include dpid services
 *
 */
/*===========================================================================*/
