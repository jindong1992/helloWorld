/*===========================================================================*/
/**
 * @file pits_desip_handler.c
 *
 * This module initialize, open and close the DESIP bus, and manage the transmission
 *    and reception of message to and from the DESIP bus.
 *
 * %full_filespec:pits_desip_handler.c~1:csrc:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:48 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module initialize, open and close the DESIP bus, and manage the transmission
 *    and reception of message to and from the DESIP bus.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - DESIP: Delco Electronics Serial Interface Protocol.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_desip_handler.h"

#include "em.h"
#include "pits_desip_wrapper.h"
#include "sippits.h"

EM_FILENUM(PITS_MODULE_ID_2, 0);     /**< define file for assert handling */

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/** Preallocated message data buffer size */
#define PITS_DESIP_MSG_SIZE (sizeof(uint32_t))

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/**
 * DESIP Temporary Receive Buffer
 */
uint8_t pits_desip_temp_buff[PITS_MAX_PACKET_SIZE];

/**
 * DESIP File Handle
 */
SIP_HANDLE sip_handle;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*
 * Initializes the DESIP module
 *
 * See API head for full description
 */
void PITS_Bus_Initialize(void)
{
   /* Clear DESIP State Machine Timer */
   SIPPITS_Tmr_Clear();

   /* Initialization of SIP protocol */
   SIPPITS_Init();

   /* Open SIP protocol */
   sip_handle = SIPPITS_Open();
}

/*
 * Closes the DESIP module
 *
 * See API head for full description
 */
void PITS_Bus_Close(void)
{
   SIPPITS_Close();
}

/**
 * Check For Receive message from the DESIP bus.
 *
 * See API head for full description
 */
void PITS_Check_RX_Message(void)
{
   int msg_len = -1;

   /* Call DESIP periodic task */
   SIPPITS_Tmr_Update();
   SIPPITS_FSM();

   /* Check if received message is available in DESIP buffer */
   /* If there is a message, pass it to PITS DESIP Receive Function to process */

   msg_len = SIPRecv(sip_handle, pits_desip_temp_buff, PITS_MAX_PACKET_SIZE);

   if (msg_len >= 3)
   {
      PITS_DESIP_Receive_Function(pits_desip_temp_buff, (uint16_t) msg_len);
   }

   /* Check if message is available to transmit */
   /* SIPXmit(sip_handle, pt_tx_buff,pt_tx_msg_size); */
}

/*===========================================================================*/
/**
 *===========================================================================
 * FUNCTION: send_function
 *===========================================================================
 * @brief Called by the PITS Message Handler to transmit a PITS packet/message.
 *
 * @returns 
 *    true - if message transmit request was accepted.
 *    false - if message transmit request was rejected or input parameter is invalid.
 *
 * @param
 *    *data - pointer to a received message to be handled by PITS.
 *    length - received message length.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * @param length
 *   Number of data bytes included in *data.
 *
 */
/*===========================================================================*/
bool_t send_function(uint8_t * data, uint16_t length)
{
   bool_t status = true;
   int sip_status;

   sip_status = SIPXmit(sip_handle, data, (int)length);
   if (sip_status == -1)
   {
      status = false;
   }
   return (status);
}

/*===========================================================================*/
/*!
 * @file pits_desip_handler.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-14  Larry Ong
 *    - Moved DESIP functions from pits_desip_manager to pits_desip_handler.
 *
 * - 2007-06-02  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
