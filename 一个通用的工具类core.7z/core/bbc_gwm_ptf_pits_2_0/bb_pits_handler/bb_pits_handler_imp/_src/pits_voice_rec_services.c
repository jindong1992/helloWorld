/*===========================================================================*/
/**
 * @file pits_voice_rec_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_voice_rec_services.c~1:csrc:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:12:04 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_voice_rec_services.h"
#include "pits_voice_rec_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 23);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_voice_initialize(void);
static void PITS_Voice_Compose_Message_Header(uint8_t mid, uint8_t size);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_VOICE_RX_INDEX

#define MID_VOICE_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_voice_rx_messages[] = {
   MID_VOICE_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_VOICE_TX_INDEX

#define MID_VOICE_TX_INDEX(name, mid) (mid),

static const uint8_t pits_voice_tx_messages[] = {
   MID_VOICE_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_VOICE_RX_INDEX
#define MSID_VOICE_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_voice_rx_message_sets[] = {
   MSID_VOICE_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_VOICE_TX_INDEX
#define MSID_VOICE_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_voice_tx_message_sets[] = {
   MSID_VOICE_TX_TABLE
};

static uint8_t voice_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T voice_message;      /* for construction of a voice service message to be transmitted */

static uint8_t voice_tx_data[PITS_MAX_MESSAGE_SIZE];

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Voice_Services_Interface = {
   pits_voice_initialize,
   pits_voice_rx_message_sets,
   Num_Elems(pits_voice_rx_message_sets),
   pits_voice_tx_message_sets,
   Num_Elems(pits_voice_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_voice_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_voice_initialize(void)
{
   voice_tx_bus_id = 0;
   memset(&voice_message, 0x00, sizeof(PITS_Message_T));
   memset(voice_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
}

static void PITS_Voice_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   voice_message.bus = voice_tx_bus_id;
   voice_message.data = voice_tx_data;
   voice_message.MSID = MSID_VOICE_SERVICES;
   voice_message.MID = mid;
   voice_message.data_size = size;
   memset(&voice_tx_data[0], 0x00, size);
}
/*===========================================================================*
 * FUNCTION: pits_voice_session_get_state_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_start_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_START_DETECTION_RPT, 8);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_start_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_start_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_START_DETECTION_RPT, 8);

      if (message->data_size != 7)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_end_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_end_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_END_DETECTION_RPT, 8);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_end_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_end_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_END_DETECTION_RPT, 8);

      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_timeout_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_timeout_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_TIMEOUT_DETECTION_RPT, 13);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_timeout_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_timeout_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_TIMEOUT_DETECTION_RPT, 13);

      if (message->data_size != 11)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_confidence_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_confidence_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_CONFIDENCE_DETECTION_RPT, 13);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_confidence_detection_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_confidence_detection_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_CONFIDENCE_DETECTION_RPT, 13);

      if (message->data_size != 9)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_snr_settings_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_snr_settings_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_SNR_SETTINGS_RPT, 3);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_set_snr_settings_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_snr_settings_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_SNR_SETTINGS_RPT, 3);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_grammar_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_grammar_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_GRAMMAR_RPT, 3);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_set_grammar_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_grammar_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_GRAMMAR_RPT, 3);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_pause_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_pause_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_PAUSE_RPT, 10);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_set_pause_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_pause_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_PAUSE_RPT, 10);

      if (message->data_size != 8)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_lastvr_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_lastvr_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_LASTVR_RPT, 6);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_lastvr_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_lastvr_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_LASTVR_RPT, 6);

      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_lastnav_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_lastnav_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_LASTNAV_RPT, 6);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_lastnav_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_lastnav_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_LASTNAV_RPT, 6);

      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_bestrate_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_bestrate_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_BESTRATE_RPT, 4);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_bestrate_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_bestrate_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_BESTRATE_RPT, 4);

      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_jumpback_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_jumpback_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_JUMPBACK_RPT, 4);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_jumpback_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_jumpback_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_JUMPBACK_RPT, 3);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_flush_jumpback_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_flush_jumpback_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_FLUSH_JUMPBACK_RPT, 3);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_srdl_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_srdl_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_SRDL_RPT, 5);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_srdl_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_srdl_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_SRDL_RPT, 5);

      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_voice_score_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_score_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_SCORE_RPT, 8);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_score_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_score_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_SCORE_RPT, 8);

      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_persistence_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_persistence_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_GET_PERSISTENCE_RPT, 3);

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_voice_set_persistence_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] voice_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] voice_tx_data[1] = Session State (CLOSE, OPECAMERAN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_voice_set_persistence_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      voice_tx_bus_id = message->bus;
      PITS_Voice_Compose_Message_Header(MID_VOICE_SESSION_SET_PERSISTENCE_RPT, 3);

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Voice Request: Message Data Error");
         voice_message.data_size = 3;
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         voice_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&voice_message);                      
      }
   }
   return (pits_status);
}
/*===========================================================================*/
/*!
 * @file pits_RearCamera_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 5
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 *
 */
/*===========================================================================*/
