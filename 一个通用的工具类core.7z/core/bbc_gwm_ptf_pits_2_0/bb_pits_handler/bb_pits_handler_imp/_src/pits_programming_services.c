/*===========================================================================*/
/**
 * @file pits_programming_services.c
 *
 * PITS Programming Service Message Definitions
 *
 * %full_filespec:pits_programming_services.c~3:csrc:ctc_ec#22 %
 * @version %version:3 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Thu Jun 23 17:09:15 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the PITS Programming Service Message used in the program.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy
 *    - MSID: Message Set Identifier
 *    - MID: Message Identifier
 *    - PPS: PITS Programming Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "checksum.h"
#include "em.h"
#include "pits_programming_services.h"
#include "pits_programming_services_cfg.h"
#include "pits_mfg_parameters_ps.h"
#include "disc_pbk_diag_proxy.h"
#include "preset_mgr.h"
#include "preset_mgr_ps.h"
#include "preset_mgr_cbk.h"
#include "theft_lock.h"
#include "theft_lock_ps.h"
#include "theft_lock_cfg.h"
#include "tone_mgr_types.h"
#include "audio_tone_mgr_ps.h"
#include "audio_facade_ps.h"
#include "bt_connection_mgr_ps.h"
#include "betula_bluetooth_diag.h"
#include "bt_diag_event_decode.h"
#include "bt_cm_event_types.h"
#include "bt_connection_manager_decode.h"
#include "touch_screen_calib_ps.h"
#include "amfm_mngr_cbk.h"
#include "cals_ps.h"
#include "hmi_ps.h"
#include "icr_eng_cals_ps.h"
#include "disc_pbk_hdlr_ps.h"
#include "allgo_gateway.h"
#include "allgo_gateway_diag_proxy.h"
#include "persistent_storage.h"
#include "tone_mgr.h"
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "utilities.h"
#include "xsal_util.h"
#include "am_fm_tuner_driver.h"
#include "fbl_linker_cbk.h"
#include "ps_proxy.h"
#include "vip_desip.h"
#include "metadata_storage_mgr.h"
#include "fbl_linker.h"
#include "gm_dimming_vip_interface_ps.h"
#include "vip_pits.h"
#include "desip_msg_types.h"
#include "version_tracking.h"
#include "pits_programming_services_cbk.h"
#include "pits_processing_manager.h"
#include "source_manager_ps.h"
#include "pits_processing_misc.h"
#include "pits_audio_services.h"
#include "pits_parameter_list_cfg.h"
#include "mfg_parameters_ps.h"
#include "diag_ps.h"


EM_FILENUM(PITS_MODULE_ID_5, 1);   /**< define file for assert handling */

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
 #define PPS_MAX_READ_HEADER           6
 
#define AM_LOW_FREC                        (0x0212)
#define AM_SPACE_FREC_CONST                (0x0A)
#define FM_LOW_FREC                        (0x2242)
#define FM_SPACE_FREC_CONST                (0xC8)
#define PRESET_CERO_SELECTED               (0x00)
#define NO_PRESET_SELECTED                 (0xFF)
#define BASE_CONSTANT_TO_CHANNEL           (0x0A)
#define TABLEMD_COMPARE  (22)
#define BT_PITS_PROG_NAME_LENGTH ((size_t)33)
#define PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG   (16+1)
#define PITS_AUTENTIFICATION_NOT_STARTED  (0x00)
#define PITS_AUTENTIFICATION_IN_PROCESS  (0x01)
#define PITS_AUTENTIFICATION_FAILED  (0x02)
#define PITS_AUTENTIFICATION_PASS  (0x03)
#define PITS_INITIAL_CRC_VALUE (0xFFFFFFFF)
#define PITS_CHKSUM_COMPLETE (0x02)
#define PITS_CHKSUM_ERROR    (0x03)
#define PITS_PPS_PARAM_LENGTH_MAX           255    /*PPS Max Data Length*/
#define PITS_PPS_REQRDHEADER_LENGTH         6      /*Head(5) + Tail(1)*/
#define PITS_PPS_REPWRPARAM_LENGTH          6      /*Report Write Parameter Length*/
#define PITS_MDS_BLOCKS     (10)
#define PITS_MDS_CHKSUM_SIZE  (17)

#define PITS_RTD_GET_DATA_NUM_MAX   (20)

#define PITS_PROG_MAX_SESSION_TIMEOUT_MS  (1800000)
#define PITS_PROG_MIN_SESSION_TIMEOUT_MS  (1000)

   typedef struct md5_convert_tag
         {
            uint8_t        newascii;
            uint8_t        newhex;
         } md5_convert_type;

         static const md5_convert_type Md5_Compare_Table[] =
                     {
                      {0x30,    0x00 },
                      {0x31,    0x01 },
                      {0x32,    0x02 },
                      {0x33,    0x03 },
                      {0x34,    0x04 },
                      {0x35,    0x05 },
                      {0x36,    0x06 },
                      {0x37,    0x07 },
                      {0x38,    0x08 },
                      {0x39,    0x09 },
                      {0x41,    0x0A },
                      {0x42,    0x0B },
                      {0x43,    0x0C },
                      {0x44,    0x0D },
                      {0x45,    0x0E },
                      {0x46,    0x0F },
                      {0x61,    0x0A },
                      {0x62,    0x0B },
                      {0x63,    0x0C },
                      {0x64,    0x0D },
                      {0x65,    0x0E },
                      {0x66,    0x0F },

                     };

typedef struct ps_preset_diag_page_Tag
{
   Preset_Type_T presets [PRESET_MGR_NUM_PRESETS];
} ps_preset_diag_page_T;

/**
 * Default values for presets
 */
static const ps_preset_diag_page_T ps_presets_diag_defaults[PRESET_MGR_NUM_PAGES] =
{
   {{
     {{PRESET_MGR_DEV_FM,  8790,  0, "",    0, false}}, /* page 0, preset 0 */
     {{PRESET_MGR_DEV_FM,  9140,  0, "",    0, false}}, /* page 0, preset 1 */
     {{PRESET_MGR_DEV_FM, 9410,  0, "",    0, false}}, /* page 0, preset 2 */
     {{PRESET_MGR_DEV_FM, 9770,  0, "",    0, false}}, /* page 0, preset 3 */
     {{PRESET_MGR_DEV_FM, 10370,  0, "",    0, false}},  /* page 0, preset 4 */
     {{PRESET_MGR_DEV_FM, 10770,  0, "",    0, false}}  /* page 0, preset 5 */
   }},
   {{
     {{PRESET_MGR_DEV_FM,   8790,  0, "",   0, false}}, /* page 1, preset 0 */
     {{PRESET_MGR_DEV_FM,  9140,  0, "",   0, false}}, /* page 1, preset 1 */
     {{PRESET_MGR_DEV_FM,  9410,  0, "",   0, false}}, /* page 1, preset 2 */
     {{PRESET_MGR_DEV_FM, 9770,  0, "",   0, false}}, /* page 1, preset 3 */
     {{PRESET_MGR_DEV_FM, 10370,  0, "",   0, false}},  /* page 1, preset 4 */
     {{PRESET_MGR_DEV_FM, 10770,  0, "",    0, false}}  /* page 1, preset 5 */
   }},
      {{
     {{PRESET_MGR_DEV_FM, 8790, 0, "",     0, false}}, /* page 2, preset 0 */
     {{PRESET_MGR_DEV_FM, 9140, 0, "",     0, false}}, /* page 2, preset 1 */
     {{PRESET_MGR_DEV_FM, 9410, 0, "",     0, false}}, /* page 2, preset 2 */
     {{PRESET_MGR_DEV_FM, 9770, 0, "",     0, false}}, /* page 2, preset 3 */
     {{PRESET_MGR_DEV_FM, 10370, 0, "",     0, false}},  /* page 2, preset 4 */
     {{PRESET_MGR_DEV_FM, 10770,  0, "",    0, false}}  /* page 2, preset 5 */
   }},
   {{
     {{PRESET_MGR_DEV_AM,  630,  0, "",    0, false}}, /* page 3, preset 0 */
     {{PRESET_MGR_DEV_AM, 720,  0, "",    0, false}}, /* page 3, preset 1 */
     {{PRESET_MGR_DEV_AM, 990,  0, "",    0, false}}, /* page 3, preset 2 */
     {{PRESET_MGR_DEV_AM, 1350,  0,  "",    0, false}}, /* page 3, preset 3 */
     {{PRESET_MGR_DEV_AM, 1440,  0, "",    0, false}},  /* page 3, preset 4 */
     {{PRESET_MGR_DEV_AM, 1530,  0, "",    0, false}}  /* page 3, preset 5 */
   }},
   {{
     {{PRESET_MGR_DEV_AM,  630,  0,  "",    0, false}}, /* page 4, preset 0 */
     {{PRESET_MGR_DEV_AM, 720,  0,  "",    0, false}}, /* page 4, preset 1 */
     {{PRESET_MGR_DEV_AM, 990,  0,  "",    0, false}}, /* page 4, preset 2 */
     {{PRESET_MGR_DEV_AM, 1350,  0,  "",    0, false}}, /* page 4, preset 3 */
     {{PRESET_MGR_DEV_AM, 1440,  0,  "",    0, false}},  /* page 4, preset 4 */
     {{PRESET_MGR_DEV_AM, 1530,  0,  "",    0, false}}  /* page 4, preset 5 */
   }}
};

typedef enum MICDTCS_DEF_ENUM_Tag
{
   DTCMICPLUS_0N_MIN,
   DTCMICPLUS_05_MIN,
   DTCMICPLUS_0E_MIN,
   DTCMICPLUS_12_MIN,
   DTCMICPLUS_02_MIN,
   DTCMICPLUS_01_MIN,
   DTCMICPLUS_18_MIN,
   DTCMICPLUS_0N_MAX,
   DTCMICPLUS_05_MAX,
   DTCMICPLUS_0E_MAX,
   DTCMICPLUS_12_MAX,
   DTCMICPLUS_02_MAX,
   DTCMICPLUS_01_MAX,
   DTCMICPLUS_18_MAX,
   DTCMICMINUS_0N_MIN,
   DTCMICMINUS_05_MIN,
   DTCMICMINUS_0E_MIN,
   DTCMICMINUS_12_MIN,
   DTCMICMINUS_02_MIN,
   DTCMICMINUS_01_MIN,
   DTCMICMINUS_18_MIN,
   DTCMICMINUS_0N_MAX,
   DTCMICMINUS_05_MAX,
   DTCMICMINUS_0E_MAX,
   DTCMICMINUS_12_MAX,
   DTCMICMINUS_02_MAX,
   DTCMICMINUS_01_MAX,
   DTCMICMINUS_18_MAX,
   DTCMIC_NUM_FIXED

}MICDTCS_DEF_TYPE;

typedef enum Pits_Prog_List_Tag
{
   LIST0       = 0,
   LIST1,
   LIST2,
   LIST3,
   LIST4,
   LIST5,
   LIST6,
   LIST7,
   LIST8,
   LIST9,
   LISTA,
   LAST_LIST,
} Pits_Prog_List_T;

typedef uint8_t(*pits_param_read) (uint8_t * data, uint8_t length);
typedef uint8_t(*pits_param_write) (uint8_t * data, uint8_t length);

typedef struct PITS_Parameter_ID_Tag
{
   uint16_t          param_id;             
   uint8_t           size;
   PPS_Access_T      read_write;
   char              param_name[255];
   pits_param_read   funct_read;
   pits_param_write  funct_write;

} PITS_Parameter_ID_T;

typedef struct PITS_Parameter_Index_Tag
{
   uint8_t                        param_list;
   const PITS_Parameter_ID_T*     param_indx;
   uint16_t                       param_size;                
} PITS_Parameter_Index_T;

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Parameter lists and ids for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PARAM_IDS
#undef PARAM_LIST
#define PARAM_IDS(pmid, pmidnum, size, read_write, name)   {pmidnum, size, read_write, name, PITS_##pmid##_Read, PITS_##pmid##_Write},
#define PARAM_LIST(pmlist, plnum, name)  static const PITS_Parameter_ID_T pits_param_ids##plnum##_table[] = \
{\
  PPS_##pmlist##_IDS\
};
PPS_PARAMETER_LISTS

#undef PARAM_LIST
#define PARAM_LIST(pmlist, plnum, name)  {plnum, pits_param_ids##plnum##_table, (PPS_MAX_PARAM_##plnum##_IDS-1)},
static const PITS_Parameter_Index_T pits_param_index_table[] = 
{
   PPS_PARAMETER_LISTS
};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_pps_initialize(void);

static void pits_pps_reset_radio(void);

static void pits_pps_compose_message_header(uint8_t mid, uint8_t size);

static Success_Or_Fail_T pits_memory_map_check(PITS_Memory_Map_ID_T map_id, uint32_t start_address, size_t length);
void pits_pps_app_version_read_req (uint16_t msg_id, uint8_t length);
void pits_pps_supplier_version_read_req (uint16_t msg_id, uint8_t length);
void pits_pps_identify_num_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_part_num_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_version_num_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_identify_code_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_supp_manufac_date_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_serial_num_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_vehicle_num_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_gwm_hw_version_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_supp_hw_version_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_supp_sw_version_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_network_info_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_sys_config_read_req(uint16_t msg_id, uint8_t length);
void pits_pps_gwm_manufac_date_read_req(uint16_t msg_id, uint8_t length);
/*void pits_CD_IIC_read_req(uint16_t msg_id, uint8_t length);*/



void pits_pps_supplier_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_app_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_identify_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_part_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_version_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_vehicle_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_identify_code_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_supp_manufac_date_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_serial_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_vehicle_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_gwm_hw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_supp_hw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_supp_sw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_network_info_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_sys_config_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
void pits_pps_gwm_manufac_date_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);
/*void pits_CD_IIC_write_req(uint16_t msg_id, uint8_t data[], uint8_t length);*/
uint16_t Pits_Get_Param_Band_Value (uint8_t zone, uint8_t page, uint8_t preset);
void Pits_Send_Dtcmics_Vip (uint8_t i, uint8_t data_first, uint8_t data_second);
void Pits_Send_Whole_Dtcmics_Vip (void);
static uint32_t PITS_PPS_CRC_Calculate_Chksum (const uint8_t *data, uint8_t block_length, uint32_t crc_data);
static void PITS_PPS_CRC_Chksum_Xmem (const uint8_t *data, uint8_t block_length);
static void PITS_PPS_CRC_Chksum_Final (void);
static void PITS_PPS_CRC_Chksum_Group (void);
extern void Pits_Get_RTD_Version(void);
extern void Pits_Get_VIP_Version(void);

#if 0
static void PITS_PPS_CRC_Chksum_Ymem (const uint8_t *data, uint8_t block_length);
static void PITS_PPS_CRC_Chksum_Align_Cal (const uint8_t *data, uint8_t block_length);
static void PITS_PPS_CRC_Chksum_Product_id (const uint8_t *data, uint8_t block_length);
static void PITS_PPS_CRC_Chksum_Audio_Eq (void);
static void PITS_PPS_CRC_Chksum_Audio_Eq (void);
static void PITS_PPS_CRC_Chksum_USB (void);
static void PITS_PPS_CRC_Chksum_Theft (void);
static void PITS_PPS_CRC_Chksum_DG_Error (void);
static void PITS_PPS_CRC_Chksum_Mic_Diag (void);
#endif

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/


/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PPS_RX_INDEX

#define MID_PPS_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_pps_rx_messages[] = {
   MID_PPS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_PPS_TX_INDEX

#define MID_PPS_TX_INDEX(name, mid) (mid),

static const uint8_t pits_pps_tx_messages[] = {
   MID_PPS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PPS_RX_INDEX
#define MSID_PPS_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_pps_rx_message_sets[] = {
   MSID_PPS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_PPS_TX_INDEX
#define MSID_PPS_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_pps_tx_message_sets[] = {
   MSID_PPS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the start and end addresses of All Memory Map to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MEMORY_ALL_INDEX
#define MEMORY_ALL_INDEX(memid, start, end) {start, end},

static const PITS_Memory_Address_T pits_memory_address[] = {
   MEMORY_ALL_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the start and end addresses of RAM Memory Map to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MEMORY_RAM_INDEX
#define MEMORY_RAM_INDEX(ramid, start, end) {start, end},

static const PITS_Memory_Address_T pits_ram_address[] = {
   MEMORY_RAM_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the start and end addresses of Download Memory Map to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MEMORY_DWNLD_INDEX
#define MEMORY_DWNLD_INDEX(dwnldid, start, end) {start, end},

static const PITS_Memory_Address_T pits_download_address[] = {
   MEMORY_DWNLD_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the start and end addresses of Persistent Storage Memory Map to be supported
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MEMORY_PS_INDEX
#define MEMORY_PS_INDEX(psid, start, end) {start, end},

static const PITS_Memory_Address_T pits_ps_address[] = {
   MEMORY_PS_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the Memory segment table for the product
 *    @see the API configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MAPID_INDEX
#define MAPID_INDEX(mapid, size, address) {mapid, size, address},

static const PITS_Memory_Map_T pits_memory_map_sets[] = {
   MAPID_TABLE
};

static PPS_Segment_ID_T pps_session_segment;
static PPS_Access_T pps_session_access;

static uint8_t pps_tx_bus_id;   /* ID of the bearing bus on which to send response */
static PITS_Message_T pps_message;      /* for construction of a PPS message to be transmitted */
static uint8_t pps_tx_data[PITS_MAX_MESSAGE_SIZE];
static uint32_t pps_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T pps_session_state;

/**
 * Stores Timer ID for PITS Sessions
 */
static SAL_Timer_Id_T pits_pps_session_timer_id;
static uint8_t pits_partition_status[5] = {2,2,2,2,2};
static uint8_t pit_shuffle_rpt[10];
/*
static uint32_t pit_preset_channel;
static uint8_t pit_preset_band;
static bool_t  pit_preset_first = false;
static bool_t  pit_preset_second = false;
*/
static uint8_t pits_autentification_status = PITS_AUTENTIFICATION_NOT_STARTED;
static bool_t pits_autentification_result = false;
static BT_CM_EVG_PAIRED_DEVICE_INFO_T paired_dev_list_data[BT_CM_MAX_PAIRED_DEVICES]={};
static uint16_t no_of_devices = 0;
static uint8_t  get_index_bt = 0;
static uint8_t buffer_ps[4];
static bool_t  write_enable = false;
static uint8_t pits_network_state = 0;
static uint32_t pit_crc_align_cal_chksum = 0;
static uint32_t pit_crc_ymem_chksum = 0;
static uint32_t pit_crc_product_id_chksum = 0;
static uint32_t pit_crc_mic_diag_chksum = 0;
static uint32_t pit_crc_error_chksum = 0;
static uint32_t pit_crc_usb_info_chksum = 0;
static uint32_t pit_crc_audio_eq_chksum = 0;
static uint32_t pit_crc_presets_chksum = 0;
static uint32_t pit_crc_group_chksum = 0;
static uint32_t pit_crc_theft_chksum = 0;
static uint32_t pit_crc_final_chksum = 0;
static uint8_t pits_vip_brightness = 0;
static uint8_t pits_data_received_from_vip[50] = {0};
static uint8_t pits_md_calculating = 0;
static uint8_t pits_md_stored_value [PITS_MDS_BLOCKS][PITS_MDS_CHKSUM_SIZE];
static bool_t mds_test_execute = false;

static uint32_t pps_session_timeout_stored = PITS_DEFAULT_SESSION_TIMEOUT_MS;
static bool_t pits_pps_is_timer_active = false;

/*add by fuxiang 20130424*/
void JD2MD( uint16_t JulDate, uint8_t Year, uint8_t *Month, uint8_t *Day)
{
 uint16_t i=0,day=0;
 int16_t temp=-1;
 uint8_t  TempDate[] ={31,28,31,30,31,30,31,30,31,30,31,30};
 
	if((Year+2000)%4==0)
		TempDate[1]=29;
	else
		TempDate[1]=28;
	
	temp = JulDate;
	
	for (i = 0; (i < 12) & (temp > 0); i++)
	{

	       temp = temp - TempDate[i];
	       day = temp + TempDate[i];

	}
	
*Month = i;

*Day = day;
}


void MD2JD(uint8_t Year, uint8_t Month, uint8_t Day,  uint16_t *JulDate)
{
 uint16_t temp=0,i=0;
 uint8_t  TempDate[] ={0,31,28,31,30,31,30,31,30,31,30,31,30};
 
	if((Year+2000)%4==0)
		TempDate[1]=29;
	else
		TempDate[1]=28;
	
	temp = 0;

	for (i = 0; i < Month - 1; i++)
        {
           if (i < 13)
          {
            temp+= TempDate[i]; 
          } 
        }
	temp+= Day;
	
*JulDate = temp;
}

uint8_t DEC2BCD(uint8_t dec)
{
   return((dec / 10 << 4) | (dec % 10));
}

uint8_t BCD2DEC(uint8_t bcd)
{
   return((bcd >> 4) * 10 + (bcd & 0x0f));
}

/*add by fuxiang 20130424*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_PPS_Interface = {
   pits_pps_initialize,
   pits_pps_rx_message_sets,
   Num_Elems(pits_pps_rx_message_sets),
   pits_pps_tx_message_sets,
   Num_Elems(pits_pps_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: pits_pps_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_pps_initialize(void)
{
   pps_tx_bus_id = 0;
   memset(&pps_message, 0x00, sizeof(PITS_Message_T));
   memset(pps_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   pps_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   pps_session_segment = PPS_SEGMENT_ID_NUM;
   pps_session_state = SESSION_CLOSE;
   pps_session_access = PPS_ACCESS_NUM;
   /* @todo Broadcast XSAL message that PPS Session is closed */
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_get_state_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = Confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = State (CLOSE, PREOPEN, OPEN)
 * @param [out] pps_tx_data[1] = Segment ID
 * @param [out] pps_tx_data[2] = Access Mode (READ, WRITE, MODIFY)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 * Open request must be preceeded by a preopen request
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_get_state_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_STATE_RPT, 4);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t)SUCCESS;
         pps_tx_data[1] = (uint8_t)pps_session_state;
         pps_tx_data[2] = (uint8_t)pps_session_segment;
         pps_tx_data[3] = (uint8_t)pps_session_access;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_preopen_req
 *===========================================================================*
 * @brief Receive a Request to pre-open a Session.
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Segment ID
 * @param [in] (message->data)[1] = Access Mode (READ, WRITE, MODIFY)
 * @param [out] pps_tx_data[0] = Segment ID
 * @param [out] pps_tx_data[1] = Access Mode (READ, WRITE, MODIFY)
 * @param [out] pps_tx_data[2] = Confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 * Preopen request is required in advance of Open Request in order to handle
 * cases where the device needs to jump from one piece of software supporting PITS
 * (e.g. host application code) to another (e.g. bootloader) prior to opening the
 * programming session.
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_preopen_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_PREOPEN_RPT, 4);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      pps_tx_data[2] = (message->data)[0];
      pps_tx_data[3] = (message->data)[1];
      
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION PREOPEN REQUEST: Message Data Error");
      }
      else
      {
         if (pps_session_state == SESSION_PREOPEN)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION PREOPEN REQUEST: Session Is Already Pre-opened");
         }
         else if (pps_session_state != SESSION_CLOSE)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION PREOPEN REQUEST: Session Is Not Closed");
         }
         else if (pps_tx_data[2] >= PPS_SEGMENT_ID_NUM)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION PREOPEN REQUEST: Invalid Segment ID");
         }
            else if (pps_tx_data[3] >= PPS_ACCESS_NUM)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION PREOPEN REQUEST: Invalid Access Type");
         }
         else
         {
            pps_session_segment = (PPS_Segment_ID_T)((message->data)[0]);
            pps_session_access = (PPS_Access_T)((message->data)[1]);
            PITS_Set_PPS_Session(SESSION_PREOPEN);

            pps_tx_data[0] = (uint8_t) SUCCESS;
            pps_tx_data[1] = pps_session_state;
            pps_tx_data[2] = pps_session_segment;
            pps_tx_data[3] = pps_session_access;

            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
         }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_open_req
 *===========================================================================*
 * @brief Receive a Request to open a Session.
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Segment ID
 * @param [in] (message->data)[1] = Access Mode (READ, WRITE, MODIFY)
 * @param [out] pps_tx_data[0] = Segment ID
 * @param [out] pps_tx_data[1] = Access Mode (READ, WRITE, MODIFY)
 * @param [out] pps_tx_data[2] = Confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 * Open Request must be preceeded by a Pre-open Request.
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_open_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_OPEN_RPT, 4);
	  
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      pps_tx_data[2] = (message->data)[0];
      pps_tx_data[3] = (message->data)[1];
	  
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Message Data Error");
      }
      else
      {
         if (pps_tx_data[2] != pps_session_segment)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Segment Error");
         }
         else if (pps_tx_data[3] != pps_session_access)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Access Error");
         }
         else if (pps_session_state == SESSION_OPEN)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Is Already Opened");
         }
         else if (pps_session_state != SESSION_PREOPEN)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Is Not Pre-Opened");
         }
         else
         {
            pps_tx_data[0] = (uint8_t) SUCCESS;
            PITS_Set_PPS_Session(SESSION_OPEN);
            pps_tx_data[1] = pps_session_state;
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
         }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_close_req
 *===========================================================================*
 * @brief Receive a Request to close a Session.
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Segment ID
 * @param [out] pps_tx_data[0] = Segment ID
 * @param [out] pps_tx_data[1] = Confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_close_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_CLOSE_RPT, 4);
	  
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t)FAIL;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION CLOSE REQUEST: Message Data Error");
      }
      else
      {
         if ((message->data)[0] != pps_session_segment)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION CLOSE REQUEST: Session Segment Error");
         }
         else if (pps_session_state == SESSION_CLOSE)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION CLOSE REQUEST: Session Is Already Closed");
         }
         else
         {
            pps_tx_data[0] = (uint8_t) SUCCESS;
            PITS_Set_PPS_Session(SESSION_CLOSE);
            pps_tx_data[1] = pps_session_state;
            pps_tx_data[2] = pps_session_segment;
            pps_tx_data[3] = pps_session_access;
            PITS_Set_Partition_Status(PITS_ALL_SEGMENTS, PITS_RO_STATUS);
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
         }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_Data_Checksum_Req
 *===========================================================================*
 * @brief Request the checksum of the memory area as defined in the request
 * message.  Note that the checksum is only calculated if the appropriate 
 * segemnt is opened.
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_data_checksum_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

#if defined(GWM_CHK041_8AT)
   uint32_t chksum = 0;
#endif

   if (NULL != message)
   {
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_DATAX_CHECKSUM_RPT, 8);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PSS SESSION SET TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
            memcpy(&pps_tx_data[1], &(message->data[0]), 3);

            switch(message->data[2])
            {
               case PITS_16_CRC:
                  pps_tx_data[0] = Pits_Calculate_Ckhsum(message->data[0], message->data[1], &pps_tx_data[6]);
                  pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
                  break;
               case PITS_32_CRC:
#if defined(GWM_CHK041_8AT)
                  pps_tx_data[0] = SUCCESS;
                  chksum = Pits_Get_Faceplate_Ckhsum();
                  Util_Put_Big_Endian_U32(&pps_tx_data[4], chksum);
                  pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
#endif
                  break;
               case PITS_16_CRC_2COMP:
                  break;
               default:
                  pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS DATA CHESKCUM REQ: Algorithm not Supported");
                  break;
            }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_refresh_req
 *===========================================================================*
 * @brief Receive a Request to Refresh PBS Session Timer
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = Confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_refresh_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_REFRESH_RPT, 1);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
	  
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION REFRESH REQUEST: Message Data Error");
      }
      else if (pps_session_state == SESSION_CLOSE)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION REFRESH REQUEST: Session is Not Opened");
      }
      else
      {
         if (pps_session_state == SESSION_OPEN)
         {
            pps_tx_data[0] = (uint8_t) SUCCESS;
            SAL_Start_Timer(pits_pps_session_timer_id, pps_session_timeout_sec, false);
            pits_pps_is_timer_active = true;
            SAL_Publish(PITS_EVG_PPS_SESSION, &pps_session_state, sizeof(pps_session_state));
         }   
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_get_timeout_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_get_timeout_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_TIMEOUT_RPT, 3);
	  
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&pps_tx_data[1], (uint16_t) (pps_session_timeout_stored/1000));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_set_timeout_req
 *===========================================================================*
 * @brief Receive a Request to Set the Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_session_set_timeout_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_SESSION_TIMESET_RPT, 3);
	  
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PSS SESSION SET TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         pps_session_timeout_sec = 1000 * Util_Get_Big_Endian_U16(&(message->data)[0]);
         pps_session_timeout_stored = pps_session_timeout_sec;
         if (pps_session_timeout_sec == 0)
         {
            pps_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
         }
         else if (pps_session_timeout_sec > PITS_PROG_MAX_SESSION_TIMEOUT_MS)
         {
            pps_session_timeout_sec = PITS_PROG_MAX_SESSION_TIMEOUT_MS;
         }
         else if (pps_session_timeout_sec < PITS_PROG_MIN_SESSION_TIMEOUT_MS)
         {
            pps_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
         }
         SAL_Start_Timer(pits_pps_session_timer_id, pps_session_timeout_sec, false);
         pits_pps_is_timer_active = true;
         pps_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&pps_tx_data[1], (uint16_t) (pps_session_timeout_stored/1000));

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
      }
   }
   return (pits_status);
}



/*===========================================================================*
 * FUNCTION: pits_pps_CarDSP_write_req
 *===========================================================================*
 * @brief Receive a Request for Data Write
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0 - 3] = write address
 * @param [in] (message->data)[4 - 5] = num_coeff or reg. length
 * @param [in] (message->data)[6]     = register type
 * @param [in] (message->data)[7 - n] = data bytes
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 4] = write address
 * @param [out] pps_tx_data[5 - 6] = write length
 * @param [out] pps_tx_data[7]     = register type
 *
 * @pre message->data_size > 6
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_CarDSP_write_req(const PITS_Message_T * message)
{
   /*uint32_t address = 0;*/
/* todo fix when audio is implemented
   DSP_X_Coeff_T  xcoefficients[10];
   DSP_Y_Coeff_T  ycoefficients[10];*/
   /*size_t num_coeff;
   size_t length_bytes;
   uint32_t value;
   uint8_t  index;*/
   CarDSP_Type_T target;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_CARDSP_WRITE_RPT;

      if (message->data_size <= 6)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA WRITE REQUEST: Message Data Error");
      }
      else
      {

         if (pps_session_state != SESSION_OPEN)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA WRITE REQUEST: Session Is Not Opened");
         }
         else if (pps_session_access == ACCESS_READ)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA WRITE REQUEST: Session Opened for Read Only");
         }
         else
         {
            pps_tx_data[0] = (uint8_t) FAIL;
            memset(&pps_tx_data[1], 0, 8);
            pps_message.data_size = 8;
            target = (CarDSP_Type_T)message->data[6];
            SAL_Start_Timer(pits_pps_session_timer_id, pps_session_timeout_sec, false);
            switch (target)
            {
               case X_COEFFICIENTS:
                  /* Compose Message Data */
                  pps_tx_data[0] = (uint8_t) SUCCESS;
                  pps_tx_data[7] = X_COEFFICIENTS;
                  /* todo fix when audio is implemented
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);
                  num_coeff = (size_t)Util_Get_Big_Endian_U16(&(message->data)[4]);
                  index = 0;

                  do
                  {
                    xcoefficients[index] = Util_Get_Big_Endian_U24(&message->data[7+index*3]);
                  }
                  while( ++index < num_coeff );
                  
                  if (DSP_Write_X_Coefficients(address, xcoefficients, num_coeff))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = X_COEFFICIENTS;
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(num_coeff&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP WRITE REQUEST: X Coefficients write failed");
                  }*/
                  break;

               case Y_COEFFICIENTS:
                  /* Compose Message Data */
                  pps_tx_data[0] = (uint8_t) SUCCESS;
                  pps_tx_data[7] = Y_COEFFICIENTS;
                  /* todo implement when audio is fixed
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);
                  num_coeff = (size_t)Util_Get_Big_Endian_U16(&(message->data)[4]);
                  index = 0;

                  do
                  {
                    ycoefficients[index] = Util_Get_Big_Endian_U16(&message->data[7+index*2]);
                  }
                  while( ++index < num_coeff );
                  
                  if (DSP_Write_Y_Coefficients(address, ycoefficients, num_coeff))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = Y_COEFFICIENTS;
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(num_coeff&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP WRITE REQUEST: Y Coefficients write failed");
                  }*/
                  
                  break;

               case CONTROL_REGISTERS:
                  /* Compose Message Data */
 /*
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);
                  length_bytes = (size_t)Util_Get_Big_Endian_U16(&(message->data)[4]);

                  if (0x01 == length_bytes)
                  {
                     value = (uint32_t)message->data[7];
                  } 
                  else if (0x02 == length_bytes)
                  {
                     value = (uint32_t)Util_Get_Big_Endian_U16(&message->data[7]);
                  } 
                  else if (0x03 == length_bytes)
                  {
                     value = Util_Get_Big_Endian_U24(&message->data[7]);
                  } 
                  else if (0x04 == length_bytes)
                  {
                     value = Util_Get_Big_Endian_U32(&message->data[7]);
                  }
                  else
                  {
                     value = Util_Get_Big_Endian_U32(&message->data[7]);
                  }*/
                  pps_tx_data[0] = (uint8_t) SUCCESS;
                  pps_tx_data[7] = CONTROL_REGISTERS;
                  /* todo fix when audio is completed
                  if (DSP_Write_To_Ctrl_Register(address, value, length_bytes))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = CONTROL_REGISTERS;
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(length_bytes&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP WRITE REQUEST: Register write failed.");
                  }*/
                  break;

               default:
                  pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA WRITE REQUEST: Invalid Memory Segment");
                  break;
            }
         }
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_pps_session_get_timeout_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_partition_req(const PITS_Message_T * message)
{
   int8_t ret;
   int fid;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_PPS_PARTITION_RPT;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 3;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARTITION REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pps_tx_data[1] = message->data[0];

         if (message->data[0] == 0x01)
         {
            if (message->data[1] == 0x00)
            {
               fid = open("/factory_data/partition_test", O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

               if (fid >= 0)
               {
                  close(fid);
                  pps_tx_data[2] = 0x01;
               }
               else
               {
                  pps_tx_data[2] = 0x02;
               }
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[1] = 0x01;
                  ret = system("mount -o remount,rw /factory_data");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[1];
               }
               else if (message->data[1] == 0x02)
               {
                  pits_partition_status[1] = 0x02;
                  ret = system("mount -o remount,ro /factory_data");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[1];
               }
               else
               {
                  /* Do nothing */
               }
            }
         }

         if (message->data[0] == 0x02)
         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[2];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[2] = 0x01;
                  ret = system("mount -o remount,rw /usr");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[2];
               }
               else if (message->data[1] == 0x02)
               {
                  pits_partition_status[2] = 0x02;
                  ret = system("mount -o remount,ro /usr");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[2];
               }
               else
               {
                  /* Do nothing */
               }
            }
         }

         if (message->data[0] == 0x03)
         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[3];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[3] = 0x01;
                  ret = system("mount -o remount,rw /usr/local/share");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[3];
               }
               else if (message->data[1] == 0x02)
               {
                  pits_partition_status[3] = 0x02;
                  ret = system("mount -o remount,ro /usr/local/share");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[3];
               }
               else
               {
                  /* Do nothing */
               }
            }
         }

         if (message->data[0] == 0x04)
         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[4];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[4] = 0x01;
                  ret = system("mount -o remount,rw /var");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[4];
               }
               else if (message->data[1] == 0x02)
               {
                  pits_partition_status[4] = 0x02;
                  ret = system("mount -o remount,ro /var");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[4];
               }
               else
               {
                  /* Do nothing */
               }
            }
         }

         if (message->data[0] == 0xFF)
         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            }
            else if (message->data[1] == 0x01)
            {
               pps_tx_data[2] = 0x01;
               pits_partition_status[1] = 0x01;
               ret = system("mount -o remount,rw /factory_data");
               PBC_Ensure((ret != -1),"Failed system call");
            }
            else if (message->data[1] == 0x02)
            {
               pps_tx_data[2] =0x02;
               pits_partition_status[1] = 0x02;
               ret = system("mount -o remount,ro /factory_data");
               PBC_Ensure((ret != -1),"Failed system call");
               pits_partition_status[2] = 0x02;
               pits_partition_status[3] = 0x02;
               pits_partition_status[4] = 0x02;
            }
            else
            {
               /* Do nothing */
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_get_timeout_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_partition_diag_req(const PITS_Message_T * message)
{
   int8_t ret;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_PPS_PARTITION_RPT;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 3;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARTITION REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pps_tx_data[1] = message->data[0];

         if (message->data[0] == 0x01)
         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[1];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[1] = 0x01;
                  ret = system("mount -o remount,rw /factory_data");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[1];
               }
               if (message->data[1] == 0x02)
               {
                  pits_partition_status[1] = 0x02;
                  ret = system("mount -o remount,ro /factory_data");
                  PBC_Ensure((ret != -1),"Failed system call");
                  pps_tx_data[2] =pits_partition_status[1];
               }
            }
         }


         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[2];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[2] = 0x01;

                  pps_tx_data[2] =pits_partition_status[2];
               }
               if (message->data[1] == 0x02)
               {
                  pits_partition_status[2] = 0x02;

                  pps_tx_data[2] =pits_partition_status[2];
               }
            }
         }


         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[3];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[3] = 0x01;

                  pps_tx_data[2] =pits_partition_status[3];
               }
               if (message->data[1] == 0x02)
               {
                  pits_partition_status[3] = 0x02;

                  pps_tx_data[2] =pits_partition_status[3];
               }
            }
         }


         {
            if (message->data[1] == 0x00)
            {
               pps_tx_data[2] =pits_partition_status[4];
            }
            else
            {
               if (message->data[1] == 0x01)
               {
                  pits_partition_status[4] = 0x01;

                  pps_tx_data[2] =pits_partition_status[4];
               }
               if (message->data[1] == 0x02)
               {
                  pits_partition_status[4] = 0x02;

                  pps_tx_data[2] =pits_partition_status[4];
               }
            }
         }
         pits_status = DONE; 

      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_pps_md5_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_md5_req(const PITS_Message_T * message)
{
   uint8_t md_length = 7;
   uint8_t pit_partition = 0;
   uint8_t third_letter = 0;
   uint8_t pitsend_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_PPS_MD5_RPT;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 32);
      pps_message.data_size = 32;
      if (message->data_size !=(6 + message->data[0]))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARTITION REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         third_letter = message->data[3];
         memcpy(&pps_tx_data[1],&message->data[0],(6 + message->data[0]));
         md_length = message->data[0];
         if (pps_tx_data[md_length+6]== 0)
         {
            pps_message.data_size = 24 + md_length;
            pps_tx_data[md_length+7] = 16;
            memset (&pps_tx_data[md_length+8],0,16);
            pit_partition = (message->data[md_length]) & 0x0F;

            if ((pits_md_stored_value[pit_partition][0] == PITS_CHKSUM_COMPLETE) && (third_letter == 0x64))
            {
               for (pitsend_index = 0; pitsend_index < 16; pitsend_index++)
               {
                  pps_tx_data[pitsend_index+md_length+8] = pits_md_stored_value[pit_partition][pitsend_index+1];
               }
            }
         }
         else
         {
            pps_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            pps_message.data_size = 1;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_md5_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_autentification_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x1F;
      pps_message.MID = 0xD1;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 2;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS Autentification REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == 0)
         {
            if (pits_autentification_status == PITS_AUTENTIFICATION_IN_PROCESS)
            {
               if (pits_autentification_result)
               {
                  pits_autentification_status = PITS_AUTENTIFICATION_PASS;
               }
               else
               {
                  pits_autentification_status = PITS_AUTENTIFICATION_FAILED;
               }
            }
            pps_tx_data[1] = pits_autentification_status;
         }
         else if (message->data[0] == 1)
         {
            pits_autentification_result = DAG_Apple_ACP_Self_Test();
            pits_autentification_status = PITS_AUTENTIFICATION_IN_PROCESS;
            pps_tx_data[1] = pits_autentification_status;
         }
         else if (message->data[0] == 2)
         {
            pits_autentification_status = PITS_AUTENTIFICATION_NOT_STARTED;
            pps_tx_data[1] = PITS_AUTENTIFICATION_FAILED;
         }
         else
         {
            pps_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_CarDSP_read_req
 *===========================================================================*
 * @brief Receive a Request for data Read
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] (message->data)[0 - 3] = read address
 * @param [in] (message->data)[4 - 5] = data byte length
 * @param [in] (message->data)[6]     = register type
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 4] = read address
 * @param [out] pps_tx_data[5 - 6] = data byte length
 * @param [out] pps_tx_data[7]     = register type
 * @param [out] pps_tx_data[8 - n] = data bytes
 *
 * @pre message->data_size = 6
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_CarDSP_read_req(const PITS_Message_T * message)
{
   /*uint32_t address = 0;*/
/* todo fix when audio is implemented
   DSP_X_Coeff_T  xcoefficients[10];
   DSP_Y_Coeff_T  ycoefficients[10];*/
   size_t num_coeff;
   /*uint32_t value;
   uint8_t  index;*/
   CarDSP_Type_T target;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_CARDSP_READ_RPT;

      if (message->data_size != 7)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP READ REQUEST: Message Data Error");
      }
      else
      {
         if (pps_session_state != SESSION_OPEN)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA READ REQUEST: Session Is Not Opened");
         }
         else
         {
            pps_tx_data[0] = (uint8_t) FAIL;
            num_coeff = (size_t)Util_Get_Big_Endian_U16(&(message->data)[4]);
            memset(&pps_tx_data[1], 0, 8+4*num_coeff);
            target = (CarDSP_Type_T)message->data[6];
            SAL_Start_Timer(pits_pps_session_timer_id, pps_session_timeout_sec, false);
            switch (target)
            {
               case X_COEFFICIENTS:
                  /* Compose Message Data */
                  pps_tx_data[0] = (uint8_t) SUCCESS;
                  pps_tx_data[7] = X_COEFFICIENTS;
                  /* todo fix when audio is implemented
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);

                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                  if (DSP_Read_X_Coefficients(address, xcoefficients, num_coeff))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = X_COEFFICIENTS;
                     index = 0;
                     do
                     {
                        Util_Put_Big_Endian_U24(&pps_tx_data[8+3*index], xcoefficients[index]);
                     }
                     while( ++index < num_coeff);
                     pps_message.data_size = (uint16_t)(8 + 3*num_coeff);
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(num_coeff&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP Read REQUEST: X Coefficients read failed");
                  }*/
                  break;

               case Y_COEFFICIENTS:
                  /* Compose Message Data */
                   pps_tx_data[0] = (uint8_t) SUCCESS;
                   pps_tx_data[7] = Y_COEFFICIENTS;
                   /* todo fix when audio is implemented
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);

                  if (DSP_Read_Y_Coefficients(address, ycoefficients, num_coeff))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = Y_COEFFICIENTS;
                     index = 0;
                     do
                     {
                        Util_Put_Big_Endian_U16(&pps_tx_data[8+2*index], ycoefficients[index]);
                     }
                     while( ++index < num_coeff);
                     pps_message.data_size = (uint16_t)(8 + 2*num_coeff);
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(num_coeff&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP Read REQUEST: Y Coefficients read failed");
                  }*/
                  break;

               case CONTROL_REGISTERS:
                  /* Compose Message Data */
                   pps_tx_data[0] = (uint8_t) SUCCESS;
                   pps_tx_data[7] = CONTROL_REGISTERS;
                   /*todo fix when audio is implemented
                  address = Util_Get_Big_Endian_U32(&(message->data)[0]);

                  if (DSP_Read_From_Control_Register(address, &value, num_coeff))
                  {
                     pps_tx_data[0] = (uint8_t) SUCCESS;
                     pps_tx_data[7] = CONTROL_REGISTERS;
                     if (num_coeff == 1)
                     {
                        pps_tx_data[8] = value;
                     } else if (num_coeff ==2)
                     {
                        Util_Put_Big_Endian_U16(&pps_tx_data[8], (uint16_t)value);
                     } else if (num_coeff ==3)
                     {
                        Util_Put_Big_Endian_U24(&pps_tx_data[8], value);
                     } else if (num_coeff ==4)
                     {
                        Util_Put_Big_Endian_U32(&pps_tx_data[8], value);
                     }
                     pps_message.data_size = (uint16_t)(8 + num_coeff);
                     Util_Put_Big_Endian_U32(&pps_tx_data[1], address);
                     Util_Put_Big_Endian_U16(&pps_tx_data[5], (uint16_t)(num_coeff&0xFFFF));
                     pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
                  }
                  else
                  {
                     pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS CarDSP Read REQUEST: Y Coefficients read failed");
                  }*/
                  break;

               default:
                  pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS DATA READ REQUEST: Invalid Memory Segment");
                  break;
            }
         }
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_pps_ECU_read_req(const PITS_Message_T * message)
{
   uint8_t length = 0;
   uint8_t pits_param_size = 0;
   uint16_t msg_add = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      length = message->data[2];
      pits_param_size = 3 + message->data[2];
      msg_add = (((message->data[0])<< 8) & 0xFF00) | message->data[1];

      pps_message.bus = message->bus;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_PARAM_READ;
      memset(&pps_tx_data[0], 0, pits_param_size);
      pps_message.data_size = length + 6;
 
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARAM READ REQUEST: Message Data Error");    
      }
      else
      {
         switch (msg_add)
         {
            case 0xF181:
            {
               pits_pps_app_version_read_req( msg_add, length);
               break;
            }
            case 0xF184:
            {
               /* pits_pps_supplier_version_read_req(msg_add, length);*/
               pits_pps_supp_sw_version_read_req(msg_add, length);
               break;
            }
            case 0xF186:
            {
               pits_pps_identify_num_read_req(msg_add, length);
               break;
            }
            case 0xF187:
            {
               pits_pps_part_num_read_req( msg_add, length);
               break;
            }  
            case 0xF189:
            {
               pits_pps_version_num_read_req( msg_add, length);
               break;
            }  
            case 0xF18A:
            {
               pits_pps_identify_code_read_req( msg_add, length);
               break;
            }
            case 0xF18B:
            {
               pits_pps_supp_manufac_date_read_req( msg_add, length);
               break;
             }  
            case 0xF18C:
            {
               pits_pps_serial_num_read_req( msg_add, length);
               break;
            }
            case 0xF190:
            {
               pits_pps_vehicle_num_read_req( msg_add, length);
               break;
            }   
            case 0xF191:
            {
               pits_pps_gwm_hw_version_read_req( msg_add, length);
               break;
            }  
            case 0xF192:
            {
               pits_pps_gwm_hw_version_read_req( msg_add, length);
               break;
            }  
            case 0xF195:
           {
               pits_pps_supp_sw_version_read_req( msg_add, length);
               break;
            }  
            case 0xF1A0:
           {
               pits_pps_network_info_read_req( msg_add, length);
               break;
            } 
            case 0xF1A1:
           {
               pits_pps_sys_config_read_req( msg_add, length);
               break;
           } 
            case 0xF1A2:
           {
              pits_pps_gwm_manufac_date_read_req( msg_add, length);
               break;
           }  
             default:
            {
               break;
            }        
           }

         pits_status = DONE; 
         }
      }

   return (pits_status);
}
Done_Or_Not_Done_T pits_pps_ECU_write_req(const PITS_Message_T * message)
{
   uint8_t pits_param_size = 0;
   uint16_t msg_add = 0;
   uint8_t length = 0;
   uint8_t pit_buff[120] = {0};
   uint8_t param_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      pits_param_size = 3 + message->data[2];
      msg_add = (((message->data[0])<< 8) & 0xFF00) | message->data[1];
      length = message->data[2];

      Tr_Info_Hi_3("W!W!msg data size =%d,list msg_add=%x,length=%d",message->data_size,msg_add, length );  
      pps_message.bus = message->bus;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_PARAM_WRITE;
      memset(&pps_tx_data[0], 0, pits_param_size);
      pps_message.data_size = pits_param_size;
     
      if (message->data_size != pits_param_size)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS PARAM READ REQUEST: Message Data Error");
      }
      else
      {
         for (param_index = 0; param_index < length; param_index++)
         {
            pit_buff[param_index] = message->data[3 + param_index];
         }

         switch (msg_add)
         {
            case 0xF181:
            {
               pits_pps_app_version_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF184:
            {
               pits_pps_supplier_version_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF186:
            {
               pits_pps_identify_num_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF187:
            {
               pits_pps_part_num_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF189:
            {
               pits_pps_version_num_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF18A:
            {
               pits_pps_identify_code_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF18B:
            {
               pits_pps_supp_manufac_date_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF18C:
            {
               pits_pps_serial_num_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF190:
            {
               pits_pps_vehicle_num_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF191:
            {
               pits_pps_gwm_hw_version_write_req( msg_add, &pit_buff[0], length);
               break;
             }
            case 0xF192:
            {
               pits_pps_gwm_hw_version_write_req( msg_add, &pit_buff[0], length);		 	
               /*pits_pps_supp_hw_version_write_req( msg_add, &pit_buff[0], length);*/
               break;
            }
            case 0xF195:
            {
               pits_pps_supp_sw_version_write_req( msg_add, &pit_buff[0], length);
               break;
             }
            case 0xF1A0:
            {
               pits_pps_network_info_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF1A1:
            {
               pits_pps_sys_config_write_req( msg_add, &pit_buff[0], length);
               break;
            }
            case 0xF1A2:
            {
               pits_pps_gwm_manufac_date_write_req( msg_add, &pit_buff[0], length);
               break;
            } 
            default:
            {
               break;
            } 
         }
            
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_Param_Read_Req
 *===========================================================================*
 * @brief Receive a Request for data Read
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_PPS_Param_Read_Req(const PITS_Message_T * message)
{
   uint16_t  param_id = 0;
   uint8_t   indx_param = 0;
   uint16_t  indx_id = 0;
   uint8_t   lenght = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   
   
   if (NULL != message)
   {
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_PARAM_READ, 7);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      if (!pits_pps_is_timer_active)
      {
         PITS_Clear_PPS_Timer_Session();
      }
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS PARAM READ REQUEST: Message Data Error");
         Tr_Warn_1("PPS PARAM READ REQUEST: Message Data Error,Error data length: %d",message->data_size);
      }   
      else if (pps_session_state != SESSION_OPEN)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Is Not Opened");
         Tr_Warn_1("PPS PARAM READ REQUEST:Session Is Not Opened,current session state is: %d",pps_session_state);
      }
      else if (pps_session_segment != PITS_MPI)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS SEGMENT REQUEST: Session Segment Error");
         Tr_Warn_1("PPS PARAM READ REQUEST:Session Segment Error,current session segment is: %d",pps_session_segment);
      }
      else  
      {
         pps_tx_data[1] = message->data[0];          
         param_id = Util_Get_Big_Endian_U16(&message->data[1]);
         Util_Put_Big_Endian_U16(&pps_tx_data[2], param_id); 
         /* Save deafult values */
         pps_tx_data[4] = 1;    /*length*/      
         pps_tx_data[5] = 0;    /* byte 1 */      

         if ((0 != param_id) && (0 != message->data[0]))
         {
            pps_tx_data[0] = (uint8_t) SUCCESS; 
            pps_tx_data[6] = PARAM_NO_LIST_EXIST;          
            for (indx_param = 0; indx_param < PPS_MAX_PARAMETER_LIST-1; indx_param++)
            {
               if (pits_param_index_table[indx_param].param_list == message->data[0])
               {
                  pps_tx_data[6] = PARAM_NO_ID_EXIST;                            
                  for (indx_id = 0; indx_id < pits_param_index_table[indx_param].param_size; indx_id++)
                  {
                     if (pits_param_index_table[indx_param].param_indx[indx_id].param_id == param_id)
                     {
                        pps_tx_data[6] = 0;          
                        lenght = pits_param_index_table[indx_param].param_indx[indx_id].size;
                        pps_tx_data[4] = lenght;                        
                        pps_tx_data[5 + lenght] = (uint8_t) pits_param_index_table[indx_param].param_indx[indx_id].funct_read(&pps_tx_data[5], lenght);
                        pps_message.data_size = pps_tx_data[4] + PPS_MAX_READ_HEADER; 
                        memset(&pps_tx_data[PPS_MAX_READ_HEADER + lenght], 0x00, (sizeof(pps_tx_data)- pps_message.data_size));                       
                        break;
                     }
                  }   
               }   
            }                         
         }   
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_Param_Write_Req
 *===========================================================================*
 * @brief Receive a Request for data write
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T PITS_PPS_Param_Write_Req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint16_t  param_id = 0;
   uint8_t   indx_param = 0;
   uint16_t  indx_id = 0;
   uint8_t   lenght = 0;

   if (NULL != message)
   {
      lenght = message->data[3];

      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pits_pps_compose_message_header(MID_PPS_PARAM_WRITE, 5);

      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      if (!pits_pps_is_timer_active)
      {
         PITS_Clear_PPS_Timer_Session();
      }
      if (message->data_size != (lenght+4))
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS PARAM READ REQUEST: Message Data Error");
         Tr_Warn_1("PPS PARAM READ REQUEST: Message Data Error,Error data length: %d",message->data_size);
      }
      else if (pps_session_state != SESSION_OPEN)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS SESSION OPEN REQUEST: Session Is Not Opened");
         Tr_Warn_1("PPS PARAM READ REQUEST:Session Is Not Opened,current session state is: %d",pps_session_state);
      }
      else if (pps_session_segment != PITS_MPI)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS SEGMENT REQUEST: Session Segment Error");
         Tr_Warn_1("PPS PARAM READ REQUEST:Session Segment Error,current session segment is: %d",pps_session_segment);
      }
      else if (ACCESS_READ_WRITE != pps_session_access)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("PPS SESSION ACCESS REQ: Session Read/Write Error");
         Tr_Warn_1("PPS PARAM READ REQUEST:Session Read/Write Error,current session access is: %d",pps_session_access);
      }
      else  
      {
         pps_tx_data[0] = (uint8_t) SUCCESS; 
         pps_tx_data[1] = message->data[0];          
         param_id = Util_Get_Big_Endian_U16(&message->data[1]);
         Util_Put_Big_Endian_U16(&pps_tx_data[2], param_id); 
         if (0 == message->data[0])
         {
            pps_tx_data[4] = PARAM_NO_LIST_EXIST;
         }
         else if (0 == param_id)
         {
           pps_tx_data[4] = PARAM_NO_ID_EXIST;
         }
         else
         {
            pps_tx_data[4] = PARAM_NO_LIST_EXIST;
            for (indx_param = 0; indx_param < PPS_MAX_PARAMETER_LIST-1; indx_param++)
            {
               if (pits_param_index_table[indx_param].param_list == message->data[0])
               {
                  pps_tx_data[4] = PARAM_NO_ID_EXIST;                            
                  for (indx_id = 0; indx_id < pits_param_index_table[indx_param].param_size; indx_id++)
                  {
                     if (pits_param_index_table[indx_param].param_indx[indx_id].param_id == param_id)
                     {
                        if (lenght != pits_param_index_table[indx_param].param_indx[indx_id].size)
                        {
                           pps_tx_data[4] = PARAM_LEN_ERROR;
                        }
                        else if (ACCESS_READ_WRITE != pits_param_index_table[indx_param].param_indx[indx_id].read_write)
                        {
                           pps_tx_data[4] = PARAM_READ;
                        }
                        else if(PITS_Enable_to_Write_Partition(pps_session_segment))
                        {
                           pps_tx_data[4] = (uint8_t) pits_param_index_table[indx_param].param_indx[indx_id].funct_write(&message->data[4], lenght);
                        }
                        else
                        {
                           pps_tx_data[4] = PARAM_UNABLE_WRITE;
                        }
                        break;
                     }
                  }
               }
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message);
      }
   }

   return (pits_status);
}

void pits_pps_app_version_read_req (uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   SW_Version_T sw_version;
   uint8_t did_sync_data[22]={0};
  
   if (0 != msg_id)
   {
        
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
    
          sw_version=SW_Version_PS_Get();
          
          pps_tx_data[3] = sw_version.platform_byte0 ;
          pps_tx_data[4] = sw_version.platform_byte1 ;
          pps_tx_data[5] = sw_version.platform_byte2 ;
          pps_tx_data[6] = sw_version.platform_byte3;
          pps_tx_data[7] = sw_version.space_character_byte4;
          pps_tx_data[8] = sw_version.ecu_name_byte5;
          pps_tx_data[9] = sw_version.ecu_name_byte6;
          pps_tx_data[10] = sw_version.ecu_name_byte7;
          pps_tx_data[11] = sw_version.ecu_name_byte8;
          pps_tx_data[12] = sw_version.ecu_sample_byte9;
          pps_tx_data[13] = sw_version.sa_byte10 ;
          pps_tx_data[14] = sw_version.sa_byte11 ;
          pps_tx_data[15] = sw_version.space_characte_byte12 ;
          pps_tx_data[16] = sw_version.version_number_byte13 ;
          pps_tx_data[17] = sw_version.version_number_byte14;
          
      
         
          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] =  msg_id>> 8;
          pps_tx_data[2] = msg_id;
          

         memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),17);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
   }
}
void pits_pps_supplier_version_read_req (uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Supp_SW_Version_T sw_version;
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {      
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
     
       sw_version=Supp_SW_Version_PS_Get();
       
      pps_tx_data[3] = sw_version.version_byte0;
      pps_tx_data[4] = sw_version.version_byte1 ;
      pps_tx_data[5] = sw_version.version_byte2 ;
      pps_tx_data[6] = sw_version.version_byte3;
      pps_tx_data[7] = sw_version.version_byte4;
      pps_tx_data[8] = sw_version.version_byte5;
      pps_tx_data[9] = sw_version.version_byte6;
      pps_tx_data[10] = sw_version.version_byte7;
      pps_tx_data[11] = sw_version.version_byte8;
      pps_tx_data[12] = sw_version.version_byte9;
      pps_tx_data[13] = sw_version.version_byte10 ;
      pps_tx_data[14] = sw_version.version_byte11 ;
      pps_tx_data[15] = sw_version.version_byte12 ;
      pps_tx_data[16] = sw_version.version_byte13 ;
      pps_tx_data[17] = sw_version.version_byte14;
      pps_tx_data[18] = sw_version.version_byte15; 
          
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),18);        

      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

void pits_pps_identify_num_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Session_Identify_Num_T identify_code;
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {
      
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
  
        identify_code=Session_Identify_Num_PS_Get();
          
        pps_tx_data[3] = identify_code.identyfy_num;
     
    
        pps_tx_data[0] = (uint8_t) SUCCESS;
        pps_tx_data[1] =  msg_id>> 8;
        pps_tx_data[2] = msg_id;
       memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),3);
     
       VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
        PITS_Send_Message(&pps_message);      
      
   }
}

void pits_pps_part_num_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Part_Num_T part_num;
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {     
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
    
      part_num=Part_Num_PS_Get();
          
      pps_tx_data[3] = part_num.part_num_byte0;
      pps_tx_data[4] = part_num.part_num_byte1;
      pps_tx_data[5] = part_num.part_num_byte2;
      pps_tx_data[6] = part_num.part_num_byte3;
      pps_tx_data[7] = part_num.part_num_byte4;
      pps_tx_data[8] = part_num.part_num_byte5;
      pps_tx_data[9] = part_num.part_num_byte6;
      pps_tx_data[10] = part_num.part_num_byte7;
      pps_tx_data[11] = part_num.part_num_byte8;
      pps_tx_data[12] = part_num.part_num_byte9;
      pps_tx_data[13] = part_num.part_num_byte10;
      pps_tx_data[14] = part_num.part_num_byte11;
      pps_tx_data[15] = part_num.part_num_byte12;
      pps_tx_data[16] = part_num.part_num_byte13;
      pps_tx_data[17] = part_num.part_num_byte14;    

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),17);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

void pits_pps_version_num_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_SW_Version_T sw_version;

    uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
       
          sw_version=GWM_SW_Version_PS_Get();
          
          pps_tx_data[3] = sw_version.platform_byte0 ;
          pps_tx_data[4] = sw_version.platform_byte1 ;
          pps_tx_data[5] = sw_version.platform_byte2 ;
          pps_tx_data[6] = sw_version.platform_byte3;
          pps_tx_data[7] = sw_version.space_character_byte4;
          pps_tx_data[8] = sw_version.ecu_name_byte5;
          pps_tx_data[9] = sw_version.ecu_name_byte6;
          pps_tx_data[10] = sw_version.ecu_name_byte7;
          pps_tx_data[11] = sw_version.ecu_name_byte8;
          pps_tx_data[12] = sw_version.ecu_sample_byte9;
          pps_tx_data[13] = sw_version.version_byte10;
          pps_tx_data[14] = sw_version.version_byte11;
          pps_tx_data[15] = sw_version.space_characte_byte12;
          pps_tx_data[16] = sw_version.version_control_byte13;
          pps_tx_data[17] = sw_version.version_control_byte14;
          
          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] =  msg_id>> 8;
          pps_tx_data[2] = msg_id;
          memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),17);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
      
   }
}

void pits_pps_identify_code_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Identify_Code_T identify_code;
    uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
        
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
      
          identify_code=Identify_Code_PS_Get();
          
          pps_tx_data[3] = identify_code.sequence_num5;
          pps_tx_data[4] = identify_code.sequence_num4;
          pps_tx_data[5] = identify_code.sequence_num3;
          pps_tx_data[6] = identify_code.sequence_num2;
          pps_tx_data[7] = identify_code.sequence_num1;
      
      
          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] =  msg_id>> 8;
          pps_tx_data[2] = msg_id;
          memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),7);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
      
   }
}


void pits_pps_supp_manufac_date_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Julianday_T julianday;
   uint16_t date = 0;
   uint8_t  Month, Day;	
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
      MFT_Get_Julianday(julianday);
      date+= julianday[1] * 100;
      date+= julianday[2] * 10;
      date+= julianday[3];
      JD2MD(date, julianday[0], &Month, &Day);
      pps_tx_data[3] = 0x20;
      pps_tx_data[4] = julianday[0];
      pps_tx_data[5] = DEC2BCD(Month);
      pps_tx_data[6] = DEC2BCD(Day);
   }
      
   pps_tx_data[0] = (uint8_t) SUCCESS;
   pps_tx_data[1] =  msg_id>> 8;
   pps_tx_data[2] = msg_id;
   memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),6);
     
   VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
   PITS_Send_Message(&pps_message);
 }

void pits_pps_serial_num_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
/*   Serial_Num_T num;  */
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
        
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
			
#if 0
          num=Serial_Num_PS_Get();
          
          pps_tx_datap[3] = num.serial_num_byte0;
          pps_tx_datap[4] = num.serial_num_byte1;
          pps_tx_datap[5] = num.serial_num_byte2;
          pps_tx_datap[6] = num.serial_num_byte3;
          pps_tx_datap[7] = num.serial_num_byte4;
          pps_tx_datap[8] = num.serial_num_byte5;
          pps_tx_datap[9] = num.serial_num_byte6;
          pps_tx_datap[10] = num.serial_num_byte7;
          pps_tx_datap[11] = num.serial_num_byte8;
          pps_tx_datap[12] = num.serial_num_byte9;
          pps_tx_datap[13] = num.serial_num_byte10;
          pps_tx_datap[14] = num.serial_num_byte11;
          pps_tx_datap[15] = num.serial_num_byte12;
          pps_tx_datap[16] = num.serial_num_byte13;
          pps_tx_datap[17] = num.serial_num_byte14;
          pps_tx_datap[18] = num.serial_num_byte15;
#endif
         /*link sn as MPI delphi PN + julianDay +SN fuxiang 20130423*/ 
            {
            int i;
            Delphi_PN_T dpn;
            Julianday_T day;
            ECU_SN_T esn;
            MFT_Get_Delphi_Part_Number(dpn);
            
            for(i = 0; i < 8; i++)
            pps_tx_data[3 + i] = dpn[i];
                  
            MFT_Get_Julianday(day);

            for(i = 0; i < 4; i++)
            pps_tx_data[11 + i] = day[i];

         
            MFT_Get_ECU_Special_Number(esn);

             for(i = 0; i < 4; i++)
             pps_tx_data[15 + i] = esn[i];
            }
/*link sn as MPI delphi PN + julianDay +SN fuxiang 20130423*/ 	
         
          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] =  msg_id>> 8;
          pps_tx_data[2] = msg_id;
          memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),18);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
      
   }
}



void pits_pps_vehicle_num_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_identify_Num_T num;
   uint8_t did_sync_data[22]={0};
   if (msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
      
      num=GWM_Identify_Num_PS_Get();

      pps_tx_data[3]=  num.identify_byte1 ;
      pps_tx_data[4]=num.identify_byte2 ;
      pps_tx_data[5]=num.identify_byte3 ;
      pps_tx_data[6]= num.car_type ;
      pps_tx_data[7]=num.parmeter_byte4 ;
      pps_tx_data[8]=num.parmeter_byte5 ;
      pps_tx_data[9]=num.body_type ;
      pps_tx_data[10]=num.wheelbus ;
      pps_tx_data[11]=num.check_digit ;
      pps_tx_data[12]=num.build_year ;
      pps_tx_data[13]=num.factory_code;
      pps_tx_data[14]=num.serial_num_byte0 ;
      pps_tx_data[15]=num.serial_num_byte1 ;
      pps_tx_data[16]=num.serial_num_byte2 ;
      pps_tx_data[17]=num.serial_num_byte3 ;
      pps_tx_data[18]=num.serial_num_byte4 ;
      pps_tx_data[19]=num.serial_num_byte5 ;    
          
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),19);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

void pits_pps_gwm_hw_version_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_HW_Version_T hw_version;
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {
   
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_data;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_data[0], 0, pps_size);
         pps_message.data_size = length + 6;
     
          hw_version=GWM_HW_Version_PS_Get();
          
          pps_tx_data[3] = hw_version.platform_byte0 ;
          pps_tx_data[4] = hw_version.platform_byte1 ;
          pps_tx_data[5] = hw_version.platform_byte2 ;
          pps_tx_data[6] = hw_version.platform_byte3;
          pps_tx_data[7] = hw_version.space_character_byte4;
          pps_tx_data[8] = hw_version.ecu_name_byte5;
          pps_tx_data[9] = hw_version.ecu_name_byte6;
          pps_tx_data[10] = hw_version.ecu_name_byte7;
          pps_tx_data[11] = hw_version.ecu_name_byte8;
          pps_tx_data[12] =hw_version.ecu_sample_byte9;
          pps_tx_data[13] = hw_version.version_byte10;
          pps_tx_data[14] = hw_version.version_byte11;
          pps_tx_data[15] = hw_version.space_characte_byte12;
          pps_tx_data[16] = hw_version.version_control_byte13;
          pps_tx_data[17] = hw_version.version_control_byte14;
          
          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] =  msg_id>> 8;
          pps_tx_data[2] = msg_id;
          memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),17);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
   }
}


void pits_pps_supp_hw_version_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   SUPP_HW_Version_T hw_version;
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {     
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
       
      hw_version=SUPP_HW_Version_PS_Get();
       
      pps_tx_data[3] = hw_version.version_byte0;
      pps_tx_data[4] = hw_version.version_byte1 ;
      pps_tx_data[5] = hw_version.version_byte2 ;
      pps_tx_data[6] = hw_version.version_byte3;
      pps_tx_data[7] = hw_version.version_byte4;
      pps_tx_data[8] = hw_version.version_byte5;
      pps_tx_data[9] = hw_version.version_byte6;
      pps_tx_data[10] = hw_version.version_byte7;
      pps_tx_data[11] = hw_version.version_byte8;
      pps_tx_data[12] = hw_version.version_byte9;
      pps_tx_data[13] = hw_version.version_byte10 ;
      pps_tx_data[14] = hw_version.version_byte11 ;
      pps_tx_data[15] = hw_version.version_byte12 ;
      pps_tx_data[16] = hw_version.version_byte13 ;
      pps_tx_data[17] = hw_version.version_byte14;
      pps_tx_data[18] = hw_version.version_byte15;
              
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),18);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

#if 0
void pits_pps_supp_sw_version_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   uint8_t pps_tx_datap[pps_size];
   SUPP_SW_Version_2_T sw_version;
   uint8_t did_sync_data[22]={0};

   if (0 != msg_id)
   {
        
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_datap;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_datap[0], 0, pps_size);
         pps_message.data_size = length + 6;
        
          sw_version=SUPP_SW_Version_PS_Get_2();
       
          pps_tx_datap[3] = sw_version.version_byte0;
          pps_tx_datap[4] = sw_version.version_byte1 ;
          pps_tx_datap[5] = sw_version.version_byte2 ;
          pps_tx_datap[6] = sw_version.version_byte3;
          pps_tx_datap[7] = sw_version.version_byte4;
          pps_tx_datap[8] = sw_version.version_byte5;
          pps_tx_datap[9] = sw_version.version_byte6;
          pps_tx_datap[10] = sw_version.version_byte7;
          pps_tx_datap[11] = sw_version.version_byte8;
          pps_tx_datap[12] = sw_version.version_byte9;
          pps_tx_datap[13] = sw_version.version_byte10 ;
          pps_tx_datap[14] = sw_version.version_byte11 ;
          pps_tx_datap[15] = sw_version.version_byte12 ;
          pps_tx_datap[16] = sw_version.version_byte13 ;
          pps_tx_datap[17] = sw_version.version_byte14;
          pps_tx_datap[18] = sw_version.version_byte15;
       
         
          pps_tx_datap[0] = (uint8_t) SUCCESS;
          pps_tx_datap[1] =  msg_id>> 8;
          pps_tx_datap[2] = msg_id;
         memcpy(&(did_sync_data[0]),&(pps_tx_datap[1]),18);
     
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
          PITS_Send_Message(&pps_message);      
      
   }
}
#endif

void pits_pps_supp_sw_version_read_req(uint16_t msg_id, uint8_t length)
{
	uint8_t pps_size = 3 + length;
	uint8_t tempbuff[16];
	uint8_t did_sync_data[22]={0};

	SAL_Message_T const *response_message = NULL;

   #if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
	SAL_Event_Id_T event_id_list[] =
	{
	   EVG_RTD_VERSION,
	};
	#endif

   SAL_Event_Id_T vip_event_id_list[] =
	{
	   EVG_VIP_SW_Version_RPT,
	};
        
   if (0 != msg_id)
   {
       
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
			
		if (SAL_Subscribe(vip_event_id_list, Num_Elems(vip_event_id_list)))
		{
         #if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)/* add by zengliangqian for get display version */
   		Pits_Get_RTD_Version();
   		
   		response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 1000);
   		if (NULL != response_message)
   		{
   		   Tr_Info_Lo("RTD Swid Response Received!!\r\n");
   		   if (EVG_RTD_VERSION == response_message->event_id)
   		   {
               /*pits_response = (uint8_t) SUCCESS;*/
               memcpy(&tempbuff[0],response_message->data,response_message->data_size);
               memcpy(&pps_tx_data[3],&tempbuff[4],4);
   			
   		   }
   		}
   		SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
		   #endif
		   
		Pits_Get_VIP_Version();

		response_message = SAL_Receive_Only_Timeout(vip_event_id_list, Num_Elems(vip_event_id_list), 1000);
		
		if (NULL != response_message)
		{
		   Tr_Info_Lo("VIP Swid Response Received!!\r\n");
                   if (EVG_VIP_SW_Version_RPT == response_message->event_id)
                   {	
                      memcpy(&tempbuff[0],response_message->data,response_message->data_size);				
                      memcpy(&pps_tx_data[11],&tempbuff[4],4);
                   }
		}
		
		SAL_Unsubscribe(vip_event_id_list, Num_Elems(vip_event_id_list));
	}	
		
         pps_tx_data[7] = (VT_SOFTWARE_VERSION >> 24) & 0xff;
         pps_tx_data[8] = (VT_SOFTWARE_VERSION >> 16) & 0xff;
         pps_tx_data[9] = (VT_SOFTWARE_VERSION >> 8) & 0xff;
         pps_tx_data[10] = (VT_SOFTWARE_VERSION) & 0xff;
		
 
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pps_tx_data[1] =  msg_id>> 8;
         pps_tx_data[2] = msg_id;
			 
         memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),18);
     
         VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
         PITS_Send_Message(&pps_message);      
      
   }
}

void pits_pps_network_info_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Network_info_T info;
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;

      info = Network_Info_PS_Get();
          
      pps_tx_data[3] = info.byte0;
      pps_tx_data[4] = info.byte1;
      pps_tx_data[5] = info.byte2;
           
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),5);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

void pits_pps_sys_config_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   System_Config_T config;
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
      
      config = Sys_Config_PS_Get();    
          
      pps_tx_data[3] = config.config_byte0;
      pps_tx_data[4] = config.config_byte1;
      pps_tx_data[5] = config.config_byte2;
      pps_tx_data[6] = config.config_byte3;
      pps_tx_data[7] = config.config_byte4;
      pps_tx_data[8] = config.config_byte5;
      pps_tx_data[9] = config.config_byte6;
      pps_tx_data[10] = config.config_byte7;
      pps_tx_data[11] = config.config_byte8;
      pps_tx_data[12] = config.config_byte9;
      pps_tx_data[13] = config.config_byte10;
      pps_tx_data[14] = config.config_byte11;
      pps_tx_data[15] = config.config_byte12;
      pps_tx_data[16] = config.config_byte13;
      pps_tx_data[17] = config.config_byte14;
      pps_tx_data[18] = config.config_byte15;
      pps_tx_data[19] = config.config_byte16;
     
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),19);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

void pits_pps_gwm_manufac_date_read_req(uint16_t msg_id, uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_Manu_Date_T date;
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_READ;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = length + 6;
    
      date=GWM_Manu_date_PS_Get();
          
      pps_tx_data[3] = date.year_high_byte;
      pps_tx_data[4] = date.year_low_byte;
      pps_tx_data[5] = date.month;
      pps_tx_data[6] = date.day; 
        
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] =  msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(did_sync_data[0]),&(pps_tx_data[1]),6);
     
      VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
      PITS_Send_Message(&pps_message);      
   }
}

#if 0
void pits_CD_IIC_read_req(uint16_t msg_id, uint8_t length)
 {
   uint8_t pps_size = 3 + length;
   uint8_t pps_tx_datap[pps_size];
   uint8_t IIC_status;
   uint8_t did_sync_data[22]={0};
   if (0 != msg_id)
   {
      
         pps_message.bus = 0x00;
         pps_message.data = pps_tx_datap;
         pps_message.MSID = MSID_PROGRAMMING_SERVICES;
         pps_message.MID = MID_PPS_SW_VERSION_READ;
         memset(&pps_tx_datap[0], 0, pps_size);
         pps_message.data_size = length + 6;
      
          IIC_status=CD_IIC_PS_Get();
          
          pps_tx_datap[3] = IIC_status;
         
          pps_tx_datap[0] = (uint8_t) SUCCESS;
          pps_tx_datap[1] =  msg_id>> 8;
          pps_tx_datap[2] = msg_id;
           memcpy(&(did_sync_data[0]),&(pps_tx_datap[1]),3);
           
          VIP_Send(VIPP_EV_GWM_DID_SYNC, &(did_sync_data[0]), 22);
         PITS_Send_Message(&pps_message);      
      
   }
}
#endif

void pits_pps_app_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
 uint8_t pps_size = 3 + length;
    SW_Version_T sw_version;
    int8_t i =0;
    if (0 != msg_id)
    {
   
          pps_message.bus = 0x00;
          pps_message.data = pps_tx_data;
          pps_message.MSID = MSID_PROGRAMMING_SERVICES;
          pps_message.MID = MID_PPS_SW_VERSION_WRITE;
          memset(&pps_tx_data[0], 0, pps_size);
          pps_message.data_size = pps_size;
       
          
          sw_version=SW_Version_PS_Get();
          sw_version.platform_byte0 = data[0];
          sw_version.platform_byte1 = data[1];
          sw_version.platform_byte2 = data[2];
          sw_version.platform_byte3 = data[3];
          sw_version.space_character_byte4= data[4];
          sw_version.ecu_name_byte5= data[5];
          sw_version.ecu_name_byte6= data[6];
          sw_version.ecu_name_byte7= data[7];
          sw_version.ecu_name_byte8= data[8];
          sw_version.ecu_sample_byte9= data[9];
          sw_version.sa_byte10 = data[10];
          sw_version.sa_byte11 = data[11];
          sw_version.space_characte_byte12 = data[12];
          sw_version.version_number_byte13 = data[13];
          sw_version.version_number_byte14= data[14];
           SW_Version_PS_Set(sw_version);

          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] = msg_id>> 8;
          pps_tx_data[2] = msg_id;
          for(i=0;i<15;i++)
          {
             pps_tx_data[i+3] =data[i];
        
          }
          PITS_Send_Message(&pps_message);        
   }
}
void pits_pps_supplier_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Supp_SW_Version_T sw_version;
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
          
      sw_version=Supp_SW_Version_PS_Get();
      sw_version.version_byte0=data[0];
      sw_version.version_byte1= data[1];
      sw_version.version_byte2= data[2];
      sw_version.version_byte3= data[3];
      sw_version.version_byte4= data[4];
      sw_version.version_byte5= data[5];
      sw_version.version_byte6= data[6];
      sw_version.version_byte7= data[7];
      sw_version.version_byte8= data[8];
      sw_version.version_byte9= data[9];
      sw_version.version_byte10 = data[10];
      sw_version.version_byte11 = data[11];
      sw_version.version_byte12 = data[12];
      sw_version.version_byte13 = data[13];
      sw_version.version_byte14= data[14];
      sw_version.version_byte15= data[15];
      Supp_SW_Version_PS_Set(sw_version);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<16;i++)
      {
         pps_tx_data[i+3] =data[i];  
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_identify_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Session_Identify_Num_T num;
   int8_t i =0;
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
          
      num=Session_Identify_Num_PS_Get();
      num.identyfy_num= data[0];

      Session_Identify_Num_PS_Set(num);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<1;i++)
      {
         pps_tx_data[i+3] =data[i];  
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_part_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Part_Num_T part_num;
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
          
      part_num=Part_Num_PS_Get();
      part_num.part_num_byte0 = data[0];
      part_num.part_num_byte1 = data[1];
      part_num.part_num_byte2 = data[2];
      part_num.part_num_byte3 = data[3];
      part_num.part_num_byte4= data[4];
      part_num.part_num_byte5= data[5];
      part_num.part_num_byte6= data[6];
      part_num.part_num_byte7= data[7];
      part_num.part_num_byte8= data[8];
      part_num.part_num_byte9= data[9];
      part_num.part_num_byte10 = data[10];
      part_num.part_num_byte11 = data[11];
      part_num.part_num_byte12 = data[12];
      part_num.part_num_byte13 = data[13];
      part_num.part_num_byte14= data[14];
      Part_Num_PS_Set(part_num);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<15;i++)
      {
         pps_tx_data[i+3] =data[i];   
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_version_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_SW_Version_T sw_version;
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
          
      sw_version=GWM_SW_Version_PS_Get();
      sw_version.platform_byte0 = data[0];
      sw_version.platform_byte1 = data[1];
      sw_version.platform_byte2 = data[2];
      sw_version.platform_byte3 = data[3];
      sw_version.space_character_byte4= data[4];
      sw_version.ecu_name_byte5= data[5];
      sw_version.ecu_name_byte6= data[6];
      sw_version.ecu_name_byte7= data[7];
      sw_version.ecu_name_byte8= data[8];
      sw_version.ecu_sample_byte9= data[9];
      sw_version.version_byte10 = data[10];
      sw_version.version_byte11 = data[11];
      sw_version.space_characte_byte12 = data[12];
      sw_version.version_control_byte13 = data[13];
      sw_version.version_control_byte14= data[14];
      GWM_SW_Version_PS_Set(sw_version);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<15;i++)
      {
         pps_tx_data[i+3] =data[i];  
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_identify_code_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   Identify_Code_T identify_code;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size;
           
      identify_code=Identify_Code_PS_Get();
      identify_code.sequence_num5 =data[0];
      identify_code.sequence_num4 = data[1];
      identify_code.sequence_num3= data[2];
      identify_code.sequence_num2 = data[3];
      identify_code.sequence_num1= data[4];
          
      Identify_Code_PS_Set(identify_code);
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
          
      memcpy(&(pps_tx_data[3]),&(data[0]),5);

      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_supp_manufac_date_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   uint16_t date;
   int8_t i =0;
   if (0 != msg_id)
   {
      Julianday_T julianday;
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size;
	    
      MD2JD(BCD2DEC(data[1]), BCD2DEC(data[2]), BCD2DEC(data[3]), &date);
      julianday[0] = data[0];
      julianday[1] = (date / 100) % 10; 
      julianday[2] = (date / 10) % 10;	
      julianday[3] = date % 10;	  
      MFT_Set_Julianday(julianday);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<4;i++)
      {
         pps_tx_data[i+3] = julianday[i];
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_serial_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   /* Serial_Num_T num;*/
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 

      /*link sn as MPI delphi PN + julianDay +SN fuxiang 20130423*/ 
      {
         Delphi_PN_T dpn;
         Julianday_T day;
         ECU_SN_T esn;
           
         for(i = 0; i < 8; i++)
         {
            dpn[i] = data[i];
         }
            
         MFT_Set_Delphi_Part_Number(dpn);

         for(i = 0; i < 4; i++)
         {
            day[i] = data[i + 8];
         }
            
         MFT_Set_Julianday(day);

         for(i = 0; i < 4; i++)
         {
            esn[i] = data[i + 12];
         }
            
         MFT_Set_ECU_Special_Number(esn);
      }

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<16;i++)
      {
         pps_tx_data[i+3] =data[i];
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_vehicle_num_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_identify_Num_T num;
   
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
         
      num=GWM_Identify_Num_PS_Get();
      num.identify_byte1 = data[0];
      num.identify_byte2 = data[1];
      num.identify_byte3 = data[2];
      num.car_type = data[3];
      num.parmeter_byte4 =data[4];
      num.parmeter_byte5 =data[5];
      num.body_type = data[6];
      num.wheelbus = data[7];
      num.check_digit = data[8];
      num.build_year = data[9];
      num.factory_code = data[10];
      num.serial_num_byte0 = data[11];
      num.serial_num_byte1 =data[12];
      num.serial_num_byte2 = data[13];
      num.serial_num_byte3 =data[14];
      num.serial_num_byte4 = data[15];
      num.serial_num_byte5 =data[16];
          
      GWM_Identify_Num_PS_Set(num);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      memcpy(&(pps_tx_data[3]),&(data[0]),17);
            
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_gwm_hw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_HW_Version_T hw_version;
   /* int8_t i =0;*/
    if (0 != msg_id)
    {
          pps_message.bus = 0x00;
          pps_message.data = pps_tx_data;
          pps_message.MSID = MSID_PROGRAMMING_SERVICES;
          pps_message.MID = MID_PPS_SW_VERSION_WRITE;
          memset(&pps_tx_data[0], 0, pps_size);
          pps_message.data_size = pps_size;
       
          
          hw_version=GWM_HW_Version_PS_Get();
          hw_version.platform_byte0 = data[0];
          hw_version.platform_byte1 = data[1];
          hw_version.platform_byte2 = data[2];
          hw_version.platform_byte3 = data[3];
          hw_version.space_character_byte4 =data[4];
          hw_version.ecu_name_byte5 = data[5];
          hw_version.ecu_name_byte6 = data[6];
          hw_version.ecu_name_byte7 = data[7];
          hw_version.ecu_name_byte8 = data[8];
          hw_version.ecu_sample_byte9 = data[9];
          hw_version.version_byte10 = data[10];
          hw_version.version_byte11 = data[11];
          hw_version.space_characte_byte12 = data[12];
          hw_version.version_control_byte13 = data[13];
          hw_version.version_control_byte14 = data[14];
          GWM_HW_Version_PS_Set(hw_version);

          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] = msg_id>> 8;
          pps_tx_data[2] = msg_id;
            memcpy(&(pps_tx_data[3]),&(data[0]),17);
            /*
          for(i=0;i<15;i++)5
          {
             pps_tx_datap[i+3] =data[i];
           
          }
          */
          PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_supp_hw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
 {
   uint8_t pps_size = 3 + length;
   SUPP_HW_Version_T hw_version;
    int8_t i =0;
    if (0 != msg_id)
    {
    
          pps_message.bus = 0x00;
          pps_message.data = pps_tx_data;
          pps_message.MSID = MSID_PROGRAMMING_SERVICES;
          pps_message.MID = MID_PPS_SW_VERSION_WRITE;
          memset(&pps_tx_data[0], 0, pps_size);
          pps_message.data_size = pps_size;
       
          
          hw_version=SUPP_HW_Version_PS_Get();
       
          hw_version.version_byte0 = data[0];
          hw_version.version_byte1= data[1];
          hw_version.version_byte2 = data[2];
          hw_version.version_byte3 = data[3];
          hw_version.version_byte4 =data[4];
          hw_version.version_byte5 = data[5];
          hw_version.version_byte6 = data[6];
          hw_version.version_byte7 = data[7];
          hw_version.version_byte8 = data[8];
          hw_version.version_byte9 = data[9];
          hw_version.version_byte10 = data[10];
          hw_version.version_byte11 = data[11];
          hw_version.version_byte12 = data[12];
          hw_version.version_byte13 = data[13];
          hw_version.version_byte14 = data[14];
          hw_version.version_byte15 = data[15];
          SUPP_HW_Version_PS_Set(hw_version);

          pps_tx_data[0] = (uint8_t) SUCCESS;
          pps_tx_data[1] = msg_id>> 8;
          pps_tx_data[2] = msg_id;
          for(i=0;i<16;i++)
          {
             pps_tx_data[i+3] =data[i];
           
          }
          PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_supp_sw_version_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   SUPP_SW_Version_2_T sw_version;
   int8_t i =0;
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size;
       
       
      sw_version=SUPP_SW_Version_PS_Get_2();
       
      sw_version.version_byte0 = data[0];
      sw_version.version_byte1= data[1];
      sw_version.version_byte2 = data[2];
      sw_version.version_byte3 = data[3];
      sw_version.version_byte4 =data[4];
      sw_version.version_byte5 = data[5];
      sw_version.version_byte6 = data[6];
      sw_version.version_byte7 = data[7];
      sw_version.version_byte8 = data[8];
      sw_version.version_byte9 = data[9];
      sw_version.version_byte10 = data[10];
      sw_version.version_byte11 = data[11];
      sw_version.version_byte12 = data[12];
      sw_version.version_byte13 = data[13];
      sw_version.version_byte14 = data[14];
      sw_version.version_byte15 = data[15];
      SUPP_SW_Version_PS_Set_2(sw_version);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<16;i++)
      {
         pps_tx_data[i+3] =data[i];  
      }
      PITS_Send_Message(&pps_message);        
   }
}


void pits_pps_network_info_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length; 
   Network_info_T info;
   int8_t i =0;
   if (0 != msg_id)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size;
           
      info =Network_Info_PS_Get();
      info.byte0 = data[0];
      info.byte1 = data[1];
      info.byte2 = data[2];  
                
      Network_Info_PS_Set( info);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<3;i++)
      {
         pps_tx_data[i+3] =data[i];   
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_sys_config_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
 {
   uint8_t pps_size = 3 + length;
   System_Config_T config;
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size;
       
      config=Sys_Config_PS_Get();
      config.config_byte0= data[0];
      config.config_byte1= data[1];
      config.config_byte2= data[2];
      config.config_byte3 = data[3];
      config.config_byte4 =data[4];
      config.config_byte5 = data[5];
      config.config_byte6= data[6];
      config.config_byte7=data[7];
      config.config_byte8=data[8];
      config.config_byte9=data[9];
      config.config_byte10 = data[10];
      config.config_byte11 = data[11];
      config.config_byte12 = data[12];
      config.config_byte13 = data[13];
      config.config_byte14 = data[14];
      config.config_byte15 = data[15];
      config.config_byte16 = data[16];
        
      Sys_Config_PS_Set(config);
      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<10;i++)
      {
         pps_tx_data[i+3] =data[i]; 
      }
      PITS_Send_Message(&pps_message);        
   }
}

void pits_pps_gwm_manufac_date_write_req(uint16_t msg_id, uint8_t data[], uint8_t length)
{
   uint8_t pps_size = 3 + length;
   GWM_Manu_Date_T date;
   int8_t i =0;
   if (0 != msg_id)
   {  
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = MSID_PROGRAMMING_SERVICES;
      pps_message.MID = MID_PPS_SW_VERSION_WRITE;
      memset(&pps_tx_data[0], 0, pps_size);
      pps_message.data_size = pps_size; 
          
      date =GWM_Manu_date_PS_Get();
      date.year_high_byte =data[0];
      date.year_low_byte = data[1];
      date.month= data[2];
      date.day= data[3];
                
      GWM_Manu_date_PS_Set(date);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_tx_data[1] = msg_id>> 8;
      pps_tx_data[2] = msg_id;
      for(i=0;i<4;i++)
      {
        pps_tx_data[i+3] =data[i];     
      }
      PITS_Send_Message(&pps_message);        
    }
}

/*===========================================================================*
 * FUNCTION: pits_pps_session_get_timeout_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_load_defaults_req(const PITS_Message_T * message)
{
   int8_t ret;
   int fid;
   if (message->data[0] == 0x00)
   {
      BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
      DAG_Diag_Clear_Dev_List();
      PS_Set_As_ReadOnly(true);
      ret = system("rm -r /var/persistent/*");
      fid = open("/factory_data/partition_test", O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

      if (fid >= 0)
      {
         close(fid);
         /* Factory data is R/W */
         ret = system("rm -r /factory_data/*");
         PBC_Ensure((ret != -1),"Failed system call factory data RW");
      }
      ret = system ("sync");
      PBC_Ensure((ret != -1),"Failed system call sync");
      pits_pps_reset_radio();
   }
   else if (message->data[0] == 0x01)
   {
      fid = open("/factory_data/partition_test", O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

      if (fid >= 0)
      {
         close(fid);
         PS_Set_As_ReadOnly(true);
         /* Factory data is R/W */
         ret = system("rm -r /factory_data/manufacturing*");
         ret = system("rm -r /factory_data/align_cals*");
         ret = system ("sync");
         PBC_Ensure((ret != -1),"Failed system call sync");
      }
      pits_pps_reset_radio();
   }
   else if (message->data[0] == 0x02)
   {
      fid = open("/factory_data/partition_test", O_WRONLY | O_CREAT | O_TRUNC, (S_IRWXU | S_IRWXG | S_IRWXO));

      if (fid >= 0)
      {
         close(fid);
         PS_Set_As_ReadOnly(true);
         /* Factory data is R/W */
         ret = system("rm -r /factory_data/product_id*");
         ret = system ("sync");
         PBC_Ensure((ret != -1),"Failed system call sync");
         
      }
      pits_pps_reset_radio();
   }
   else if (message->data[0] == 0x03)
   {
      BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
      PS_Set_As_ReadOnly(true);
      ret = system("rm -r /var/persistent/nonvol*");
      ret = system("rm -r /var/persistent/presets*");
     
      ret = system ("sync");
      PBC_Ensure((ret != -1),"Failed system call sync");
      pits_pps_reset_radio();
   }
   else if (message->data[0] == 0x04)
   {
      DAG_Diag_Clear_Dev_List();
      ret = system("sync");
      PBC_Ensure((ret != -1),"Failed system call sync");
   }
   else if (message->data[0] == 0x05)
   {
      MSM_Erase_Media();
      ret = system("sync");
      PBC_Ensure((ret != -1),"Failed system call sync");
   }
   return (DONE);
}

/* After the PS files are removed, cause radio reset. This allows the radio to
* load defaults on next startup.
*/
static void pits_pps_reset_radio(void)
{
   Tr_Fault("PS Data has been removed. Resetting now...");
   SAL_Sleep(500);                                 /* Allow time for trace message to be printed */
   VIP_Send(VIPP_EV_RESET_REQUEST, NULL, 0);
}

/*===========================================================================*
 * FUNCTION: pits_memory_map_check
 *===========================================================================*
 * @brief Check Memory Address is within valid range
 *
 * @param [in] map_id = Table of Memory Start & End Addresses to check against
 * @param [in] address = Start Address to check
 * @param [in] length = Memory block size
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
Success_Or_Fail_T pits_memory_map_check(PITS_Memory_Map_ID_T map_id, uint32_t start_address, size_t length)
{
   Success_Or_Fail_T status = FAIL;
   uint8_t map_index, segment_index;
   const PITS_Memory_Map_T *map;
   const PITS_Memory_Address_T *address;
   uint32_t end_address;

   end_address = start_address + length - 1;
   if (end_address >= start_address)    /* guard against overflow */
   {
      for (map_index = 0; map_index < MAPID_NUM; map_index++)
      {
         /* Look for the correct Map ID */
         map = &(pits_memory_map_sets[map_index]);
         if (map->id == map_id)
         {
            /* This is the correct Map ID, look for correct address range */
            for (segment_index = 0; segment_index < map->size; segment_index++)
            {
               address = &(map->addresses[segment_index]);
               if ((start_address >= address->start) && (start_address <= address->end) &&      /* start address within range? */
                   (end_address <= address->end))       /* end address within range? */
               {
                  /* Correct Map ID and valid address: */
                  status = SUCCESS;
                  break;        /* Stop search. */
               }
            }                   /* look until the end of address table */
            break;              /* Correct Map ID but invalid address, stop search */
         }
      }                         /* look through all MAP IDs */
   }
   return (status);
}

/*===========================================================================*
 * FUNCTION: PITS_Download_Memory_Map_Check
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
Success_Or_Fail_T PITS_Download_Memory_Map_Check(uint32_t start_address, size_t length)
{
   return (pits_memory_map_check(MEMORY_DOWNLOAD, start_address, (size_t) length));
}

/*===========================================================================*
 * FUNCTION: PITS_Create_PPS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_PPS_Timer(void)
{
   SAL_Create_Timer(PITS_EV_PPS_SESSION_TIMEOUT, &pits_pps_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_PPS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_PPS_Timer(void)
{
   SAL_Destroy_Timer(pits_pps_session_timer_id);
}
/*===========================================================================*
 * FUNCTION: PITS_Check_PPS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_PPS_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_PPS_SESSION_TIMEOUT)
   {
      if (PITS_Set_PPS_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS PROGRAMMING SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_PPS_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_PPS_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (pps_session_state != session)    /* Session State change? */
   {
      pps_session_state = session;      /* Set to new State */
      SAL_Publish(PITS_EVG_PPS_SESSION, &session, sizeof(pps_session_state));  /* Publish new Session State */
      if (pps_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_pps_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_pps_session_timer_id, pps_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_PPS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_PPS_Session(void)
{
   return (pps_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_PPS_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_PPS_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &pps_session_state, sizeof(pps_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PPS_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_PPS_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_PPS_SESSION,NULL,0,PITS_EVG_PPS_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_PPS_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply.*/
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

uint16_t Pits_Get_Param_Band_Value (uint8_t zone, uint8_t page, uint8_t preset)
{
   Preset_Type_T presets;
   uint16_t dpid_channel = 0;

      presets = Preset_PS_Get_Preset_Data(zone, page, preset);
      if (presets.tuner_info.band == PRESET_MGR_DEV_AM)
      {
         dpid_channel = (uint16_t)presets.tuner_info.idd;
      }
      if (presets.tuner_info.band == PRESET_MGR_DEV_FM)
      {
         dpid_channel = (uint16_t)(presets.tuner_info.idd/10);
      }
      if(presets.tuner_info.band == PRESET_MGR_DEV_XM)
      {
         dpid_channel = (uint16_t) presets.tuner_info.idd;
      }

      
      return (dpid_channel);
}

uint16_t Pits_Get_Param_Band_Value_Mpi (uint8_t zone, uint8_t page, uint8_t preset)
{
   Preset_Type_T presets;
   uint16_t dpid_channel = 0;

      presets = Preset_PS_Get_Preset_Data(zone, page, preset);
      if (presets.tuner_info.band == PRESET_MGR_DEV_AM)
      {
         dpid_channel = (uint16_t)presets.tuner_info.idd;
      }
      if (presets.tuner_info.band == PRESET_MGR_DEV_FM)
      {
         dpid_channel = (uint16_t)(presets.tuner_info.idd);
      }
      if(presets.tuner_info.band == PRESET_MGR_DEV_XM)
      {
         dpid_channel = (uint16_t) presets.tuner_info.idd;
      }

      #ifdef FEATURE_EMPTY_PRESET
      if(presets.tuner_info.empty_flag)
      {
        dpid_channel = 0xffff;
      }

      #endif
      
      return (dpid_channel);
}



void Pits_Get_Random_Shuffle (const uint8_t * data, size_t length)
{
   memcpy(&pit_shuffle_rpt[0],&data[0],10);

}

void Preset_Prog_PS_Put_Preset_Data (Tuner_Info_T tuner_info,
                                    preset_mgr_zone_num_type zone_index,
                                    preset_mgr_page_num_type page_index,
                                    preset_mgr_preset_num_type preset_index)
{
   char id[30];
   uint32_t new_channel = tuner_info.idd;
   uint32_t new_bcd_string = 0;
   uint8_t  new_string1;
   uint8_t  new_string2;
   uint8_t  new_string3;
   uint8_t  new_string4;
   uint8_t  new_string5;

   new_bcd_string = Hex_To_BCD(new_channel,5);
   new_string5 = (new_bcd_string) & 0x0F;
   new_string4 = (new_bcd_string>>4) & 0x0F;
   new_string3 = (new_bcd_string>>8) & 0x0F;
   new_string2 = (new_bcd_string>>12) & 0x0F;
   new_string1 = (new_bcd_string>>16) & 0x0F;

      if (tuner_info.band == 0)
      {
         tuner_info.band = PRESET_MGR_DEV_AM;
         if (new_string2 == 0)
         {
            snprintf(id, sizeof(id), "AM %d%d%d", new_string3, new_string4, new_string5);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }
         else
         {
             snprintf(id, sizeof(id), "AM %d%d%d%d",new_string2, new_string3, new_string4, new_string5);
             Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }

      }
      else if (tuner_info.band == 1)
      {
         tuner_info.band = PRESET_MGR_DEV_FM;
         tuner_info.pi = 0;
         if (new_string1 == 0)
         {
            snprintf(id, sizeof(id), "FM %d%d.%d", new_string2, new_string3, new_string4);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }
         else
         {
            snprintf(id, sizeof(id), "FM %d%d%d.%d",new_string1, new_string2, new_string3, new_string4);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }

      }
      else if (tuner_info.band == 2)
      {
         tuner_info.band = PRESET_MGR_DEV_XM;
         if ((new_string2 == 0) && (new_string3 == 0))
         {
            snprintf(id, sizeof(id), "XM %d%d", new_string4, new_string5);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }
         else if (new_string2 == 0)
         {
            snprintf(id, sizeof(id), "XM %d%d%d", new_string3, new_string4, new_string5);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }
         else
         {
            snprintf(id, sizeof(id), "XM %d%d%d%d",new_string1, new_string2, new_string3, new_string4);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }

      }
      else
      {
         tuner_info.band = PRESET_MGR_DEV_FM;
         tuner_info.pi = 0;
         if (new_string1 == 0)
         {
            snprintf(id, sizeof(id), "FM %d%d.%d", new_string2, new_string3, new_string4);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }
         else
         {
            snprintf(id, sizeof(id), "FM %d%d%d.%d",new_string1, new_string2, new_string3, new_string4);
            Safe_Strncpy(tuner_info.station_name,id, PITS_PRESET_MGR_MAX_LABEL_SIZE_PROG);
         }

      }
      Preset_PS_Put_Preset_Data(tuner_info, zone_index, page_index, preset_index);
      Preset_PS_Put_Current_Page(SYS_ZONE_MAIN, (page_index+1));
      Pits_Preset_Update_HMI_Display_Info2(SYS_ZONE_MAIN, (page_index+1));
      Pits_Preset_Update_HMI_Highlights2(SYS_ZONE_MAIN);
}

Done_Or_Not_Done_T pits_pps_eng_menus_req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      PITS_Set_Engineering_Menu(message->data[0]);
   }
   return (DONE);
}

void Pits_Get_Paired_Data_Info (const uint8_t * data, size_t length)
{
   SAL_Event_Id_T event_id = BT_CM_EVG_PAIRED_DEVICE_INFO;
   uint16_t device_index  = 0;
   uint8_t  name_index = 0;
   bool_t bt_next_name_empty = false;

   /* clear structure to remove deleted entries */
   memset(&paired_dev_list_data[device_index], 0, Num_Elems(paired_dev_list_data)*sizeof(BT_CM_EVG_PAIRED_DEVICE_INFO_T));
   get_index_bt = 0;
   no_of_devices = BT_CM_Get_Paired_Device_Count((SAL_Event_Id_T)event_id, data, length);
   if (no_of_devices > BT_CM_MAX_PAIRED_DEVICES)
   {
      no_of_devices = BT_CM_MAX_PAIRED_DEVICES;
   }
   for(device_index = 0; device_index < no_of_devices; device_index++)
   {
      paired_dev_list_data[device_index] = BT_CM_Get_Paired_Device_List_Entry((SAL_Event_Id_T)event_id, data, length, device_index);
      if (paired_dev_list_data[device_index].connected_services[BT_CM_SERVICE_TYPE_HFP])
      {
         get_index_bt = device_index;
      }
   }

   for(device_index = 0; device_index < BT_CM_MAX_PAIRED_DEVICES; device_index++)
   {
      for(name_index = 0; name_index < 33; name_index++)
      {
         if (bt_next_name_empty)
         {
            paired_dev_list_data[device_index].name[name_index] = 0;
         }

         if (paired_dev_list_data[device_index].name[name_index] == 0)
         {
            bt_next_name_empty = true;
         }
      }
      bt_next_name_empty = false;
   }
}

extern uint16_t Pits_Get_Diag_Btdevices_Number (void)
{
   return (no_of_devices);
}

extern void Pits_Get_Diag_Btconnected_Address (uint8_t *new_address)
{
   memcpy(&new_address[0], &paired_dev_list_data[0].device_address[0], 6);
}

extern void Pits_Get_Diag_Bt_Address_Paired (uint8_t list_data, uint8_t *new_address)
{
   memcpy(&new_address[0], &paired_dev_list_data[list_data].device_address[0], 6);
}

extern void Pits_Get_Diag_Btconnected_Name (uint8_t *new_name)
{
   new_name[0] = strlen(&paired_dev_list_data[0].name[0]);
   memcpy(&new_name[1], &paired_dev_list_data[0].name[0], 33);
}

extern void Pits_Get_Diag_Btconnected_Profile (uint8_t *new_profile)
{
   new_profile[0] = paired_dev_list_data[get_index_bt].services_supported[BT_CM_SERVICE_TYPE_HFP];
   new_profile[1] = paired_dev_list_data[get_index_bt].services_supported[BT_CM_SERVICE_TYPE_PBAP];
   new_profile[2] = paired_dev_list_data[get_index_bt].services_supported[BT_CM_SERVICE_TYPE_MAP];
   new_profile[3] = paired_dev_list_data[get_index_bt].services_supported[BT_CM_SERVICE_TYPE_SPP];
   new_profile[4] = paired_dev_list_data[get_index_bt].services_supported[BT_CM_SERVICE_TYPE_AS];
}
void Pits_Send_Dtcmics_Vip (uint8_t i, uint8_t data_first, uint8_t data_second)
{
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   PITs_GM_Set_DID (0,15);
   PITs_GM_Set_DID(1, i);
   PITs_GM_Set_DID(2, data_first);
   PITs_GM_Set_DID(3, data_second);
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}

void Pits_Send_Whole_Dtcmics_Vip (void)
{
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   uint8_t dtc_index = 0;
   uint8_t new_index = 1;
   PITs_GM_Set_DID (0,16);
   new_index = 1;
   for (dtc_index = 0; dtc_index < 28; dtc_index++)
   {
      PITs_GM_Set_DID(new_index,(uint8_t)((Self_Di_Get_Micdtcs(dtc_index))>>8));
      PITs_GM_Set_DID(new_index+1,(uint8_t)Self_Di_Get_Micdtcs(dtc_index));
      new_index = new_index+2;
   }
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
}

Done_Or_Not_Done_T pits_pps_send_micdtc_req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      Pits_Send_Whole_Dtcmics_Vip();
   }
   return (DONE);
}

Done_Or_Not_Done_T pits_pps_send_usbdtc_req(const PITS_Message_T * message)
{
   int rc = 0;
   int8_t fp = 0;
   int16_t temp_file_created;
   uint8_t offset_usbdtc = 0;
   uint8_t buffer[4] = {0};
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;

   if (NULL != message)
   {
      temp_file_created = Create_Temp_File_Copy_Of_Nor();

      if(temp_file_created)
      {
         fp = open("/tmp/Nor_Copy", O_RDONLY, 0);

         if(0 <= fp)
         {
            if(0 > lseek(fp, offset_usbdtc, SEEK_SET))
            {
               Tr_Warn("PITS file seek operation failed");
            }

            rc = read(fp, buffer, 4);

            if(0 != rc)
            {
               /* Data is stored on buffer*/
               write_enable = false;
               memcpy (&buffer_ps[0],&buffer[0],4);
               if ((buffer[0] == 0x13)||(buffer[0] == 0x17))
               {
                  buffer_ps[0] = 0x11;
                  write_enable = true;
               }
               if ((buffer[1] == 0x13)||(buffer[1] == 0x17))
               {
                  buffer_ps[1] = 0x11;
                  write_enable = true;
               }
               if ((buffer[2] == 0x13)||(buffer[2] == 0x17))
               {
                  buffer_ps[2] = 0x11;
                  write_enable = true;
               }
               if ((buffer[3] == 0x13)||(buffer[3] == 0x17))
               {
                  buffer_ps[3] = 0x11;
                  write_enable = true;
               }
            }

            if(0 > close(fp))
            {
               Tr_Warn("PITS file close operation failed");
            }
         }
         else
         {
            Tr_Warn("PITS file open operation failed");
         }
      }

      PITs_GM_Set_DID (0,17);
      PITs_GM_Set_DID (1,buffer[0]);
      PITs_GM_Set_DID (2,buffer[1]);
      PITs_GM_Set_DID (3,buffer[2]);
      PITs_GM_Set_DID (4,buffer[3]);
      PITs_GM_Set_DID (5,0);
      PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
   }
   return (DONE);
}

Done_Or_Not_Done_T pits_pps_send_usbtest_req(const PITS_Message_T * message)
{

   int8_t fp;
   int16_t temp_file_created;
   int16_t nor_writting_ok;
   uint8_t offset_usbdtc = 0;
   int32_t num_written = 0;
   if (NULL != message)
   {
      temp_file_created = Create_Temp_File_Copy_Of_Nor();
      if(temp_file_created)
      {
         offset_usbdtc = 0;
         fp = open("/tmp/Nor_Copy", O_WRONLY, 0);
         if(0 <= fp)
         {
           lseek(fp, offset_usbdtc, SEEK_SET);

           if (write_enable)
           {
              num_written = write(fp, &buffer_ps[0], 4);
              PBC_Ensure_1((num_written == 4),"Failed written %d bytes", num_written);
              
              close(fp);
              nor_writting_ok = Write_Temp_File_Copy_To_Nor();
              UNUSED_PARAM(nor_writting_ok);
              write_enable = false;
           }
           else
           {
              close(fp);
           }

         }
      }
   }
   return (DONE);
}

Done_Or_Not_Done_T pits_pps_send_usbset_req(const PITS_Message_T * message)
{

   int8_t fp;
   int16_t temp_file_created;
   int16_t nor_writting_ok;
   uint8_t offset_usbdtc = 0;
   int32_t num_written = 0;
   if (NULL != message)
   {
      temp_file_created = Create_Temp_File_Copy_Of_Nor();
      if(temp_file_created)
      {
         offset_usbdtc = 0;
         buffer_ps[0] = 0x05;
         buffer_ps[1] = 0x05;
         buffer_ps[2] = 0x05;
         buffer_ps[3] = 0x05;
         fp = open("/tmp/Nor_Copy", O_WRONLY, 0);
         if(0 <= fp)
         {
           lseek(fp, offset_usbdtc, SEEK_SET);

              num_written = write(fp, &buffer_ps[0], 4);
              PBC_Ensure_1((num_written == 4),"Failed written %d bytes", num_written);
              close(fp);
              nor_writting_ok = Write_Temp_File_Copy_To_Nor();
              UNUSED_PARAM(nor_writting_ok);
         }
      }
   }
   return (DONE);
}

Done_Or_Not_Done_T pits_pps_send_usbset9_req(const PITS_Message_T * message)
{

   /*int8_t fp;
   int16_t temp_file_created;
   int16_t nor_writting_ok;
   uint8_t offset_usbdtc = 0;
   int32_t num_written = 0;*/
   uint8_t pit_index = 0;
   uint8_t pit_stub = 0;

   if (NULL != message)
   {
      /*temp_file_created = Create_Temp_File_Copy_Of_Nor();
      if(temp_file_created)
      {
         offset_usbdtc = 0;
         buffer_ps[0] = 0x13;
         buffer_ps[1] = 0x17;
         buffer_ps[2] = 0x11;
         buffer_ps[3] = 0x05;
         fp = open("/tmp/Nor_Copy", O_WRONLY, 0);
         if(0 <= fp)
         {
           lseek(fp, offset_usbdtc, SEEK_SET);

              num_written = write(fp, &buffer_ps[0], 4);
              close(fp);
              nor_writting_ok = Write_Temp_File_Copy_To_Nor();


         }
      }*/

      if (message->data[0] == 0x01)
      {
         pit_stub = 0xAA;
      }
      else if (message->data[0] == 0x04)
      {
         pit_stub = 0xBB;
      }
      else if (message->data[0] == 0x06)
      {
         pit_stub = 0xCC;
      }
      pits_md_stored_value[message->data[0]][0] = PITS_CHKSUM_COMPLETE;
      for (pit_index = 0; pit_index < PITS_MDS_CHKSUM_SIZE-1; pit_index++)
      {
         pits_md_stored_value[message->data[0]][pit_index+1] = pit_stub;
      }
      mds_test_execute = true;
   }
   return (DONE);
}

Done_Or_Not_Done_T pits_pps_set_reflash_req(const PITS_Message_T * message)
{
   uint8_t pits_reflash_status = 3;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   
   if (NULL != message)
   {
      pps_message.bus = 0x00;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_START_REFLASH_ACK;
      memset(&pps_tx_data[0], 0, 2);
      pps_message.data_size = 2;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("MFG REFLASH REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pits_reflash_status = Pits_Get_Reflash_Status();
         if (message->data[0] == 0)
         {
            if (pits_reflash_status < 4)
            {
               pps_tx_data[1] = pits_reflash_status; /* Return Status */
            }
            else
            {
               pps_tx_data[1] = 4;  /*Reserved*/
            }
         }
         else if (message->data[0] == 1)
         {
            if ((pits_reflash_status == 0)||(pits_reflash_status == 3))
            {
               Pits_Set_Reflash_Process();
               pps_tx_data[1] = 0x01;  /* Respond in progress*/
            }
            else if (pits_reflash_status == 1)
            {
               pps_tx_data[1] = pits_reflash_status;
            }
            else if (pits_reflash_status == 2)
            {
               /* Already reflashed report Fail and complete */
               pps_tx_data[0] = (uint8_t) FAIL;
               pps_tx_data[1] = pits_reflash_status;
            }
            else
            {
               pps_tx_data[0] = (uint8_t) FAIL;
            }
         }
         else
         {
            pps_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_pps_test_usbset_req(const PITS_Message_T * message)
{
   if (NULL != message)
   {
      Tr_Fault("PS Data has been removed. Resetting now...");
         SAL_Sleep(500);                                 /* Allow time for trace message to be printed */
         VIP_Send(VIPP_EV_RESET_REQUEST, NULL, 0);
   }
   return (DONE);
}

/*===========================================================================*
 * FUNCTION: pits_pps_mpi_checksums_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_mpi_checksums_req(const PITS_Message_T * message)
{
   uint8_t pit_stub8 = 0;
   uint16_t pit_stub16 = 0;
   uint32_t pit_stub32 = 0;
   Whole_Vin_T    vin_number = {0};
   Whole_DayTrim_T day_number;
   preset_mgr_zone_num_type zone_index = 0;
   Preset_Type_T presets;
   uint8_t pit_step = 0;
   uint8_t pit_step_two = 0;
   audio_tone_info_type tone_temp;
   uint8_t pit_usb_num_devices = 0;
   DAG_Device_List_T pit_usb_devices;
   char name[20];
   uint16_t pit_all_chksum[5];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = 0xF1;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 50);
      pps_message.data_size = 50;

      pps_tx_data[0] = (uint8_t) SUCCESS;
      if (message->data[0] == 2)
      {
         pit_usb_num_devices = DAG_Diag_Get_Num_Dev_List();
         pit_stub16 = 0;
         for (pit_step = 0; pit_step < 11; pit_step++)
         {
            if (pit_usb_num_devices > pit_step)
            {
               pit_usb_devices = DAG_Diag_Get_Device_List(pit_step + 1);
               if ((pit_usb_devices.device_type == DAG_DEVICE_MSD)||(pit_usb_devices.device_type == DAG_DEVICE_MTP))
               {
                  pit_stub16 = pit_stub16 + ((pit_usb_devices.version_id >> 24)&0x000000FF) + ((pit_usb_devices.version_id >> 16)&0x000000FF) + ((pit_usb_devices.version_id >> 8)&0x000000FF) + ((pit_usb_devices.version_id)&0x000000FF);
                  pit_stub16 = pit_stub16 + ((pit_usb_devices.product_id >> 24)&0x000000FF) + ((pit_usb_devices.product_id >> 16)&0x000000FF) + ((pit_usb_devices.product_id >> 8)&0x000000FF) + ((pit_usb_devices.product_id)&0x000000FF);
               }
               if (pit_usb_devices.device_type == DAG_DEVICE_IPOD)
               {
                  pit_stub16 = pit_stub16 + (pit_usb_devices.iPod_info.iPodSwVers.major) + (pit_usb_devices.iPod_info.iPodSwVers.minor) + pit_usb_devices.iPod_info.iPodSwVers.revision;
                  pit_stub16 = pit_stub16 + pit_usb_devices.iPod_info.iPodModelNumber[0] + pit_usb_devices.iPod_info.iPodModelNumber[1] + pit_usb_devices.iPod_info.iPodModelNumber[2] + pit_usb_devices.iPod_info.iPodModelNumber[3];
                  pit_stub16 = pit_stub16 + pit_usb_devices.iPod_info.iPodModelNumber[4] + pit_usb_devices.iPod_info.iPodModelNumber[5] + pit_usb_devices.iPod_info.iPodModelNumber[6];
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.general.major + pit_usb_devices.pbk_lingo.general.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.display_remote.major + pit_usb_devices.pbk_lingo.display_remote.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.extended.major + pit_usb_devices.pbk_lingo.extended.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.digital_audio.major + pit_usb_devices.pbk_lingo.digital_audio.minor;
               }
            }
         }
         pps_tx_data[1] = 14;
         pps_message.data_size = 10 + pps_tx_data[1];
         snprintf(name, sizeof(name), "Block_CRC_IPOD");
         memcpy(&pps_tx_data[2],&name[0],pps_tx_data[1]);
         pps_tx_data[16] = 0;
         pps_tx_data[17] = 0;
         pps_tx_data[18] = 0;
         pps_tx_data[19] = 87; /*size of the block*/
         pps_tx_data[20] = 0;
         pps_tx_data[21] = 2;
         pps_tx_data[22] = pit_stub16>>8;
         pps_tx_data[23] = pit_stub16;
      }

      if (message->data[0] == 3)
      {
         pit_stub16 = 0;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x01);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x02);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x03);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x11);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x06);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0A);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0B);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0C);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x04);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x05);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x08);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x13);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;

         pps_tx_data[1] = 16;
         pps_message.data_size = 10 + pps_tx_data[1];
         snprintf(name, sizeof(name), "Block_CRC_AUD_EQ");
         memcpy(&pps_tx_data[2],&name[0],pps_tx_data[1]);
         pps_tx_data[18] = 0;
         pps_tx_data[19] = 0;
         pps_tx_data[20] = 0;
         pps_tx_data[21] = 56; /*size of the block*/
         pps_tx_data[22] = 0;
         pps_tx_data[23] = 2;
         pps_tx_data[24] = pit_stub16>>8;
         pps_tx_data[25] = pit_stub16;
      }

      if (message->data[0] == 4)
      {
         pit_stub16 = 0;
         for (pit_step = 0; pit_step < 5; pit_step++)
         {
            for (pit_step_two = 0; pit_step_two < 6; pit_step_two++)
            {
               pit_stub8 = 0;
               presets = Preset_PS_Get_Preset_Data(zone_index, pit_step, pit_step_two);
               if (presets.tuner_info.band == 0)
               {
                  pit_stub8 = 0x10;
               }
               if (presets.tuner_info.band == 1)
               {
                  pit_stub8 = 0x20;
               }
               if (presets.tuner_info.band == 2)
               {
                  pit_stub8 = 0x30;
               }
               pit_stub8 |= (Pits_Get_Param_Band_Value(zone_index, pit_step, pit_step_two))>>8;
               pit_stub16 = pit_stub16 + pit_stub8;
               pit_stub16 = pit_stub16 + ((Pits_Get_Param_Band_Value(zone_index, pit_step, pit_step_two))&0x00FF);
               pit_stub16 = pit_stub16 + presets.tuner_info.pi;
            }
         }
         pps_tx_data[1] = 17;
         pps_message.data_size = 10 + pps_tx_data[1];
         snprintf(name, sizeof(name), "Block_CRC_Presets");
         memcpy(&pps_tx_data[2],&name[0],pps_tx_data[1]);
         pps_tx_data[19] = 0;
         pps_tx_data[20] = 0;
         pps_tx_data[21] = 0;
         pps_tx_data[22] = 90; /*size of the block*/
         pps_tx_data[23] = 0;
         pps_tx_data[24] = 2;
         pps_tx_data[25] = pit_stub16>>8;
         pps_tx_data[26] = pit_stub16;
      }

      if (message->data[0] == 5)
      {
         Theft_PS_Get_Whole_VIN(vin_number);
         Mfg_PS_Get_RTC_Daytrim(day_number);
         pit_stub16 = day_number[0];
         for (pit_stub8 = 0; pit_stub8 < 16; pit_stub8++)
         {
            pit_stub16 = pit_stub16 + vin_number[pit_stub8];
         }
         pps_tx_data[1] = 15;
         pps_message.data_size = 10 + pps_tx_data[1];
         snprintf(name, sizeof(name), "Block_CRC_Theft");
         memcpy(&pps_tx_data[2],&name[0],pps_tx_data[1]);
         pps_tx_data[17] = 0;
         pps_tx_data[18] = 0;
         pps_tx_data[19] = 0;
         pps_tx_data[20] = 17; /*size of the block*/
         pps_tx_data[21] = 0;
         pps_tx_data[22] = 2;
         pps_tx_data[23] = pit_stub16>>8;
         pps_tx_data[24] = pit_stub16;
      }

      if (message->data[0] == 0)
      {
         pit_all_chksum[0] = message->data[1];
         pit_all_chksum[0] = ((pit_all_chksum[0]<<8)&0xFF00)+message->data[2];
         /* USB CHKSUM*/
         pit_usb_num_devices = DAG_Diag_Get_Num_Dev_List();
         pit_stub16 = 0;
         for (pit_step = 0; pit_step < 11; pit_step++)
         {
            if (pit_usb_num_devices > pit_step)
            {
               pit_usb_devices = DAG_Diag_Get_Device_List(pit_step + 1);
               if ((pit_usb_devices.device_type == DAG_DEVICE_MSD)||(pit_usb_devices.device_type == DAG_DEVICE_MTP))
               {
                  pit_stub16 = pit_stub16 + ((pit_usb_devices.version_id >> 24)&0x000000FF) + ((pit_usb_devices.version_id >> 16)&0x000000FF) + ((pit_usb_devices.version_id >> 8)&0x000000FF) + ((pit_usb_devices.version_id)&0x000000FF);
                  pit_stub16 = pit_stub16 + ((pit_usb_devices.product_id >> 24)&0x000000FF) + ((pit_usb_devices.product_id >> 16)&0x000000FF) + ((pit_usb_devices.product_id >> 8)&0x000000FF) + ((pit_usb_devices.product_id)&0x000000FF);
               }
               if (pit_usb_devices.device_type == DAG_DEVICE_IPOD)
               {
                  pit_stub16 = pit_stub16 + (pit_usb_devices.iPod_info.iPodSwVers.major) + (pit_usb_devices.iPod_info.iPodSwVers.minor) + pit_usb_devices.iPod_info.iPodSwVers.revision;
                  pit_stub16 = pit_stub16 + pit_usb_devices.iPod_info.iPodModelNumber[0] + pit_usb_devices.iPod_info.iPodModelNumber[1] + pit_usb_devices.iPod_info.iPodModelNumber[2] + pit_usb_devices.iPod_info.iPodModelNumber[3];
                  pit_stub16 = pit_stub16 + pit_usb_devices.iPod_info.iPodModelNumber[4] + pit_usb_devices.iPod_info.iPodModelNumber[5] + pit_usb_devices.iPod_info.iPodModelNumber[6];
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.general.major + pit_usb_devices.pbk_lingo.general.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.display_remote.major + pit_usb_devices.pbk_lingo.display_remote.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.extended.major + pit_usb_devices.pbk_lingo.extended.minor;
                  pit_stub16 = pit_stub16 + pit_usb_devices.pbk_lingo.digital_audio.major + pit_usb_devices.pbk_lingo.digital_audio.minor;
               }
            }
         }
         pit_all_chksum[1] = pit_stub16;
         /*Audio CHKSUM*/
         pit_stub16 = 0;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x01);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x02);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x03);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x11);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x06);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0A);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0B);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0C);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x04);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x05);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x08);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x13);
         pit_stub16 = pit_stub16 + tone_temp.EQ_mode + tone_temp.bass + tone_temp.mid + tone_temp.treble;
         pit_all_chksum[2] = pit_stub16;
         /* Presets CHKSUM*/
         pit_stub16 = 0;
         for (pit_step = 0; pit_step < 5; pit_step++)
         {
            for (pit_step_two = 0; pit_step_two < 6; pit_step_two++)
            {
               pit_stub8 = 0;
               presets = Preset_PS_Get_Preset_Data(zone_index, pit_step, pit_step_two);
               if (presets.tuner_info.band == 0)
               {
                  pit_stub8 = 0x10;
               }
               if (presets.tuner_info.band == 1)
               {
                  pit_stub8 = 0x20;
               }
               if (presets.tuner_info.band == 2)
               {
                  pit_stub8 = 0x30;
               }
               pit_stub8 |= (Pits_Get_Param_Band_Value(zone_index, pit_step, pit_step_two))>>8;
               pit_stub16 = pit_stub16 + pit_stub8;
               pit_stub16 = pit_stub16 + ((Pits_Get_Param_Band_Value(zone_index, pit_step, pit_step_two))&0x00FF);
               pit_stub16 = pit_stub16 + presets.tuner_info.pi;
            }
         }
         pit_all_chksum[3] = pit_stub16;
         /* Theft CHKSUM*/
         Theft_PS_Get_Whole_VIN(vin_number);
         Mfg_PS_Get_RTC_Daytrim(day_number);
         pit_stub16 = day_number[0];
         for (pit_stub8 = 0; pit_stub8 < 16; pit_stub8++)
         {
            pit_stub16 = pit_stub16 + vin_number[pit_stub8];
         }
         pit_all_chksum[4] = pit_stub16;
         /*Calculate all checksums*/
         pit_stub32 = 0;
         for (pit_stub8 = 0; pit_stub8 < 5; pit_stub8++)
         {
            pit_stub32 = pit_stub32 + pit_all_chksum[pit_stub8];
         }
         pps_tx_data[1] = 15;
         pps_message.data_size = 12 + pps_tx_data[1];
         snprintf(name, sizeof(name), "Block_CRC_Final");
         memcpy(&pps_tx_data[2],&name[0],pps_tx_data[1]);
         pps_tx_data[17] = 0;
         pps_tx_data[18] = 0;
         pps_tx_data[19] = 0;
         pps_tx_data[20] = 10; /*size of the block*/
         pps_tx_data[21] = 0;
         pps_tx_data[22] = 4;
         pps_tx_data[23] = pit_stub32>>24;
         pps_tx_data[24] = pit_stub32>>16;
         pps_tx_data[25] = pit_stub32>>8;
         pps_tx_data[26] = pit_stub32;

      }

   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&pps_message));
}

/*===========================================================================*
 * FUNCTION: pits_pps_network_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_network_req(const PITS_Message_T * message)
{
   int8_t ret;
   char name[20];

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x1F;
      pps_message.MID = 0xE1;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 20);

      pps_tx_data[0] = (uint8_t) SUCCESS;
      pps_message.data_size = 3;
      pps_tx_data[2] = 0;

      if (message->data[0] == 1)
      {
         pits_network_state = 1;
         ret = system("ifconfig eth0 up 192.168.53.53");
         ret = system ("sync");
         PBC_Ensure((ret != -1),"Failed system call sync");
      }
      if (message->data[0] == 2)
      {
         pits_network_state = 0;
         ret = system("ifconfig eth0 down 192.168.53.53");
         ret = system ("sync");
         PBC_Ensure((ret != -1),"Failed system call sync");
      }

      pps_tx_data[1] = pits_network_state;

      if (pits_network_state == 1)
      {
         pps_message.data_size = 16;
         pps_tx_data[2] = 13;
         snprintf(name, sizeof(name), "192.168.53.53");
         memcpy(&pps_tx_data[3],&name[0],13);
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&pps_message));
}


static uint32_t PITS_PPS_CRC_Calculate_Chksum (const uint8_t *data, uint8_t block_length, uint32_t crc_data)
{
   /* calculates a byte by byte CRC checksum and returns a 4 byte value in crc_value*/
   uint8_t   byte_value;   /* 8 bit value*/
   uint8_t bytes_read;
   uint32_t   address;/* memory address*/
   uint32_t   crc_value;
   uint32_t table[ 256 ] =/* CRC table calculated by Randy Sencaj*/
   {
   0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
   0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
   0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
   0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
   0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
   0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
   0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
   0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
   0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
   0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
   0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
   0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
   0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
   0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
   0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
   0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
   0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
   0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
   0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
   0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
   0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
   0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
   0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
   0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
   0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
   0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
   0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
   0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
   0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
   0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
   0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
   0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
   };

   address = 0;/* assign a starting address*/
   crc_value = crc_data;/* initialize crc*/
   bytes_read = 0;/* keep track of the number of bytes that were read*/

   while( bytes_read < block_length )     /* read each byte in the memory block*/
   {
       byte_value = data[address];/* get one byte from product memory*/
      /*update the CRC
       the new byte just read is XORed with the current CRC to get a value from the table
       the table value is then XORed with the current CRC shifted right 8 times (8 bits)
       ^ is the XOR operator, >> is the shift right operator, & is the AND operator*/
#ifndef LINEAR_SPACE
       crc_value = ((crc_value >> 8) & 0x00FFFFFF) ^ table[ (crc_value ^ byte_value)& 0xFF ];
#else  /*a+b = b+a checksum method may be needed for further requirement,20131126 by fuxiang*/
			 crc_value = (crc_value & 0xFFFFFFFF) ^ table[ byte_value & 0xFF ];
#endif
       bytes_read = bytes_read + 1;
       address = address + 1;
   }
   return (crc_value);
}

#if 0
static void PITS_PPS_CRC_Chksum_Align_Cal (const uint8_t *data, uint8_t block_length)
{
   uint8_t pps_chksum_stub[20];
   uint8_t  pit_size = 0;
   uint8_t  pit_index = 0;

   pit_size = block_length+6;
   memset(&pps_chksum_stub[0], 0x00, pit_size+1);

   for (pit_index = 0; pit_index < block_length; pit_index++)
   {
      pps_chksum_stub[pit_index] = data[pit_index];
   }
   pps_chksum_stub[block_length] = AMFM_Mgr_Get_FM_WBAM_Values(1);
   pps_chksum_stub[block_length+1] = AMFM_Mgr_Get_FM_WBAM_Values(0);
   pps_chksum_stub[block_length+2] = AMFM_Mgr_Get_FM_USN_Values(1);
   pps_chksum_stub[block_length+3] = AMFM_Mgr_Get_FM_USN_Values(0);
   pps_chksum_stub[block_length+4] =  AMFM_Mgr_Get_AM_USN_Values(1);
   pps_chksum_stub[block_length+5] = AMFM_Mgr_Get_AM_USN_Values(0);
   pit_crc_align_cal_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}

static void PITS_PPS_CRC_Chksum_Ymem (const uint8_t *data, uint8_t block_length)
{
   uint8_t pps_chksum_stub[65];
   uint8_t  pit_size = 0;
   uint8_t  pit_index = 0;

   pit_size = block_length;
   memset(&pps_chksum_stub[0], 0x00, pit_size+1);

   for (pit_index = 0; pit_index < block_length; pit_index++)
   {
      pps_chksum_stub[pit_index] = data[pit_index];
   }

   pit_crc_ymem_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);

}

static void PITS_PPS_CRC_Chksum_Product_id (const uint8_t *data, uint8_t block_length)
{

   uint8_t pps_chksum_stub[22];
   uint8_t  pit_size = 0;
   uint8_t  pit_index = 0;
   Disc_Pbk_Diag_Playback_Levels_t playback_levels = Disc_Pbk_Diag_Get_Playback_Levels();
   pit_size = 2 + block_length;

   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   /*(parameter == 0x0022)*/
   pps_chksum_stub[block_length] = playback_levels.hw_level;
   pps_chksum_stub[block_length+1] = playback_levels.sw_level;

   for (pit_index = 0; pit_index < block_length; pit_index++)
   {
      pps_chksum_stub[pit_index] = data[pit_index];
   }

   pit_crc_product_id_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}
#endif

static void PITS_PPS_CRC_Chksum_Xmem (const uint8_t *data, uint8_t block_length)
{
   uint8_t pps_chksum_stub[65];
   uint8_t  pit_size = 0;
   uint8_t  pit_index = 0;

   if (block_length <= 64)
   {
      pit_size = block_length;
      memset(&pps_chksum_stub[0], 0x00, pit_size+1);

      for (pit_index = 0; pit_index < block_length; pit_index++)
      {
         pps_chksum_stub[pit_index] = data[pit_index];
      }

      pit_crc_ymem_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, pit_crc_ymem_chksum);
   }
}

#if 0
static void PITS_PPS_CRC_Chksum_Mic_Diag (void)
{
   uint8_t pps_chksum_stub[60];
   uint16_t pit_stub16 = 0;
   uint8_t  pit_size = 56;

   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   /*(parameter == 0x0024)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0N_MIN);
      pps_chksum_stub[0] = pit_stub16 >> 8;
      pps_chksum_stub[1] = pit_stub16;
   /*(parameter == 0x0025)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_05_MIN);
      pps_chksum_stub[2] = pit_stub16 >> 8;
      pps_chksum_stub[3] = pit_stub16;
   /*(parameter == 0x0026)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0E_MIN);
      pps_chksum_stub[4] = pit_stub16 >> 8;
      pps_chksum_stub[5] = pit_stub16;
   /*(parameter == 0x0027)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_12_MIN);
      pps_chksum_stub[6] = pit_stub16 >> 8;
      pps_chksum_stub[7] = pit_stub16;
   /*(parameter == 0x0028)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_02_MIN);
      pps_chksum_stub[8] = pit_stub16 >> 8;
      pps_chksum_stub[9] = pit_stub16;
   /*(parameter == 0x0029)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_01_MIN);
      pps_chksum_stub[10] = pit_stub16 >> 8;
      pps_chksum_stub[11] = pit_stub16;
   /*(parameter == 0x002A)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_18_MIN);
      pps_chksum_stub[12] = pit_stub16 >> 8;
      pps_chksum_stub[13] = pit_stub16;
   /*(parameter == 0x002B)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0N_MAX);
      pps_chksum_stub[14] = pit_stub16 >> 8;
      pps_chksum_stub[15] = pit_stub16;
   /*(parameter == 0x002C)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_05_MAX);
      pps_chksum_stub[16] = pit_stub16 >> 8;
      pps_chksum_stub[17] = pit_stub16;
   /*(parameter == 0x002D)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0E_MAX);
      pps_chksum_stub[18] = pit_stub16 >> 8;
      pps_chksum_stub[19] = pit_stub16;
   /*(parameter == 0x002E)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_12_MAX);
      pps_chksum_stub[20] = pit_stub16 >> 8;
      pps_chksum_stub[21] = pit_stub16;
   /*(parameter == 0x002F)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_02_MAX);
      pps_chksum_stub[22] = pit_stub16 >> 8;
      pps_chksum_stub[23] = pit_stub16;
   /*(parameter == 0x0030)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_01_MAX);
      pps_chksum_stub[24] = pit_stub16 >> 8;
      pps_chksum_stub[25] = pit_stub16;
   /*(parameter == 0x0031)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_18_MAX);
      pps_chksum_stub[26] = pit_stub16 >> 8;
      pps_chksum_stub[27] = pit_stub16;
   /*(parameter == 0x0032)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0N_MIN);
      pps_chksum_stub[28] = pit_stub16 >> 8;
      pps_chksum_stub[29] = pit_stub16;
   /*(parameter == 0x0033)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_05_MIN);
      pps_chksum_stub[30] = pit_stub16 >> 8;
      pps_chksum_stub[31] = pit_stub16;
   /*(parameter == 0x0034)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0E_MIN);
      pps_chksum_stub[32] = pit_stub16 >> 8;
      pps_chksum_stub[33] = pit_stub16;
   /*(parameter == 0x0035)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_12_MIN);
      pps_chksum_stub[34] = pit_stub16 >> 8;
      pps_chksum_stub[35] = pit_stub16;
   /*(parameter == 0x0036)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_02_MIN);
      pps_chksum_stub[36] = pit_stub16 >> 8;
      pps_chksum_stub[37] = pit_stub16;
   /*(parameter == 0x0037)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_01_MIN);
      pps_chksum_stub[38] = pit_stub16 >> 8;
      pps_chksum_stub[39] = pit_stub16;
   /*(parameter == 0x0038)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_18_MIN);
      pps_chksum_stub[40] = pit_stub16 >> 8;
      pps_chksum_stub[41] = pit_stub16;
   /*(parameter == 0x0039)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0N_MAX);
      pps_chksum_stub[42] = pit_stub16 >> 8;
      pps_chksum_stub[43] = pit_stub16;
   /*(parameter == 0x003A)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_05_MAX);
      pps_chksum_stub[44] = pit_stub16 >> 8;
      pps_chksum_stub[45] = pit_stub16;
   /*(parameter == 0x003B)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0E_MAX);
      pps_chksum_stub[46] = pit_stub16 >> 8;
      pps_chksum_stub[47] = pit_stub16;
   /*(parameter == 0x003C)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_12_MAX);
      pps_chksum_stub[48] = pit_stub16 >> 8;
      pps_chksum_stub[49] = pit_stub16;
   /*(parameter == 0x003D)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_02_MAX);
      pps_chksum_stub[50] = pit_stub16 >> 8;
      pps_chksum_stub[51] = pit_stub16;
   /*(parameter == 0x003E)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_01_MAX);
      pps_chksum_stub[52] = pit_stub16 >> 8;
      pps_chksum_stub[53] = pit_stub16;
   /*(parameter == 0x003F)*/
      pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_18_MAX);
      pps_chksum_stub[54] = pit_stub16 >> 8;
      pps_chksum_stub[55] = pit_stub16;

      pit_crc_mic_diag_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}

static void PITS_PPS_CRC_Chksum_DG_Error (void)/*341*/
{
   uint8_t pps_chksum_stub[8];
   uint8_t  pit_size = 7;

   Disc_Pbk_Diag_Playback_Error_t pit_errors;
   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   pit_errors = Disc_Pbk_Diag_Get_Playback_Error();

   /* (parameter == 0x0025)*/
   pps_chksum_stub[0] = pit_errors.error_count.cd_focus;
   /*(parameter == 0x0026)*/
   pps_chksum_stub[1] = pit_errors.error_count.cd_tracking;
   /*(parameter == 0x0027)*/
   pps_chksum_stub[2] = pit_errors.error_count.cd_load_eject;
   /*(parameter == 0x0028)*/
   pps_chksum_stub[3] = pit_errors.error_count.dvd_play;
   /*(parameter == 0x0029)*/
   pps_chksum_stub[4] = pit_errors.error_count.dvd_region_code;
   /*(parameter ==0x002A)*/
   pps_chksum_stub[5] = pit_errors.error_count.dvd_load_eject;
   /*(parameter == 0x002B)*/
   pps_chksum_stub[6] = pit_errors.error_count.dvd_format;

   pit_crc_error_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}
static void PITS_PPS_CRC_Chksum_Theft (void)
{
   uint8_t pps_chksum_stub[20];
   uint8_t  pit_size = 18;
   Whole_Vin_T    vin_number = {0};
   Whole_DayTrim_T day_number;

   Theft_PS_Get_Whole_VIN(vin_number);
   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   pps_chksum_stub[0] = pits_vip_brightness;  /*include vip brigthness */
   /*if (parameter == 0x0198)*/
   Mfg_PS_Get_RTC_Daytrim(day_number);
   pps_chksum_stub[1] = day_number[0];
   /*(parameter == 0x0199)*/
   pps_chksum_stub[2] = vin_number[0];
   /*(parameter == 0x019A)*/
   pps_chksum_stub[3] = vin_number[1];
   /*(parameter == 0x019B)*/
   pps_chksum_stub[4] = vin_number[2];
   /*(parameter == 0x019C)*/
   pps_chksum_stub[5] = vin_number[3];
   /*(parameter == 0x019D)*/
   pps_chksum_stub[6] = vin_number[4];
   /*(parameter == 0x019E)*/
   pps_chksum_stub[7] = vin_number[5];
   /*(parameter == 0x019F)*/
   pps_chksum_stub[8] = vin_number[6];
   /*(parameter == 0x01A0)*/
   pps_chksum_stub[9] = vin_number[7];
   /*(parameter == 0x01A1)*/
   pps_chksum_stub[10] = vin_number[8];
   /*(parameter == 0x01A2)*/
   pps_chksum_stub[11] = vin_number[9];
   /*(parameter == 0x01A3)*/
   pps_chksum_stub[12] = vin_number[10];
   /*(parameter == 0x01A4)*/
   pps_chksum_stub[13] = vin_number[11];
   /*(parameter == 0x01A5)*/
   pps_chksum_stub[14] = vin_number[12];
   /*(parameter == 0x01A6)*/
   pps_chksum_stub[15] = vin_number[13];
   /*(parameter == 0x01A7)*/
   pps_chksum_stub[16] = vin_number[14];
   /*(parameter == 0x01A8)*/
   pps_chksum_stub[17] = vin_number[15];

   pit_crc_theft_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}

static void PITS_PPS_CRC_Chksum_USB (void)
{
   uint8_t pps_chksum_stub[40];
   uint16_t  pit_size = 31;
   uint8_t  pit_index = 0;
   uint8_t pit_usb_num_devices = DAG_Diag_Get_Num_Dev_List();
   DAG_Device_List_T pit_usb_devices;
   uint32_t pit_crc_initial = PITS_INITIAL_CRC_VALUE;

   for (pit_index = 0; pit_index < 11; pit_index++)
   {
      memset(&pps_chksum_stub[0], 0x00, pit_size+1);
      if (pit_usb_num_devices > pit_index)
      {
         pit_usb_devices = DAG_Diag_Get_Device_List(pit_index+1);
         if ((pit_usb_devices.device_type == DAG_DEVICE_MSD)||(pit_usb_devices.device_type == DAG_DEVICE_MTP))
         {
            pps_chksum_stub[0] = pit_usb_devices.version_id >> 24;
            pps_chksum_stub[1] = pit_usb_devices.version_id >> 16;
            pps_chksum_stub[2] = pit_usb_devices.version_id >> 8;
            pps_chksum_stub[3] = pit_usb_devices.version_id;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_MSD)||(pit_usb_devices.device_type == DAG_DEVICE_MTP))
         {
            pps_chksum_stub[4] = 0;
            pps_chksum_stub[5] = pit_usb_devices.product_id >> 24;
            pps_chksum_stub[6] = pit_usb_devices.product_id >> 16;
            pps_chksum_stub[7] = pit_usb_devices.product_id >> 8;
            pps_chksum_stub[8] = pit_usb_devices.product_id;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[9] = pit_usb_devices.iPod_info.iPodSwVers.major;
            pps_chksum_stub[10] = pit_usb_devices.iPod_info.iPodSwVers.minor;
            pps_chksum_stub[11] = pit_usb_devices.iPod_info.iPodSwVers.revision;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[12] = pit_usb_devices.iPod_info.iPodModelNumber[0];
            pps_chksum_stub[13] = pit_usb_devices.iPod_info.iPodModelNumber[1];
            pps_chksum_stub[14] = pit_usb_devices.iPod_info.iPodModelNumber[2];
            pps_chksum_stub[15] = pit_usb_devices.iPod_info.iPodModelNumber[3];
            pps_chksum_stub[16] = pit_usb_devices.iPod_info.iPodModelNumber[4];
            pps_chksum_stub[17] = pit_usb_devices.iPod_info.iPodModelNumber[5];
            pps_chksum_stub[18] = pit_usb_devices.iPod_info.iPodModelNumber[6];
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[19] = 0;
            pps_chksum_stub[20] = pit_usb_devices.pbk_lingo.general.major;
            pps_chksum_stub[21] = pit_usb_devices.pbk_lingo.general.minor;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[22] = 0;
            pps_chksum_stub[23] = pit_usb_devices.pbk_lingo.display_remote.major;
            pps_chksum_stub[24] = pit_usb_devices.pbk_lingo.display_remote.minor;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[25] = 0;
            pps_chksum_stub[26] = pit_usb_devices.pbk_lingo.extended.major;
            pps_chksum_stub[27] = pit_usb_devices.pbk_lingo.extended.minor;
         }
         if ((pit_usb_devices.device_type == DAG_DEVICE_IPOD))
         {
            pps_chksum_stub[28] = 0;
            pps_chksum_stub[29] = pit_usb_devices.pbk_lingo.digital_audio.major;
            pps_chksum_stub[30] = pit_usb_devices.pbk_lingo.digital_audio.minor;
         }
      }
      pit_crc_initial = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, pit_crc_initial);
   }

   pit_crc_usb_info_chksum = pit_crc_initial;

}

static void PITS_PPS_CRC_Chksum_Audio_Eq (void)
{
   uint8_t pps_chksum_stub[62];
   uint8_t  pit_size = 60;
   preset_mgr_zone_num_type zone_index = 0;
   audio_tone_info_type tone_temp;

   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   /*(parameter == 0x00AA)*/
   pps_chksum_stub[0] = Audio_PS_Get_Volume(zone_index);
   /*(parameter == 0x00B0)*/
   pps_chksum_stub[1] = Audio_PS_Get_Fade(zone_index);
   /*(parameter == 0x00B1)*/
   pps_chksum_stub[2] = Audio_PS_Get_Balance(zone_index);
   /*(parameter == 0x00B3)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
   pps_chksum_stub[3] = tone_temp.EQ_mode;
   /*(parameter == 0x00B4)*/
   pps_chksum_stub[4] = tone_temp.bass;
   /*(parameter == 0x00B5)*/
   pps_chksum_stub[5] = tone_temp.mid;
   /*(parameter == 0x00B6)*/
   pps_chksum_stub[6] = tone_temp.treble;
   /*(parameter == 0x00B7)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x01);
   pps_chksum_stub[7] = tone_temp.EQ_mode;
   /*(parameter == 0x00B8)*/
   pps_chksum_stub[8] = tone_temp.bass;
   /*(parameter == 0x00B9)*/
   pps_chksum_stub[9] = tone_temp.mid;
   /*(parameter == 0x00BA)*/
   pps_chksum_stub[10] = tone_temp.treble;
   /*(parameter == 0x00BB)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0);
   pps_chksum_stub[11] = tone_temp.EQ_mode;
   /*(parameter == 0x00BC)*/
   pps_chksum_stub[12] = tone_temp.bass;
   /*(parameter == 0x00BD)*/
   pps_chksum_stub[13] = tone_temp.mid;
   /*(parameter == 0x00BE)*/
   pps_chksum_stub[14] = tone_temp.treble;
   /*(parameter == 0x00BF)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x02);
   pps_chksum_stub[15] = tone_temp.EQ_mode;
   /*(parameter == 0x00C0)*/
   pps_chksum_stub[16] = tone_temp.bass;
   /*(parameter == 0x00C1)*/
   pps_chksum_stub[17] = tone_temp.mid;
   /*(parameter == 0x00C2)*/
   pps_chksum_stub[18] = tone_temp.treble;
   /*(parameter == 0x00C3)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x03);
   pps_chksum_stub[19] = tone_temp.EQ_mode;
   /*(parameter == 0x00C4)*/
   pps_chksum_stub[20] = tone_temp.bass;
   /*(parameter == 0x00C5)*/
   pps_chksum_stub[21] = tone_temp.mid;
   /*(parameter == 0x00C6)*/
   pps_chksum_stub[22] = tone_temp.treble;
   /*(parameter == 0x00C7)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x11);
   pps_chksum_stub[23] = tone_temp.EQ_mode;
   /*(parameter == 0x00C8)*/
   pps_chksum_stub[24] = tone_temp.bass;
   /*(parameter == 0x00C9)*/
   pps_chksum_stub[25] = tone_temp.mid;
   /*(parameter == 0x00CA)*/
   pps_chksum_stub[26] = tone_temp.treble;
   /*(parameter == 0x00CB)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x06);
   pps_chksum_stub[27] = tone_temp.EQ_mode;
   /*(parameter == 0x00CC)*/
   pps_chksum_stub[28] = tone_temp.bass;
   /*(parameter == 0x00CD)*/
   pps_chksum_stub[29] = tone_temp.mid;
   /*(parameter == 0x00CE)*/
   pps_chksum_stub[30] = tone_temp.treble;
   /*(parameter == 0x00CF)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0A);
   pps_chksum_stub[31] = tone_temp.EQ_mode;
   /*(parameter == 0x00D0)*/
   pps_chksum_stub[32] = tone_temp.bass;
   /*(parameter == 0x00D1)*/
   pps_chksum_stub[33] = tone_temp.mid;
   /*(parameter == 0x00D2)*/
   pps_chksum_stub[34] = tone_temp.treble;
   /*(parameter == 0x00D3)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0B);
   pps_chksum_stub[35] = tone_temp.EQ_mode;
   /*(parameter == 0x00D4)*/
   pps_chksum_stub[36] = tone_temp.bass;
   /*(parameter == 0x00D5)*/
   pps_chksum_stub[37] = tone_temp.mid;
   /*(parameter == 0x00D6)*/
   pps_chksum_stub[38] = tone_temp.treble;
   /*(parameter == 0x00D7)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x0C);
   pps_chksum_stub[39] = tone_temp.EQ_mode;
   /*(parameter == 0x00D8)*/
   pps_chksum_stub[40] = tone_temp.bass;
   /*(parameter == 0x00D9)*/
   pps_chksum_stub[41] = tone_temp.mid;
   /*(parameter == 0x00DA)*/
   pps_chksum_stub[42] = tone_temp.treble;

   /*(parameter == 0x01B0)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x04);
   pps_chksum_stub[43] = tone_temp.EQ_mode;
   /*(parameter == 0x01B1)*/
   pps_chksum_stub[44] = tone_temp.bass;
   /*(parameter == 0x01B2)*/
   pps_chksum_stub[45] = tone_temp.mid;
   /*(parameter == 0x01B3)*/
   pps_chksum_stub[46] = tone_temp.treble;
   /*(parameter == 0x01B4)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x05);
   pps_chksum_stub[47] = tone_temp.EQ_mode;
   /*(parameter == 0x01B5)*/
   pps_chksum_stub[48] = tone_temp.bass;
   /*(parameter == 0x01B6)*/
   pps_chksum_stub[49] = tone_temp.mid;
   /*(parameter == 0x01B7)*/
   pps_chksum_stub[50] = tone_temp.treble;
   /*(parameter == 0x01B8)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x08);
   pps_chksum_stub[51] = tone_temp.EQ_mode;
   /*(parameter == 0x01B9)*/
   pps_chksum_stub[52] = tone_temp.bass;
   /*(parameter == 0x01BA)*/
   pps_chksum_stub[53] = tone_temp.mid;
   /*(parameter == 0x01BB)*/
   pps_chksum_stub[54] = tone_temp.treble;
   /*(parameter == 0x01BC)*/
   tone_temp = Tone_Mgr_Get_Current_Audio_Tone_Per_Src(zone_index,0x13);
   pps_chksum_stub[55] = tone_temp.EQ_mode;
   /*(parameter == 0x01BD)*/
   pps_chksum_stub[56] = tone_temp.bass;
   /*(parameter == 0x01BE)*/
   pps_chksum_stub[57] = tone_temp.mid;
   /*(parameter == 0x01BF)*/
   pps_chksum_stub[58] = tone_temp.treble;
   /*(parameter == 0x00DF)*/
   pps_chksum_stub[59] =  Audio_PS_Get_SCV_Lvl(zone_index);
   pit_crc_audio_eq_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}

static void PITS_PPS_CRC_Chksum_Presets (void)
{
   uint8_t pps_chksum_stub[92];
   uint8_t pps_chksum_send[92];
   uint8_t  pit_size = 91;
   uint8_t  pit_index = 0;
   uint8_t  pit_increment = 0;
   Preset_Type_T presets;
   preset_mgr_zone_num_type zone_index = 0;

   memset(&pps_chksum_stub[0], 0x00, pit_size+1);
   memset(&pps_chksum_send[0], 0x00, pit_size+1);
   /*(parameter == 0x00E7)*/
   pps_chksum_send[0] = Preset_PS_Get_Num_Pages(zone_index);

   for (pit_index = 0; pit_index < 6; pit_index++)
   {
      /*(parameter == 0x00E8)*/
      presets = Preset_PS_Get_Preset_Data(zone_index, pit_index, 0);
      if (presets.tuner_info.band == 0)
      {
         pps_chksum_stub[pit_increment+0] = 0x10;
      }
      if (presets.tuner_info.band == 1)
      {
         pps_chksum_stub[pit_increment+0] = 0x20;
      }
      if (presets.tuner_info.band == 2)
      {
         pps_chksum_stub[pit_increment+0] = 0x30;
      }
      pps_chksum_stub[pit_increment+0] |= (Pits_Get_Param_Band_Value(zone_index, pit_index, 0))>>8;

      /*(parameter == 0x00E9)*/
      pps_chksum_stub[pit_increment+1] = Pits_Get_Param_Band_Value(zone_index, pit_index, 0);
      /*(parameter == 0x00EA)*/
      pps_chksum_stub[pit_increment+2] = presets.tuner_info.pi;

      /*(parameter == 0x00EB)*/
      presets = Preset_PS_Get_Preset_Data(zone_index, pit_index, 1);
      if (presets.tuner_info.band == 0)
      {
         pps_chksum_stub[pit_increment+3] = 0x10;
      }
      if (presets.tuner_info.band == 1)
      {
         pps_chksum_stub[pit_increment+3] = 0x20;
      }
      if (presets.tuner_info.band == 2)
      {
         pps_chksum_stub[pit_increment+3] = 0x30;
      }
      pps_chksum_stub[pit_increment+3] |= (Pits_Get_Param_Band_Value(zone_index, pit_index, 1))>>8;

      /*(parameter == 0x00EC)*/
      pps_chksum_stub[pit_increment+4] = Pits_Get_Param_Band_Value(zone_index, pit_index, 1);
      /*(parameter == 0x00ED)*/
      pps_chksum_stub[pit_increment+5] = presets.tuner_info.pi;

      /*(parameter == 0x00EE)*/
      presets = Preset_PS_Get_Preset_Data(zone_index, pit_index, 2);
      if (presets.tuner_info.band == 0)
      {
         pps_chksum_stub[pit_increment+6] = 0x10;
      }
      if (presets.tuner_info.band == 1)
      {
         pps_chksum_stub[pit_increment+6] = 0x20;
      }
      if (presets.tuner_info.band == 2)
      {
         pps_chksum_stub[pit_increment+6] = 0x30;
      }
      pps_chksum_stub[pit_increment+6] |= (Pits_Get_Param_Band_Value(zone_index, pit_index, 2))>>8;

      /*(parameter == 0x00EF)*/
      pps_chksum_stub[pit_increment+7] = Pits_Get_Param_Band_Value(zone_index, pit_index, 2);
      /*(parameter == 0x00F0)*/
      pps_chksum_stub[pit_increment+8] = presets.tuner_info.pi;

      /*(parameter == 0x00F1)*/
      presets = Preset_PS_Get_Preset_Data(zone_index, pit_index, 3);
      if (presets.tuner_info.band == 0)
      {
         pps_chksum_stub[pit_increment+9] = 0x10;
      }
      if (presets.tuner_info.band == 1)
      {
         pps_chksum_stub[pit_increment+9] = 0x20;
      }
      if (presets.tuner_info.band == 2)
      {
         pps_chksum_stub[pit_increment+9] = 0x30;
      }
      pps_chksum_stub[pit_increment+9] |= (Pits_Get_Param_Band_Value(zone_index, pit_index, 3))>>8;

      /*(parameter == 0x00F2)*/
      pps_chksum_stub[pit_increment+10] = Pits_Get_Param_Band_Value(zone_index, pit_index, 3);
      /*(parameter == 0x00F3)*/
      pps_chksum_stub[pit_increment+11] = presets.tuner_info.pi;

      /*(parameter == 0x00F4)*/
      presets = Preset_PS_Get_Preset_Data(zone_index, pit_index, 4);
      if (presets.tuner_info.band == 0)
      {
         pps_chksum_stub[pit_increment+12] = 0x10;
      }
      if (presets.tuner_info.band == 1)
      {
         pps_chksum_stub[pit_increment+12] = 0x20;
      }
      if (presets.tuner_info.band == 2)
      {
         pps_chksum_stub[pit_increment+12] = 0x30;
      }
      pps_chksum_stub[pit_increment+12] |= (Pits_Get_Param_Band_Value(zone_index, pit_index, 4))>>8;

      /*(parameter == 0x00F5)*/
      pps_chksum_stub[pit_increment+13] = Pits_Get_Param_Band_Value(zone_index, pit_index, 4);
      /*(parameter == 0x00F6)*/
      pps_chksum_stub[pit_increment+14] = presets.tuner_info.pi;

      pit_increment = (pit_index + 1)*15;
   }
   memcpy(&pps_chksum_send[1], &pps_chksum_stub[0], pit_size-1);
   pit_crc_presets_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_send[0], pit_size, PITS_INITIAL_CRC_VALUE);
#endif
/*start add PITS_PPS_CRC_Chksum_Group for group checksum 20131121 by fuxiang */
static void PITS_PPS_CRC_Chksum_Group (void)
{
   uint8_t pps_chksum_stub[236];
   uint8_t pit_size = 236;
   uint8_t pit_index = 0;
   Tuner_Region_Config_T region;
   Tuner_Stopping_Levels_T pit_stopping_levels;
   DTC_Cal_Mask_T dtc_cal_mask;
   Delphi_PN_T dpn;
   Part_Num_T part_num;
   Identify_Code_T identify_code;
   GWM_HW_Version_T hw_version;
   System_Config_T config;
   DTC_Status_T dtc_status;
   Disc_Pbk_Diag_Playback_Error_t dpid8_errors;
   Operation_Time_T radio_time;
   Brightness_Level_T level;
   PITS_Source_T  pits_src = PITS_SRC_NONE;
   DISPLAY_Brightness_T brightness;
   GWM_identify_Num_T num;
   uint16_t pit_stub16;
   PWM_Brighteness_Duty_T duty;
   SSM_Source_T ssm_src = {SSM_SRC_FM, 1};
   pit_index = 0;
   
   /*01001200-01001900*/
   region = PS_Region_Config_Get();
   pps_chksum_stub[0] = region.AM_Range;
   pps_chksum_stub[1] = region.FM_Range;
   pps_chksum_stub[2] = region.AM_Step;
   pps_chksum_stub[3] = region.FM_Step;

   pit_stopping_levels = PS_stopping_levels_Get();
   pps_chksum_stub[4] = pit_stopping_levels.tuner_stoping_levels[1][0];
   pps_chksum_stub[5] = pit_stopping_levels.tuner_stoping_levels[1][1];
   pps_chksum_stub[6] = pit_stopping_levels.tuner_stoping_levels[0][0];
   pps_chksum_stub[7] = pit_stopping_levels.tuner_stoping_levels[0][1];
   /*01001A00*/
   pps_chksum_stub[8] = 0x24;
   /*02000100-02000500*/
   dtc_cal_mask = DTC_Cal_Mask_PS_Get();
   pps_chksum_stub[9] = dtc_cal_mask.dtc_cal_mask[0];
   pps_chksum_stub[10] = dtc_cal_mask.dtc_cal_mask[1];
   pps_chksum_stub[11] = dtc_cal_mask.dtc_cal_mask[2];
   pps_chksum_stub[12] = dtc_cal_mask.dtc_cal_mask[3];
   pps_chksum_stub[13] = dtc_cal_mask.dtc_cal_mask[4];
   /*04000100-04000800*/
   MFT_Get_Delphi_Part_Number(dpn);
   pit_index = 1;
   pps_chksum_stub[pit_index+13] = dpn[0];
   pps_chksum_stub[pit_index+14] = dpn[1];
   pps_chksum_stub[pit_index+15] = dpn[2];
   pps_chksum_stub[pit_index+16] = dpn[3];
   pps_chksum_stub[pit_index+17] = dpn[4];
   pps_chksum_stub[pit_index+18] = dpn[5];
   pps_chksum_stub[pit_index+19] = dpn[6];
   pps_chksum_stub[pit_index+20] = dpn[7];
   /*04001100-04001F00*/
   part_num=Part_Num_PS_Get();
   pps_chksum_stub[pit_index+21] = part_num.part_num_byte0;
   pps_chksum_stub[pit_index+22] = part_num.part_num_byte1;
   pps_chksum_stub[pit_index+23] = part_num.part_num_byte2;
   pps_chksum_stub[pit_index+24] = part_num.part_num_byte3;
   pps_chksum_stub[pit_index+25] = part_num.part_num_byte4;
   pps_chksum_stub[pit_index+26] = part_num.part_num_byte5;
   pps_chksum_stub[pit_index+27] = part_num.part_num_byte6;
   pps_chksum_stub[pit_index+28] = part_num.part_num_byte7;
   pps_chksum_stub[pit_index+29] = part_num.part_num_byte8;
   pps_chksum_stub[pit_index+30] = part_num.part_num_byte9;
   pps_chksum_stub[pit_index+31] = part_num.part_num_byte10;
   pps_chksum_stub[pit_index+32] = part_num.part_num_byte11;
   pps_chksum_stub[pit_index+33] = part_num.part_num_byte12;
   pps_chksum_stub[pit_index+34] = part_num.part_num_byte13;
   pps_chksum_stub[pit_index+35] = part_num.part_num_byte14;
   /*04002400-04003F00*/

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0N_MIN);
   pps_chksum_stub[pit_index+36] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+37] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_05_MIN);
   pps_chksum_stub[pit_index+38] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+39] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0E_MIN);
   pps_chksum_stub[pit_index+40] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+41] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_12_MIN);
   pps_chksum_stub[pit_index+42] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+43] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_02_MIN);
   pps_chksum_stub[pit_index+44] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+45] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_01_MIN);
   pps_chksum_stub[pit_index+46] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+47] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_18_MIN);
   pps_chksum_stub[pit_index+48] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+49] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0N_MAX);
   pps_chksum_stub[pit_index+50] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+51] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_05_MAX);
   pps_chksum_stub[pit_index+52] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+53] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_0E_MAX);
   pps_chksum_stub[pit_index+54] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+55] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_12_MAX);
   pps_chksum_stub[pit_index+56] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+57] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_02_MAX);
   pps_chksum_stub[pit_index+58] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+59] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_01_MAX);
   pps_chksum_stub[pit_index+60] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+61] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICPLUS_18_MAX);
   pps_chksum_stub[pit_index+62] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+63] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0N_MIN);
   pps_chksum_stub[pit_index+64] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+65] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_05_MIN);
   pps_chksum_stub[pit_index+66] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+67] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0E_MIN);
   pps_chksum_stub[pit_index+68] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+69] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_12_MIN);
   pps_chksum_stub[pit_index+70] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+71] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_02_MIN);
   pps_chksum_stub[pit_index+72] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+73] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_01_MIN);
   pps_chksum_stub[pit_index+74] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+75] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_18_MIN);
   pps_chksum_stub[pit_index+76] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+77] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0N_MAX);
   pps_chksum_stub[pit_index+78] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+79] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_05_MAX);
   pps_chksum_stub[pit_index+80] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+81] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_0E_MAX);
   pps_chksum_stub[pit_index+82] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+83] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_12_MAX);
   pps_chksum_stub[pit_index+84] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+85] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_02_MAX);
   pps_chksum_stub[pit_index+86] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+87] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_01_MAX);
   pps_chksum_stub[pit_index+88] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+89] = pit_stub16;

   pit_stub16 = Self_Di_Get_Micdtcs(DTCMICMINUS_18_MAX);
   pps_chksum_stub[pit_index+90] = pit_stub16 >> 8;
   pps_chksum_stub[pit_index+91] = pit_stub16;
   /*04004000-04004400*/
   identify_code=Identify_Code_PS_Get();	
   pps_chksum_stub[pit_index+91] = identify_code.sequence_num5;
   pps_chksum_stub[pit_index+92] = identify_code.sequence_num4;
   pps_chksum_stub[pit_index+93] = identify_code.sequence_num3;
   pps_chksum_stub[pit_index+94] = identify_code.sequence_num2;
   pps_chksum_stub[pit_index+95] = identify_code.sequence_num1;
   /*04004500-04005300*/
   hw_version = GWM_HW_Version_PS_Get();
   pps_chksum_stub[pit_index+96] = hw_version.platform_byte0;
   pps_chksum_stub[pit_index+97] = hw_version.platform_byte1;
   pps_chksum_stub[pit_index+98] = hw_version.platform_byte2;
   pps_chksum_stub[pit_index+99] = hw_version.platform_byte3;
   pps_chksum_stub[pit_index+100] = hw_version.space_character_byte4;
   pps_chksum_stub[pit_index+101] = hw_version.ecu_name_byte5;
   pps_chksum_stub[pit_index+102] = hw_version.ecu_name_byte6;
   pps_chksum_stub[pit_index+103] = hw_version.ecu_name_byte7;
   pps_chksum_stub[pit_index+104] = hw_version.ecu_name_byte8;
   pps_chksum_stub[pit_index+105] = hw_version.ecu_sample_byte9;
   pps_chksum_stub[pit_index+106] = hw_version.version_byte10;
   pps_chksum_stub[pit_index+107] = hw_version.version_byte11;
   pps_chksum_stub[pit_index+108] = hw_version.space_characte_byte12;
   pps_chksum_stub[pit_index+109] = hw_version.version_control_byte13;
   pps_chksum_stub[pit_index+110] = hw_version.version_control_byte14;
   /*04005400-04006400*/
   config = Sys_Config_PS_Get();
   pps_chksum_stub[pit_index+111] = config.config_byte0;
   pps_chksum_stub[pit_index+112] = config.config_byte1;
   pps_chksum_stub[pit_index+113] = config.config_byte2;
   pps_chksum_stub[pit_index+114] = config.config_byte3;
   pps_chksum_stub[pit_index+115] = config.config_byte4;
   pps_chksum_stub[pit_index+116] = config.config_byte5;
   pps_chksum_stub[pit_index+117] = config.config_byte6;
   pps_chksum_stub[pit_index+118] = config.config_byte7;
   pps_chksum_stub[pit_index+119] = config.config_byte8;
   pps_chksum_stub[pit_index+120] = config.config_byte9;
   pps_chksum_stub[pit_index+121] = config.config_byte10;
   pps_chksum_stub[pit_index+122] = config.config_byte11;
   pps_chksum_stub[pit_index+123] = config.config_byte12;
   pps_chksum_stub[pit_index+124] = config.config_byte13;
   pps_chksum_stub[pit_index+125] = config.config_byte14;
   pps_chksum_stub[pit_index+126] = config.config_byte15;
   pps_chksum_stub[pit_index+127] = config.config_byte16;
   /*05001000-05001500*/
   pps_chksum_stub[pit_index+128] = AMFM_Mgr_Get_FM_WBAM_Values(1);  
   pps_chksum_stub[pit_index+129] = AMFM_Mgr_Get_FM_WBAM_Values(0); 
   pps_chksum_stub[pit_index+130] = AMFM_Mgr_Get_FM_USN_Values(1); 
   pps_chksum_stub[pit_index+131] = AMFM_Mgr_Get_FM_USN_Values(0);  
   pps_chksum_stub[pit_index+132] = AMFM_Mgr_Get_AM_USN_Values(1);
   pps_chksum_stub[pit_index+133] = AMFM_Mgr_Get_AM_USN_Values(0);
   /*06000300-06002400*/
   dtc_status = DTC_Status_PS_Get();
   pps_chksum_stub[pit_index+134] = dtc_status.parmater3;
   pps_chksum_stub[pit_index+135] = dtc_status.parmater4;
   pps_chksum_stub[pit_index+136] = dtc_status.parmater5;
   pps_chksum_stub[pit_index+137] = dtc_status.parmater6;
   pps_chksum_stub[pit_index+138] = dtc_status.parmater7;
   pps_chksum_stub[pit_index+139] = dtc_status.parmater8;
   pps_chksum_stub[pit_index+140] = dtc_status.parmater9;
   pps_chksum_stub[pit_index+141] = dtc_status.parmaterA;
   pps_chksum_stub[pit_index+142] = dtc_status.parmaterB;
   pps_chksum_stub[pit_index+143] = dtc_status.parmaterC;
   pps_chksum_stub[pit_index+144] = dtc_status.parmaterD;
   pps_chksum_stub[pit_index+145] = dtc_status.parmaterE;
   pps_chksum_stub[pit_index+146] = dtc_status.parmaterF;
   pps_chksum_stub[pit_index+147] = dtc_status.parmater10;
   pps_chksum_stub[pit_index+148] = dtc_status.parmater11;
   pps_chksum_stub[pit_index+149] = dtc_status.parmater12;
   pps_chksum_stub[pit_index+150] = dtc_status.parmater13;
   pps_chksum_stub[pit_index+151] = dtc_status.parmater14;
   pps_chksum_stub[pit_index+152] = dtc_status.parmater15;
   pps_chksum_stub[pit_index+153] = dtc_status.parmater16;
   pps_chksum_stub[pit_index+154] = dtc_status.parmater17;
   pps_chksum_stub[pit_index+155] = dtc_status.parmater18;
   pps_chksum_stub[pit_index+156] = dtc_status.parmater19;
   pps_chksum_stub[pit_index+157] = dtc_status.parmater1A;
   pps_chksum_stub[pit_index+158] = dtc_status.parmater1B;
   pps_chksum_stub[pit_index+159] = dtc_status.parmater1C;
   pps_chksum_stub[pit_index+160] = dtc_status.parmater1D;
   pps_chksum_stub[pit_index+161] = dtc_status.parmater1E;
   pps_chksum_stub[pit_index+162] = dtc_status.parmater1F;
   pps_chksum_stub[pit_index+163] = dtc_status.parmater20;
   pps_chksum_stub[pit_index+164] = dtc_status.parmater21;
   pps_chksum_stub[pit_index+165] = dtc_status.parmater22;
   pps_chksum_stub[pit_index+166] = dtc_status.parmater23;
   pps_chksum_stub[pit_index+167] = dtc_status.parmater24;
   /*06002500-06002E00*/
   dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   pps_chksum_stub[pit_index+168] = dpid8_errors.error_count.cd_focus;

   radio_time = Operation_Time_PS_Get();
   pps_chksum_stub[pit_index+169] = (uint8_t)((radio_time.radio_operation_time >> 8) & 0x00ff);
   pps_chksum_stub[pit_index+170] = (uint8_t)(radio_time.radio_operation_time & 0x00ff);

   radio_time = Operation_Time_PS_Get();
   pps_chksum_stub[pit_index+171] = (uint8_t)((radio_time.playback_operation_time >> 8) & 0x00ff);
   pps_chksum_stub[pit_index+172] = (uint8_t)(radio_time.playback_operation_time & 0x00ff);

   dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   pps_chksum_stub[pit_index+173] = dpid8_errors.error_count.dvd_play;

   dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   pps_chksum_stub[pit_index+174] = dpid8_errors.error_count.dvd_region_code;

   dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   pps_chksum_stub[pit_index+175] = dpid8_errors.error_count.dvd_load_eject;

   dpid8_errors = Disc_Pbk_Diag_Get_Playback_Error();
   pps_chksum_stub[pit_index+176] = dpid8_errors.error_count.dvd_format;

   pps_chksum_stub[pit_index+177] = Theft_PS_Get_VIN_Learnt_Count();

   pps_chksum_stub[pit_index+178] = Theft_PS_Get_Mode();
   /*06005000-06007200*/ 
   level = Brightness_Level_PS_Get();
   pps_chksum_stub[pit_index+179] = level.night_highest_min;
   pps_chksum_stub[pit_index+181] = level.night_highest_max;
   pps_chksum_stub[pit_index+182] = level.day_highest;
   pps_chksum_stub[pit_index+183] = level.night_high_min;
   pps_chksum_stub[pit_index+184] = level.night_high_max;
   pps_chksum_stub[pit_index+185] = level.day_high;
   pps_chksum_stub[pit_index+186] = level.night_mid_min;
   pps_chksum_stub[pit_index+187] = level.night_mid_max;
   pps_chksum_stub[pit_index+188] = level.day_mid;
   pps_chksum_stub[pit_index+189] = level.night_low_min;
   pps_chksum_stub[pit_index+190] = level.night_low_max;
   pps_chksum_stub[pit_index+191] = level.day_low;
   pps_chksum_stub[pit_index+192] = level.night_lowest_min;
   pps_chksum_stub[pit_index+193] = level.night_lowest_max;
   pps_chksum_stub[pit_index+194] = level.day_lowest;
   duty = Brightness_Duty_PS_Get();	
   pps_chksum_stub[pit_index+195] = duty.pwm_duty[0].brightness_duty;
   pps_chksum_stub[pit_index+196] = duty.pwm_duty[0].pwm_point;
   pps_chksum_stub[pit_index+197] = duty.pwm_duty[1].brightness_duty;
   pps_chksum_stub[pit_index+198] = duty.pwm_duty[1].pwm_point;
   pps_chksum_stub[pit_index+199] = duty.pwm_duty[2].brightness_duty;
   pps_chksum_stub[pit_index+201] = duty.pwm_duty[2].pwm_point;
   pps_chksum_stub[pit_index+202] = duty.pwm_duty[3].brightness_duty;
   pps_chksum_stub[pit_index+203] = duty.pwm_duty[3].pwm_point;
   pps_chksum_stub[pit_index+204] = duty.pwm_duty[4].brightness_duty;
   pps_chksum_stub[pit_index+205] = duty.pwm_duty[4].pwm_point;
   pps_chksum_stub[pit_index+206] = duty.pwm_duty[5].brightness_duty;
   pps_chksum_stub[pit_index+207] = duty.pwm_duty[5].pwm_point;
   pps_chksum_stub[pit_index+208] = duty.pwm_duty[6].brightness_duty;
   pps_chksum_stub[pit_index+209] = duty.pwm_duty[6].pwm_point;
   pps_chksum_stub[pit_index+210] = duty.pwm_duty[7].brightness_duty;
   pps_chksum_stub[pit_index+211] = duty.pwm_duty[7].pwm_point;
   pps_chksum_stub[pit_index+212] = duty.pwm_duty[8].brightness_duty;
   pps_chksum_stub[pit_index+213] = duty.pwm_duty[8].pwm_point;
   pps_chksum_stub[pit_index+214] = duty.pwm_duty[9].brightness_duty;
   pps_chksum_stub[pit_index+215] = duty.pwm_duty[9].pwm_point;	
   /*06016600-06016600*/ 

   SSM_Get_Last_User_Source(0, &ssm_src);
   pits_audio_map_ssm_src_to_pits_src(ssm_src.type,  &pits_src);
   pps_chksum_stub[pit_index+216] = pits_src;

   /*06019000-06019000*/	
   brightness = DISPLAY_Brightness_PS_Get();
   pps_chksum_stub[pit_index+217] = brightness.brightness;

   /*06019800-0601A800*/

   num=GWM_Identify_Num_PS_Get();    
   pps_chksum_stub[pit_index+218] = num.identify_byte1;
   pps_chksum_stub[pit_index+219] = num.identify_byte2;
   pps_chksum_stub[pit_index+220] = num.identify_byte3;
   pps_chksum_stub[pit_index+221] = num.car_type;
   pps_chksum_stub[pit_index+222] = num.parmeter_byte4;
   pps_chksum_stub[pit_index+223] = num.parmeter_byte5;
   pps_chksum_stub[pit_index+224] = num.body_type;
   pps_chksum_stub[pit_index+225] = num.wheelbus;
   pps_chksum_stub[pit_index+226] = num.check_digit;
   pps_chksum_stub[pit_index+227] = num.build_year;
   pps_chksum_stub[pit_index+228] = num.factory_code;
   pps_chksum_stub[pit_index+229] = num.serial_num_byte0;
   pps_chksum_stub[pit_index+230] = num.serial_num_byte1;
   pps_chksum_stub[pit_index+231] = num.serial_num_byte2;
   pps_chksum_stub[pit_index+232] = num.serial_num_byte3;
   pps_chksum_stub[pit_index+233] = num.serial_num_byte4;
   pps_chksum_stub[pit_index+234] = num.serial_num_byte5;
   pit_crc_group_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
   printf("**pit_crc_group_chksum** 0X%X\n", pit_crc_group_chksum);
}
/*end add PITS_PPS_CRC_Chksum_Group for group checksum 20131121 by fuxiang */
static void PITS_PPS_CRC_Chksum_Final (void)
{
   uint8_t pps_chksum_stub[37];
   uint8_t  pit_size = 36;

   memset(&pps_chksum_stub[0], 0x00, pit_size+1);

   pps_chksum_stub[0] = pit_crc_align_cal_chksum>>24;
   pps_chksum_stub[1] = pit_crc_align_cal_chksum>>16;
   pps_chksum_stub[2] = pit_crc_align_cal_chksum>>8;
   pps_chksum_stub[3] = pit_crc_align_cal_chksum;
   pps_chksum_stub[4] = pit_crc_ymem_chksum>>24;
   pps_chksum_stub[5] = pit_crc_ymem_chksum>>16;
   pps_chksum_stub[6] = pit_crc_ymem_chksum>>8;
   pps_chksum_stub[7] = pit_crc_ymem_chksum;
   pps_chksum_stub[8] = pit_crc_mic_diag_chksum>>24;
   pps_chksum_stub[9] = pit_crc_mic_diag_chksum>>16;
   pps_chksum_stub[10] = pit_crc_mic_diag_chksum>>8;
   pps_chksum_stub[11] = pit_crc_mic_diag_chksum;
   pps_chksum_stub[12] = pit_crc_error_chksum>>24;
   pps_chksum_stub[13] = pit_crc_error_chksum>>16;
   pps_chksum_stub[14] = pit_crc_error_chksum>>8;
   pps_chksum_stub[15] = pit_crc_error_chksum;
   pps_chksum_stub[16] = pit_crc_usb_info_chksum>>24;
   pps_chksum_stub[17] = pit_crc_usb_info_chksum>>16;
   pps_chksum_stub[18] = pit_crc_usb_info_chksum>>8;
   pps_chksum_stub[19] = pit_crc_usb_info_chksum;
   pps_chksum_stub[20] = pit_crc_audio_eq_chksum>>24;
   pps_chksum_stub[21] = pit_crc_audio_eq_chksum>>16;
   pps_chksum_stub[22] = pit_crc_audio_eq_chksum>>8;
   pps_chksum_stub[23] = pit_crc_audio_eq_chksum;
   pps_chksum_stub[24] = pit_crc_presets_chksum>>24;
   pps_chksum_stub[25] = pit_crc_presets_chksum>>16;
   pps_chksum_stub[26] = pit_crc_presets_chksum>>8;
   pps_chksum_stub[27] = pit_crc_presets_chksum;
   pps_chksum_stub[28] = pit_crc_theft_chksum>>24;
   pps_chksum_stub[29] = pit_crc_theft_chksum>>16;
   pps_chksum_stub[30] = pit_crc_theft_chksum>>8;
   pps_chksum_stub[31] = pit_crc_theft_chksum;
   pps_chksum_stub[32] = pit_crc_product_id_chksum>>24;
   pps_chksum_stub[33] = pit_crc_product_id_chksum>>16;
   pps_chksum_stub[34] = pit_crc_product_id_chksum>>8;
   pps_chksum_stub[35] = pit_crc_product_id_chksum;

   pit_crc_final_chksum = PITS_PPS_CRC_Calculate_Chksum (&pps_chksum_stub[0], pit_size, PITS_INITIAL_CRC_VALUE);
}
/*===========================================================================*
 * FUNCTION: pits_pps_receive_chksum_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_receive_chksum_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_CHECKSUM_CRC_ACK;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 2;
      if (message->data_size < 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pps_tx_data[1] = PITS_CHKSUM_COMPLETE;
         /* vip brightness*/
         pits_vip_brightness = message->data[0];
#if 0         /*start speed up the process 20131121 add by fuxiang*/
         /* Send vip data for align cal*/
         PITS_PPS_CRC_Chksum_Align_Cal (&message->data[1], 12);
         /* Send vip data for product id*/
         PITS_PPS_CRC_Chksum_Product_id (&message->data[13], 19);
         /* Send vip data for ymem*/
         PITS_PPS_CRC_Chksum_Ymem (&message->data[32], 64);
         PITS_PPS_CRC_Chksum_Mic_Diag ();
         PITS_PPS_CRC_Chksum_DG_Error ();
         PITS_PPS_CRC_Chksum_Theft ();
         PITS_PPS_CRC_Chksum_USB ();
         PITS_PPS_CRC_Chksum_Audio_Eq ();
         PITS_PPS_CRC_Chksum_Presets ();
#endif    /*end speed up the process 20131121 add by fuxiang*/  

         PITS_PPS_CRC_Chksum_Group ();
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_receive_chksum_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_rec_chksum_last_req(const PITS_Message_T * message)
{
      Done_Or_Not_Done_T pits_status = NOT_DONE; 
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_CHECKSUM_CRC_ACK;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 2;

      if (message->data_size < 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         pps_tx_data[0] = (uint8_t) SUCCESS;
         pps_tx_data[1] = PITS_CHKSUM_COMPLETE;
         /*Second part for ymem table*/
         PITS_PPS_CRC_Chksum_Xmem (&message->data[0], 64);
         /*Get Total checksum of checksums*/
         PITS_PPS_CRC_Chksum_Final();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&pps_message); 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_read_partial_param_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_read_partial_param_req(const PITS_Message_T * message)
{
   uint16_t parameter = 0;
   uint8_t  length = 0;
   uint8_t  pit_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      if (message->data_size < 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         memset(&pits_data_received_from_vip[0], 0, 50);
         parameter = message->data[0];
         parameter = ((parameter<<8)&0xFF00)+message->data[1];
         length = message->data[2];
         if (parameter == 0x0001)
         {
            for (pit_index = 0; pit_index<(length-6); pit_index++)
            {
               pits_data_received_from_vip[pit_index] =  message->data[pit_index+3];
            }
/*            Pits_Param_TableA_Read_Req (parameter, length);     */
         }
         if (parameter == 0x0003)
         {
            for (pit_index = 0; pit_index<(length-2); pit_index++)
            {
               pits_data_received_from_vip[pit_index] =  message->data[pit_index+3];
            }
/*            Pits_Param_TableA_Read_Req (parameter, length);   */
         }
         if (parameter == 0xF001)
         {
            parameter = 0x0001;
 /*           Pits_Param_TableA_Write_Req(parameter, &message->data[3], length); */
         }

         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_calc_md_five_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_calc_md_five_req(const PITS_Message_T * message)
{
   uint8_t md_selected = 0;
   uint32_t md_block = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      if (message->data_size < 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {

         md_selected = message->data[0];
         pits_md_calculating = md_selected;
         md_block = message->data[1];
         md_block = ((md_block << 8)&0x0000FF00) + message->data[2];
         md_block = ((md_block << 8)&0x00FFFF00) + message->data[3];
         md_block = ((md_block << 8)&0xFFFFFF00) + message->data[4];
         pits_md_stored_value[md_selected][0] = 0;  /*Set md as not calculated*/
         /* Calculate MD5 Checksum*/
         Pits_Calculate_MD_Chksum_Value (md_selected, md_block);
         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_get_calc_md_status_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_get_calc_md_status_req(const PITS_Message_T * message)
{
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
   uint8_t pits_chksum_value [PITS_MDS_CHKSUM_SIZE-1];
   uint8_t pit_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      if (message->data_size < 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {

         if(Pits_Get_MD_Calc_Status(pits_md_calculating) == PITS_CHKSUM_COMPLETE)
         {
            Pits_Get_MD_Calc_Result (pits_md_calculating, &pits_chksum_value[0]);
            pits_md_stored_value[pits_md_calculating][0] = PITS_CHKSUM_COMPLETE;
            for (pit_index = 0; pit_index < PITS_MDS_CHKSUM_SIZE-1; pit_index++)
            {
               pits_md_stored_value[pits_md_calculating][pit_index+1] = pits_chksum_value[pit_index];
            }
            PITs_GM_Set_DID (0,19);
            PITs_GM_Set_DID (1,pits_md_calculating);
            PITs_GM_Set_DID (2,PITS_CHKSUM_COMPLETE);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
         }
         else if(Pits_Get_MD_Calc_Status(pits_md_calculating) == PITS_CHKSUM_ERROR)
         {
            PITs_GM_Set_DID (0,19);
            PITs_GM_Set_DID (1,pits_md_calculating);
            PITs_GM_Set_DID (2,PITS_CHKSUM_ERROR);
            PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
         }

         pits_status = DONE; 
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_pps_jump_to_bootloader_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_jump_to_bootloader_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   int ret;	
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_BOOT_JUMP_ACK;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 2);
      pps_message.data_size = 2;
      if (message->data_size < 1)
      {
         status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         ret = system("fw_setenv enable_reflash_mode true");
		
         if(ret != 0) Tr_Info_Lo("***set reflash_mode value failed***");
		
         ret = system("sync");
      
         FBL_Linker_Enter_Boot_Mode_Req();
         /*SAL_Sleep(300);*/
         pps_tx_data[0] = Jump_To_FBL_Ready();

      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&pps_message));
   }
   return(status);

}

/*===========================================================================*
 * FUNCTION: pits_pps_get_set_FCID_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_get_set_FCID_req(const PITS_Message_T * message)
{
   uint16_t fcid;
   uint8_t write_success = false;
   Done_Or_Not_Done_T status = NOT_DONE;
  
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_GET_SET_FCID_ACK;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, 3);
      pps_message.data_size = 3;
      if (message->data_size < 1)
      {
         status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         if(0x00 == (message->data)[0])  /*Read FCID*/
         {
           pps_tx_data[0] = (uint8_t) SUCCESS;
           fcid = Get_HWID();
           pps_tx_data[1] = (uint8_t) (fcid >> 8) & 0xFF;
           pps_tx_data[2] = (uint8_t) fcid & 0xFF;
         }
         else if(0x01 == (message->data)[0])  /*Write FCID*/
         {
           fcid = (message->data)[1];
           fcid = (fcid << 8) | (message->data)[2];
           write_success = Set_HWID(fcid);
           if(write_success == 0)
           {
             pps_tx_data[0] = (uint8_t) SUCCESS;
           }
         }
      }
   }
   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&pps_message));
   }
   return(status);
}


/*===========================================================================*
 * FUNCTION: 
 *===========================================================================*
 * @brief Processes a request to read or write the Manifest version, APP or FBL
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] pps_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] pps_tx_data[1] = PITS_CHKSUM_COMPLETE
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_pps_manifest_version_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T status = NOT_DONE;
   char_t mnf_ver_buffer[20];

   if ( NULL != message )
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pps_tx_bus_id = message->bus;
      pps_message.bus = pps_tx_bus_id;
      pps_message.data = pps_tx_data;
      pps_message.MSID = 0x10;
      pps_message.MID = MID_MFG_MNF_VER_READ_WRITE_RPT;
      /* Compose Message Data */
      pps_tx_data[0] = (uint8_t) FAIL;
      memset(&pps_tx_data[1], 0, MNF_VER_READ_WRITE_MSG_SIZE);
      pps_message.data_size = MNF_VER_READ_WRITE_MSG_SIZE;
      if ( message->data_size < 2 )
      {
         status = PITS_PBS_Error_Report("PPS REQUEST: Message Data Error");
      }
      else
      {
         if(0 == message->data[0])        /* Read Manifest Version */
         {
            FBL_Get_Mnf_Version(message->data[1], mnf_ver_buffer);
            pps_tx_data[0] = (uint8_t) SUCCESS;
            pps_tx_data[1] = message->data[0];
            pps_tx_data[2] = message->data[1];
            memcpy(&pps_tx_data[3], mnf_ver_buffer, 20);
         }
         else if (1 == message->data[0])   /* Write Manifest version */
         {
            memcpy(mnf_ver_buffer, &message->data[2], 20);
            FBL_Set_Mnf_Version(message->data[1], mnf_ver_buffer);
            pps_tx_data[0] = (uint8_t) SUCCESS;
            pps_tx_data[1] = message->data[0];
            pps_tx_data[2] = message->data[1];
            FBL_Get_Mnf_Version(message->data[1], mnf_ver_buffer);
            memcpy(&pps_tx_data[3], mnf_ver_buffer, 20);
         }
         else
         {
            pps_tx_data[0] = (uint8_t) FAIL;
            pps_tx_data[1] = message->data[0];
            pps_tx_data[2] = message->data[1];
         }
      }
   }

   if (NOT_DONE == status)
   {
      status = ((Done_Or_Not_Done_T) PITS_Send_Message(&pps_message));
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Clear_PPS_Timer
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Clear_PPS_Timer_Session(void)
{
   PITS_Set_PPS_Session(SESSION_CLOSE);
   pps_session_access = ACCESS_READ;
   PITS_Set_Partition_Status(PITS_ALL_SEGMENTS, PITS_RO_STATUS);
   PITS_Clear_All_Overrides();
   
   Tr_Notify("PITS_Clear_PPS_Timer_Session");
}

/*===========================================================================*
 * FUNCTION: pits_pps_compose_message_header
 *===========================================================================*
 * Set up message header for the response.
 *
 * @param [in] mid - PITS MID for the response message
 * @param [in] size - data length for the response message
 */
/*===========================================================================*/
static void pits_pps_compose_message_header(uint8_t mid, uint8_t size)
{
   pps_message.bus  = pps_tx_bus_id;
   pps_message.data = pps_tx_data;
   pps_message.MSID = MSID_PROGRAMMING_SERVICES;
   pps_message.MID  = mid;
   pps_message.data_size = size;
   memset(pps_tx_data, 0x00, size);
}

/*===========================================================================*
 * FUNCTION: PITS_Set_Partition_Status
 *===========================================================================*
 *
 * @see pits_processing_manager.h for detail description of this function.
 */
/*===========================================================================*/
bool PITS_Enable_to_Write_Partition(uint8_t partition)
{
   bool status = false;
   if(PITS_Get_Partition_Status(partition) != PITS_RO_STATUS)
   {
      status = true;
   }
   return(status);
}

/*===========================================================================*/
/*!                      
 * @file pits_programming_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 3
 * ctc_ec#156415: Remove build warnings.
 *
 * 20-Jun-2014 Tim Wang
 * Add message header set uo function.
 *
 * 24-Feb-2013 Jiang Tao
 * + For pits_pps_param_read_req, no need put PS
 * + Change Warn Debug message to Hi Debug message
 *
 * 17-Dec-2012 Arthur Chen
 * Remove unused variables to fix compil warnings.
 *
 * 26-Nov-2012 Arthur Chen
 * Add variables for manufest for GWM mpi file.
 *
 * 22-Nov-2012 Steven Cheng
 * SCR Task ctc_ec#32022: Add PITS PPS parameter read/write function for RTD EEProm       
 *                                        (MPI requirement from system)
 *
 * 28-Set-2012 Christian Nigri
 * SCR kok_basa#32156/Task kok_basa#120846: Add Steering Wheel Control Mute Button
 *                                          Add PPS to MDF
 *
 * 18-Sep-2012 Carolina Tovar (WZRJ41)
 * kok_basa#30935: There was no response from PITS $10$14 and $10$12 since PITS_Send_Message() wasn't being called
 *
 * - 11-Sep-2012  Jorge Rodriguez
 *   kok_basa#31658 - PIT 10/60 implemented to read/write manifest version.
 *
 * 10-Sep-2012 Carolina Tovar (WZRJ41)
 * kok_basa#30935: Implement PITS to read/write FCID PITS 10h 14h and Status 10h 15h
 *
 * 10-Sep-2012 Carolina Tovar (WZRJ41)
 * kok_basa#30933: Implement PITS 10 12 Request Jump to FBL and 10h 13h status.
 *
 *  06-Sep-2012 Darinka L\F3pez Rev 79
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 03 Sep 2012 Miguel Garcia
 * Include Pits chksum error to the md5 response
 *
 * 23 Aug 2012 Miguel Garcia
 * Task kok_basa#115934 - Fix Pits Timers
 *
 * 23-Aug-2012 Christian Nigri
 * SCR kok_basa#31028/Task kok_basa#115655: Move Flash Cal for AUX HMI to PS
 *                                          Add PPS to MDF
 *
 * 21-Aug-2012 Christian Nigri
 * SCR kok_basa#30915/Task kok_basa#115478: Remove Hand Drive Selection Service 
 *
 * 16 Aug 2012 Miguel Garcia
 * Include MD5 calc checksums
 *
 * 08 Aug 2012 Chris Baker Rev 73
 * Task kok_basa#113422: Updated BT PS calls to match new API.
 *
 * 02-Aug-2012 Christian Nigri
 * SCR kok_basa#29475/Task kok_basa#112332 Create Table 09, add new PITS 
 *											parameters and read/write functions
 *
 * 26 Jul 2012 Miguel Garcia
 * Include CRC32 Checksum functions
 * 
 * 20 Jul 2012 Hernan Gegenschatz Rev 69
 * kok_basa#109960: Implement read request for sw_setting variable, Table $01, Parameter $15
 * 
 * 26 Jun 2012 Miguel Garcia Rev 68
 * Include erase metadata 10/20 05
 *
 * 11 Jun 2012 Miguel Garcia Rev 65
 * Create pits mpi checksums and network
 *
 * 29-May-2012 Oscar Vega  Rev 64
 * SCR task_kok_basa#99814 : Implement various BT Services 
 *
 * 31May12  David Origer (hz1941)
 * SCR kok_basa#27541 : Perform sync after clearing memory sections before reset
 *    to ensure changes are written to NAND.
 *
 * 28 May 2012 Miguel Garcia 63
 * Include Reset from vip when load defaults for factory data
 *
 * 25 May 2012 Miguel Garcia 62
 * Include extra set for usb dtcs
 *
 * 23 May 2012 Miguel Garcia 61
 * Include pits reflash functions
 *
 * 18 May 2012 Pramod N K Rev 60
 * - Set the PS as read only when PITS command to remove PS files is received.
 * - Cause the radio to reset to load defaults on subsequent startup.
 *
 * 17 May 2012 Miguel Garcia Rev 59
 * Update load defaults bt devices
 *
 * 11 May 2012 Miguel Garcia Rev 58
 * Include individual bt devices address call
 *
 * 04 May 2012 Miguel Garcia Rev 57
 * Set Reflash dtcs to 0x11 and 0x05
 *
 * 1-May-2012 Darinka Lopez  Rev 55
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 27 Apr 2012 Miguel Garcia Rev 54
 * Remove label from presets
 *
 * 12 Apr 2012 Miguel Garcia Rev 53
 * Update md5 locations
 *
 * 10 Apr 2012 Miguel Garcia Rev 52
 * Fix set presets display
 *
 * 21-Mar-2012 Darinka Lopez  Rev 51
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 13 Mar 2012 Miguel Garcia
 * Fix load defaults function
 *
 * 07 Mar 2012 Miguel Garcia
 * Fix friendly name extra ceros
 *
 * 27 Feb 2012 Miguel Garcia
 * Include pits bt diagnostics
 *
 * 14 Feb 2012 Miguel Garcia
 * Include pits mics dtcs
 *
 * 09 Feb 2012 Miguel Garcia
 * Include partiotion for FF and tuner mpi parameters
 *
 * 02 Feb 2012 Miguel Garcia
 * Fix lingos versions and sizes
 *
 * 27 Jan 2012 Miguel Garcia
 * Include pits BT functions calls
 *
 * 16-Jan-2012 Chris Baker   Rev 43
 * SCR kok_basa#20128
 * - Ensure paired_dev_list_data is cleared for non-existent entries.
 * - Implemented link key read request.
 *
 * 16-Jan-2012 Miguel Garcia
 * Include Pits parameters bt and tone mgr
 *
 * 11Jan12  David Origer (hz1941)  Rev 40
 * SCR kok_basa#20342 : Corrected problems that were causing persistent storage
 *    files to be misnumbered and misused.
 *
 *
 * 05-Jan-2012 Darinka Lopez  Rev 34
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move tuner specif fuctions to proccesing_tuner file .
 *
 * 14-Dec-2011 Darinka Lopez  Rev 33
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 32
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 28 Nov 2011 Miguel Garcia
 * Include changes for tuner porting
 *
 * 22 Nov 2011 Miguel Garcia
 * Include daytrim ps
 *
 * 16 Nov 2011 Miguel Garcia
 * Fix table md5
 *
 * 30 Sep 2011 Miguel Garcia
 * Include pits partition rw, ro
 *
 * 26 May 2011 Miguel Garcia
 * Include pits parameter read and write
 *
 * 21-Oct-2010 Miguel Garcia  Rev 12
 * SCR kok_basa#3879 : Remove Pits Audio Dependencies.
 *
 *
 * 03-Ago-2010 Miguel Garcia  Rev 11
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 9-Apr-2010 Pramod N K
 * SCR kok_basa#7952: Remove PC Lint errors.
 *
 * 2-Oct-2009 David Mooar  Rev 10
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 7-august-2009 David Mooar  Rev 9
 *   - SCR kok_aud#61925: Fix incorrect response to PPS preopen.
 *
 * - 2009-06-24  Larry Ong
 *    - Restored pits programming service MIDs and data format to their original values.
 *
 * - 30-Apr-2009 Yi Liu
 *    - Update DSP Register Read.
 *
 * - 27-Feb-2009  Yi Liu
 *    - Added ability to read and write CarDSP.
 *
 * - 17-Dec-2008 Yi Liu
 * + SCR 58578 - Run J2 PITS tests
 *               Added read/write area for PITS memory access tests.
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Change code to be BASA2.0 compatible.
 *
 * - 05-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-30  Larry Ong
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-06-25  Larry Ong
 *    - Added Diagnostic Session in PBS as a master session, and allow other
 *      services in Diagnostic Session.
 *    - Added ability to change session timeout
 *
 * - 2008-06-10  Larry Ong
 *    - Moved MID definitions to pits_programming_services_cfg file.
 *    - Define 1st byte of transmit message data as Confirmation (SUCCESS, FAIL).
 *    - Check for valid receive message data length.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-10-09  Larry Ong
 *    - Changed Memory Check for EEPROM only in case: EEPROM of datax request read.
 *
 * - 2007-10-01  Larry Ong
 *    - Change pits services EM ID to PITS_MODULE_ID_5.
 *    - Implemented EEPROM (Persistent Storage) checksum feature.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-09-27  Jaroslaw Saferna
 *    - EEPROM (Persistent Storage) reading/writing data implemented.
 *    - Fixed bug in PITS_Memory_Map_Check() - now function returns TRUE
 *      also when memory block size is equal to 1.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-15  Larry Ong
 *    - Added PPS Session Timer.
 *    - Added Session Refresh message to refresh the PPS Session Timer.
 *
 * - 2007-07-05  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
