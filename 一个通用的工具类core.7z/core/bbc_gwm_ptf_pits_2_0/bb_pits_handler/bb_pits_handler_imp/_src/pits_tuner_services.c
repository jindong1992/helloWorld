/*===========================================================================*/
/**
 * @file pits_tuner_services.c
 *
 * @PITS Tuner Services.
 *
 * %full_filespec:pits_tuner_services.c~1:csrc:ctc_ec#18 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:59 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_tuner_services.h"
#include "pits_tuner_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"

EM_FILENUM(PITS_MODULE_ID_5, 6);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

typedef enum PITS_HD_BLEND_MODE_Tag
{
   PITS_BLEND_MODE_ANALOG  = 0x00,
   PITS_BLEND_MODE_AUTO    = 0x01,
   PITS_BLEND_MODE_DIGITAL = 0x02
} PITS_HD_BLEND_MODE_T;

typedef enum PITS_Band_Tag
{
   PITS_BAND_AM     = 0x00,
   PITS_BAND_FM1    = 0x01,
   PITS_BAND_FM2    = 0x02,
   PITS_BAND_WX     = 0x10,
   PITS_BAND_LW     = 0x20,
   PITS_BAND_XM     = 0x30,
   PITS_BAND_SIRRUS = 0x40,
   PITS_BAND_DAB    = 0x50
} PITS_Band_T;

typedef enum PITS_SEEK_ACTION_Tag
{
   PITS_SEEK_UP = 0,
   PITS_SEEK_DOWN,
   PITS_SEEK_STOP,
   PITS_SEEK_UNKNOWN,
}PITS_SEEK_ACTION_T;

typedef enum PITS_Channel_Selection_Tag
{
   PITS_AUDIO_CH_TUNER1 = 0x00,
   PITS_AUDIO_CH_TUNER2 = 0x01,
   PITS_AUDIO_CH_TMC    = 0x02,
} PITS_Channel_Selection_T;


typedef struct Band_Translation_Tag
{
   PITS_Band_T  pits_band;
   PITS_Tuner_Band_T   tuner_band;
} Band_Translation_T;



/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
static const SSM_Source_T FM_Source = {SSM_SRC_FM, 1};
static const SSM_Source_T AM_Source = {SSM_SRC_AM, 1};

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_tuner_initialize(void);

static bool_t pits_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_T *pits_band);
static bool_t pits_tuner_map_pits_band_to_band(PITS_Band_T pits_band, PITS_Tuner_Band_T *tuner_band);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_TUNER_RX_INDEX

#define MID_TUNER_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_tuner_rx_messages[] = {
   MID_TUNER_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_TUNER_TX_INDEX

#define MID_TUNER_TX_INDEX(name, mid) (mid),

static const uint8_t pits_tuner_tx_messages[] = {
   MID_TUNER_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_TUNER_RX_INDEX
#define MSID_TUNER_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_tuner_rx_message_sets[] = {
   MSID_TUNER_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_TUNER_TX_INDEX
#define MSID_TUNER_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_tuner_tx_message_sets[] = {
   MSID_TUNER_TX_TABLE
};



/*---------------------------------------------------------------------------*
 * X-Macro to create the source translation table for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef PITS_X
#define PITS_X(pits_src, logical_src) {pits_src, logical_src},

static const Band_Translation_T Band_Translation[] =
{
   PITS_BAND_TO_TUNER_BAND_TABLE
};

static uint8_t tuner_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T tuner_message;      /* for construction of a pbs message to be transmitted */

static uint8_t tuner_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t tuner_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T tuner_session_state;

/**
 * Stores Timer ID for PBS Session
 */
static SAL_Timer_Id_T pits_tuner_session_timer_id;


/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Tuner_Services_Interface = {
   pits_tuner_initialize,
   pits_tuner_rx_message_sets,
   Num_Elems(pits_tuner_rx_message_sets),
   pits_tuner_tx_message_sets,
   Num_Elems(pits_tuner_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_tuner_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_tuner_initialize(void)
{
   tuner_tx_bus_id = 0;
   memset(&tuner_message, 0x00, sizeof(PITS_Message_T));
   memset(tuner_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   tuner_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   tuner_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that PBS Session is closed? */
}


void PITS_Tuner_Clear_Overrides(void)
{
   RemRcvr_Disable_Override();
}

static void pits_tuner_compose_message_header(uint8_t mid, uint8_t size)
{
   tuner_message.bus = tuner_tx_bus_id;
   tuner_message.data = tuner_tx_data;
   tuner_message.MSID = MSID_TUNER_SERVICES;
   tuner_message.MID = mid;
   tuner_message.data_size = size;
   memset(tuner_tx_data, 0x00, size);
}

static bool_t pits_tuner_map_band_to_pits_band(PITS_Tuner_Band_T tuner_band, PITS_Band_T *pits_band)
{
   int8_t i;
   bool_t pits_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation); i++)
   {
      if (Band_Translation[i].tuner_band == tuner_band)
      {
         (*pits_band) = Band_Translation[i].pits_band;
         pits_band_found = true;
         break;
      }
   }

   return(pits_band_found);
}

static bool_t pits_tuner_map_pits_band_to_band(PITS_Band_T pits_band, PITS_Tuner_Band_T *tuner_band)
{
   uint8_t i;
   bool_t tuner_band_found = false;

   for (i = 0; i < Num_Elems(Band_Translation); i++)
   {
      if (Band_Translation[i].pits_band == pits_band)
      {
         (*tuner_band) = Band_Translation[i].tuner_band;
         tuner_band_found = true;
         break;
      }
   }

   return(tuner_band_found);
}



/*===========================================================================*
 * FUNCTION: pits_tuner_get_band_and_freq_req
 *=========================================g==================================*
 * @brief Receive a Request to Get the Receiver Band.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Tuner ID
 * @param [out] tuner_tx_data[2] = Tuner Band
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_band_and_freq_req(const PITS_Message_T * message)
{
   PITS_Band_T pits_band      = PITS_BAND_AM;
   PITS_Tuner_Band_T src_band = SSM_SRC_NONE;
   bool_t pits_band_found = false;
   Sys_Zone_T pits_zone;
   PITS_Tuner_Channel_T pits_tu_channel;
   PITS_Channel_Selection_T channel_selection;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_BAND_AND_FREQ_REPORT, 6);

      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         /* Decode received messages  */
         pits_zone = (Sys_Zone_T)message->data[0];
         channel_selection = (PITS_Channel_Selection_T)message->data[1];
         tuner_tx_data[1] = (uint8_t)pits_zone;
         tuner_tx_data[2] = (uint8_t)channel_selection;

         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
              case PITS_AUDIO_CH_TUNER1:
               src_band = PITS_Get_Tuner_Source_Type();
               pits_band_found = pits_tuner_map_band_to_pits_band(src_band, &pits_band);
               if (pits_band_found)
               {
                 tuner_tx_data[0] = (uint8_t) SUCCESS;
                 tuner_tx_data[3] = (uint8_t) pits_band;
                 switch (pits_band)
                 {
                 case PITS_BAND_FM1:
                 case PITS_BAND_FM2:
                 case PITS_BAND_AM:
                   pits_tu_channel = PITS_Get_AMFM_Tuner_Frequency();
                   tuner_tx_data[4] = (uint8_t) (pits_tu_channel >> 8);
                   tuner_tx_data[5] = (uint8_t) (pits_tu_channel + PITS_Get_Tuner_HD_Subchannel());
                   break;
                  case PITS_BAND_XM:
                   tuner_tx_data[4] = (uint8_t) PITS_Get_XM_Tuner_SID();
                   tuner_tx_data[5] = 0;
                  break;
                  case PITS_BAND_DAB:
                   tuner_tx_data[4] = PITS_Get_DAB_Tuner_Frequency();
                   tuner_tx_data[5] = 0x00;
                  break;
                  default:
                   tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
                  break;
                 }
              }
            break;
            case PITS_AUDIO_CH_TMC:
             #if PITS_TMC_IS
             tuner_tx_data[0] = (uint8_t) PITS_subscribing_TMC();
             tuner_tx_data[3] = PITS_BAND_FM1;
             tuner_tx_data[4] = (uint8_t)(PITS_TMC_Frequency() >> 8);
             tuner_tx_data[5] = (uint8_t)(PITS_TMC_Frequency());
             #endif
            break;
            case PITS_AUDIO_CH_TUNER2:
             #if PITS_TUNER_2_IS
             tuner_tx_data[0] = (uint8_t) SUCCESS;
             tuner_tx_data[3] = PITS_BAND_FM1;
             tuner_tx_data[4] = (uint8_t)(PITS_Get_Tuner_2_Frequency() >> 8);
             tuner_tx_data[5] = (uint8_t)(PITS_Get_Tuner_2_Frequency());
             #endif
            break;
            default:
            break;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_set_band_and_freq_req
 *===========================================================================*
 * @brief Receive a Request to Set the Tuner Band
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Tuner ID
 * @param [in] (message->data)[1] = Tuner Band
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_set_band_and_freq_req(const PITS_Message_T * message)
{
   PITS_Band_T pits_band;
   PITS_SSM_Src_T src_band;  
   PITS_Tuner_Mgr_Target_T tune_band_info = {TUNER_MGR_TARGET_TYPE_CHANNEL};
   bool_t band_found = false;
   bool_t valid_channel = false;
   PITS_Channel_Selection_T channel_selection;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_BAND_AND_FREQ_SET_ACK, 6);
  
      /* Compose Message Data */
      if (message->data_size != 5)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         
         memcpy(&tuner_tx_data[1], message->data, 5);
         
         /* Decode received messages  */
         pits_band = (PITS_Band_T)message->data[2];
         band_found = pits_tuner_map_pits_band_to_band(pits_band, (PITS_Tuner_Band_T*) &src_band.type);

         if (((SYS_ZONE_MAIN == (Sys_Zone_T)message->data[0]) && band_found))
         {
            channel_selection = (PITS_Channel_Selection_T)message->data[1];
            switch (channel_selection)
            { 
               case PITS_AUDIO_CH_TUNER1:
                   src_band.device = 1; 

                   switch (pits_band)
                   {
                      case PITS_BAND_FM1:
                      case PITS_BAND_FM2:
                         valid_channel = PITS_Tuner_Set_FM_Value(&tune_band_info, message->data[3], message->data[4]);
                         break;
                      case PITS_BAND_AM:
                         valid_channel = PITS_Tuner_Set_AM_Value(&tune_band_info, message->data[3], message->data[4]); 
                         break;
                      case PITS_BAND_XM:
                         valid_channel = PITS_Tuner_Set_XM_Value(&tune_band_info, message->data[3], message->data[4]); 
                         break;
                      case PITS_BAND_DAB:
                         valid_channel  = PITS_Tuner_Set_DAB_Value(&tune_band_info, message->data[3], message->data[4]);
                         break;
                      default:
                         break;

                   }
                   if (valid_channel)
                   {
                      tuner_tx_data[0] = (uint8_t) SUCCESS;
                      RemRcvr_Enable_Override();
                      PITS_Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);
                   }
               break;
               
               case PITS_AUDIO_CH_TMC:
                  #if PITS_TMC_IS
                  if((PITS_BAND_FM1 == pits_band) || (PITS_BAND_FM2 == pits_band))
                  {
                      tuner_tx_data[0] = (uint8_t) SUCCESS;
                      PITS_TMC_Tune_Frequency(&tune_band_info, message->data[3], message->data[4]); 
                  }
                  #endif
               break; 
               case PITS_AUDIO_CH_TUNER2:
                  #if PITS_TUNER_2_IS
                  if((PITS_BAND_FM1 == pits_band) || (PITS_BAND_FM2 == pits_band))
                  {
                     valid_channel = PITS_Tuner_Set_FM_Value(&tune_band_info, message->data[3], message->data[4]);
                  }
                  if (valid_channel)
                  {
                     tuner_tx_data[0] = (uint8_t) SUCCESS;
                     PITS_AMFM_Mngr_EM_Tune_Frequency(AMFM_MNGR_INSTANCE_1, tune_band_info.target_value, 1);
                  }
                  #endif
               break;
               default:
               break;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_scan_req
 *===========================================================================*
 * @brief Receive a Request to AM/FM frequency scan
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_scan_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   Tuner_Mgr_Seek_T seek = {0};
   uint8_t tuner_band = 0xFF;
   uint8_t seek_status = 0xFF;


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_SACN_ACK, 3);

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER SCAN Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         tuner_tx_data[1] = (uint8_t)message->data[0];
         tuner_tx_data[2] = (uint8_t)message->data[1];

         tuner_band = (uint8_t)message->data[0];
         seek_status = (uint8_t)message->data[1];

         seek.seek_mode = TUNER_MGR_PROPERTY_STRONG_SIGNAL;
         switch (tuner_band)
         {
            case PITS_BAND_AM:
               switch (seek_status)
               {
                  case PITS_SEEK_UP:
                     seek.seek_direction = TUNER_MGR_DIRECTION_UP;
                     Tuner_Mgr_Seek(AM_Source, seek);
                     break;
                  case PITS_SEEK_DOWN:
                     seek.seek_direction = TUNER_MGR_DIRECTION_DOWN;
                     Tuner_Mgr_Seek(AM_Source, seek);
                     break;
                  case PITS_SEEK_STOP:
                     Tuner_Mgr_Seek_Cancel(AM_Source, true);
                     break;
                  default:
                     break;
               }
               break;
            case PITS_BAND_FM1:
               switch (seek_status)
               {
                  case PITS_SEEK_UP:
                     seek.seek_direction = TUNER_MGR_DIRECTION_UP;
                     Tuner_Mgr_Seek(FM_Source, seek);
                     break;
                  case PITS_SEEK_DOWN:
                     seek.seek_direction = TUNER_MGR_DIRECTION_DOWN;
                     Tuner_Mgr_Seek(FM_Source, seek);
                     break;
                  case PITS_SEEK_STOP:
                     Tuner_Mgr_Seek_Cancel(FM_Source, true);
                     break;
                  default:
                     break;
               }
               break;
            default:
               Tr_Info_Lo_2("Tuner Seek request, invalid parameter band: %d, action: %d", tuner_band, seek_status);
         }
         
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}


/*===========================================================================*
 * FUNCTION: pits_tuner_set_band_and_freq_req
 *===========================================================================*
 * @brief Receive a Request to Set the Tuner Band
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Tuner ID
 * @param [in] (message->data)[1] = Tuner Band
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_set_band_and_freq_diag_req(const PITS_Message_T * message)
{
   PITS_Band_T pits_band;
   PITS_SSM_Src_T src_band;
   PITS_Tuner_Mgr_Target_T tune_band_info = {0};
   bool_t band_found = false;
   bool_t valid_channel = false;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_BAND_AND_FREQ_SET_ACK, 5);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         memcpy(&tuner_tx_data[1], message->data, 4);
         /* Decode received messages  */
         pits_band = (PITS_Band_T)message->data[1];
         band_found = pits_tuner_map_pits_band_to_band(pits_band, (PITS_Tuner_Band_T*) &src_band.type);

         if (((SYS_ZONE_MAIN == (Sys_Zone_T)message->data[0]) && band_found))
         {

            src_band.device = 1; 

            switch (pits_band)
            {
               case PITS_BAND_FM1:
               case PITS_BAND_FM2:
                  valid_channel = PITS_Tuner_Set_FM_Value(&tune_band_info, message->data[2], message->data[3]);
                  break;
               case PITS_BAND_AM:
                  valid_channel = PITS_Tuner_Set_AM_Value(&tune_band_info, message->data[2], message->data[3]);
                  break;
               case PITS_BAND_XM:
                  valid_channel = PITS_Tuner_Set_XM_Value(&tune_band_info, message->data[3], message->data[2]);
                  break;
               default:
                  break;
            }      

            if (valid_channel)
            {
               RemRcvr_Enable_Override();
               PITS_Tuner_Mgr_Absolute_Tune(SSM_CHAN_MAIN_AUDIO, src_band, tune_band_info);
               tuner_tx_data[0] = (uint8_t) SUCCESS;
            }
            else
            {
               tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
            }
         }
         else
         {
            tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = DONE;                      
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_tuner_get_Signal_Strengh_req
 *===========================================================================*
 * @brief Receive a Request to Get the Signal Strengh.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Tuner ID
 * @param [out] tuner_tx_data[2] = Signal Strength
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_Signal_Strengh_req(const PITS_Message_T * message)
{

   Sys_Zone_T pits_zone;
   PITS_Channel_Selection_T channel_selection;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 


   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_SIGNAL_STRENGTH_REPORT, 4);

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;		    

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

        channel_selection = (PITS_Channel_Selection_T)message->data[1];         
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
             case PITS_AUDIO_CH_TUNER1:
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_Quality();
               break;
             case PITS_AUDIO_CH_TMC:
                #if PITS_TMC_IS
                  tuner_tx_data[0] = (uint8_t) PITS_subscribing_TMC();
                  tuner_tx_data[3] = PITS_Get_TMC_RSSI();
                #endif
                 break; 
             case PITS_AUDIO_CH_TUNER2:
                #if PITS_TUNER_2_IS 
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_2_Field_Strenght();
                #endif
             default:
                 break;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}



/*===========================================================================*
 * FUNCTION: pits_tuner_get_User_PI_req
 *===========================================================================*
 * @brief Receive a Request to Get the User PI.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = User PI[0]
 * @param [out] tuner_tx_data[2] = User PI[1]
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_User_PI_req(const PITS_Message_T * message)
{
   RDS_Pi_T received_pi;
   PITS_Channel_Selection_T channel_selection;
   Sys_Zone_T pits_zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_USER_PI_REPORT, 5);

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {

         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;		    

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

	     channel_selection = (PITS_Channel_Selection_T)message->data[1];         
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
               case PITS_AUDIO_CH_TUNER1:
                   received_pi = PITS_Get_Tuner_User_PI_Code();
                   tuner_tx_data[0] = (uint8_t) SUCCESS;

                   tuner_tx_data[3] = (uint8_t) (received_pi >> 8);
                   tuner_tx_data[4] = (uint8_t) received_pi;
                   break;
               case PITS_AUDIO_CH_TMC:
                  #if PITS_TMC_IS
                       tuner_tx_data[0] = (uint8_t) PITS_subscribing_TMC();
                       tuner_tx_data[3] = (uint8_t)(PITS_TMC_User_Pi() >> 8);
                       tuner_tx_data[4] = (uint8_t)(PITS_TMC_User_Pi());
                  #endif
                   break; 
               case PITS_AUDIO_CH_TUNER2:
                  #if PITS_TUNER_2_IS
                     received_pi = PITS_Get_Tuner_2_User_PI_Code();
                     tuner_tx_data[0] = (uint8_t) SUCCESS;
                     tuner_tx_data[3] = (uint8_t) (received_pi >> 8);
                     tuner_tx_data[4] = (uint8_t) received_pi;
                  #endif
               default:
                   break;
           }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_get_Received_PI_req
 *===========================================================================*
 * @brief Receive a Request to Get the User PI.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = User PI[0]
 * @param [out] tuner_tx_data[2] = User PI[1]
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_Received_PI_req(const PITS_Message_T * message)
{
   RDS_Pi_T current_pi;
   PITS_Channel_Selection_T channel_selection;
   Sys_Zone_T pits_zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_RECEIVED_PI_REPORT, 5);

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;		    

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

        channel_selection = (PITS_Channel_Selection_T)message->data[1];         
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
             case PITS_AUDIO_CH_TUNER1:
                current_pi = PITS_Get_Tuner_Received_PI();
                tuner_tx_data[0] = (uint8_t) SUCCESS;
                tuner_tx_data[3] = (uint8_t) (current_pi >> 8);
                tuner_tx_data[4] = (uint8_t) current_pi;
          	 break;
             case PITS_AUDIO_CH_TMC:
                #if PITS_TMC_IS
                    tuner_tx_data[0] = (uint8_t) PITS_subscribing_TMC();
                    tuner_tx_data[3] = (uint8_t)(PITS_TMC_Received_Pi() >> 8);
                    tuner_tx_data[4] = (uint8_t)(PITS_TMC_Received_Pi());
                #endif
                 break; 
             case PITS_AUDIO_CH_TUNER2:
                #if PITS_TUNER_2_IS
                    current_pi = PITS_Get_Tuner_2_Received_PI();
                    tuner_tx_data[0] = (uint8_t) SUCCESS;
                    tuner_tx_data[3] = (uint8_t) (current_pi >> 8);
                    tuner_tx_data[4] = (uint8_t) current_pi;
                #endif
             default:
                 break;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_get_User_PTY_req
 *===========================================================================*
 * @brief Receive a Request to Get the User PTY.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = User PTY
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_User_PTY_req(const PITS_Message_T * message)
{
   PITS_Channel_Selection_T channel_selection;
   Sys_Zone_T pits_zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_USER_PTY_REPORT, 4);

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

         channel_selection = (PITS_Channel_Selection_T)message->data[1];
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
             case PITS_AUDIO_CH_TUNER1:
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_Received_PTY();
               break;
             case PITS_AUDIO_CH_TMC:
               #if PITS_TMC_IS
                  tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;  /*Temporal response until Define RDS */
                  /*TODO*/
               #endif
               break;
             case PITS_AUDIO_CH_TUNER2:
               #if PITS_TUNER_2_IS
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_2_Received_PTY();
               #endif
			   break;
             default:
               break;
           }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_set_User_PTY_req
 *===========================================================================*
 * @brief Receive a Request to Set the User PTY
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = User PTY
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = n
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_set_User_PTY_req(const PITS_Message_T * message)
{
   PITS_Channel_Selection_T channel_selection;
   Sys_Zone_T pits_zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_USER_PTY_SET_ACK, 4);	

      /* Decode received messages  */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;		    

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

	     channel_selection = (PITS_Channel_Selection_T)message->data[1];         
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
		       case PITS_AUDIO_CH_TUNER1:
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
      	          /* TODO Set_User_PTY();*/
		    	   break;
		       case PITS_AUDIO_CH_TMC:
		          #if PITS_TMC_IS
		            tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;  /*Temporal response until Define RDS */
		             /*TODO*/
		          #endif
		           break; 
		       case PITS_AUDIO_CH_TUNER2:
		       default:
		           break;
		      }
	       }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_tuner_get_Received_PTY_req
 *=========================================g==================================*
 * @brief Receive a Request to Get the Received PTY.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] tuner_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] tuner_tx_data[1] = Received PTY
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_tuner_get_Received_PTY_req(const PITS_Message_T * message)
{
   PITS_Channel_Selection_T channel_selection;
   Sys_Zone_T pits_zone;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      pits_tuner_compose_message_header(MID_TUNER_RECEIVED_PTY_REPORT, 4);	

      /* Decode received messages  */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;		    

         pits_zone = (Sys_Zone_T)message->data[0];
         tuner_tx_data[1] = (uint8_t) pits_zone;

	     channel_selection = (PITS_Channel_Selection_T)message->data[1];         
         tuner_tx_data[2] = (uint8_t) channel_selection;
        
         if (SYS_ZONE_MAIN == pits_zone)
         {
            switch (channel_selection)
            { 
		       case PITS_AUDIO_CH_TUNER1:
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_Received_PTY();
		    	   break;
		       case PITS_AUDIO_CH_TMC:
		          #if PITS_TMC_IS
		            tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;  /*Temporal response until Define RDS */
		             /*TODO*/
		          #endif
		           break; 
		       case PITS_AUDIO_CH_TUNER2:
                #if PITS_TUNER_2_IS
                  tuner_tx_data[0] = (uint8_t) SUCCESS;
                  tuner_tx_data[3] = PITS_Get_Tuner_2_Received_PTY();
                #endif
		       default:
	             break;
		      }
	       }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}



#if PITS_HD_IS
Done_Or_Not_Done_T pits_tuner_get_hd_radio_audio_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   HDR_Diagnostics_Information_T hd_diagnostics;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_HD_RADIO_AUDIO_STATUS_RPT, 4);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) SUCCESS;
         hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
         switch (hd_diagnostics.status_info.blend_mode)
         {
            case HDB_BLEND_MODE_ANALOG:
               tuner_tx_data[1] = PITS_BLEND_MODE_ANALOG;
               break;
            case HDB_BLEND_MODE_AUTO:
               tuner_tx_data[1] = PITS_BLEND_MODE_AUTO;
               break;
            case HDB_BLEND_MODE_DIGITAL:
               tuner_tx_data[1] = PITS_BLEND_MODE_DIGITAL;
               break;
            default:
               tuner_tx_data[1] = PITS_BLEND_MODE_ANALOG;
               break;
         }
         tuner_tx_data[2] = (uint8_t) hd_diagnostics.status_info.digital_audio_acquired;
         tuner_tx_data[3] = hd_diagnostics.station_info.current_audio_program;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_tuner_get_hd_radio_get_mode_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 
   HDR_Diagnostics_Information_T hd_diagnostics;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_HD_RADIO_GET_MODE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) SUCCESS;
         hd_diagnostics = HDR_Get_Diagnostics_Information(HD_RADIO_1);
         switch (hd_diagnostics.status_info.blend_mode)
         {
            case HDB_BLEND_MODE_ANALOG:
            tuner_tx_data[1] = PITS_BLEND_MODE_ANALOG;
            break;
            case HDB_BLEND_MODE_AUTO:
            tuner_tx_data[1] = PITS_BLEND_MODE_AUTO;
            break;
            case HDB_BLEND_MODE_DIGITAL:
            tuner_tx_data[1] = PITS_BLEND_MODE_DIGITAL;
            break;
            default:
            tuner_tx_data[1] = PITS_BLEND_MODE_ANALOG;
            break;
          }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_tuner_get_hd_radio_set_mode_req(const PITS_Message_T * message)
{
   HDB_Blend_Mode_T data_ptr;
   HDB_Blend_Mode_T new_mode;
   PITS_HD_BLEND_MODE_T pits_mode;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_HD_RADIO_SET_MODE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) SUCCESS;
         pits_mode = (PITS_HD_BLEND_MODE_T)message->data[0];
         if(pits_mode == PITS_BLEND_MODE_ANALOG)
         {
            new_mode = HDB_BLEND_MODE_ANALOG;
         }
         else if (pits_mode == PITS_BLEND_MODE_AUTO)
         {
            new_mode = HDB_BLEND_MODE_AUTO;
         }
         else if (pits_mode == PITS_BLEND_MODE_DIGITAL)
         {
            new_mode = HDB_BLEND_MODE_DIGITAL;
         }
         else
         {
            new_mode = HDB_BLEND_MODE_AUTO;
         }
         HDB_Set_Blend_Mode(HD_RADIO_1, new_mode, &data_ptr);
         tuner_tx_data[1] = message->data[0];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_tuner_set_hd_split_mode_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_SET_HD_SPLIT_MODE_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         tuner_tx_data[0] = (uint8_t) SUCCESS;
         tuner_tx_data[1] = message->data[0];
         HDB_Set_Digital_Analog_Split_Mode(message->data[0]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_tuner_set_hd_digital_delay_req(const PITS_Message_T * message)
{
   uint16_t pits_dad =0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_SET_HD_DIGITAL_DELAY_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         if((message->data[0]< 0x02) && (message->data[1]<0x06))
         {
            tuner_tx_data[0] = (uint8_t) SUCCESS;
            pits_dad = message->data[2];
            pits_dad = ((pits_dad<<8) & 0xFF00) + message->data[3];
            if ((pits_dad <= PITS_IDM_DAD_MAX)&&((IDM_CODEC_MODE_0 == message->data[1]) || (IDM_CODEC_MODE_2 == message->data[1])))
            {
               IDM_Set_Digital_Audio_Delay(message->data[0],message->data[1], pits_dad);
            }
            else
            {
               tuner_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
            }
         }
         else
         {
            tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         tuner_tx_data[1] = message->data[0];
         tuner_tx_data[2] = message->data[1];
         tuner_tx_data[3] = message->data[2];
         tuner_tx_data[4] = message->data[3];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_tuner_set_hd_audio_scale_req(const PITS_Message_T * message)
{
   uint16_t pits_das =0;
   Done_Or_Not_Done_T pits_status = NOT_DONE; 

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      tuner_tx_bus_id = message->bus;
      pits_tuner_compose_message_header(MID_TUNER_SET_HD_AUDIO_SCALE_RPT, 5);

      /* Compose Message Data */
      if (message->data_size != 4)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("TUNER Request: Message Data Error");
      }
      else
      {
         if((message->data[0]< 0x02) && (message->data[1]<0x06))
         {
            tuner_tx_data[0] = (uint8_t) SUCCESS;
            pits_das = message->data[2];
            pits_das = ((pits_das<<8) & 0xFF00) + message->data[3];
            if ((IDM_CODEC_MODE_0 == message->data[1]) || (IDM_CODEC_MODE_2 == message->data[1]))
            {
               IDM_Set_Digital_Audio_Scaling(message->data[0],message->data[1], pits_das);
            }
            else
            {
               tuner_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
            }
         }
         else
         {
            tuner_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         tuner_tx_data[1] = message->data[0];
         tuner_tx_data[2] = message->data[1];
         tuner_tx_data[3] = message->data[2];
         tuner_tx_data[4] = message->data[3];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&tuner_message);                      
      }
   }
   return (pits_status);
}
#endif /*PITS_HD_IS*/

/*===========================================================================*
 * FUNCTION: PITS_Set_Tuner_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_Tuner_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (tuner_session_state != session)   /* Session State change? */
   {
      tuner_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_AUDIO_SESSION, &tuner_session_state, sizeof(tuner_session_state));   /* Publish new Session State */
      if (tuner_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_tuner_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_tuner_session_timer_id, tuner_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_Tuner_Session(void)
{
   return (tuner_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_Tuner_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_Tuner_Timer(void)
{
   SAL_Create_Timer(PITS_EV_TUNER_SESSION_TIMEOUT, &pits_tuner_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Tuner_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_Tuner_Timer(void)
{
   SAL_Destroy_Timer(pits_tuner_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_Tuner_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_Tuner_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_TUNER_SESSION_TIMEOUT)
   {
      if (PITS_Set_Tuner_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS TUNER SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_TUNER_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Tuner_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &tuner_session_state, sizeof(tuner_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Tuner_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_Tuner_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_TUNER_SESSION,NULL,0,PITS_EVG_TUNER_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_TUNER_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}


/*===========================================================================*/
/*!
 * @file pits_tuner_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Tuner Services Session Timer function.
 * 
 *  06-Sep-2012 Darinka L�pez Rev 59
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 01 Ago 2012 Miguel Garcia 58
 * Task kok_basa#112307 Include Pits Set Tuner 2
 *
 * 26 Jul 2012 Miguel Garcia 57
 * Fix hd set call to pointer
 *
 * 6-Jul-2012 Arturo Perez 56
 * Task kok_basa#107504 - Implement MID 10/11 & 38/39 for Tuner2
 *
 * 4-Jul-2012 Juan Carlos Castillo 55
 * Task kok_basa#106816 - implement TMC Signal Strength
 *
 * 22-May-2012 Juan Carlos Castillo 54
 * Task kok_basa#98416 - gmsbx14_pits - Received PTY PITs
 *
 * 17-May-2012 Juan Carlos Castillo 53
 * Task kok_basa#96194 - gmsbx14_pits - Signal Strength and PI code Pit.
 *
 * 1-May-2012 Darinka Lopez  Rev 52
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 30-Mar-2012 Oscar Vega 51
 * Task kok_basa#86208 - Fix DAB message to use 1 byte to get frequency.
 *
 * 28-Mar-2012 Oscar Vega 50
 * Task kok_basa#85766 - 20 - Fix DAB message to use 1 byte.
 *
 * 27 Feb 2012 Miguel Garcia Rev 47
 * Fix XM setting with SID for ICR
 *
 * 30-Jan-2012 Oscar Vega  Rev 47
 * SCR kok_basa#21073: Implemente set/get Request Band and Frequency for DAB
 * Fix: Implement code to get and set frequency for DAB.
 *
 * 13-Jan-2012 Darinka Lopez  Rev 46
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move specific functions for TMC.
 *
 * 05-Jan-2012 Darinka Lopez  Rev 44
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move tuner specif fuctions to proccesing_tuner file .
 *
 * 03 Jan 2012 Miguel Garcia Rev 43
 * Update ICR select XM
 *
 * 27 Dec 2011 Miguel Garcia Rev 42
 * Update pits ICR functions to match PDD and SBX
 *
 * 16-Dec-2011 Manuel Robledo  Rev 41
 * SCR kok_basa#17410: Use SSM event to define current band
 *
 * 14-Dec-2011 Darinka Lopez  Rev 40
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 39
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 28 Nov 2011 Miguel Garcia
 * Include changes for tuner porting
 *
 * 08-Nov-2011 Marco Castillo  Rev 36
 * SCR kok_basa#17665 :  Create PIT for getting the TMC Tuner Frequency.
 *
 * 07-Nov-2011 Oscar Vega  Rev 35
 * SCR kok_basa#17473 :  Create PIT to support TMC RF circuitry manufacturing test.
 * Create functionality to support TMC RF circuitry manufacturing test.
 *
 * 07-Nov-2011 Darinka Lopez  Rev 34
 * SCR kok_basa#17610:  Implement TMC Channel in Tuner Services MSID 11
 * Add zone in PI and PTY messages.
 *
 * 07-Nov-2011 Darinka Lopez  Rev 33
 * SCR kok_basa#17610:  Implement TMC Channel in Tuner Services MSID 11
 * Add Channel input in Tuner messages.
 *
 * 03-Nov-2011 Manuel Robledo  Rev 32
 * SCR kok_basa#16238: Implement message for Set Receiver Band and Frequency.
 * SCR kok_basa#17422: Add service ID to Get/set band and frequency PIT
 *
 * 01-Nov-2011 Darinka Lopez  Rev 31
 * SCR kok_basa#17394: Create general function for pits_manager (events)
 * Add X macro for suscribe events.
 *
 * 28-Oct-2011 Manuel Robledo  Rev 30
 * SCR kok_basa#16239: Implement message for Get Receiver Band and Frequency.
 * Implement PITS_Get_Current_Station_Info, PITS_Get_Tuner_Source_Type, PITS_Get_Tuner_Frequency
 * PITS_Get_Tuner_Quality and PITS_Get_Tuner_HD_Subchannel
 *
 * 26-Oct-2011 Darinka Lopez  Rev 29
 * SCR kok_basa#16236: Implement MSID(11h) - Tuner Services
 * Fix: Tune function is commented to avoid fault issues in the Radio.
 *
 * 26-Oct-2011 Darinka Lopez  Rev 28
 * SCR kok_basa#16236: Implement MSID(11h) - Tuner Services
 * Fix: Make Tuner Services common for ICR and SBX projects.
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 23 June 2011 Miguel Garcia
 * Include HD services
 *
 * 04 Mar 2011 Miguel Garcia Rev 22
 * Include dpid functions
 *
 * 22 Feb 2011 Miguel Garcia Rev 21
 * Include HD changes HDR_EVG_DIAG_UPDATE_T
 *
 * 01 Feb 2011 Miguel Garcia Rev 20
 * Include HD set mode.
 *
 * 25 Jan 2011 Miguel Garcia Rev19
 * Remove HD pits from AP.
 *
 * 13-Jan-2011 Miguel Garcia  Rev 18
 * Remove unused Pits services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 16
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 15
 *   - SCR kok_basa#1607: pits_event_types.h includes fix
 *      Specifically fixes SCR kok_basa#1637
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 13
 *  Merged: Fix parallel versions
 *
 * 08-Jul-2010 Miguel Garcia  Rev 12
 * SCR kok_basa#1676: Implement Diagnostic Services PITS for DIDs in APP.
 *
 * 04-May-2010 Miguel Garcia  Rev 11
 * SCR kok_basa#1397: Implement pits_tuner_set_band_and_channel.
 *
 * 2-Oct-2009 David Mooar  Rev 10
 * SCR kok_aud#63224: Fix compiler warning with hd_diagnostics initialization.
 *
 * 2-Oct-2009 David Mooar  Rev 9
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 * SCR kok_aud#63224: Fix hd_diagnostics in pits_tuner_get_hd_radio_audio_status_req.
 *
 * 12-Sept-2009 David Mooar  Rev 8
 * SCR kok_aud#62402: Fix PITs response for HD blend mode.
 *
 * 10-Sept-2009 David Mooar  Rev 7
 * SCR kok_aud#62396/62402: Implement PITS Tuner messages.
 *
 * - 18-august-2009 David Mooar  Rev 6
 *   SCR kok_aud#62242: Remove warning due to Tuner_Seek direction.
 *
 * - 29-Apr-2009 Yi Liu
 *   - Fixed Compile warnings.
 *
 * - 13-Mar-2009 Yi Liu
 *   - Fixed errors found during tests.
 *
 * - 16-Jan-2009 Yi Liu
 *   - Updated the tuner services with latest APIs.
 *
 * - 12-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
