/*===========================================================================*/
/**
 * @file pits_bt_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_bt_services.c~3:csrc:ctc_ec#18 %
 * @version %version:3 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Fri Jul 15 17:33:42 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "betula_bluetooth_diag.h"
#include "em.h"
#include "pbc_trace.h"
#include "pits_bt_services.h"
#include "pits_bt_services_cbk.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "ps_ds_friend.h"

EM_FILENUM(PITS_MODULE_ID_5, 24);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
#if PITS_BLUETOOTH_IS
typedef enum HFAP_Diag_Loopback_Mode_Tag
{
   HFAP_DIAG_LOOPBACK_DISABLED            = 0x00,
   HFAP_DIAG_LOOPBACK_INTERNAL,
   HFAP_DIAG_LOOPBACK_PASSTRHROUGH,
   HFAP_DIAG_LOOPBACK_BCCMD_COMMAND
}HFAP_Diag_Loopback_Mode_T;

typedef enum BT_COEX_Setup_Tag
{
   BT_COEX_PATTERN_0,
   BT_COEX_PATTERN_1,
   BT_COEX_PATTERN_MAX
}BT_COEX_SETUP_T;

#endif

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_bt_initialize(void);
#if PITS_BLUETOOTH_IS
static void pits_bt_compose_message_header(uint8_t mid, uint8_t size);
#endif
/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_BT_RX_INDEX

#define MID_BT_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_bt_rx_messages[] = {
   MID_BT_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_BT_TX_INDEX

#define MID_BT_TX_INDEX(name, mid) (mid),

static const uint8_t pits_bt_tx_messages[] = {
   MID_BT_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_BT_RX_INDEX
#define MSID_BT_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_bt_rx_message_sets[] = {
   MSID_BT_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_BT_TX_INDEX
#define MSID_BT_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_bt_tx_message_sets[] = {
   MSID_BT_TX_TABLE
};

static uint8_t bt_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T bt_message;      /* for construction of a bluetooth service message to be transmitted */

static uint8_t bt_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t bt_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T bt_session_state;

/**
 * Stores Timer ID for Bluetooth Services Session
 */
static SAL_Timer_Id_T pits_bt_session_timer_id;

#if PITS_BLUETOOTH_IS
static bool_t BT_BCCMD_Results_Pending = false;
static bool_t BT_BCCMD_Results_Available = false;
static BT_DIAG_EVG_COMMAND_RESULT_T BT_BCCMD_Result;
static uint8_t BT_BCCMD_Result_Data[BT_PITS_MAX_BCCMD_LEN];
static uint8_t last_loopback_test_mode;
static uint8_t bt_cleared_devices = 0;
#endif
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_BT_Services_Interface = {
   pits_bt_initialize,
   pits_bt_rx_message_sets,
   Num_Elems(pits_bt_rx_message_sets),
   pits_bt_tx_message_sets,
   Num_Elems(pits_bt_tx_message_sets),
};


/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_bt_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_bt_initialize(void)
{
   bt_tx_bus_id = 0;
   memset(&bt_message, 0x00, sizeof(PITS_Message_T));
   memset(bt_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   bt_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   bt_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that BT Session is closed? */
}

#if PITS_BLUETOOTH_IS
/*===========================================================================*
 * FUNCTION: pits_CD_compose_message_header
 *===========================================================================*
 * @brief This function compose the buffer structure
 *
 * @returns
 * @param [in] mid = Response MID
 * @param [in] size = cd tx data size
 *
 * @pre
 *
 * @post
 *
 * This function is executed in each pit response */
/*===========================================================================*/
static void pits_bt_compose_message_header(uint8_t mid, uint8_t size)
{
   bt_message.bus = bt_tx_bus_id;
   bt_message.data = bt_tx_data;
   bt_message.MSID = MSID_BT_SERVICES;
   bt_message.MID = mid;
   bt_message.data_size = size;
   memset(bt_tx_data, 0x00, size);
}

/*===========================================================================*
 * FUNCTION: pits_bt_test_req
 *===========================================================================*
 * @brief Receive a Request for Bluetooth Configuration
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Configuration item
 * @param [out] bt_tx_data[0] = Configuration requested
 * @param [out] bt_tx_data[1] = Range
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_test_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t data[2] = {0};

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_TEST_RPT, 2);
      /* Compose Message Data */
      if (1 != message->data_size)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t)  SUCCESS;
         bt_tx_data[1] = message->data[0];

         if(1 == message->data[0])
         {
            /* Enter into BT diagnostic mode */
            data[0] = 0x03;
            data[1] = 0x18;

            BT_DIAG_Send_HCI_Command(data, sizeof(data));

         }
         else if(0 == message->data[0])
         {
            /* Exit from BT diagnostic mode */
            data[0] = 0x03;
            data[1] = 0x0C;

            BT_DIAG_Send_HCI_Command(data, sizeof(data));

         }
         else
         {
            /* Invalid command */
            bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_test_req
 *===========================================================================*
 * @brief Receive a Request for Bluetooth Configuration
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Configuration item
 * @param [out] bt_tx_data[0] = Configuration requested
 * @param [out] bt_tx_data[1] = Range
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_btaddress_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_BTADDRESS_RPT, 7);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Device_Address_T read_address;
         bt_tx_data[0] = (uint8_t) SUCCESS;
         BT_CM_PS_Get_BDAddress(&read_address);
         memcpy(&bt_tx_data[1], read_address, sizeof(read_address));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);        
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_name_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[32] = Name 32 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_conname_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_CONNAME_RPT, 36);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] =(uint8_t) SUCCESS;
         if (PITS_Get_Bt_Status_Connected() == BT_CM_STATE_CONNECTED)
         {
            bt_tx_data[1] = 0x01;
            bt_tx_data[2] = 0x00;
            Pits_Get_Diag_Btconnected_Name(&bt_tx_data[2]);
            bt_message.data_size = bt_tx_data[2] + 3;
         }
         else
         {
            bt_message.data_size = 3;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_name_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[32] = Name 32 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_name_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_NAME_RPT, BT_PITS_NAME_LENGTH+2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = PITS_BT_Get_Name_Req_Processing(&bt_tx_data[1]);
         bt_message.data_size = 2 + bt_tx_data[1];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_set_name_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[32] = Name 32 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_name_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_NAME_RPT, (2 + message->data[0]));

      /* Compose Message Data */
      bt_tx_data[0] =(uint8_t) FAIL;
      if (message->data_size != (1 + message->data[0]))
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[1] = message->data[0];
         if (message->data[0] == 0)
         {
            bt_tx_data[0] =(uint8_t) SUCCESS;
            PITS_BT_DIAG_PS_Write_Name(NULL, 0);
         }
         else if (message->data[0] <= BT_PITS_NAME_LENGTH)
         {
            bt_tx_data[0] =(uint8_t) SUCCESS;
            memcpy(&bt_tx_data[2], &message->data[1], message->data[0]);
            PITS_BT_DIAG_PS_Write_Name(&message->data[1], message->data[0]);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_btaddress_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   Tr_Info_Lo("pits_bt_set_btaddress_req");

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_BTADDRESS_RPT, 7);
      /* Compose Message Data */
      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] =(uint8_t) SUCCESS;
         memcpy(&bt_tx_data[1], &message->data[0], BT_PITS_ADDRESS_LENGTH);
         system("mount -o remount,rw /factory_data");
         BT_CM_PS_Put_BDAddress(&message->data[0]);
         PS_Save_Now();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_connected_dev_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   Tr_Info_Lo("pits_bt_get_connected_dev_req");

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_CONNECT_DEV_RPT, 8);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) SUCCESS;
         if (PITS_Get_Bt_Status_Connected() == BT_CM_STATE_CONNECTED)
         {
            bt_tx_data[1] = 1;
            Pits_Get_Diag_Btconnected_Address(&bt_tx_data[2]);
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_pairing_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_PAIRING_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
               bt_tx_data[0] = (uint8_t) FAIL;
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {
               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

               /* check result status */

                  Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
                  Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
                  Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
                  Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
                  Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);


                  /* success! fill out return message data*/
                  bt_tx_data[0] = (uint8_t) SUCCESS;
                  bt_tx_data[1] = get_module_state.pairable;
             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
                bt_tx_data[0] = (uint8_t) FAIL;
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
            bt_tx_data[0] = (uint8_t) FAIL;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_pairing_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state = {1,1,1,1};
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_PAIRING_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {

               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

               /* check result status */
               Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
               Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
               Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
               Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
               Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);

             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
         }

         if (message->data[0] < 2)
         {
            BT_CM_Set_Settings(get_module_state.radio_on,message->data[0],get_module_state.discoverable,get_module_state.connectable);
            bt_tx_data[0] = (uint8_t) SUCCESS;
            bt_tx_data[1] = message->data[0];
         }
         else
         {
            bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_discover_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_DISCOVER_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
               bt_tx_data[0] = (uint8_t) FAIL;
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {
               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

               /* check result status */
                  Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
                  Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
                  Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
                  Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
                  Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);

                  /* success! fill out return message data*/
                  bt_tx_data[0] = (uint8_t) SUCCESS;
                  bt_tx_data[1] = get_module_state.discoverable;
             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
                bt_tx_data[0] = (uint8_t) FAIL;
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
            bt_tx_data[0] = (uint8_t) FAIL;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_discover_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state = {1,1,1,1};
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_DISCOVER_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Start_Connection_Manager();   /*set bt status ON*/
	  
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {
               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

                  /* check result status */
                  Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
                  Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
                  Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
                  Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
                  Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);
             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
         }

         if (message->data[0] < 2)
         {
            BT_CM_Set_Settings(get_module_state.radio_on,get_module_state.pairable,message->data[0],get_module_state.connectable);
            bt_tx_data[0] = (uint8_t) SUCCESS;
            bt_tx_data[1] = message->data[0];
         }
         else
         {
            bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_connectability_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_CONNECTABILITY_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
               bt_tx_data[0] = (uint8_t) FAIL;
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {
               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

               /* check result status */
                  Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
                  Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
                  Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
                  Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
                  Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);

                  /* success! fill out return message data*/
                  bt_tx_data[0] = (uint8_t) SUCCESS;
                  bt_tx_data[1] = get_module_state.connectable;
             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
                bt_tx_data[0] = (uint8_t) FAIL;
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
            bt_tx_data[0] = (uint8_t) FAIL;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_connectability_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_CM_EVG_MODULE_STATUS };
   BT_CM_EVG_MODULE_STATUS_T get_module_state = {1,1,1,1};
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_CONNECTABILITY_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         BT_CM_Get_Status(PITS_APP_ID,PITS_THREAD_ID);
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),50);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
            }
            else if((NULL != msg) && (msg->event_id == BT_CM_EVG_MODULE_STATUS))
            {
               Tr_Info_Lo("BT_CM_EVG_MODULE_STATUS received ");

               /* correct message received, parse the data */
                get_module_state = BT_CM_Get_Module_State_Details((SAL_Event_Id_T)msg->event_id, msg->data, msg->data_size);

               /* check result status */
                  Tr_Info_Lo_1("Get Module state = %d",get_module_state.state);
                  Tr_Info_Lo_1("Get Module connectable = %d",get_module_state.connectable);
                  Tr_Info_Lo_1("Get Module pairable = %d",get_module_state.pairable);
                  Tr_Info_Lo_1("Get Module radio_on = %d",get_module_state.radio_on);
                  Tr_Info_Lo_1("Get Module discoverable = %d",get_module_state.discoverable);

             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
         }

         if (message->data[0] < 2)
         {
            BT_CM_Set_Settings(get_module_state.radio_on,get_module_state.pairable,get_module_state.discoverable,message->data[0]);
            bt_tx_data[0] = (uint8_t) SUCCESS;
            bt_tx_data[1] = message->data[0];
         }
         else
         {
            bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_echo_cancel_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_ECHO_CANCEL_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = (uint8_t)PITS_HFAP_Diag_Get_AEC_State();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_echo_cancel_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_ECHO_CANCEL_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         if (message->data[0] < 2)
         {
            bt_tx_data[0] = (uint8_t) SUCCESS;
            PITS_HFAP_Diag_Set_Diag_Mode(true);
            if (message->data[0] == 0)
            {
               PITS_HFAP_Diag_Set_AEC_State(0x02);
               bt_tx_data[1] = 0;
            }
            if (message->data[0] == 1)
            {
               PITS_HFAP_Diag_Set_AEC_State(0x01);
               bt_tx_data[1] = 1;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_bt_reset_echo_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_ECHO_CANCEL_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         PITS_HFAP_Diag_Set_Diag_Mode(false);
         pits_status = DONE;             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_profile_req(const PITS_Message_T * message)
{
   uint8_t bt_profile[5] = {0};
   uint8_t bt_stream;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_PROFILE_RPT, 13);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) SUCCESS;
         if (PITS_Get_Bt_Status_Connected() == BT_CM_STATE_CONNECTED)
         {
            bt_tx_data[1] = 1;
            Pits_Get_Diag_Btconnected_Address(&bt_tx_data[2]);
            Pits_Get_Diag_Btconnected_Profile(&bt_profile[0]);
            /* Hands Free*/
            if (bt_profile[0]==1)
            {
               bt_tx_data[8] |= BIT7;
            }
            /*App*/
            if (bt_profile[4]==1)
            {
               bt_tx_data[10] |= BIT7;
            }
            /*Net not supported*/
            bt_tx_data[11] = 0;
            /*Phone book*/
            if (bt_profile[1]==1)
            {
               bt_tx_data[12] |= BIT7;
            }
            /*Message Access*/
            if (bt_profile[2]==1)
            {
               bt_tx_data[12] |= BIT6;
            }
            bt_stream = Pits_Get_Diag_Btprofile_stream();
            /* Stream*/
            if (bt_stream==0)
            {
               bt_tx_data[9] |= BIT7;
            }
            else if (bt_stream==1)
            {
               bt_tx_data[9] |= BIT6;
            }
            else if (bt_stream==2)
            {
               bt_tx_data[9] |= BIT5;
            }
            else if (bt_stream==3)
            {
               bt_tx_data[9] |= BIT4;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_profile_req(const PITS_Message_T * message)
{
   uint8_t new_address[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
   uint8_t devices_number = 0;
   bool_t  device_paired = false;
   uint8_t bt_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_PROFILE_RPT, 8);
      /* Compose Message Data */
      if (message->data_size != 6)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         devices_number = (uint8_t) Pits_Get_Diag_Btdevices_Number();
         if (devices_number > 0)
         {
            for (bt_index = 0; bt_index < devices_number; bt_index++)
            {
               Pits_Get_Diag_Bt_Address_Paired(bt_index, &new_address[0]);
               if(0 == memcmp(&message->data[0], &new_address[0], sizeof(new_address)))
               {
                  device_paired = true;
               }
            }
            if (device_paired)
            {
               memcpy(&new_address,&message->data[0], sizeof(new_address));
               BT_CM_Connect_Device(&new_address[0]);
               bt_tx_data[0] = (uint8_t) SUCCESS;
               bt_tx_data[1] = 0x01;
            }
            else
            {
               bt_tx_data[0] = (uint8_t) FAIL;
               bt_tx_data[1] = 0x00;
            }
            memcpy(&bt_tx_data[2],&message->data[0], message->data_size);
         }
         else
         {
            bt_tx_data[0] = (uint8_t) FAIL;
            bt_tx_data[1] = 0x00;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_disconnect_req(const PITS_Message_T * message)
{
   uint8_t new_address[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_DISCONNECT_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 7)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         if (message->data[0] < 2)
         {
            bt_tx_data[0] = (uint8_t) SUCCESS;
            if (message->data[0] == 0)
            {
               /*Disconnect all*/
               BT_CM_Disconnect_Device(&new_address[0]);
               bt_tx_data[1] = 0x02;
            }
            else
            {
               memcpy(&new_address,&message->data[1], sizeof(new_address));
               BT_CM_Disconnect_Device(&new_address[0]);
               bt_tx_data[1] = 0x01;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_signal_strength_req(const PITS_Message_T * message)
{
   SAL_Message_T const *msg;
   SAL_Event_Id_T subscribe_list[] = {BT_DIAG_EVG_COMMAND_FAILURE, BT_DIAG_EVG_RSSI_RESULT };
   BT_DIAG_EVG_RSSI_RESULT_T rssi_result;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_SIGNAL_STRENGTH_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) FAIL;
         /*
          * request the signal strength in the current connection
          */
         if (SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list)))
         {
            BT_DIAG_Request_RSSI(0);
            msg = SAL_Receive_Only_Timeout(subscribe_list, Num_Elems(subscribe_list),200);
            if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_COMMAND_FAILURE))
            {
               Tr_Info_Hi("error BT_DIAG_EVG_COMMAND_FAILURE ");
               /*
                * set negative response
                */
            }
            else if((NULL != msg) && (msg->event_id == BT_DIAG_EVG_RSSI_RESULT))
            {
               Tr_Info_Lo("BT_DIAG_EVG_RSSI_RESULT received ");

               /* correct message received, parse the data */
               rssi_result = BT_DIAG_Get_RSSI_Result(msg->event_id, msg->data, msg->data_size);

               /* check result status */
               if (BT_DIAG_OK == rssi_result.result_code)
               {
                  Tr_Info_Lo_1("Signal strength result = 0x%2.2X", rssi_result.rssi_value);
                  bt_tx_data[0] = (uint8_t) SUCCESS;
                  bt_tx_data[1] = rssi_result.rssi_value;
               }
               else
               {
                  Tr_Info_Mid("Failed to retrieve signal strength");
                  /*
                   * set negative response
                   */
               }
             }
             else
             {
                Tr_Warn(" BT_DIAG_EVG_RSSI_RESULT timeout error");
             }
             /* Unsubscribe from the message needed for this test case */
             SAL_Unsubscribe(subscribe_list, Num_Elems(subscribe_list));
         }
         else
         {
            Tr_Warn("Unsuccessful subscription");
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_setup_coexistence_req
 *===========================================================================*
 * @brief setup coexistence pin status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[1] = selected loopback test mode
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_setup_coexistence_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t product_id1[]= {0x00, 0xFC, 0x0B, 0xC2, 0x02, 0x00,
                           0x05, 0x00, 0x12, 0x34, 0x1E, 0x68,
                           0xFF, 0xFF};

   Tr_Info_Lo(" Call pits_bt_setup_coexistence_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SETUP_COEXISTENCE_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT pits_bt_setup_coexistence_req REQUEST: Message Data Error");
      }
      else
      {
         uint8_t coex_pattern = message->data[0];

         Tr_Info_Lo_1("coex_pattern =%d", coex_pattern);

         if (BT_COEX_PATTERN_MAX > coex_pattern)
         {
            bt_tx_data[0] = (uint8_t) SUCCESS;
            
            BT_DIAG_Send_HCI_Command(product_id1, sizeof(product_id1));


            SAL_Sleep(100);
            
            if (BT_COEX_PATTERN_0 == coex_pattern)/* All bit set to 0 */
            {
               uint8_t product_id2[]= {0x00, 0xFC, 0x0B, 0xC2, 0x02, 0x00,
                                       0x05, 0x00, 0x12, 0x34, 0x1F, 0x68,
                                       0x00, 0x00};
               BT_DIAG_Send_HCI_Command(product_id2, sizeof(product_id2));
            }
            else if (BT_COEX_PATTERN_1 == coex_pattern)/* All bit set to 1 */
            {
               uint8_t product_id2[]= {0x00, 0xFC, 0x0B, 0xC2, 0x02, 0x00,
                                       0x05, 0x00, 0x12, 0x34, 0x1F, 0x68,
                                       0xFF, 0xFF};
               BT_DIAG_Send_HCI_Command(product_id2, sizeof(product_id2));
            }
            else
            {
               /* do nothing */
            }
         }
         else
         {
            bt_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
         }
            
         bt_tx_data[1] = coex_pattern;
         
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_paired_num_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_PAIRED_NUM_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = Pits_Get_Diag_Btdevices_Number();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_clear_paired_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_CLEAR_PAIRED_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         bt_tx_data[0] = (uint8_t) SUCCESS;
         if (Pits_Get_Diag_Btdevices_Number() > 0)
         {
            BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
            bt_tx_data[1] = 1;
         }
         else
         {
            bt_tx_data[1] = 0;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_clear_all_devices_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      pits_bt_compose_message_header(MID_BT_CLEAR_PAIRED_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         bt_tx_data[0] = (uint8_t) SUCCESS;
         if (Pits_Get_Diag_Btdevices_Number() > 0)
         {
            BT_CM_Delete_Device(BT_CM_ALL_PAIRED_DEVICES);
            bt_cleared_devices = 1;
         }
         else
         {
            bt_cleared_devices = 0;
         }
         pits_status = DONE;
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_get_all_devices_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_all_devices_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      pits_bt_compose_message_header(MID_BT_CLEAR_PAIRED_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = bt_cleared_devices;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_get_ps_key_req
 *===========================================================================*
 * @brief Receive a Request for a PS key
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_ps_key_req(const PITS_Message_T * message)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] = {BT_DIAG_EVG_PS_DATA};
   BT_DIAG_EVG_PS_DATA_T ps_data;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_get_ps_key_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_PS_KEY_RPT, 5);
      /* Compose Message Data */
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         uint16_t pskey = (message->data[0] << 8) | message->data[1];

         Tr_Info_Lo_1("Requested PSKey 0x%4.4X", pskey);

         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = message->data[0];
         bt_tx_data[2] = message->data[1];
         bt_tx_data[3] = 0;

         /* subscribe to the response event */
         if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
         {
            /* trigger the PS read */
            BT_DIAG_PS_Read(BT_DIAG_PS_DEFAULT_STORAGE, pskey, 128);
            
            /* wait for the response event */
            response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 200); /** @todo what is an appropriate timeout? how long can we block the queue? */

            if (NULL != response_message)
            {
               Tr_Info_Lo("PSKey Response Received");
               if (BT_DIAG_EVG_PS_DATA == response_message->event_id)
               {
                  /* parse the response data */
                  ps_data = BT_DIAG_Get_PS_Data_Info(response_message->event_id, response_message->data, response_message->data_size);
                  Tr_Info_Lo_1("PSKey Received: 0x%4.4X", ps_data.ps_key);
                  
                  /* is this the same key we were trying to read? */
                  if (ps_data.ps_key == pskey)
                  {
                     /* check the data length */
                     if (0xFF >= ps_data.data_length)
                     {
                        Tr_Info_Lo_1("Returning PSKey with %d bytes", ps_data.data_length);
                        /* copy the data into the outgoing buffer */
                        bt_message.data_size = 4+ps_data.data_length;
                        bt_tx_data[3] = ps_data.data_length;
                        BT_DIAG_Copy_PS_Data(response_message->event_id, response_message->data, response_message->data_size, &bt_tx_data[4]);
                     }
                     else
                     {
                        Tr_Info_Lo_1("PSKey data was too large: %d", ps_data.data_length);
                        /* there is really no way this should be possible... */
                        bt_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
                     }
                  }
                  
               }
            }
            SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_ps_key_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_PS_KEY_RPT, 3);
      /* Compose Message Data */
      if (message->data_size != 3)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         /*  Fix with bt set ps function function
         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = Set_BT_PS_KEY();*/
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_bccmd_req
 *===========================================================================*
 * @brief Receive a Request message to send a BCCMD (Bluetooth Command) to the product which will then be used to execute commands in the Bluetooth device.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size > 0
 * @pre message->data_size > message->data[0]
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_bccmd_req(const PITS_Message_T * message)
{
   SAL_Message_T const *response_message = NULL;
   SAL_Event_Id_T event_id_list[] = {BT_DIAG_EVG_COMMAND_RESULT};
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_set_bccmd_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_BCCMD_RPT, 1);
      /* Compose Message Data */
      if (message->data_size == 0)
      {
         Tr_Info_Lo("Message Data Error");
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         if ((0 == message->data[0]) || (message->data_size < (message->data[0]+1)))
         {
            Tr_Info_Lo("Message Data Error");
            pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
         }
         else
         {
            Tr_Info_Lo_1("Requested BCCMD with length=%d", message->data[0]);
            /* subscribe to the response event */
            if (SAL_Subscribe(event_id_list, Num_Elems(event_id_list)))
            {
               BT_BCCMD_Results_Pending = true;
               BT_BCCMD_Results_Available = false;

               /* trigger the BCCMD transmit */
               BT_DIAG_Send_Vendor_Command(&message->data[1], message->data[0]);

               /* wait for the response event */
               response_message = SAL_Receive_Only_Timeout(event_id_list, Num_Elems(event_id_list), 600); /** @todo what is an appropriate timeout? how long can we block the queue? even the quickest commands take 300 ms or so.*/

               if (NULL != response_message)
               {
                  Tr_Info_Lo("BCCMD Response Received");
                  BT_BCCMD_Results_Pending = false;

                  if (BT_DIAG_EVG_COMMAND_RESULT == response_message->event_id)
                  {
                     /* parse the response data */
                     BT_BCCMD_Result = BT_DIAG_Get_Result_Data_Info(response_message->event_id, response_message->data, response_message->data_size);
                     Tr_Info_Lo_1("BCCMD Response Length: %d bytes", BT_BCCMD_Result.data_length);
                     if (BT_PITS_MAX_BCCMD_LEN < BT_BCCMD_Result.data_length)
                     {
                        Tr_Info_Lo_1("Truncating to %d bytes", BT_PITS_MAX_BCCMD_LEN);
                        BT_BCCMD_Result.data_length = BT_PITS_MAX_BCCMD_LEN;
                        memcpy(BT_BCCMD_Result_Data, BT_BCCMD_Result.data_pointer, BT_PITS_MAX_BCCMD_LEN);
                        BT_BCCMD_Result.data_pointer = &BT_BCCMD_Result_Data[0];
                        BT_BCCMD_Results_Available = true;
                     }
                     else
                     {
                        if ((0 == BT_BCCMD_Result.data_length) || (NULL == BT_BCCMD_Result.data_pointer))
                        {
                           BT_BCCMD_Result.data_length = 0;
                           BT_BCCMD_Result_Data[0] = 0;
                        }
                        else
                        {
                           memcpy(BT_BCCMD_Result_Data, BT_BCCMD_Result.data_pointer, BT_BCCMD_Result.data_length);
                        }
                        BT_BCCMD_Result.data_pointer = &BT_BCCMD_Result_Data[0];
                     }
                     
                     BT_BCCMD_Results_Available = true;
                     bt_tx_data[0] = (uint8_t) SUCCESS;
                  }
               }
               SAL_Unsubscribe(event_id_list, Num_Elems(event_id_list));
            }
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
         }
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_get_bccmd_req
 *===========================================================================*
 * @brief Receive a Request message to retrieved the BCCMD result data
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_bccmd_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   Tr_Info_Lo("pits_bt_get_bccmd_req");

   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_BCCMD_RPT, 2);
      /* Compose Message Data */
      bt_tx_data[0] = (uint8_t) FAIL;

      if (message->data_size != 0)
      {
         Tr_Info_Lo("Message Data Error");
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) SUCCESS;

         if (BT_BCCMD_Results_Pending)
         {
            Tr_Info_Lo("Result: Command Pending");
            bt_tx_data[1] = 1; /* Command Pending */
         }
         else if (BT_BCCMD_Results_Available)
         {
            if (BT_DIAG_OK == BT_BCCMD_Result.result_code)
            {
               if ((BT_PITS_MAX_BCCMD_LEN >= BT_BCCMD_Result.data_length)&&(NULL != BT_BCCMD_Result.data_pointer))
               {
                  Tr_Info_Lo_1("Result: Results Available (data len = %d bytes)", BT_BCCMD_Result.data_length);
                  bt_tx_data[1] = 3; /* Results Available */
                  bt_tx_data[2] = BT_BCCMD_Result.data_length;
                  memcpy(&(bt_tx_data[3]), BT_BCCMD_Result.data_pointer, BT_BCCMD_Result.data_length);
                  bt_message.data_size = 3 + BT_BCCMD_Result.data_length;
               }
               else
               {
                  bt_tx_data[1] = 0; /* No Command Executed */
               }
            }
            else
            {
               Tr_Info_Lo("Result: Command Error");
               bt_tx_data[1] = 2; /* Command Error */
            }

            BT_BCCMD_Results_Available = false;
         }
         else
         {
            Tr_Info_Lo("Result: No Command Executed");
            bt_tx_data[1] = 0; /* No Command Executed */
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btaddress_req
 *===========================================================================*
 * @brief Receive a Request for the Initialization, status, and completion of the pairing process
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[6] = Address 6 bytes
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_reset_chip_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_reset_chip_req ");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_RESET_CHIP_RPT, 2);
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {

         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = 1;
         BT_CM_Set_Settings(false,false,false,false);
         BT_CM_Set_Settings(true, true, true, true );
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             

      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_btloop_req
 *===========================================================================*
 * @brief sets the loopback test mode
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] bt_tx_data[0] = success
 * @param [out] bt_tx_data[1] = selected loopback test mode
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_btloop_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t loopback_test_mode = HFAP_DIAG_LOOPBACK_DISABLED;

   Tr_Info_Lo(" Call pits_bt_set_btloop_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_BTLOOP_RPT, 2);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         loopback_test_mode = message->data[0];

         bt_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;

         if((HFAP_DIAG_LOOPBACK_DISABLED == loopback_test_mode) || (HFAP_DIAG_LOOPBACK_BCCMD_COMMAND == loopback_test_mode))
         {
            bt_tx_data[0] = (uint8_t) SUCCESS;
            bt_tx_data[1] = loopback_test_mode;
            last_loopback_test_mode = loopback_test_mode;

            if(HFAP_DIAG_LOOPBACK_DISABLED == loopback_test_mode)
            {
               BT_CM_Mfg_Test_Send_PCM_Loopback(false);
            }
            else
            {
               BT_CM_Mfg_Test_Send_PCM_Loopback(true);
            }

            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);
         }
         else
         {
            pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
         }
      }
   }

   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_get_btloop_req
 *===========================================================================*
 * @brief returns the current loopback status mode
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_btloop_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_get_btloop_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_BTLOOP_RPT, 2);
      if (message->data_size != 0)
      {
         Tr_Info_Lo("Message Data Error");
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Message Data Error");
      }
      else
      {
         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = last_loopback_test_mode;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: pits_bt_get_align_cal_req
 *===========================================================================*
 * @brief Receive a Request message for the Alignment CAL Value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_get_align_cal_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_get_align_cal_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_GET_ALIGN_CAL_RPT, 2);
      /* Compose Message Data */
      bt_tx_data[0] = (uint8_t) FAIL;
      bt_tx_data[1] = 0;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Message Data Error");
      }
      else
      {
         bt_tx_data[0] = PITS_BT_Get_Align_Cal_Req_Processing(&bt_tx_data[1]);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_bt_set_align_cal_req
 *===========================================================================*
 * @brief Receive a Request message to set the Alignment CAL Value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_bt_set_align_cal_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   Tr_Info_Lo("pits_bt_set_align_cal_req");
   if (NULL != message)
   {
      /* Compose Message Header */
      bt_tx_bus_id = message->bus;
      pits_bt_compose_message_header(MID_BT_SET_ALIGN_CAL_RPT, 2);
      /* Compose Message Data */
      bt_tx_data[0] = (uint8_t) FAIL;
      bt_tx_data[1] = 0;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("BT SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         Tr_Info_Lo_1("Writing XTAL FTRIM to AP PS: 0x%2.2X", message->data[0]);
         system("mount -o remount,rw /factory_data");
         PITS_BT_DIAG_PS_Write_Cal(&message->data[0], 1);
         PS_Save_Now();

         bt_tx_data[0] = (uint8_t) SUCCESS;
         bt_tx_data[1] = message->data[0];
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&bt_message);             
      }
   }
   return (pits_status);
}
#endif /* BLUETOOTH_IS*/

/*===========================================================================*
 * FUNCTION: PITS_Set_BT_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_BT_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (bt_session_state != session)   /* Session State change? */
   {
      bt_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_BT_SESSION, &bt_session_state, sizeof(bt_session_state));   /* Publish new Session State */
      if (bt_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_bt_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_bt_session_timer_id, bt_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_BT_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_BT_Session(void)
{
   return (bt_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_BT_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_BT_Timer(void)
{
   SAL_Create_Timer(PITS_EV_BT_SESSION_TIMEOUT, &pits_bt_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_BT_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_BT_Timer(void)
{
   SAL_Destroy_Timer(pits_bt_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_BT_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_BT_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_BT_SESSION_TIMEOUT)
   {
      if (PITS_Set_BT_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS BT SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_BT_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_BT_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &bt_session_state, sizeof(bt_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_BT_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_BT_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_BT_SESSION,NULL,0,PITS_EVG_BT_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_BT_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   
   return ret;
}

/*===========================================================================*/
/*!
 * @file pits_bt_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 15July2016 Rahul Chirayil (vzm576) Rev.3
 * ctc_ec#158168: Implement BT diagnostic mode enable/disable service.
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 2
 * ctc_ec#156415: Remove build warnings.
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Bluetooth Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 31
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 08 Aug 2012 Chris Baker Rev 30
 * Task kok_basa#113422: Updated BT PS calls to match new API.
 *
 * 29-May-2012 Oscar Vega  Rev 29
 * SCR task_kok_basa#99814 : Implement various BT Services 
 *
 * 17-May-2012 Oscar Vega Rev 28
 * Task kok_basa#97161 - MID 96/97- 98/99
 *
 * 17 May 2012 Miguel Garcia Rev 27
 * Include remove all devices from vip
 *
 * 11 May 2012 Miguel Garcia Rev 26
 * Update pit 18/88 with new size
 *
 * 1-May-2012 Darinka Lopez  Rev 25
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 27 Apr 2012 Miguel Garcia Rev 24
 * Include loop get and set
 *
 * 24 Apr 2012 Miguel Garcia Rev 23
 * Include clear all devices list
 *
 * 16-Mar-2012 Oscar Vega  Rev 22
 * fix task_kok_basa#83530 : Add bluetooth services handler in SBX program
 *
 * 14-Mar-2012 Oscar Vega  Rev 21
 * SCR task_kok_basa#82989 : Add bluetooth services handler in SBX program
 *
 * 27 Feb 2012 Miguel Garcia
 * Include missing pits bt services
 *
 * 09 Feb 2012 Miguel Garcia
 * Fix get conn size
 *
 * 27 Jan 2012 Miguel Garcia
 * Include pits bt services
 *
 * 16 Jan 2012 Miguel Garcia
 * Include Echo cancelation functions
 *
 * 5-Jan-2012 Darinka Lopez  Rev 16
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * - 15-Dec-2011 Chris Baker
 *   Task kok_basa#64725 Revision 15
 *   - Changed PS access for BT Name to use BT_DIAG interface.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 11
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 01-Oct-2011 Chris Baker
 *   Task kok_basa#51751 Revision 10
 *   - Added implementation for MID_BT_GET_PS_KEY_REQ.
 *   - Added implementation for MID_BT_SET_BCCMD_REQ.
 *   - Added implementation for MID_BT_GET_BCCMD_REQ.
 *   - Added implementation for MID_BT_GET_ALIGN_CAL_RE.
 *   - Added implementation for MID_BT_SET_ALIGN_CAL_RE.
 *
 * 13 Apr 2011 Miguel Garcia Rev 6
 * Include 33 size for name message
 *
 * 18 Mar 2011 Miguel Garcia Rev 5
 * Include Cpid services
 *
 * 17 Jan 2011 Miguel Garcia Rev 4
 * Remove unused Pits services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 3
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 2-Oct-2009 David Mooar  Rev 2
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
