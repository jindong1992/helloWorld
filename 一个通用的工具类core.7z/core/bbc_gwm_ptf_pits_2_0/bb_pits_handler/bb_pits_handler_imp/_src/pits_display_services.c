/*===========================================================================*/
/**
 * @file pits_display_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_display_services.c~1:csrc:ctc_ec#8 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:10:56 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#include "em.h"
#include "pits_display_services.h"
#include "pits_display_services_cbk.h"
#include "touch_screen_calib.h"
#include "touch_screen_calib_ps.h"
#include "video_control.h"

#include "hmi_ps.h"
#include <string.h>
#include <stdio.h>
#include "utilities.h"
#include "unistd.h"
#include "xsal_util.h"
#include "frame_buffer_cfg.h"
#include "screen_check_proxy.h"
#include "pits_processing_display.h"
#ifdef FORD_C490
#include "ford_diagnostic.h"
#include "ford_diagnostic_proxy.h"
#endif
#include "pcan_appl_proxy.h"
#include "pcan_il_tx.h"

EM_FILENUM(PITS_MODULE_ID_5, 25);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#if defined(GWM_CHB041)|| defined(GWM_CHK041_8AT)|| defined(GWM_CHK011_8AT)
static const uint32_t display_color_value[] = {
   0x00000000,                           /*Black*/
   0x000000FF,                           /*Blue*/
   0x0000FF00,                           /*Green*/
   0x00FF0000,                           /*Red*/
   0x00FFFFFF,                          /*White*/
};  
#endif

#ifdef FORD_C490
static const uint16_t display_color_value[] = {
   0x0000,                           /*Black*/
   0x001F,                           /*Blue*/
   0x07E0,                           /*Green*/
   0xF800,                           /*Red*/
   0xFFFF,                          /*White*/
};  
#endif

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef enum
{
   PITS_DISP_OVERRIDE_DISABLED,
   PITS_DISP_OVERRIDE_ENABLED, 
}PITS_SET_OVERRIDE_REQ_ENUM_T;

typedef enum
{
   PITS_START_IR_TOUCH_CAL = 0x00,
   PITS_ABORT_IR_TOUCH_CAL, 
}PITS_IR_TOUCH_CAL_REQ_ENUM_T;

#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
typedef enum
{
   SC_EXIT = 0,
   SC_PIC_ALL_BLACK,
   SC_PIC_ALL_WHITE,
   SC_PIC_ALL_RED,
   SC_PIC_ALL_GREEN,
   SC_PIC_ALL_BLUE,
   SC_PIC_MAX,
}PITS_SC_PIC_PATT_ENUM_T;
#endif

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_display_initialize(void);
/*static void PITS_Disp_Compose_Message_Header(uint8_t mid, uint8_t size);*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_DISPLAY_RX_INDEX

#define MID_DISPLAY_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_display_rx_messages[] = {
   MID_DISPLAY_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_DISPLAY_TX_INDEX

#define MID_DISPLAY_TX_INDEX(name, mid) (mid),

static const uint8_t pits_display_tx_messages[] = {
   MID_DISPLAY_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_DISPLAY_RX_INDEX
#define MSID_DISPLAY_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_display_rx_message_sets[] = {
   MSID_DISPLAY_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_DISPLAY_TX_INDEX
#define MSID_DISPLAY_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_display_tx_message_sets[] = {
   MSID_DISPLAY_TX_TABLE
};

static uint8_t display_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T display_message;      /* for construction of a display service message to be transmitted */

static uint8_t display_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t display_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T display_session_state;

/**
 * Stores Timer ID for display Services Session
 */
static SAL_Timer_Id_T pits_display_session_timer_id;

static bool_t pits_required_status = false;
static bool_t pits_required_screen = false;
static uint8_t pits_screen_number = 0;
static uint8_t pits_screen_data[4] = {0,0,0,0};
static bool_t pits_override_test = false;
static uint8_t pits_screen_number_prev = 0;
static bool_t pits_read_screen = false;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/
static void PITS_Disp_Compose_Message_Header(uint8_t mid, uint8_t size);

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_Display_Services_Interface = {
   pits_display_initialize,
   pits_display_rx_message_sets,
   Num_Elems(pits_display_rx_message_sets),
   pits_display_tx_message_sets,
   Num_Elems(pits_display_tx_message_sets),
};

uint16_t diag_dimming_cal;
/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_display_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_display_initialize(void)
{
   display_tx_bus_id = 0;
   memset(&display_message, 0x00, sizeof(PITS_Message_T));
   memset(display_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   display_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   display_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that display Session is closed? */
}

/*static void PITS_Disp_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   display_message.bus = display_tx_bus_id;
   display_message.data = display_tx_data;
   display_message.MSID = MSID_DISPLAY_SERVICES;
   display_message.MID = mid;
   display_message.data_size = size;
   memset(&display_tx_data[0], 0x00, size);
}*/
/*===========================================================================*
 * FUNCTION: pits_display_session_get_state_req
 *===========================================================================*
 * @brief Receive a Request for Session State
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = Session State (CLOSE, OPEN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_get_state_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_STATE_RPT;
      /* Compose Message Data */
      display_tx_data[0]   = (uint8_t)SUCCESS;
      display_tx_data[1]   = (uint8_t)display_session_state;
      display_message.data_size = 2;
      if (message->data_size != 0)
      {
         display_tx_data[0] = (uint8_t)FAIL;
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION GET REQUEST: Message Data Error");
      }
      else
      {
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }   
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_display_session_open_req
 *===========================================================================*
 * @brief Receive a Request to Open a Session
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = Session State (CLOSE, OPEN)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_open_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_STATE_RPT;
      /* Compose Message Data */
      display_tx_data[0]   = (uint8_t) FAIL;
      display_tx_data[1]   = display_session_state;
      display_message.data_size = 2;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION OPEN REQUEST: Message Data Error");
      }
      else if (display_session_state == SESSION_OPEN)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION OPEN REQUEST: Session Is Already Opened");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         display_tx_data[1] = SESSION_OPEN;
         PITS_Set_Display_Session(SESSION_OPEN);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_display_session_close_req
 *===========================================================================*
 * @brief Receive a Request to close a Session.
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] display_tx_data[0] = Confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = State (OPEN, CLOSE)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_close_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_STATE_RPT;
      /* Compose Message Data */
      display_tx_data[0]   = (uint8_t)FAIL;
      display_tx_data[1]   = display_session_state;
      display_message.data_size = 2;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION CLOSE REQUEST: Message Data Error");
      }
      else if (display_session_state == SESSION_CLOSE)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION CLOSE REQUEST: Session Is Already Closed");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         display_tx_data[1] = SESSION_CLOSE;
         PITS_Set_Display_Session(SESSION_CLOSE);
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_display_session_refresh_req
 *===========================================================================*
 * @brief Receive a Request to Refresh display Session Timer
 *
 * @returns
 *    DONE = Message processing completed
 *    NOT_DONE = Message processing not done, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_refresh_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_REFRESH_RPT;
      /* Compose Message Data */
      display_tx_data[0]   = (uint8_t) FAIL;
      display_message.data_size = 1;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION REFRESH REQUEST: Message Data Error");
      }
      else if (display_session_state != SESSION_OPEN)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION REFRESH REQUEST: Session is Not Opened");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         SAL_Start_Timer(pits_display_session_timer_id, display_session_timeout_sec, false);
         SAL_Publish(PITS_EVG_DISPLAY_SESSION, &display_session_state, sizeof(display_session_state));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_display_session_get_timeout_req
 *===========================================================================*
 * @brief Receive a Request for Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 0
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_get_timeout_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_TIMEOUT_RPT;
      /* Compose Message Data */
      display_tx_data[0]   = (uint8_t) FAIL;
      memset(&display_tx_data[1], 0, 2);
      display_message.data_size = 3;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&display_tx_data[1], (uint16_t) (display_session_timeout_sec/1000));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_display_session_set_timeout_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_display_session_set_timeout_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISPLAY_SESSION_TIMEOUT_RPT;
      /* Compose Message Data */
      memset(&display_tx_data[1], 0, 2);
      display_message.data_size = 3;
      if ((message->data_size != 2) && (message->data_size != 0 ) )
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SESSION SET TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         display_session_timeout_sec = 1000 * Util_Get_Big_Endian_U16(&(message->data)[0]);
         if (display_session_timeout_sec == 0)
         {
            display_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
         }
         display_tx_data[0] = (uint8_t) SUCCESS;
         Util_Put_Big_Endian_U16(&display_tx_data[1], (uint16_t) (display_session_timeout_sec/1000));
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_disp_get_time_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_get_time_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
#if 0
   char id[5];
   char idtime[17];
   Persistent_Section_ID_T section_id_time = PS_SECTION_NONVOL;
   uint8_t read_buffer_time[30];
   PS_AMPM_T pits_time_format = HMI_FORMAT_24HR;
   uint8_t  new_string2;
   uint8_t  new_string3;
   uint8_t  new_string4;
   uint8_t  new_string5;
   uint8_t   pit_minutes;
   uint8_t   pit_hours;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISP_GET_TIME_ACK;
      /* Compose Message Data */
      memset(&display_tx_data[1], 0, 8);
      display_message.data_size = 8;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY GET TIME REQUEST: Message Data Error");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         snprintf(idtime, sizeof(idtime), "Time_Format_24Hr");
         if(PS_Read(section_id_time, (const char *)&idtime[0], &read_buffer_time[0], sizeof(PS_AMPM_T)))
         {
            pits_time_format = read_buffer_time[0];
         }

         if (pits_time_format == HMI_FORMAT_24HR)
         {
            display_tx_data[1] = 0x01;
            display_tx_data[7] = 0x00;
         }
         else
         {
            display_tx_data[1] = 0x00;
            display_tx_data[7] = (uint8_t) pits_time_format;
         }
         if ((pits_time_format == HMI_FORMAT_PM) && (message->data[0]>12))
         {
            pit_hours = (uint8_t) Hex_To_BCD (((message->data[0])-12),2);
         }
         else
         {
            pit_hours = (uint8_t) Hex_To_BCD (message->data[0],2);
         }
         if ((pits_time_format == HMI_FORMAT_AM) && (message->data[0]==0))
         {
            pit_hours = (uint8_t) Hex_To_BCD (12,2);
         }
         pit_minutes = (uint8_t) Hex_To_BCD (message->data[1],2);
         new_string2 = (pit_hours>>4) & 0x0F;
         new_string3 = pit_hours & 0x0F;
         new_string4 = (pit_minutes>>4) & 0x0F;
         new_string5 = pit_minutes & 0x0F;
         snprintf(id, sizeof(id), "%d%d%d%d", new_string2, new_string3, new_string4, new_string5);

         display_tx_data[2] = (uint8_t)id[0];
         display_tx_data[3] = (uint8_t)id[1];
         display_tx_data[4] = 0x3A;
         display_tx_data[5] = (uint8_t)id[2];
         display_tx_data[6] = (uint8_t)id[3];

         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
#endif   
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_disp_set_time_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_set_time_req(const PITS_Message_T * message)
{
   DIAG_EVG_AMPM24_T pit_ampm = DIAG_FORMAT_24HR;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISP_SET_TIME_ACK;
      /* Compose Message Data */
      memset(&display_tx_data[1], 0, 1);
      display_message.data_size = 1;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY GET TIME REQUEST: Message Data Error");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         if (message->data[0] == DIAG_FORMAT_AM)
         {
            pit_ampm = DIAG_FORMAT_AM;
         }
         if (message->data[0] == DIAG_FORMAT_PM)
         {
            pit_ampm = DIAG_FORMAT_PM;
         }
         if (message->data[0] == DIAG_FORMAT_24HR)
         {
            pit_ampm = DIAG_FORMAT_24HR;
         }

         SAL_Publish((SAL_Event_Id_T)DIAG_EVG_SET_AMPM24, &pit_ampm, sizeof(pit_ampm));
         pits_status = DONE;             
      }
   }
   return (pits_status);
}

#if defined FORD_C490
/*===========================================================================*
 * FUNCTION: pits_disp_get_override_req
 *===========================================================================*
 * @brief Respond with the current outside temperature that is used to display on the radio.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_get_override_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      display_tx_bus_id = message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_GET_OVERRIDE_ACK, 2);

      display_tx_data[0] = (uint8_t)FAIL;

      /* Compose Message Data */
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Get Display Override REQ: Message Data Error");
      }
      else
      {
         display_tx_data[0]   = (uint8_t)SUCCESS;
         display_tx_data[1]   = (uint8_t)PITS_Get_Screen_Check_Override_Status();
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_disp_set_time_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_set_override_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   PITS_SET_OVERRIDE_REQ_ENUM_T Req = (PITS_SET_OVERRIDE_REQ_ENUM_T)message->data[0];
   uint8_t test_id = (uint8_t)message->data[0];

   if (NULL != message)
   {
      /* Compose Message Header */
      display_tx_bus_id = message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_SET_OVERRIDE_ACK, 2);

      display_tx_data[0] = (uint8_t)FAIL;

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Set Display Override REQ: Message Data Error");
      }
      else
      { 
         if (PITS_DISP_OVERRIDE_DISABLED == Req)
         {
           Screen_Check_Stop_Request();  /*stop Screen Check*/   
         }
         else if (PITS_DISP_OVERRIDE_ENABLED == Req)
         {
           Screen_Check_Start_Request();   /*start Screen Check*/
         }

         display_tx_data[0]   = (uint8_t)SUCCESS;
         display_tx_data[1]   = (uint8_t)Req;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);
      }
   }
   return (pits_status);
}
#endif

extern bool_t Pits_Display_Override_Status (void)
{
   return (pits_override_test);
}
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: pits_disp_set_time_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_select_test_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   uint8_t Req = (uint8_t)message->data[0];
   bool Ret_val =  false;

   if (NULL != message)
   {
      /* Compose Message Header */
      display_tx_bus_id= message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_SELECT_TEST_ACK, 2);

      display_tx_data[0] = (uint8_t)FAIL;
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T)PITS_PBS_Error_Report("Select test pattern REQ: Message Data Error");
      }
      else
      {
         if ((Req >= SC_EXIT) && (Req <= SC_PIC_ALL_BLUE))
         {
            SAL_Send(APP_HMI, HMI_XSAL_LISTENER_THREAD_ID, PITS_EV_SCREEN_CHECK, &Req, sizeof(Req));
            display_tx_data[0] = (uint8_t)SUCCESS;
         }
         else
         {
            display_tx_data[0]   = (uint8_t)DATA_OUT_OF_RANGE;
         }
         display_tx_data[1] = Req;
            
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);
      }
   }
   return (pits_status);
}
#endif

/*===========================================================================*
 * FUNCTION: pits_disp_set_time_req
 *===========================================================================*
 * @brief Receive a Request to Set the display Session Timeout
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0 - 1] = Session Timeout in sec
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1 - 2] = Session Timeout in sec
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_display_text_req(const PITS_Message_T * message)
{
   uint8_t  pits_text_length = 0;
   DIAG_EVG_DISPLAY_TEXT_T  pits_send_text_data;
   uint8_t  pits_stub_text = 0;
   uint8_t  pits_index = 0;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      pits_text_length = message->data[2];

      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id = message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_DISPLAY_TEXT_ACK, 2);

      display_tx_data[0] = (uint8_t)FAIL;

      /* Compose Message Data */
      memset(&display_tx_data[1], 0, 2);
      display_message.data_size = 2;
      if (message->data_size != (pits_text_length + 3))
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY GET TIME REQUEST: Message Data Error");
      }
      else
      {
         display_tx_data[0] = (uint8_t) SUCCESS;
         /* text defaults*/
         pits_send_text_data.diag_horizontal_location = 1;
         pits_send_text_data.diag_vertical_location = 1;
         pits_send_text_data.diag_clear_screen_before_write = 0;
         pits_send_text_data.diag_line_number = 0;
         pits_send_text_data.diag_text_length = pits_text_length;

/*         if (pits_override_test)*/
         {
/*            if (pits_override_status == DISPLAY_TEXT)   */
            {
               display_tx_data[1] = 3;
               pits_stub_text = ((message->data[0])&0x30)>>4;
               if ((pits_stub_text > 0) && (pits_stub_text < 0x04))
               {
                  pits_send_text_data.diag_horizontal_location = pits_stub_text;
               }
               pits_stub_text = ((message->data[0])&0x03);
               if ((pits_stub_text > 0) && (pits_stub_text < 0x04))
               {
                  pits_send_text_data.diag_vertical_location = pits_stub_text;
               }
               pits_stub_text = ((message->data[0])&0x80);
               if (pits_stub_text == 0x80)
               {
                  pits_send_text_data.diag_clear_screen_before_write = 1;
               }
               if (message->data[1] < 8)
               {
                  pits_send_text_data.diag_line_number = message->data[1];
               }
               for (pits_index = 0; pits_index < pits_text_length; pits_index++)
               {
                  pits_send_text_data.diag_display_text[pits_index] = message->data[pits_index+3];
               }
               SAL_Publish((SAL_Event_Id_T)DIAG_EVG_DISPLAY_TEXT, &pits_send_text_data, (pits_text_length+5));
            }
#if 0			
            else
            {
               display_tx_data[1] = 1;
            }
#endif
         }
#if 0		 
         else
         {
            display_tx_data[1] = DISPLAY_EXIT;
         }
#endif		 
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

void Pits_Display_Text_Test(const uint8_t * data, size_t length)
{
   DIAG_EVG_DISPLAY_TEXT_T  pits_rec_text_data;
   uint8_t pits_index = 0;
   display_tx_bus_id    = 0;
   display_message.bus  = display_tx_bus_id;
   display_message.data = display_tx_data;
   display_message.MSID = MSID_DISPLAY_SERVICES;
   display_message.MID  = 0x1D;
   /* Compose Message Data */
   memset(&display_tx_data[1], 0, length);
   pits_rec_text_data.diag_horizontal_location = data[0];
   pits_rec_text_data.diag_vertical_location = data[1];
   pits_rec_text_data.diag_clear_screen_before_write = data[2];
   pits_rec_text_data.diag_line_number = data[3];
   pits_rec_text_data.diag_text_length = data[4];
   for (pits_index = 0; pits_index < pits_rec_text_data.diag_text_length; pits_index++)
   {
      pits_rec_text_data.diag_display_text[pits_index] = data[pits_index+5];
   }
   display_message.data_size = length+1;
   display_tx_data[0] = (uint8_t) SUCCESS;
   display_tx_data[1] = (uint8_t) pits_rec_text_data.diag_horizontal_location;
   display_tx_data[2] = (uint8_t) pits_rec_text_data.diag_vertical_location;
   display_tx_data[3] = (uint8_t) pits_rec_text_data.diag_clear_screen_before_write;
   display_tx_data[4] = (uint8_t) pits_rec_text_data.diag_line_number;
   display_tx_data[5] = (uint8_t) pits_rec_text_data.diag_text_length;

   for (pits_index = 0; pits_index < pits_rec_text_data.diag_text_length; pits_index++)
   {
      display_tx_data[pits_index+6] = pits_rec_text_data.diag_display_text[pits_index];
   }
   (void)PITS_Send_Message(&display_message);

}

/*===========================================================================*
 * FUNCTION: pits_disp_set_video_source_req
 *===========================================================================*
 * @brief Select a source for video and target for the video
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Select Source
 *                           0x00 = None (Override Off)
 *                           0x01 = DVD mech
 *                           0x02 = Backup Camera
 *                           0x03 = Rear Aux
 *                           0x04 = USB
 *                           0x05 .. = Additional Aux Channels
 *
 * @param [in] (message->data)[1] = Select Target
 *                           0x01 = Main Display
 *                           0x02 = Rear Video 1
 *                           0x04 = Rear Video 2
 *
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = Select Source
 * @param [out] display_tx_data[2] = Select Target
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_set_video_source_req(const PITS_Message_T * message)
{
   DIAG_SET_VIDEO_T pits_set_video_source;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISP_SET_VIDEO_SOURCE_ACK;
      /* Compose Message Data */
      memset(&display_tx_data[1], 0, 2);
      display_message.data_size = 3;
      if (message->data_size != 2)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY SET VIDEO SRC REQUEST: Message Data Error");
      }
      else
      {

         pits_set_video_source.diag_source = message->data[0];
         pits_set_video_source.diag_zone = (message->data[1]) & DISPLAY_VIDEO_MASK;
         if(PITS_Display_Execute_Video_Steering(pits_set_video_source.diag_source,pits_set_video_source.diag_zone))
         {
            display_tx_data[0] = (uint8_t) SUCCESS;
         }
         else
         {
            display_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
         }

         display_tx_data[1] = pits_set_video_source.diag_source;
         display_tx_data[2] = pits_set_video_source.diag_zone;
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

Done_Or_Not_Done_T pits_disp_get_dim_req(const PITS_Message_T * message)
{
   uint8_t dimming_display_level = 0;;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id= message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_GET_DIM_ACK, 2);

      display_tx_data[0]   = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         display_tx_data[0] = (uint8_t)FAIL;
         PITS_PBS_Error_Report("LCD DISPLAY GET DIM CONTROL REQ: Message Data Error");
      }
      else
      {
         dimming_display_level = PITS_Display_Get_Dim_Brightness();
         
         display_tx_data[0]   = (uint8_t)SUCCESS;
         display_tx_data[1]   = (uint8_t)dimming_display_level;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&display_message));
}

/*===========================================================================*
 * FUNCTION: pits_disp_set_dim_req
 *===========================================================================*
 * @brief set the display output level to a specific value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Specific brightness value                                                                          
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = Specific brightness value 
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_set_dim_req(const PITS_Message_T * message)
{
   uint8_t pit_brightness;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_SET_DIM_ACK, 2);
	  
      /* Compose Message Data */
      display_tx_data[0] = FAIL;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY GET DIM REQUEST: Message Data Error");
      }
      else
      {
         pit_brightness = message->data[0];

	 if (pit_brightness >= DIM_MIN && pit_brightness <= DIM_MAX)
	 {
	    PITS_Display_Set_Dim_Brightness(pit_brightness);
            display_tx_data[0] = (uint8_t) SUCCESS;
	 }
         else
         {
            display_tx_data[0] = (uint8_t) DATA_OUT_OF_RANGE;
         }
         display_tx_data[1] = pit_brightness;
		 
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
Done_Or_Not_Done_T pits_disp_get_faceplate_dim_req(const PITS_Message_T * message)
{
   uint8_t illu_step = 0;;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id= message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_GET_FACEPLATE_DIM_ACK, 2);

      display_tx_data[0]   = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 0)
      {
         display_tx_data[0] = (uint8_t)FAIL;
         PITS_PBS_Error_Report("LCD DISPLAY GET FACEPLATE DIM CONTROL REQ: Message Data Error");
      }
      else
      {
         illu_step = PITS_Disp_Get_Faceplat_Dim();
         
         display_tx_data[0]   = (uint8_t)SUCCESS;
         display_tx_data[1]   = (uint8_t)illu_step;
      }
   }
   return ((Done_Or_Not_Done_T) PITS_Send_Message(&display_message));
}

/*===========================================================================*
 * FUNCTION: pits_disp_set_faceplate_dim_req
 *===========================================================================*
 * @brief set the display output level to a specific value
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Specific brightness value                                                                          
 * @param [out] display_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] display_tx_data[1] = Specific brightness value 
 *
 * @pre message->data_size = 2
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_disp_set_faceplate_dim_req(const PITS_Message_T * message)
{
   uint8_t pit_brightness;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id    = message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_SET_FACEPLATE_DIM_ACK, 2);
	  
      /* Compose Message Data */
      display_tx_data[0] = FAIL;

      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("DISPLAY GET FACEPLATE DIM REQUEST: Message Data Error");
      }
      else
      {
         pit_brightness = message->data[0];

         PCAN_Send_K011_Ill_Step_Status(1, pit_brightness);
         display_tx_data[0] = (uint8_t) SUCCESS;
         display_tx_data[1] = pit_brightness;
		 
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_ir_touch_cali_req
 *===========================================================================*
 * @brief Receive a Request to Start touch screen calibration
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_ir_touch_cali_req(const PITS_Message_T * message)
{
   uint8_t Req = (uint8_t)message->data[0];
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */
      /* Compose Message Header */
      display_tx_bus_id= message->bus;
      PITS_Disp_Compose_Message_Header(MID_DISP_IR_TOUCH_CALI_RPT, 2);

      display_tx_data[0]   = (uint8_t) COMMAND_NOT_SUPPORTED;
      /* Compose Message Data */
      if (message->data_size != 1)
      {
         display_tx_data[0] = (uint8_t)FAIL;
         PITS_PBS_Error_Report("IR Touch Calibration REQ: Message Data Error!");
      }
      else
      {
         if (Req >= PITS_START_IR_TOUCH_CAL && Req <= PITS_ABORT_IR_TOUCH_CAL)
         {
            SAL_Publish(PITS_EV_TSC_REQ, &Req, sizeof(uint8_t));

            display_tx_data[0] = SUCCESS;
         }
         else
         {
            display_tx_data[0] = DATA_OUT_OF_RANGE;
         }
         display_tx_data[1] = Req;
      }
   }

   return ((Done_Or_Not_Done_T) PITS_Send_Message(&display_message)); 
}

#endif

Done_Or_Not_Done_T pits_disp_get_rtd_temp_req(const PITS_Message_T * message)
{
    
    Done_Or_Not_Done_T pits_status = NOT_DONE;
    uint16_t AD_Value = 0;
    int8_t temperature = 0;
    
    if (NULL != message)
    {
       /* Initial call (new message received -- first call for this message) */
    
       /* Compose Message Header */
      display_tx_bus_id = message->bus;
      
      display_message.bus  = display_tx_bus_id;
      display_message.data = display_tx_data;
      display_message.MSID = MSID_DISPLAY_SERVICES;
      display_message.MID  = MID_DISP_GET_TEMP_ACK;
    /* Compose Message Data */
      memset(&display_tx_data[1], 0, 1);
     display_message.data_size = 3;
       /* Compose Message Data */
       if (message->data_size != 0)
       {
          pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("Misc Request: Message Data Error");
       }
       else
       {          
         
           display_tx_data[0] = PITS_Misc_Get_RTD_Temperature(&display_tx_data[1]);

           if(display_tx_data[0])
           {
                AD_Value =  ((uint16_t )display_tx_data[2] << 8 ) + display_tx_data[1];

                temperature = Pits_RTD_Convert_AD_2_Temperature(AD_Value);
                display_tx_data[1] = 0;/*0x00 C, 0x01 F */
                display_tx_data[2] = temperature * 0.5 -40 ; /*C  E = N/2-40 ; F E =N * 0.9 -40*/


           }
           else
           {
                Tr_Info_Mid("Fail to get temperature from rtd.");
                display_tx_data[1] = 0;
                display_tx_data[2] = 0;
           }

          Tr_Info_Mid_2("RTD temperature is %d  centigrade. AD : %d ",temperature,AD_Value);
          pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&display_message);
       }
       
    }
    return (pits_status);

}

void Pits_Request_Screen_Test_XY (const uint8_t * data, size_t length)
{
         pits_required_screen = true;
         pits_required_status = true;
         pits_screen_data[0] =  data[1];
         pits_screen_data[1] =  data[0];
         pits_screen_data[2] =  data[3];
         pits_screen_data[3] =  data[2];

}

void Pits_Request_Screen_Error (const uint8_t * data, size_t length)
{
#if PITS_ICR_IS
   SIP_DTC_Code_T pits_dtc_code_send = AP_DTC_DUMMY;
#endif
   if (pits_read_screen)
   {
      pits_screen_number_prev = pits_screen_number;
   }
   else
   {
      pits_screen_number_prev = pits_screen_number+1;
   }
   pits_screen_number = 0xFF;
#if PITS_ICR_IS
   PITs_GM_Set_DID (0,10);
   PITs_GM_Set_DID(1, pits_screen_number);
   PITs_GM_DTC_Set(pits_dtc_code_send, false, true);
#endif
}
/*===========================================================================*
 * FUNCTION: PITS_Set_Display_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_Display_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (display_session_state != session)   /* Session State change? */
   {
      display_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_DISPLAY_SESSION, &display_session_state, sizeof(display_session_state));   /* Publish new Session State */
      if (display_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_display_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_display_session_timer_id, display_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_Display_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_Display_Session(void)
{
   return (display_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_Display_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_Display_Timer(void)
{
   SAL_Create_Timer(PITS_EV_DISPLAY_SESSION_TIMEOUT, &pits_display_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Display_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_Display_Timer(void)
{
   SAL_Destroy_Timer(pits_display_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Check_Display_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_Display_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_DISPLAY_SESSION_TIMEOUT)
   {
      if (PITS_Set_Display_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS DISPLAY SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_Display_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Display_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &display_session_state, sizeof(display_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Display_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_Display_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_DISPLAY_SESSION,NULL,0,PITS_EVG_DISPLAY_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_DISPLAY_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   return ret;
}

static void PITS_Disp_Compose_Message_Header(uint8_t mid, uint8_t size)
{
   display_message.bus = display_tx_bus_id;
   display_message.data = display_tx_data;
   display_message.MSID = MSID_DISPLAY_SERVICES;
   display_message.MID = mid;
   display_message.data_size = size;
   memset(&display_tx_data[0], 0x00, size);
}

/*===========================================================================*/
/*!
 * @file pits_display_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Display Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L\F3pez Rev 32
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 22-Aug-2012 Miguel Garcia Rev 31
 * Include pits display status
 *
 * 10 Aug 2012 Hernan Gegenschatz (jzn5sv) Rev 30
 * kok_basa#113867: PITS Implement set video source 19 50/51
 *
 * 11 Jun 2012 Miguel Garcia Rev 29
 * Create pits set video source
 *
 * 1-May-2012 Darinka Lopez  Rev 28
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 23 Mar 2012 Miguel Garcia Rev 27
 * Fix Set 12 AM hour
 *
 * 21-Mar-2012 Darinka Lopez  Rev 26
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 2 Feb 2012 Miguel Garcia Rev 25
 * Fix test display after sleep mode
 *
 * 5-Jan-2012 Darinka Lopez  Rev 21
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 20
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 19
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 23 Nov 2011 Miguel Garcia
 * Fix pits test patterns
 *
 * 22 Nov 2011 Miguel Garcia
 * Fix pits test screen issues
 *
 * 18 Nov 2011 Miguel Garcia
 * Include Pits test patterns
 *
 * 30 Sep 2011 Miguel Garcia
 * Fix pits screen test
 *
 * 07 Sep 2011 Miguel Garcia
 * Insert AMPM function
 *
 * 13-Jan-2011 Miguel Garcia  Rev 7
 * Remove unused Pits services
 *
 * 03-Ago-2010 Miguel Garcia  Rev 5
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 16-Jul-2010 lzz7kf (JICASTANON)  Rev 4
 *  Fix merge versions
 *
 * 08-Jul-2010 Miguel Garcia  Rev 3
 * SCR kok_basa#1676: Implement Diagnostic Services PITS for DIDs in APP.
 *
 * 2-Oct-2009 David Mooar  Rev 2
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
