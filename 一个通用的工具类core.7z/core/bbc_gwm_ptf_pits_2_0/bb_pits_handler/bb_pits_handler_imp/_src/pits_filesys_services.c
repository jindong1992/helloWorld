/*===========================================================================*/
/**
 * @file pits_filesys_services.c
 *
 * @todo Add a one line description of the implementation.
 *
 * %full_filespec:pits_filesys_services.c~1:csrc:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:11:00 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "em.h"
#include "pits_filesys_services.h"
#include "pits_filesys_services_cbk.h"
#include "pits_processing_filesys.h"
#include "playback_plugin_engine_types.h"
#include "gm_dimming_vip_interface_ps.h"


#include "desip_msg_ids.h"
#include "desip_msg_types.h"
#include "pbc_trace.h"
#include "vip_desip.h"
#include <string.h>
#include "utilities.h"
#include "xsal_util.h"
#include "playback_plugin_engine.h"

EM_FILENUM(PITS_MODULE_ID_5, 22);   /**< define file for assert handling */
/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
#define PIT_LINGOS_ENABLE  1
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
#define NEXT_TRACK      1
#define PREV_TRACK    -1

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void pits_filesys_initialize(void);

static void pits_filesys_compose_message_header(uint8_t mid, uint8_t size);

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
/*---------------------------------------------------------------------------*
 * X-Macro to create the table of MIDs and Receive Messages to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_FILESYS_RX_INDEX

#define MID_FILESYS_RX_INDEX(name, mid, function) {mid, function},

static const PITS_MID_T pits_filesys_rx_messages[] = {
   MID_FILESYS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of Transmit Message MIDs to be supported
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MID_FILESYS_TX_INDEX

#define MID_FILESYS_TX_INDEX(name, mid) (mid),

static const uint8_t pits_filesys_tx_messages[] = {
   MID_FILESYS_TX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Receive MSIDs, MSID Names, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_FILESYS_RX_INDEX
#define MSID_FILESYS_RX_INDEX(msid, name, mid, size) {msid, name, mid, size},

static const PITS_MSID_T pits_filesys_rx_message_sets[] = {
   MSID_FILESYS_RX_TABLE
};

/*---------------------------------------------------------------------------*
 * X-Macro to create the table of the Transmit MSIDs, MIDs and MID sizes for the product
 *    @see the configuration file for detail description.
 *---------------------------------------------------------------------------*/
#undef MSID_FILESYS_TX_INDEX
#define MSID_FILESYS_TX_INDEX(msid, mid, size) {msid, mid, size},

static const PITS_TX_MSID_T pits_filesys_tx_message_sets[] = {
   MSID_FILESYS_TX_TABLE
};

static uint8_t filesys_tx_bus_id;   /* ID of the bearing bus on which to send response */

static PITS_Message_T filesys_message;      /* for construction of a filesys service message to be transmitted */

static uint8_t filesys_tx_data[PITS_MAX_MESSAGE_SIZE];

static uint32_t filesys_session_timeout_sec;  /* stores the configurable session timeout in sec */

static PITS_EVG_SESSION_T filesys_session_state;

/**
 * Stores Timer ID for filesys Services Session
 */
static SAL_Timer_Id_T pits_filesys_session_timer_id;

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/
/**
 * This is the interface to this application that is exposed to the rest of the world.
 * You must provide an initialization function for this Application, the message sets
 * and the number of message sets.
 */
PITS_Application_Interface_T PITS_FileSys_Services_Interface = {
   pits_filesys_initialize,
   pits_filesys_rx_message_sets,
   Num_Elems(pits_filesys_rx_message_sets),
   pits_filesys_tx_message_sets,
   Num_Elems(pits_filesys_tx_message_sets),
};

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: pits_filesys_initialize
 *===========================================================================*
 * @brief This function initializes all data structures for this Application
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 * This function is executed when PITS first starts
 */
/*===========================================================================*/
void pits_filesys_initialize(void)
{
   filesys_tx_bus_id = 0;
   memset(&filesys_message, 0x00, sizeof(PITS_Message_T));
   memset(filesys_tx_data, 0x00, PITS_MAX_MESSAGE_SIZE);
   filesys_session_timeout_sec = PITS_DEFAULT_SESSION_TIMEOUT_MS;
   filesys_session_state = SESSION_CLOSE;
   /*   PITS_Create_PBS_Session_Timer(); */
   /* @todo Broadcast XSAL message that filesys Session is closed? */
}


static void pits_filesys_compose_message_header(uint8_t mid, uint8_t size)
{
   filesys_message.bus = filesys_tx_bus_id;
   filesys_message.data = filesys_tx_data;
   filesys_message.MSID = MSID_FILESYS_SERVICES;
   filesys_message.MID = mid;
   filesys_message.data_size = size;
   memset(filesys_tx_data, 0x00, size);
}

/*===========================================================================*
 * FUNCTION: pits_filesys_device_status_req
 *===========================================================================*
 * @brief Receive a Request to inquire Device connection status.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] filesys_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] filesys_tx_data[1] = Device ID
 * @param [out] filesys_tx_data[2] = Device connection status
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_device_status_req(const PITS_Message_T * message)
{
   Done_Or_Not_Done_T pits_status = NOT_DONE;
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      filesys_tx_bus_id = message->bus;
      pits_filesys_compose_message_header(MID_FILESYS_DEVICE_STATUS_RPT, 3);

      /* Compose Message Data */
      filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 0)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         filesys_tx_data[0] = (uint8_t) SUCCESS;
         filesys_tx_data[1] = PITS_FSYS_USB_Device_Type();
  
         if(filesys_tx_data[1]!=0 )
         {
            filesys_tx_data[2] = PITS_FSYS_CONNECTED;
         }
         else
         {
           filesys_tx_data[2] = PITS_FSYS_DISCONNECTED;
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message);             
      }
   }
   return (pits_status);
}

/* this function call every RTD_FAIL_CHECK_PS_MS, for check cycled,
   protect the PS value is match the actual case, modify by zlq    */
void Pits_Rtd_Connected_Status(const uint8_t * data, size_t length)
{
    /*SIP_GM_DTC_T gm_dtc_data;*/
    uint8_t did_dtc_data[87]={0};
    DTC_Status_T dtc_status;
   
    uint8_t tsi_status;
    bool tsi_status_changed = false;
    
   if(data[0])
   {
       dtc_status =DTC_Status_PS_Get();
       tsi_status =dtc_status.parmaterF;
   
       if(tsi_status!= (tsi_status&0x0E))
       {
           Tr_Notify_2("TSI Status changed : 0x%02x->0x%02x ", tsi_status, (tsi_status&0x0E)); 
           tsi_status = (tsi_status&0x0E);    
           dtc_status.parmaterF = tsi_status;
           DTC_Status_PS_Set(dtc_status);
           tsi_status_changed = true;
           did_dtc_data[3]= 0x01;
       }

   }
   else
   { 
        dtc_status =DTC_Status_PS_Get();
        tsi_status =dtc_status.parmaterF;
         
        if(tsi_status!=0x09)
        {
            Tr_Notify_1("TSI Status changed : 0x%02x->0x09 ", tsi_status); 
            tsi_status =0x09;
         
            dtc_status.parmaterF = tsi_status;
            DTC_Status_PS_Set(dtc_status);
            tsi_status_changed = true;      
            did_dtc_data[3]= 0x05;
        }
   }
   if( tsi_status_changed == true)
   {
     Tr_Notify_1("TSI Status changed : 0x%02x ", dtc_status.parmaterF);
     #if 0
      memset(&gm_dtc_data, 0, sizeof(gm_dtc_data));	 
      gm_dtc_data.dtc_code = AP_RTD_UART_Malfunctionl;
      gm_dtc_data.dtc_value = dtc_status.parmaterF;
      VIP_Send(VIPP_EV_GM_DTC_SET_REQ, &(gm_dtc_data), 87);
     #else
     did_dtc_data[0] = 1;
     did_dtc_data[2]= 0x11;  
     did_dtc_data[8] = dtc_status.parmaterF ;
     Tr_Warn_4("iic status,byte 0 is %0x,data 3 is %0x,data 4 is %0x,data 8 is %0x", did_dtc_data[0], did_dtc_data[3], did_dtc_data[4], did_dtc_data[8]);
     VIP_Send(VIPP_EV_GM_DTC_SET_REQ, &did_dtc_data, 87);      
     #endif
   }  
}



/*===========================================================================*
 * FUNCTION: pits_filesys_media_position_req
 *===========================================================================*
 * @brief Receive a Request to inquire Media Position.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] filesys_tx_data[0]         = confirmation (SUCCESS, FAIL)
 * @param [out] filesys_tx_data[1]         = Device ID
 * @param [out] filesys_tx_data[2]         = Media status
 * @param [out] filesys_tx_data[3]         = ID size
 * @param [out] filesys_tx_data[4 - (n+3)] = String Track ID
 * @param [out] filesys_tx_data[n+4]       = Minute (BCD)
 * @param [out] filesys_tx_data[n+5]       = Second (BCD)
 *
 * @pre message->data_size = n+6
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_media_position_req(const PITS_Message_T * message)
{
   PITS_FILESYS_Pos_T file_pos;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
         /* Initial call (new message received -- first call for this message) */

         
         /* Compose Message Header */
         filesys_tx_bus_id = message->bus;
         pits_filesys_compose_message_header(MID_FILESYS_MEDIA_POSITION_RPT, 6);
   
         /* Compose Message Data */
         if (message->data_size != 0)
         {
            pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
         }
         else
         {
               filesys_tx_data[0] = (uint8_t) SUCCESS;
   
               if (PITS_FSYS_USB_Device_Conected())
               {
                  PITS_Get_Media_Position(&file_pos);
                  filesys_tx_data[1] = PITS_FSYS_MEDIA_PRESENT;
                  filesys_tx_data[2] = file_pos.minutes;
                  filesys_tx_data[3] = file_pos.seconds;
                  filesys_tx_data[4] = file_pos.name_length;
                  filesys_message.data_size = 5 + file_pos.name_length;
                  memcpy(&filesys_tx_data[5], &file_pos.title_name[0],file_pos.name_length);
               }
               else
               {
                  filesys_tx_data[1] = PITS_FSYS_NO_MEDIA;
               }
   
            pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message);             
         }
      }
      return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_filesys_set_media_position_req
 *===========================================================================*
 * @brief Receive a Request to Set Media position.
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 *              (message->data)[0] = Device ID
 *              (message->data)[1] = Media Position
 * @param [out] filesys_tx_data[0] = confirmation (SUCCESS, FAIL)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_set_media_position_req(const PITS_Message_T * message)
{
   int32_t track_index = 0;
   PITS_FILESYS_Pos_T file_pos;
   Done_Or_Not_Done_T pits_ret = NOT_DONE;
   
   if (NULL != message)
   {
      /* Initial call (new message received -- first call for this message) */

      /* Compose Message Header */
      filesys_tx_bus_id = message->bus;
      pits_filesys_compose_message_header(MID_FILESYS_MEDIA_POSITION_SET_ACK, 4);

      /* Compose Message Data */
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
         filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      }
      else
      {
         if ((message->data[0]>0)&&(message->data[0]<3))
         {
            filesys_tx_data[0] = (uint8_t) SUCCESS;
            if (PITS_FSYS_USB_Device_Conected())
            {
               filesys_tx_data[1] = 1;

               /*Change track*/
               if (message->data[0] == 1)
               	{
               	   track_index = NEXT_TRACK;
               	}
               else
               	{
               	   track_index = PREV_TRACK;
               	}

               PPE_Track_Change(&pits_source, pits_instanced_id, track_index, false);

               /*Get current media information*/
               PITS_Get_Media_Position(&file_pos);
	       filesys_tx_data[2] = file_pos.name_length;
	       filesys_message.data_size = 3 + file_pos.name_length;	   
	       memcpy(&filesys_tx_data[3], &file_pos.title_name[0], file_pos.name_length);	   

	       pits_ret = (Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message);
            }
            else
            {
               filesys_tx_data[1] = 0;
            }

         }
         else
         {
            filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
      }
   }

    return pits_ret;
}


/*===========================================================================*
 * FUNCTION: pits_filesys_device_authentication_self_test_req
 *===========================================================================*
 * @brief Receive a Request to inquire Device Authentication Self Test status
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] filesys_tx_data[0] = confirmation (SUCCESS, FAIL)
 * @param [out] filesys_tx_data[1] = Device ID
 * @param [out] filesys_tx_data[2] = Bit array of Selt Tests status
 *
 * @pre message->data_size = 3
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_device_authentication_self_test_req(const PITS_Message_T * message)
{
   PITS_DEVICE_ID_T device;
   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      filesys_tx_bus_id = message->bus;
      pits_filesys_compose_message_header(MID_FILESYS_DEVICE_AUTH_SELF_TEST_RPT, 3);

      /* Compose Message Data */
      filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      device = message->data[0];
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         if(PITS_NUM_DEVICE <= device)
         {
            filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
         }
         else
         {
            filesys_tx_data[0] = (uint8_t) SUCCESS;
            filesys_tx_data[1] = device;
            filesys_tx_data[2] = PITS_FSYS_Device_Self_Tests_Status(device);
          }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message);             
      }
   }
   return (pits_status);
}

/*===========================================================================*
 * FUNCTION: pits_filesys_device_ids_req
 *===========================================================================*
 * @brief Receive a Request to report Device IDs
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] filesys_tx_data[0]     = confirmation (SUCCESS, FAIL)
 * @param [out] filesys_tx_data[1]     = Device ID
 * @param [out] filesys_tx_data[2 - 5] = Name
 * @param [out] filesys_tx_data[6 - 8] = Version
 * @param [out] filesys_tx_data[9 -12] = Date
 * @param [out] filesys_tx_data[13-16] = Checksum
 * @param [out] filesys_tx_data[17-20] = IC Firmware
 *
 * @pre message->data_size = 22
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_device_ids_req(const PITS_Message_T * message)
{
   PITS_DEVICE_ID_T device;
   PITS_Device_Info_T device_info;

   if (NULL != message)
   {
      /* Compose Message Header */
      filesys_tx_bus_id = message->bus;

      pits_filesys_compose_message_header(MID_FILESYS_DEVICE_IDS_RPT, 21);

      /* Compose Message Data */
      device  = message->data[0];
      filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 1)
      {
         PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         if(!(PITS_NUM_DEVICE < device))
         {
            PITS_FSYS_Get_Device_Info(&device_info, device);
            filesys_tx_data[0] = (uint8_t) SUCCESS;
            filesys_tx_data[1] = device;
            memcpy(&filesys_tx_data[2],device_info.name, NAME_SIZE);
            memcpy(&filesys_tx_data[6],device_info.version, VERSION_SIZE);
            memcpy(&filesys_tx_data[9],&device_info.date, SIZE_FOUR);
            memcpy(&filesys_tx_data[9],&device_info.chcksum, SIZE_FOUR);
            memcpy(&filesys_tx_data[9],&device_info.ic_firmware, SIZE_FOUR);
         }
      }
   }

   return ((Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message));
}

/*===========================================================================*
 * FUNCTION: pits_filesys_lingos_enable_req
 *===========================================================================*
 * @brief Receive a Request to report Device IDs
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [out] filesys_tx_data[0]     = confirmation (SUCCESS, FAIL)
 * @param [out] filesys_tx_data[1]     = lingos enable (1 enable, 2 disabled)
 *
 * @post
 *
 */
/*===========================================================================*/
Done_Or_Not_Done_T pits_filesys_lingos_enable_req(const PITS_Message_T * message)
{

   Done_Or_Not_Done_T pits_status = NOT_DONE;

   if (NULL != message)
   {
      /* Compose Message Header */
      filesys_tx_bus_id = message->bus;
      pits_filesys_compose_message_header(MID_FILESYS_LINGOS_ENABLE_RPT, 2);

      /* Compose Message Data */
      filesys_tx_data[0] = (uint8_t) COMMAND_NOT_SUPPORTED;
      if (message->data_size != 1)
      {
         pits_status = (Done_Or_Not_Done_T) PITS_PBS_Error_Report("FILESYS SESSION TIMEOUT REQUEST: Message Data Error");
      }
      else
      {
         if (message->data[0] < 3)
         {
            filesys_tx_data[0] = (uint8_t) SUCCESS;
            if (message->data[0] == 1)
            {
               PITS_Set_Ipod_Diag_Lingos_Enable(PIT_LINGOS_ENABLE);
            }
            if (message->data[0] == 2)
            {
               PITS_Set_Ipod_Diag_Lingos_Enable(0);
            }
            if (PITS_Get_Ipod_Diag_Lingos_Enable() == 0)
            {
               filesys_tx_data[1] = 2;
            }
            else
            {
               filesys_tx_data[1] = 1;
            }
         }
         pits_status = (Done_Or_Not_Done_T) PITS_Send_Message(&filesys_message);             
      }
   }

   return (pits_status);
}
/*===========================================================================*
 * FUNCTION: PITS_Set_FileSys_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Set_FileSys_Session(const PITS_EVG_SESSION_T session)
{
   bool_t result = false;

   EM_REQUIRE(session < SESSION_MAX, session);
   if (filesys_session_state != session)   /* Session State change? */
   {
      filesys_session_state = session;  /* Set to new State */
      SAL_Publish(PITS_EVG_FILESYS_SESSION, &filesys_session_state, sizeof(filesys_session_state));   /* Publish new Session State */
      if (filesys_session_state == SESSION_CLOSE)
      {
         SAL_Stop_Timer(pits_filesys_session_timer_id);
      }
      else
      {
         SAL_Start_Timer(pits_filesys_session_timer_id, filesys_session_timeout_sec, false);
      }
      result = true;
   }
   return (result);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_FileSys_Session
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_FileSys_Session(void)
{
   return (filesys_session_state);
}

/*===========================================================================*
 * FUNCTION: PITS_Create_FileSys_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Create_FileSys_Timer(void)
{
   SAL_Create_Timer(PITS_EV_FILESYS_SESSION_TIMEOUT, &pits_filesys_session_timer_id);
}

/*===========================================================================*
 * FUNCTION: PITS_Destroy_FileSys_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
void PITS_Destroy_FileSys_Timer(void)
{
   SAL_Destroy_Timer(pits_filesys_session_timer_id);
}


/*===========================================================================*
 * FUNCTION: PITS_Check_FileSys_Timer
 *===========================================================================*
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_Check_FileSys_Timer(const SAL_Event_Id_T event_id)
{
   bool_t status = false;

   if (event_id == PITS_EV_FILESYS_SESSION_TIMEOUT)
   {
      if (PITS_Set_FileSys_Session(SESSION_CLOSE))
      {
         PITS_PBS_Status_Report("PITS FILESYS SERVICES Session Time Out");
      }
      status = true;
   }
   return(status);
}

/*===========================================================================*
 * FUNCTION: PITS_FileSys_Send_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
bool_t PITS_FileSys_Send_Session_State(const SAL_Message_T * message)
{
   SAL_Send(message->sender_app_id, message->sender_thread_id, message->event_id, &filesys_session_state, sizeof(filesys_session_state));
   return(true);
}

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_FileSys_Session_State
 *===========================================================================*
 *
 * @see the API for detail description of this function.
 */
/*===========================================================================*/
PITS_EVG_SESSION_T PITS_Get_SAL_FileSys_Session_State(void)
{
   PITS_EVG_SESSION_T ret = SESSION_MAX;
   const SAL_Message_T *msg;
   SAL_Util_Send_Rcv_T send_reply = {0,SAL_UNKNOWN_THREAD_ID,PITS_EVG_FILESYS_SESSION,NULL,0,PITS_EVG_FILESYS_SESSION,0,0};
   SAL_Thread_Id_T PITS_Thread_Id = SAL_UNKNOWN_THREAD_ID;

   PITS_Thread_Id = PITS_Get_Thread_Id();

   send_reply.app_id = PITS_APP_ID;
   send_reply.thread_id = PITS_Thread_Id;
   send_reply.send_data = NULL;
   send_reply.send_data_sz = 0;
   send_reply.reply_id = PITS_EVG_FILESYS_SESSION;
   send_reply.max_tries = 2;
   send_reply.timeout_ms = PITS_DATA_REQUEST_TIMEOUT_MS;

   /* Request a data report from the PITS task and wait for the reply. */
   msg = SAL_Util_Req_And_Rcv(&send_reply);
   if (msg)
   {
      ret = *((PITS_EVG_SESSION_T *) msg->data);
   }
   return ret;
}


/*===========================================================================*/
/*!
 * @file pits_filesys_services.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS FileSys Services Session Timer function.
 *  Changed select track method.
 *
 *  06-Sep-2012 Darinka L�pez Rev 26
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 01-Ago-2012 Miguel Garcia  Rev 25
 * Task kok_basa#112058: PITS: Update Pits filesys services
 * Remove compilation variable
 *
 * 31-Jul-2012 Miguel Garcia  Rev 24
 * Task kok_basa#112058: PITS: Update Pits filesys services
 * Update PITS_FILESYS_Pos_T
 *
 * 26 July 2012 Miguel Garcia Rev 14
 * Fix Error response for device status
 *
 * 11 June 2012 Miguel Garcia Rev 13
 * Move pits icr filesys to processing services
 *
 * 17 May 2012 Miguel Garcia Rev 22
 * Remove cd/dvd from usb devices
 *
 * 04 May 2012 Miguel Garcia Rev 20
 * Include get file track
 *
 * 1-May-2012 Darinka Lopez  Rev 19
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 21-Mar-2012 Darinka Lopez  Rev 16
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 07 Mar 2012 Miguel Garcia Rev 15
 * Include ipod lingos enable pit
 *
 * 27 Jan 2012 Miguel Garcia Rev 14
 * Include filesys getter
 *
 * 14-Dec-2011 Darinka Lopez  Rev 13
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 8-Dec-2011 Oscar Vega  Rev 11
 * SCR kok_basa#16243 : Implement MSID(16h) - File System Services.
 * Add new function to get information from IPOD and MSD
 *
 * 2-Dec-2011 Oscar Vega  Rev 10
 * SCR kok_basa#16243 : Implement MSID(16h) - File System Services.
 * Implement File System Services
 *
 * 13 Jan 2011 Miguel Garcia
 * Remove unused Pits
 *
 * 03-Ago-2010 Miguel Garcia  Rev 8
 * SCR kok_basa#2414: Clean Pits Services. Implement Bool_t
 *
 * 11-Mar-2010 Pramod N K  Rev 7
 * SCR kok_basa#685: Remove references to old header files and API related to MH
 *
 * 11-Mar-2010 Pramod N K       Rev 6
 * SCR kok_basa#702: Remove reference to old API header file
 *
 * 2-Oct-2009 David Mooar  Rev 4
 * SCR kok_aud#63052: Remove SAL_Get_Requested_Id, and change BASA_APP_ID to
 * PITS_APP_ID.
 *
 * 12-Sept-2009 David Mooar  Rev 3
 * SCR kok_aud#62403: Fix selection of next or prev track.
 *
 * 10-Sept-2009 David Mooar  Rev 2
 * SCR kok_aud#62403: Implement PITS FileSys messages.
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
