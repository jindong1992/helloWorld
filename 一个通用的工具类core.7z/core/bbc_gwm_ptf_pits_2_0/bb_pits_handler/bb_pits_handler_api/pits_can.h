#ifndef PITS_CAN_H
#   define PITS_CAN_H
/*===========================================================================*/
/**
 * @file pits_can.h
 *
 * Public Interface (API) for PITS_CAN
 *
 * %full_filespec:pits_can.h~1:incl:ctc_ec#3 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:26 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include "pits_can_event_types.h"
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
/** Type for a Diagnostic USDT Physical Response. */

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern const SAL_Thread_Attr_T PITS_Can_Thread_Attr;

/*===========================================================================*
 * Exported Object Definitions
 *===========================================================================*/
extern SAL_Timer_Id_T mdg_timeout;

extern bool_t mdg_diag_enable;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Test_Initialize
 *===========================================================================*
 * @brief Initialize the PITS_CAN Thread and Configure the Bearing Bus.
 *        May be called only once.
 *
 * @returns
 *
 * @param
 *
 * @pre The PITS Thread ID has not been registered yet.
 *
 * @post The PITS Thread ID is valid.
 *
 */
/*===========================================================================*/
extern void PITS_Can_Initialize(void);

/**
 * Shutdown the thread for the PITS CAN Handler.
 */
extern void PITS_Can_Shutdown(void);

/**
 * Create diagnostics timer.
 */
extern void Create_MDG_Timer (void);

/**
 * Destroy diagnostics timer.
 */
extern void Destroy_MDG_Timer (void);

/**
 * Exit diagnostics mode.
 */
extern void Exit_Manufacturing_Mode (void);


/*===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_can.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 2014-06-11  Tim Wang
 *    - Created initial file.
 */
/*===========================================================================*/

#endif /* PITS_CAN_H */

