#ifndef PITS_MESSAGE_HANDLER_H
#   define PITS_MESSAGE_HANDLER_H
/*===========================================================================*/
/**
 * @file pits_message_handler.h
 *
 * Public Interface (API) for the PITS message handler.
 *
 * %full_filespec:pits_message_handler.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:22 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This module defines the API for:
 *    - Application Manager
 *    - Bearing Bus Configuration
 *    - Bearing Bus Wrapper
 *    - Periodic Task
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 *
 *===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_common_types.h"
#   include "pits_application_manager.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/**
 *  Defines the 4 possible packetization stages defined in the 
 *  appropriate document and section that defines the PITS stage values.
 */
typedef enum
{
   STAGE_FIRST_OF_ONE = 0x00,
   STAGE_FIRST_OF_MULTIPLE = 0x01,
   STAGE_MIDDLE_OF_MULTIPLE = 0x02,
   STAGE_LAST_OF_MULTIPLE = 0x03
} Packetization_Stage_T;

/*************************************************************
 * Bearing Bus Wrapper API
 *************************************************************/
typedef struct PITS_Packetization_State_Machine_Tag
{
   Packetization_Stage_T stage; /* Current packetization stage of this message */
   uint8_t counter;             /* Current packet counter for this message */
   bool_t in_use;                 /* is a packetized message in process? */
   uint16_t buffer_position;    /* Current position in rx/tx buffer */
} PITS_Packetization_State_Machine_T;

/**
 * A function type implemented in a Bearing Bus wrapper that handles the 
 * transmission of packets/messages on the underlying bearing bus. 
 *
 * Returns - boolean indicating success (true) or failure (false).
 */
typedef bool_t(*send_fptr) (uint8_t * data, uint16_t length);

typedef struct PITS_Bearing_Bus_Tag
{
   uint8_t bus_id;              /* Bus ID assigned by the Configuration */
   uint16_t max_message_length; /* maximum size for a message on this bus */
   uint16_t max_packet_length;  /* maximum size of a single message/packet */
   PITS_Message_T tx_message;   /* message to be transmitted on this bus */
   PITS_Message_T rx_message;   /* message received on this bus */
   PITS_Packetization_State_Machine_T tx_state_machine; /* state machine used for transmitting a message */
   PITS_Packetization_State_Machine_T rx_state_machine; /* state machien used for receiving a message */
   send_fptr send_function;     /* pointer to a function used to transmit a message on the Bearing Bus */
} PITS_Bearing_Bus_T;

typedef struct PITS_Bearing_Busses_Tag
{
   uint8_t num_busses;
   PITS_Bearing_Bus_T **busses;
} PITS_Bearing_Busses_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*************************************************************
 * Application Manager API
 *************************************************************/

/*===========================================================================*/
/**
 * @brief Initiates the transmission of a PITS message on the appropriate bus.
 *
 * @returns 
 *    - true: if message was sent.
 *    - false: if message was not sent.
 *
 * @param message
 *   A pointer to the message that the calling PITS Diagnostic Application 
 *   wishes to transmit.
 */
/*===========================================================================*/
extern bool_t PITS_Message_Handler_Send_Message(const PITS_Message_T * message);

/*************************************************************
 * Bearing Bus Wrapper API
 *************************************************************/

/*===========================================================================*/
/**
 * @brief Handles the reception of a single packet of a PITS message and places it
 * into a full PITS message. Passes on the full PITS message to the next layer 
 * when done.
 *
 * @returns 
 *    nothing
 *
 * @param bus
 *   Pointer to the bus that is receiving this message.
 *
 * @param data
 *   Pointer to the raw data received on the underlying bearing bus.
 *
 * @param length
 *   Indicates the number of bytes of data received on the bus.
 */
/*===========================================================================*/
extern void PITS_Message_Handler_Receive_Packet(PITS_Bearing_Bus_T * bus, const uint8_t * data, uint16_t length);

/*************************************************************
 * Periodic Operations
 *************************************************************/

/*===========================================================================*/
/**
 * @brief Handles transmission of subsequent packets of a PITS message.
 *
 * @returns 
 *    Enumerated value indicating whether or not the Handler has completed 
 *    sending all packets.
 */
/*===========================================================================*/
extern Done_Or_Not_Done_T PITS_Message_Packet_Handler(void);

/*************************************************************
 * Configuration API
 *************************************************************/

/*===========================================================================*/
/**
 * @brief Configure the Bearing Busses 
 *
 */
/*===========================================================================*/
extern void PITS_Configure_Bearing_Busses(PITS_Bearing_Bus_T *const record[], uint8_t count);

/**
 * @brief Send a Pits server Request
 *
 */
extern void Pits_Server_Request (const uint8_t * pits_msg, size_t num_bytes);
/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_message_handler.h
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 * - 2011-12-27 Miguel Garcia
 *    - Include Pits server request function
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-05-30  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-08  Mike Gerig/Kris Boultbee
 *    - Created initial file.
 *
 *===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_MESSAGE_HANDLER_H */
