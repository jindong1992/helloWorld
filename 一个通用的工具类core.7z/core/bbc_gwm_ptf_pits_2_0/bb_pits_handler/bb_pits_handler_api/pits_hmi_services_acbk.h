#ifndef PITS_HMI_SERVICES_ACBK_H
#   define PITS_HMI_SERVICES_ACBK_H
/*===========================================================================*/
/**
 * @file pits_hmi_services_acbk.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_hmi_services_acbk.h~1:incl:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:02 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @addtogroup pits_hmi_services
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_hmi_services_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for API Callouts
 *===========================================================================*/

/*===========================================================================*
 * External Function Prototypes for API Callouts
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_hmi_services_acbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 17-feb-2010 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_HMI_SERVICES_ACBK_H */

