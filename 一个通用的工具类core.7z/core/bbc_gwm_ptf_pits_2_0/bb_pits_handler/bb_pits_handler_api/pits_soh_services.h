#ifndef PITS_SOH_SERVICES_H
#   define PITS_SOH_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_soh_services.h
 *
 * API for PITS Health Services.
 *
 * %full_filespec:pits_soh_services.h~1:incl:ctc_ec#22 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:06:03 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *    This module defines the PITS Health Service Messages used in the project. 
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS - Product Integrated Test Strategy.
 *    - MSID - Message Set Identifier
 *    - MID  - Message Identifier
 *    - DTC  - Diagnostic Trouble Code.
 *    - PSS  - Pits SOH Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *          SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/* *INDENT-OFF* */

/*
 * DTC Status Byte Mask
 */
#define PITS_DTC_ENABLE_BIT           0x01u
#define PITS_DTC_CURRENT_BIT          0x02u
#define PITS_DTC_TEST_NOT_PASSED_BIT  0x04u
#define PITS_DTC_HISTORY_BIT          0x10u
#define PITS_DTC_NO_MASK_BIT          0x80u
/* *INDENT-ON* */

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 *
 * The only thing exposed by an application to the outside world is it's interface
 * This is defined in the Applications C file and is used by the Configuration 
 * and then the PITS Application Manager. This interface contains a number of
 * PITS Message Sets. This interface is of type PITS_Application_Interface_T
 *
 * An application could expose two or more interfaces if desired
 *
 * @todo make this const
 */
/*===========================================================================*/
extern PITS_Application_Interface_T PITS_PSS_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*/

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_PSS_Get_Single_DTC_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Set_Single_DTC_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_All_DTC_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Get_Enable_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Set_Enable_State_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Clear_All_DTC_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Reset_Enable_Bits_Default_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Get_DTC_Ign_Counter_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PSS_Set_DTC_Ign_Counter_Req(const PITS_Message_T * message);

/*===========================================================================*/
/*!
 * @file pits_soh_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 18-Feb-2013 Oscar Vega  Rev 7
 * SCR kok_basa#38553: DTCs - Change default value to $01
 *
 * 30 0ct 2012 Miguel Garcia Rev 6
 * Task kok_basa#126309. Remove unused session timeout functions
 *
 *  06-Sep-2012 Darinka L�pez Rev 5
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Mar-2012 Oscar Vega 4
 * Task kok_basa#86597 - MID 1A/1B - Clear all DTCs.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 23-Nov-2011 Oscar Vega  Rev 1
 * SCR kok_basa#17216 :  Implement MSID(05h) - SOH Services.
 * Implement PITS SOH services.
 * Initial Revision
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_SOH_SERVICES_H */
