#ifndef PITS_MANAGER_H
#   define PITS_MANAGER_H
/*===========================================================================*/
/**
 * @file pits_manager.h
 *
 * Public Interface (API) for PITS_MANAGER
 *
 * %full_filespec:pits_manager.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:17 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This is the PITS Task module. It initializes and closes the Bearing bus,
 *    and manages the transmission and reception of message to and from the bus.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 *
 *===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include "pits_event_types.h"
#   include "pits_manager_acfg.h"
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef void (*PITS_Setup_Fptr) (void);

typedef bool_t(*private_event) (const SAL_Event_Id_T event_id);

typedef struct PITS_Private_Event_Handler_Tag
{
   SAL_Event_Id_T  name;   /* Name of the event */
   PITS_Setup_Fptr setup;  /**< pointer to function to setup the private event handler, such as create the event timer */
   PITS_Setup_Fptr destroy; /**< pointer to function to setup the private event handler, such as create the event timer */
   private_event handler;  /**< pointer to function to handle the private event */
} PITS_Private_Event_Handler_T;

typedef bool_t(*global_event) (const SAL_Message_T * message);

typedef struct PITS_Global_Event_Handler_Tag
{
   global_event handler;   /**< pointer to function to handle the global event */
} PITS_Global_Event_Handler_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern const SAL_Thread_Attr_T PITS_Thread_Attr;

/*===========================================================================*
 * Exported Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Initialize
 *===========================================================================*
 * @brief Initialize the PITS Thread and Configure the Bearing Bus.
 *        May be called only once.
 *
 * @returns
 *
 * @param
 *
 * @pre The PITS Thread ID has not been registered yet.
 *
 * @post The PITS Thread ID is valid.
 *
 */
/*===========================================================================*/
extern void PITS_Initialize(void);

/**
 * Shutdown the thread for the PITS Handler.
 */
extern void PITS_Handler_Shutdown (void);

/**
 * Accessor to get MODULE's thread id
 *
 * @return Thread ID for the MODULE
 */
extern SAL_Thread_Id_T PITS_Get_Thread_Id(void);

/**
 * Restart Timer to poll the Bearing Bus
 *
 * @param [in] interval_msec
 */
extern void PITS_Restart_Poll_Timer(uint32_t interval_msec);

/**
 * Stop Timer to poll the Bearing Bus
 *
 */
extern void PITS_Stop_Poll_Timer(void);

/*===========================================================================*/
/*!
 * @file pits_manager.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Struct PITS_Private_Event_Handler_Tag add sub-type PITS_Private_Event_Handler_Tag.
 *
 *  06-Sep-2012 Darinka L�pez Rev 10
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 23 Aug 2012 Miguel Garcia Rev9
 * Task kok_basa#115934 - Fix Pits Timers
 *
 * 16 Aug 2012 Oscar Vega Rev 8
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 21-Mar-2012 Oscar Vega Rev 7
 * Adding shutdown function for PITS.
 *
 * - 16-July-2010 (JICASTANON) lzz7kf  Rev 5
 *   - SCR kok_basa#1607: pits_event_types.h includes fix
 *
 * 1-Oct-2009 David Mooar  Rev 3
 * SCR kok_aud#62242: Fix release tag.
 *
 * - 18-august-2009 David Mooar  Rev 2
 *   SCR kok_aud#62242: Create PITS_Setup_Fptr to use instead of void_fptr, to
 *   avoid warnings. 
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-30  Larry Ong
 *    - Add functions to restart and stop the poll timer.
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2007-12-03  Larry Ong
 *    - Add DTC Test Execute Timeout timer:
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-09  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-10-05  Larry Ong
 *    - Changed Task name from Module_Task to PITS_Task.
 *
 * - 2007-10-01  Jaroslaw Saferna
 *    - Module_Task() function defined as extern.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-14  Larry Ong
 *    - Renamed module to pits_manager.
 *    - Moved DESIP functions to pits_desip_handler.
 *    - Added XSAL publish message PITS_PPS_Session and PITS_PCS_Session.
 *
 * - 2007-06-01  Larry Ong
 *    - Created initial file.
 *
 *===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_MANAGER_H */
