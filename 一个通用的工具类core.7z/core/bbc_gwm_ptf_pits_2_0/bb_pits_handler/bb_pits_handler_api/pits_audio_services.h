#ifndef PITS_AUDIO_SERVICES_H
#   define PITS_AUDIO_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_audio_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_audio_services.h~2:incl:ctc_ec#23 %
 * @version %version:2 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Thu Jun 23 17:08:43 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_audio_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "audio_shared_types.h"
#include "pits_application_manager.h"
#include "pits_configuration.h"
#include "source_manager.h"
#include "zone.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

typedef enum PITS_Audio_Overrides_Tag
{
   PITS_AU_EN_VOLUME,
   PITS_AU_EN_FADE,
   PITS_AU_EN_BALANCE,
   PITS_AU_EN_TONE,
} PITS_Audio_Overrides_T;

typedef enum PITS_Playback_Tag
{
   PITS_PLAYBACK_TUNER     = 0x00,
   PITS_PLAYBACK_CD        = 0x01,
   PITS_PLAYBACK_ICDX      = 0x02,
   PITS_PLAYBACK_FRONT_AUX = 0x04,
   PITS_PLAYBACK_REAR_AUX  = 0x05,
   PITS_PLAYBACK_DVD       = 0x06,
   PITS_PLAYBACK_DVDX      = 0x07,
   PITS_PLAYBACK_USB1      = 0x08,
   PITS_PLAYBACK_USB2      = 0x09,
   PITS_PLAYBACK_SD1       = 0x0A,
   PITS_PLAYBACK_SD2       = 0x0B,
   PITS_PLAYBACK_BLUETOOTH = 0x0C,
   PITS_PLAYBACK_CF_CARD   = 0x0D
} PITS_Playback_T;

/*XW changed definition according to Jiangchong's request*/
typedef enum PITS_Source_Tag
{
   PITS_SRC_NONE                  = 0x00,
   PITS_SRC_TUNER_AM       = 0x01,
   PITS_SRC_TUNER_FM1     = 0x02,
   PITS_SEC_HDRADIO          = 0x03,
   PITS_SRC_SD                        = 0x04,
   PITS_SRC_USB1                   = 0x05,
   PITS_SRC_RDS                     = 0x06,
   PITS_SRC_MIC                     = 0x07,
   PITS_SRC_AUX                     = 0x08,
   PITS_SRC_MONO                 = 0x0A,
   PITS_SRC_BT_PHONE        = 0x0B,
   PITS_SRC_TTS                      = 0x0C,
   PITS_SRC_NAV                     = 0x0D,
   PITS_SRC_SPDIF                  = 0x0E,
   PITS_SRC_USB2                   = 0x0F,  
   PITS_SRC_T_BOX_AUDIO  = 0x10,
   PITS_SRC_ALARM                =  0x11,
   PITS_SRC_ALARM_CANCEL = 0x12,
   PITS_SRC_T_BOX_AUDIO_CANCEL = 0x13,
   PITS_SRC_SPDIF_CANCEL = 0x14,
} PITS_Source_T;

typedef enum PITS_Virtual_Source_Tag
{
   PITS_V_SRC_MIC                  = 0x01,
   PITS_V_SRC_MONO                 = 0x02,
   PITS_V_SRC_BT_PHONE             = 0x03,
   PITS_V_SRC_TTS                  = 0x04,
   PITS_V_SRC_NAV                  = 0x05,
} PITS_VIRTUAL_Source_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Audio_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/**
 * Clear overrides related to audio.
 */
extern void PITS_Audio_Clear_Overrides(void);
/**
 * Enable or Disable an audio override.
 * @param [in] au_override - desired type of override
 * @param [in] state - true or false.
 */
extern void PITS_Set_Audio_Overrides(PITS_Audio_Overrides_T au_override, bool_t state);

/**
 * Command a source change.  Used by pits_audio_services.h when a source change
 * command is received, but also available for use by tuner manager if it
 * initiates source change.
 *
 * @param [in] zone - desired zone
 * @param [in] audio_bus - audio bus for the given zone to which the source is connected
 * @param [in] logical_source - new logical source
 */
extern void PITS_Audio_Connect_Src_To_Zone(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Logical_Src_T logical_source);

/*===========================================================================*
 * FUNCTION: PITS_Create_Audio_Timer
 *===========================================================================*
 * @brief Create PITS Audio Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_Audio_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Audio_Timer
 *===========================================================================*
 * @brief Destroy PITS Audio Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_Audio_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_Audio_Timer
 *===========================================================================*
 * @brief Check for Audio Session Timeout
 *
 * @returns
 *    false = If Event is not a Audio Session Timeout
 *    true = If Event is a Audio Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_Audio_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Create_ALARM_Timer
 *===========================================================================*
 * @brief Create alarm channel test timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
extern void PITS_Create_ALARM_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_ALARM_Timer
 *===========================================================================*
 * @brief Check whether alarm channel test timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_ALARM_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: Pits_Destroy_ALARM_Timer
 *===========================================================================*
 * @brief destroy alarm channel test timer 
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void Pits_Destroy_ALARM_Timer(void);

#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
/*===========================================================================*
 * FUNCTION: PITS_Create_RES_Timer
 *===========================================================================*
 * @brief Create RES periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Create_RES_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_RES_Timer
 *===========================================================================*
 * @brief Destroy RES periodic send timer
 *
 * @returns
 *    Void
 *
 * @param [in] message = void
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
void PITS_Destroy_RES_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_RES_Timer
 *===========================================================================*
 * @brief Check whether RES send timer is timeout
 *
 * @returns
 *    ture = timer is timeout
 *    false = timer still not arrived
 *
 * @param [in] message = PITS event id
 *
 * @param [out] TX_Message[0] = void
 * @param [out] TX_Message[1] = void
 *
 */
/*===========================================================================*/
bool_t PITS_Check_RES_Timer(const SAL_Event_Id_T event_id);
#endif

/*===========================================================================*
 * FUNCTION: PITS_Set_Audio_Session
 *===========================================================================*
 * @brief Setter Function for the PCS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_Audio_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_Audio_Session_State
 *===========================================================================*
 * @brief Getter function for Audio Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_Audio_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_Audio_Send_Session_State
 *===========================================================================*
 * @brief Function to send Audio Session State
 *
 * @returns
 *    false - Request is not for Audio Session
 *    true - Request is for Audio Session, and message sent
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Audio_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Audio_Session_State
 *===========================================================================*
 * @brief Getter functions for published Audio Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_Audio_Session_State(void);
/**
 * Clear overrides related to audio source.
 */
extern void PITS_Audio_Clear_Source_Override(void);
/**
 * Sinad Enable Response.
 */
#if PITS_SINAD_IS
extern void PITS_SINAD_Enable_Mfg_Test_Rsp(const uint8_t * data, size_t length);
/**
 * Sinad Play Audio Response.
 */
extern void PITS_SINAD_Play_Audio_Rsp(const uint8_t * data, size_t length);
/**
 * Sinad Stop Response.
 */
extern void PITS_SINAD_Stop_Audio_Rsp(const uint8_t * data, size_t length);
/**
 * Sinad Measure Response.
 */
extern void PITS_SINAD_Measure_SINAD_Rsp(const uint8_t * data, size_t length);
#endif

extern void Pits_Get_Muted_Data (const uint8_t * data, size_t length);

extern void Pits_Get_Unmuted_Data (const uint8_t * data, size_t length);

extern void Pits_Get_Sdar_Quality (const uint8_t * data,  size_t length);

extern void pits_audio_set_ssm_source_present(uint8_t source);

extern void pits_audio_set_ssm_source_last_source(Sys_Zone_T zone, uint8_t source);


extern void ssm_Save_Channel_Source(SSM_Channel_T channel, SSM_Source_T const * source);
/*===========================================================================*
 * FUNCTION: PITS_Audio_Map_Logical_Src_To_Pits_Src
 *===========================================================================*
 * @brief Function to Map logical source to pits source
 *
 * @returns
 *    true/false
 * @param logical source / pits_source
 *
 */
/*===========================================================================*/
extern bool_t PITS_Audio_Map_Logical_Src_To_Pits_Src(Audio_Logical_Src_T logical_source, PITS_Source_T *pits_source);


/**
 * Get Volume for a given audio bus on a zone.
 *
 * @return
 *   absolute detent for volume.
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus for the given zone for which the volume is sought.
 *
 */
extern Audio_Detent_T PITS_AU_Get_Volume(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);

/**
 * Set Volume for a given audio bus on a zone.
 *
 * @return
 *   None
 *   Publishes: AUMGR_EVG_REPORT_VOLUME
 *              volume_report.logical_path - the affected logical path
 *              volume_report.zone - the given zone
 *              volume_report.audio_bus - the affected audio_bus
 *              volume_report.absolute_detent - the absolute detent
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus for the given zone for which the volume is set.
 *
 * @param [in]   absolute_detent
 *   absolute detent for volume.
 *
 */
extern void PITS_AU_Set_Volume(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Detent_T absolute_detent);

/**
* Set a single Tone band.
*
* @return
*   None
*   Publishes: AUMGR_EVG_REPORT_TONE
*              tone_report.logical_path - the affected logical path
*              tone_report.zone - the given zone
*              tone_report.audio_bus - the affected audio_bus
*              tone_report.absolute_detent[AUDIO_TONE_BAND_NUM] - absolute detents for each tone band
*
*
* @param [in]    zone
*   given zone.
*
* @param [in]    audio_bus
*   audio bus in the given zone for which the tone band is set.
*
* @param [in]   audio_tone_struct
*   tone band set.

* @param [in]   audio_tone_struct
*   absolute detent for tone band.
*
*/
extern void PITS_AU_Set_All_Tone_Bands(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Tone_T audio_tone_struct);

/**
 * Get Tone for all bands.
 *
 *
 * @return
 *   audio_tone_struct
 *   structure with absolute detents for each tone band.
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus in the given zone for which the tone is requested.
 *
 */
extern Audio_Tone_T PITS_AU_Get_All_Tone_Bands(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);

/**
 * Set Balance
 *
 * @return
 *   None
 *   Publishes: AUMGR_EVG_REPORT_BALANCE
 *              balance_report.zone - the given zone
 *              balance_report.audio_bus - the affected audio_bus
 *              balance_report.logical_path - the affected logical path
 *              balance_report.absolute_detent - absolute detent for balance
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus in the given zone for which the balance is set.
     *
 * @param [in]   absolute_detent
 *   absolute detent for balance.
 *
 */
extern void PITS_AU_Set_Balance(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Detent_T absolute_detent);


/**
 * Get Balance for a given audio bus on a zone.
 *
 * @return
 *   absolute detent for Balance.
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus for the given zone for which the Balance is sought.
 *
 */
extern Audio_Detent_T PITS_AU_Get_Balance(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);

/**
 * Set Fade
 *
 * @return
 *   None
 *   Publishes: AUMGR_EVG_REPORT_FADE
 *              fade_report.zone - the given zone
 *              fade_report.audio_bus - the affected audio_bus
 *              fade_report.logical_path - the affected logical path
 *              fade_report.absolute_detent - absolute detent for balance
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus in the given zone for which the fade is set.
     *
 * @param [in]   absolute_detent
 *   absolute detent for fade.
 *
 */
extern void PITS_AU_Set_Fade(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Detent_T absolute_detent);


/**
 * Get Fade for a given audio bus on a zone.
 *
 * @return
 *   absolute detent for Fade.
 *
 * @param [in]    zone
 *   given zone.
 *
 * @param [in]    audio_bus
 *   audio_bus for the given zone for which the Fade is sought.
 *
 */
extern Audio_Detent_T PITS_AU_Get_Fade(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus);

/**
 * Enable / disable diagnostic override on specified features.
 *
 * @return
 *   None
 *    	 *
 * @param [in]    audo_DO_Enable
 *   specifies features on which diagnotic override is to be enabled
*   or disabled
 */

extern void  PITS_AU_Enable_Overrides(AuMgr_DO_Enable_T audo_DO_Enable);

/**
 * Set Mute State, either mute or unmute, for specified audio bus
 * on a given zone.
 *
 * @return
 *   None
 *   Publishes: AUMGR_EVG_MUTED or AUMGR_EVG_UNMUTED
 *              logical_path - the affected logical path
 *              audio_bus - the affected audio bus
 *              zone - the affected zone
 *
 * @param [in]   zone
 *   given zone.
 *
 * @param [in]   audio_bus
 *   audio bus on the given zone for which the mute state is set.
 *
 * @param [in]   mute_state
 *   mute state, either mute or unmute
 *
 */
extern void PITS_AU_Set_Mute_State_Bus(Sys_Zone_T zone, Sys_Audio_Bus_T audio_bus, Audio_Mute_State_T mute_state);

/**
 * Request a source type to be connected to an output channel
 *    Will select 1st available source of the specified type
 *    If none exits, it will leave the channel unchanged
 *
 * @param source_type - Source type
 * @param channel - desired output channel
 */
extern void PITS_AU_Select_Source_Type(SSM_Source_Type_T source_type, SSM_Channel_T channel);

/**
 * Request a source type to be connected to an output channel
 *    Will select 1st available source of the specified type
 *    If none exits, it will leave the channel unchanged
 *
 * @param source_type - Source type
 * @param channel - desired output channel
 */
extern void  PITS_SSM_Store_Source_Type(SSM_Source_Type_T source_type, SSM_Channel_T channel);

/** 
 * Request a source type to be connected to an output channel
 *     
 *    
 *
 * @param source_type - Source type
 * 
 */
extern void PITS_AU_Select_Virtual_Source_Type(PITS_VIRTUAL_Source_T source_type, int8_t volume);

bool_t pits_audio_map_ssm_src_to_pits_src(SSM_Source_Type_T ssm_source, PITS_Source_T *pits_source);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_audio_get_volume_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_volume_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_fade_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_fade_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_balance_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_balance_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_source_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_ssm_source_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_ssm_source_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_virtual_source_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_mute_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_mute_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_chime_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_chime_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_cdsp_mute_req(const PITS_Message_T * message);
#if 0
extern Done_Or_Not_Done_T pits_audio_get_ddl_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_ddl_req(const PITS_Message_T * message);
#endif
extern Done_Or_Not_Done_T pits_audio_get_info_can_state_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_rsa_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_rsa_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_scv_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_scv_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_tone_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_tone_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_playback_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Audio_Get_SSM_Playback_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_set_source_audio_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Audio_Set_Internal_Audio(const PITS_Message_T * message);

#if PITS_SINAD_IS
extern Done_Or_Not_Done_T pits_audio_start_sinad_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_play_sinad_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_stop_sinad_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_measure_sinad_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_audio_get_quality_diag_req(const PITS_Message_T * message);
#endif
extern Done_Or_Not_Done_T pits_audio_set_dsp_mode_req(const PITS_Message_T * message);

/*===========================================================================*/
/*!
 * @file pits_audio_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 23June2016 Rahul Chirayil (vzm576) Rev. 2
 * ctc_ec#156415: Remove build warnings.
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Audio Services Session Timer function.
 * 
 *  06-Sep-2012 Darinka L�pez Rev 23
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Aug-2012 Darinka Lopez 22
 * Taks kok_basa#116889 - Change MID 30/32 - Set standarized Input
 * Fix Include issue. *_cbk.h should not be call in *.h files.
 *
 * 16 Aug 2012 Oscar Vega Rev 21
 * Task kok_basa#115113 - Fix Task for kok_basa#114795: 20_Audio klocwork issues
 *
 * 16 Aug 2012 Oscar Vega Rev 20
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 15-Aug-2012 Arturo Perez  Rev 19
 * Task kok_basa#114601 - Implement PIT 42/43 & 44/45 - Get/Set RSA Enable Status
 *
 * 26-Jun-2012 Oscar Vega  Rev 18
 * Task kok_basa#105387 - 2_0 - MID 40/41 - Request/Report  Get Playback Status
 *
 * 09 May 2012 Miguel Garcia Rev 17
 * Include SMM source present
 *
 * 04 May 2012 Miguel Garcia Rev 16
 * Include audio set dsp mode
 *
 * 1-May-2012 Darinka Lopez  Rev 15
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 24 Apr 2012 Miguel Garcia Rev 13
 * Include get quality for diagnostics
 *
 * 21-Mar-2012 Darinka Lopez  Rev 12
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 27 Feb 2012 Miguel Garcia Rev 11
 * Include mute, unmute events
 *
 * 16-Jan-2012 Juan Carlos Castillo  Rev 10
 * SCR kok_basa#19216: PITS Get Source - Audio Services
 * Fix: Get Source directly from SSM instead of logical audio.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 8
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 9-Feb-2010 Shaoli Dai Rev 4
 * Fix EOL
 * 10-Sept-2009 David Mooar  Rev 3
 * SCR kok_aud#62361/62399: Implement PITS audio messages.
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *               Change code to be BASA 2.0 compatible.
 *
 * - 01-oct-2008 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_AUDIO_SERVICES_H */
