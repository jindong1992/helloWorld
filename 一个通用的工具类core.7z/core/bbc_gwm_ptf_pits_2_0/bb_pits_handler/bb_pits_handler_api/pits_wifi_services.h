#ifndef PITS_WIFI_SERVICES_H
#   define PITS_WIFI_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_wifi_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_wifi_services.h~1:incl:ctc_ec#21 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:06:16 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_wifi_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_manager.h"
#include "pits_application_manager.h"
#include "pits_wifi_services_cbk.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_WIFI_STATUS                        (0)
#define PITS_WIFI_ON                            (1)
#define PITS_WIFI_OFF                           (2)

#define PITS_WIFI_MAC_ADDR_MAX_LENS             (6)
typedef enum 
{
   PITS_WIFI_STATUS_ON,
   PITS_WIFI_STATUS_OFF,
   PITS_WIFI_STATUS_IN_PROCESSING,
   PITS_WIFI_STATUS_OPERATION_ERROR
}PITS_WIFI_STATUS_ENUM_T;

#define PITS_WIFI_CONNECT     (1)
#define PITS_WIFI_DISCONNECT  (2)
typedef enum 
{
   PITS_WIFI_CONN_STATUS_ON,
   PITS_WIFI_CONN_STATUS_OFF,
   PITS_WIFI_CONN_STATUS_IN_PROCESSING,
   PITS_WIFI_CONN_STATUS_OPERATION_ERROR
}PITS_WIFI_CONN_STATUS_ENUM_T;

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Wifi_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_Wifi_Get_IP_Address_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Set_IP_Address_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Tot_Networks_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Start_Packets_trans_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Set_Carrier_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Carrier_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Set_Alignment_Cal_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Alignment_Cal_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Save_Alignment_Cal_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Stop_Packets_trans_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Connect_Network_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Query_Connect_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Signal_Level_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Signal_PER_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Clear_Signal_Packet_Number_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Signal_Packet_Number_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Ssid_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Mode_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Encryp_State_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Encryp_Type_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Set_Ping_Test_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Ping_Test_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Ad_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Ssid_Ad_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Test_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Query_Test_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Set_Mac_Addr_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Get_Mac_Addr_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Wifi_Observe_Coexistence_Status_Req(const PITS_Message_T * message);




/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_wifi_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 06 Mar 2014 Bao Qifan Rev 6
 * Task ctc_ec#60736. [NGK PITS] add bt and wifi coexistance function
 *
 * 12-Feb-2014 Bao Qifan Rev 5
 * Task ctc_ec#58862 [NGK PITS] add pits msg 12 7E save wifi alignment cal value function
 *
 * 21-Jan-2014 Bao Qifan Rev 4
 * Task ctc_ec#58134 [NGK PITS] add wifi pits message
 *
 * 30-Augu-2013 Bao Qifan Rev 3
 * Task ctc_ec#43034 [NGK PITS]draf version for wif pits function
 *
 * 08-Jan-2012 Bao Qifan  Rev 2
 * SCR ctc_ec#33077: [NGK PITS] add pits wifi status define
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_WIFI_SERVICES_H */
