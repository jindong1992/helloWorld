#ifndef PITS_CONTROL_SERVICES_H
#   define PITS_CONTROL_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_control_services.h
 *
 * API for PITS_control_services.c.
 *
 * %full_filespec:pits_control_services.h~1:incl:ctc_ec#25 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:42 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the PITS Control Service Messages used in the project. 
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy
 *    - MSID: Message Set Identifier
 *    - MID: Message Identifier
 *    - PCS: PITS Control Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 *
 * The only thing exposed by an application to the outside world is it's interface
 * This is defined in the Applications C file and is used by the Configuration 
 * and then the PITS Application Manager. This interface contains a number of
 * PITS Message Sets. This interface is of type PITS_Application_Interface_T
 *
 * An application could expose two or more interfaces if desired
 *
 * @todo make this const
 */
/*===========================================================================*/
extern PITS_Application_Interface_T PITS_PCS_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Create_PCS_Timer
 *===========================================================================*
 * @brief Create PITS Control Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_PCS_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_PCS_Timer
 *===========================================================================*
 * @brief Destroy PITS Control Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_PCS_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_PCS_Timer
 *===========================================================================*
 * @brief Check for PCS Session Timeout
 *
 * @returns
 *    false = If Event is not a PCS Session Timeout
 *    true = If Event is a PCS Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_PCS_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Set_PCS_Session
 *===========================================================================*
 * @brief Setter Function for the PCS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_PCS_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_PCS_Session_State
 *===========================================================================*
 * @brief Getter function for PCS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_PCS_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_PCS_Send_Session_State
 *===========================================================================*
 * @brief Function to send PCS Session State
 *
 * @returns
 *    false - Request is not for PCS Session
 *    true - Request is for PCS Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PCS_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PCS_Session_State
 *===========================================================================*
 * @brief Getter functions for published PCS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_PCS_Session_State(void);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_pcs_parameter_write_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pcs_parameter_read_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pcs_downloadx_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pcs_iic_write_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pcs_iic_read_req(const PITS_Message_T * message);

/*===========================================================================*/
/*!
 * @file pits_control_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Control Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 8
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 16 Aug 2012 Oscar Vega Rev 7
 * Task kok_basa#114795 - 2_0 - Klocwork issues
 *
 * 21-Mar-2012 Darinka Lopez  Rev 6
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Remove _j2 in control services files too.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Change code to be BASA2.0 compatible.
 *
 * - 2008-06-30  Larry Ong
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-06-10  Larry Ong
 *    - Moved MID definitions to pits_control_services_cfg file.
 *    - Move Private Event declaration and processing to each PITs Services.
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up @todo comments.
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-15  Larry Ong
 *    - Added Session Refresh message to Refresh Session Timer.
 *
 * - 2007-07-31  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_CONTROL_SERVICES_H */
