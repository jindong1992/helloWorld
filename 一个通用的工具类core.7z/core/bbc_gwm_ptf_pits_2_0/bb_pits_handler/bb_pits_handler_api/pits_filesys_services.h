#ifndef PITS_FILESYS_SERVICES_H
#   define PITS_FILESYS_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_filesys_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_filesys_services.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:50 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_filesys_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  
#include "metadata_handler_acfg.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_NEXT_TRACK                0x01
#define PITS_PREV_TRACK                0x02
#define PITS_FSYS_MEDIA_PRESENT        0x01
#define PITS_FSYS_NO_MEDIA             0x00
#define PITS_FSYS_CONNECTED            0x01
#define PITS_FSYS_DISCONNECTED         0x02
#define SIZE_FOUR                      0x04

#define TITLE_NAME_SIZE_MAX           MDH_LONG_STRING_LENGTH

 typedef struct PITS_FILESYS_Pos_Tag
 {
    uint8_t      minutes;          /*BCD*/
    uint8_t      seconds;          /*BCD*/
    uint8_t     name_length;
    uint8_t     title_name[TITLE_NAME_SIZE_MAX];
 } PITS_FILESYS_Pos_T;


/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_FileSys_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Set_FileSys_Session
 *===========================================================================*
 * @brief Setter Function for the FileSys Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_FileSys_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_FileSys_Session
 *===========================================================================*
 * @brief Getter function for FileSys Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_FileSys_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_Create_FileSys_Timer
 *===========================================================================*
 * @brief Create PITS FileSys Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_FileSys_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_FileSys_Timer
 *===========================================================================*
 * @brief Destroy PITS FileSys Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_FileSys_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_FileSys_Timer
 *===========================================================================*
 * @brief Check for FileSys Session Timeout
 *
 * @returns
 *    false = If Event is not a FileSys Session Timeout
 *    true = If Event is a FileSys Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_FileSys_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_FileSys_Send_Session_State
 *===========================================================================*
 * @brief Function to send FileSys Session State
 *
 * @returns
 *    false - Request is not for FileSys Session
 *    true - Request is for FileSys Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_FileSys_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_FileSys_Session_State
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_FileSys_Session_State(void);

/*===========================================================================*
 * FUNCTION: Pits_Msd_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Msd_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Mtp_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Mtp_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Ipod_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Ipod_Connected_Status (const uint8_t * data, size_t length);
/*===========================================================================*
 * FUNCTION: Pits_Sd_Connected_Status
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Sd_Connected_Status (const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: Pits_Rtd_Connected_Status
 *===========================================================================*
 * @brief  get t=rtd connection status
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Rtd_Connected_Status (const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: Pits_USB_Device_Connected_Status
 *===========================================================================*
 * @brief  Getter functions for published FileSys Session States
 *
 * @returns
 *    Disconnected
 *    Connected
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_USB_Device_Connected_Status(const uint8_t * data, size_t length);
extern void Pits_USB_Device_Remove(const uint8_t * data, size_t length);

/*===========================================================================*
 * FUNCTION: Pits_Filesys_Get_Elapsed_Time
 *===========================================================================*
 * @brief Getter functions for published FileSys Session States
 *
 * @returns
 *    Elapsed Time
 *
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
extern void Pits_Filesys_Get_Elapsed_Time (const uint8_t * data, uint16_t length);
extern void Pits_Get_File_Track_Info (const uint8_t * data, size_t length);
extern bool_t Pits_Filesys_Get_Authentication_Status (uint8_t device);
extern void Pits_Set_Ipod_Aut_Failure (const uint8_t * data, size_t length);
extern void Pits_Unsupported_Device_Inserted (const uint8_t * data, size_t length);
extern Done_Or_Not_Done_T pits_filesys_device_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_media_position_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_set_media_position_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_device_authentication_self_test_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_device_ids_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_lingos_enable_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_filesys_set_diag_position_req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_filesys_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS FileSys Services Session Timer function.
 *  Added Pits_USB_Device_Connected_Status function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 14
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 11 June 2012 Miguel Garcia Rev 13
 * Move pits icr filesys to processing services
 *
 * 04 May 2012 Miguel Garcia Rev 12
 * Include Get File Track info
 *
 * 21-Mar-2012 Darinka Lopez  Rev 9
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 07 Mar 2012 Miguel Garcia Rev 8
 * Include ipod lingos enable
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 6
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 8-Dec-2011 Oscar Vega  Rev 5
 * SCR kok_basa#16243 : Implement MSID(16h) - File System Services.
 * Add new function to get information from IPOD and MSD
 *
 * 2-Dec-2011 Oscar Vega  Rev 4
 * SCR kok_basa#16243 : Implement MSID(16h) - File System Services.
 * Implement File System Services
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_FILESYS_SERVICES_H */
