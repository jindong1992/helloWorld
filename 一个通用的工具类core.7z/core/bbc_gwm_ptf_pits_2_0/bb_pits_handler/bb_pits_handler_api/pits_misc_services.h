#ifndef PITS_MISC_SERVICES_H
#   define PITS_MISC_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_misc_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_misc_services.h~4:incl:ctc_ec#23 %
 * @version %version:4 %
 * @author  %derived_by:vj430z %
 * @date    %date_modified:Mon Apr  3 20:04:27 2017 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_misc_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"


/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum PITS_User_Input_Tag
{
   PITS_INPUT_OPEN              = 0x00,
   PITS_INPUT_NEXT              = 0x01,
   PITS_INPUT_PREVIOUS          = 0x02,
   PITS_INPUT_BAND              = 0x03,
   PITS_INPUT_SOURCE            = 0x04,
   PITS_INPUT_TUNE_UP           = 0x05,
   PITS_INPUT_CA_EJECT          = 0x06,
   PITS_INPUT_CD_EJECT          = 0x07,
   PITS_INPUT_POWER_OFF         = 0x08,
   PITS_INPUT_POWER_ON          = 0x09,
   PITS_INPUT_PROG              = 0x0A,
   PITS_INPUT_ICDX_SINGLE_LOAD  = 0x0B,
   PITS_INPUT_ICDX_SINGLE_EJECT = 0x0C,
   PITS_INPUT_ICDX_MULTI_LOAD   = 0x0D,
   PITS_INPUT_ICDX_MULTI_EJECT  = 0x0E,
} PITS_User_Input_T;

typedef enum VIP_GPIO_SET_PIN_Tag
{
   DVD_EN = 0,
   DISP_REMOTE_EN,
   REAR_DVD_REMOTE_EN,
}VIP_GPIO_PIN_T;

typedef struct VIP_GPIO_PINS_ITEM_Tag
{
   VIP_GPIO_PIN_T pin;
   SIP_VIP_Ports_Enum_T port;
   uint8_t  mask_code;
}VIP_GPIO_PINS_ITEM_T;

typedef enum VIP_DIP_PIN_Tag
{
   REVERSE  = 0,
   ILL      = 1,
   ACC      = 2,
   P7_5     = 3,
   P7_6     = 4,
   P7_7     = 5
}VIP_DIP_PIN_T;

typedef struct VIP_DIP_PIN_ITEM_Tag
{
   VIP_DIP_PIN_T pin;
   SIP_VIP_Ports_Enum_T port;
   uint8_t  mask_code;
}VIP_DIP_PIN_ITEM_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Misc_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

extern void PITS_Misc_Clear_Overrides(void);


/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_Misc_Clear_Override_Controls_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Exit_Diagnostics_Mode_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Enter_Sleep_Mode_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Module_Reset_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Radio_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Radio_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_AD_Ports(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_IO_Ports(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_ClkOut_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_ClkOut_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Standardized_Input_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Standardized_Input_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Test_Flags_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Test_Flags_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Remote_Enable_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Remote_Enable_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Amp_Control_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Amp_Control_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_RTD_Checksum_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_SWID_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Part_Number_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_VIN_Number_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_VIN_Number_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Remote_Enable_Diag_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Rear_Display_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Rear_Bright_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Rearaux_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Headphone_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Headphone_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Di_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Do_Status_Req(const PITS_Message_T * message);
/* extern Done_Or_Not_Done_T PITS_Misc_Get_Microphone_AD_Value_Req (const PITS_Message_T * message); */
extern Done_Or_Not_Done_T PITS_Misc_Set_Power_Antenna (const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Power_Antenna (const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Rtd_AD_Temp_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_DVD_Status_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_DVD_Status_Req(const PITS_Message_T * message);
/* extern Done_Or_Not_Done_T PITS_Misc_Get_Ir_Touchscreen_Key_Req(const PITS_Message_T * message);   */
#if 0
extern Done_Or_Not_Done_T PITS_Misc_Get_Func_Cfg_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Func_Cfg_Req(const PITS_Message_T * message);
#endif

#if defined(GWM_CHK041_8AT)||defined(GWM_CHK011_8AT)
extern Done_Or_Not_Done_T PITS_Misc_Get_VIP_Key_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Key_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Knob_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Set_Knob_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Knob_Test_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_RSE_Ctrl_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Coordinate_Req(const PITS_Message_T * message);
#endif

void PITS_Get_Key_Pressed(const uint8_t * data, size_t length);

#ifdef PITS_CCR_IS
extern Done_Or_Not_Done_T PITS_Misc_Set_Sw_Setting_Req (const PITS_Message_T * message);
#endif

extern Done_Or_Not_Done_T PITS_Misc_Get_Rtc_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Misc_Get_Dip_Status_Req(const PITS_Message_T * message);

extern Done_Or_Not_Done_T PITS_Misc_Get_Board_Type_Req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_misc_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 03Apr2017  Sunil G (vj430z) Rev. 4
 * ctc_ec#180296: Implement Get Board type status command for PITS.
 *
 * 09Jan2017  Mandar Bhat (tzl4my) Rev. 3
 * ctc_ec#172934: Vehicle Configuration's Read and Write Parameter for PITS.
 *
 * 20June2016 Rahul Chirayil (vzm576) - Rev 2
 * ctc_ec#156521: Update Get Discrete Input Status service (1A F8) for Board type verification.
 *
 * 05-Sept-2012 Oscar Vega 16
 * Taks kok_basa#117698 - 2_0 - Request/Report Read A/D and I/O Ports
 *
 *  06-Sep-2012 Darinka L�pez Rev 15
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 31-Aug-2012 Darinka Lopez 14
 * Taks kok_basa#116889 - Change MID 30/32 - Set standarized Input
 *
 * 7-Aug-2012 Oscar Vega Rev 13
 * Task kok_basa#113317: 2_0 - Request/Report  Get Power Antenna
 *
 * 17-Jul-2012 Hernan Gegenschatz 12
 * kok_basa#109058: Add PITS message to get/set Sw_Setting MPI variable (GMB-ICR)
 *
 * 5-Jun-2012 Marco Castillo Rev 11
 * Task kok_basa#100215: mdf_2_0: Microphone AD Value 1A92/93
 *
 * 30-May-2012 Marco Castillo  Rev 10
 * Task kok_basa#100232:  Request Microphone Status 1A90/91
 *
 * 29-May-2012 Juan Carlos Castillo  Rev 9
 * Task kok_basa#99843: CLKOUT pin enable/disable PIT
 *
 * 1-May-2012 Darinka Lopez  Rev 8
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 11 Apr 2012 Miguel Garcia Rev 7
 * Include Set Radio Status Diag
 *
 * 25-Jan-2012 Erick Sanchez Rev 6
 * SCR kok_basa#19539: PITS: MSID 1A - MID 12 - Exit Diagnostics Mode
 * Fix: Implement PITS (MSID 1A - MID 12) to Exit Diagnostics Mode
 *
 * 19-Jan-2012 Oscar Vega  Rev 5
 * SCR kok_basa#19539: PITS: MSID 1A - MID 16 - Module Reset (cold start)
 * SCR kok_basa#19537: PITS: MSID 1A - MID 14 -  Enter Sleep Mode
 * Fix: Implement desip messages to reset and enter sleep mode.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 *
 * 10-Sept-2009 David Mooar  Rev 1
 * SCR kok_aud#62401/62406/62439/62488: Implement Misc Services.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_MISC_SERVICES_H */
