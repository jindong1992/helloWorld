#ifndef PITS_COMMON_TYPES_H
#   define PITS_COMMON_TYPES_H
/*===========================================================================*/
/**
 * @file pits_common_types.h
 *
 * PITS common types definitions.
 *
 * %full_filespec:pits_common_types.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:34 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the pits common types data.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_platform_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
/* Bus ID used to broadcast message to all available busses. */
#   define PITS_BROADCAST ((uint8_t)255)
/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

typedef enum
{
   NOT_DONE = 0,                /* State machine has not completed execution */
   DONE                         /* State machine has completed execution */
} Done_Or_Not_Done_T;

typedef enum
{
   FAIL                  = 0,    /* Called routine failed to execute     */
   SUCCESS               = 1,    /* Called routine executed successfully */
   COMMAND_NOT_SUPPORTED = 2,    /* Called routine is not supported      */
   DATA_OUT_OF_RANGE     = 4,    /* Called routine data is out of range  */
   DATA_NOT_WRITEABLE    = 8     /* Called routine data is not writeable */
} Success_Or_Fail_T;

typedef struct PITS_Message_Tag
{
   uint8_t bus;                 /* Bus the message belongs to */
   uint8_t MSID;                /* Message Set Id of the message */
   uint8_t MID;                 /* Message ID of the message */
   uint16_t data_size;          /* Number of bytes in the PITS message */
   uint8_t *data;               /* pointer to the PITs message data */
} PITS_Message_T;

/**
 * Data definition for published event PITS EVG_xxx_SESSION 
 *    CLOSE
 *    PREOPEN
 *    OPEN
 */
typedef enum PITS_EVG_SESSION_Tag
{
   SESSION_CLOSE     = 0,
   SESSION_PREOPEN   = 1,
   SESSION_OPEN      = 2,
   SESSION_MAX       = 3
} PITS_EVG_SESSION_T;


/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_common_types.h
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 8
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 1-May-2012 Darinka Lopez  Rev 7
 * Task kok_basa#93346 - Fix sal_publish/sal_send messages, update files for SBX program
 * Update module for SBX program (modular changes). Fix sizeof of  Sal_Publish/ Sal_Send messages
 *
 * 07 Mar 2012 Miguel Garcia
 * Include Mac address structure
 *
 * 22 Nov 2011 Miguel Garcia
 * Include daytrim structure
 *
 * 10-Sept-2009 David Mooar  Rev 2
 * SCR kok_aud#62353: Change Success_Or_Fail_T per the new spec.
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-01  Larry Ong
 *    - Added Success_Or_Fail type.
 *
 * - 2007-06-01  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-08 Mike Gerig/Kris Boultbee
 *    - Created initial file.
 *
 *===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_COMMON_TYPES_H */
