#ifndef PITS_APPLICATION_MANAGER_H
#   define PITS_APPLICATION_MANAGER_H
/*===========================================================================*/
/**
 * @file pits_application_manager.h
 *
 * API for PITS_Application Manager.
 *
 * %full_filespec:pits_application_manager.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:10 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module is responsible for routing received PITS messages to any and 
 *    all PITS application modules which implement the MSID/MID contained in
 *    the PITS message. In order to accomplish this task, this module will 
 *    search through all registered PITS application interfaces for a matching
 *    MSID/MID pair. For each match that is found, the message will be passed to
 *    the function provided by that PITS application interface.
 *
 *    This module is also responsible for allowing the state machine of each 
 *    PITS application to run. If a PITS application is unable to fully complete
 *    all necessary actions upon first receiving a message, the state machine for
 *    that PITS application will be placed into queue to be re executed later. Once
 *    the PITS application has finished all necessary actions, it will be removed
 *    from the queue.
 *    
 *    This module also handles transmission of PITS messages from a PITS application
 *    to the PITS Message Handler. (Future improvement) If the PITS message is 
 *    unable to be transmitted at this time for any reason, it will be placed into
 *    queue for a later attempt at transmission.
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @defgroup PITS_grp PITS group
 * @{
 */
/*===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_common_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#   define MAX_MSID_NAME (20)

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Application API types
 *===========================================================================*/
typedef void (*PITS_Init_Fptr) (void);

typedef Done_Or_Not_Done_T(*recv_func) (const PITS_Message_T *data);

typedef struct PITS_MID_Tag
{
   uint8_t MID;                     /**< Receive Message ID */
   recv_func rx_state_machine;      /**< Receive function to handle the message */
} PITS_MID_T;

typedef struct PITS_MSID_Tag
{
   uint8_t MSID;                    /**< Receive Message Set ID */
   char_t MSID_Name[MAX_MSID_NAME]; /**< Message Set ID String Name */
   const PITS_MID_T *message_ids;   /**< Pointer to an array of Receive Message IDs in the Message Set */
   uint8_t message_count;           /**< Number of receive message IDs supported in the Message Set */
} PITS_MSID_T;

typedef struct PITS_TX_MSID_Tag
{
   uint8_t MSID;                    /**< Transmit Message Set ID */
   const uint8_t *MID;              /**< Pointer to an array of Transmit Message IDs in the Message Set */
   uint8_t message_count;           /**< Number of transmit message IDs supported in the Message Set */
} PITS_TX_MSID_T;

typedef struct PITS_Application_Interface_Tag
{
   PITS_Init_Fptr initialize;            	/**< pointer to function to initialize the application */
   const PITS_MSID_T *rx_message_sets;		/**< pointer to an array of Receive Message Sets supported by the application */
   uint8_t rx_message_set_count;    		/**< Number of receive message sets supported by the application */
   const PITS_TX_MSID_T *tx_message_sets;	/**< pointer to an array of Transmit Message Sets supported by the application */
   uint8_t tx_message_set_count;    		/**< Number of transmit message sets supported by the application */
} PITS_Application_Interface_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*/
/**
 * Application API Function Prototypes
 *
 * @brief Moves a PITS message to be transmitted from the Application to the 
 * Message Handler.
 *
 * @returns 
 *    Boolean indicating success or failure of transmission
 *      --> true - PITS message transmitted successfully.
 *      --> false - PITS messages not transmitted.
 *
 * @param *message
 *   PITS message to be transmitted
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * This function passes the message to be transmitted to the PITS Message Handler
 * layer.
 */
/*===========================================================================*/
extern bool_t PITS_Send_Message(const PITS_Message_T * message);

/*===========================================================================*/
/**
 * Message Handler API Function Prototypes
 *
 * @brief Routes the received message to all applications that support it.
 *
 * @returns 
 *    nothing
 *
 * @param *message
 *   Pointer to a received message to be routed to application(s).
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * This function will determine what applications support the passed in message
 * and pass the pointer to the message to every application that supports it. 
 */
/*===========================================================================*/
extern void PITS_Route_Receive_Message(PITS_Message_T * message);

/*===========================================================================*/
/**
 * Configuration API Function Prototypes
 *
 * @brief Sets up the receive routing for all applications.
 *
 * @returns 
 *    nothing
 *
 * @param *record[]
 *   This is a pointer to the structure that contains the interfaces for all
 *   the PITS applications supported by this system
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * @param count
 *   Number of applications supported by this system.
 *
 * @pre
 *   none
 *
 * @post
 *   none
 *
 * Here are some more details about the API definition for the function. It should 
 * cover WHAT the function does and not HOW it does it.
 */
/*===========================================================================*/
extern void PITS_Configure_Receive_Routing(PITS_Application_Interface_T * record[], uint8_t count);

/*===========================================================================*/
/**
 * Periodic Application State Machine Function Prototypes
 *
 * @brief Handles the execution of all PITS Application state machines that have not
 * yet completed.
 *
 * @returns 
 *    nothing
 *
 * This function will execute the next unfinished receive state machine. If this 
 * state machine completes, it will be removed from the queue to not be executed 
 * again. If it does not complete, it will be placed back into the end of the 
 * queue.
 */
/*===========================================================================*/
extern void PITS_Application_Manager(void);

/*===========================================================================*
 * FUNCTION: PITS_Response_Command_No_Supported
 *===========================================================================*
 * @brief Receive any request of MID not supported yet (no implemented)
 *
 * @returns
 *    DONE = Message successfully sent
 *    NOT_DONE = Message was not sent yet, keeps state machine active
 *
 * @param [in] message = Pointer to the received PITS message
 * @param [in] (message->data)[0] = Does not matter.
 * @param [out] pbs_tx_data[0] = confirmation (COMMAND_NO_SUPPORTED)
 *
 * @pre message->data_size = 1
 *
 * @post
 *
 */
/*===========================================================================*/
extern Done_Or_Not_Done_T PITS_Response_Command_No_Supported(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_application_manager.h
 *
 * @section  RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 18-august-2009 David Mooar  Rev 2
 *   SCR kok_aud#62242: Create PITS_Init_Fptr to use instead of void_fptr, to
 *   avoid warnings. 
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up todo comments.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-06-07  Larry Ong
 *    - Adapted for BASA.
 *
 * - 2007-02-08 Mike Gerig/Kris Boultbee
 *    - Created initial file.
 *
 *===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_APPLICATION_MANAGER_H */
