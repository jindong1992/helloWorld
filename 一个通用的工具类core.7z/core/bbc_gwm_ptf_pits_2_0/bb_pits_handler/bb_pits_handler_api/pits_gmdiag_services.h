#ifndef PITS_GMDIAG_SERVICES_H
#   define PITS_GMDIAG_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_gmdiag_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_gmdiag_services.h~1:incl:ctc_ec#8 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:54 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_gmdiag_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  
#include "preset_mgr.h"
#include "preset_mgr_cbk.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_GMdiag_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void Pits_Get_Elapsed_Time (const uint8_t * data, size_t length);

extern void PITS_Get_App_SWID (void);

extern void Pits_Get_SWC_Time (const uint8_t * data, uint16_t length);

extern void Send_APP_SWID_To_Vip_Start (void);

extern void Pits_Get_Server_Data (const uint8_t * data, size_t length);

extern void Pits_Preset_Update_HMI_Display_Info2(preset_mgr_zone_t zone, uint8_t page_number);

extern void Pits_Preset_Update_HMI_Highlights2(preset_mgr_zone_t zone);

extern void Pits_Get_BT_Connected_Status (const uint8_t * data, size_t length);

extern uint8_t Pits_Return_BT_Connected_Status (void);

extern void Pits_Get_Hands_Call_Status (const uint8_t * data, size_t length);

extern void Pits_Get_Btaudio_Stream_Status (const uint8_t * data, size_t length);

extern void Pits_Get_Bt_Operations_Status (const uint8_t * data, size_t length);

extern uint8_t Pits_Get_Diag_Btprofile_stream (void);

extern void Pits_Ptt_Pressed_Voice (const uint8_t * data, size_t lenght);

extern void Pits_Ptt_Ended_Voice (const uint8_t * data, size_t lenght);

extern uint8_t Pits_Get_AM_Freq_Step (void);

extern uint8_t Pits_Get_FM_Freq_Step (void);

extern uint32_t Pits_Get_FM_Freq_Low (void);

extern uint32_t Pits_Get_AM_Freq_Low (void);

extern void Pits_Set_Gmdiag_Quality (uint8_t quality);

extern void PITS_Set_Engineering_Menu (uint8_t menu_output);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID02_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID04_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID07_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID08_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID09_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID10_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID11_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID14_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID15_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID16_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DPID17_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_CPID3_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel0_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel1_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel2_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Limits_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Cancel4_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_Source_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_Cancel_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID90_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_DID90_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID53_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_DID53_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID53X_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_DID53X_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Test_Dpid08_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Preset_Default_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_DYN_PID_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DYN_PID_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_First_Tones_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID17_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_App_Swid_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_Cpid1a_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_Cpid2a_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Set_Audio_Source_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Oats_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Srdl_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Param_Test_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE1_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE2_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE3_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE4_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE5_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE6_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE7_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE8_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDE9_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_DIDEA_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Gmdiag_Cpid5_Screen_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID0B_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID0C_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID0D_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_DID0E_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC430_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC431_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC433_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC434_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC435_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_volume_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_fade_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_balance_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_mute_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_tone_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_band_and_freq_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_Set_Remote_Enable_Diag_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_power_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_get_power_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_set_source_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_get_ps_mfg_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC753_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC751_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_GMdiag_Get_PIDC754_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_get_did_xm_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_put_did_xm_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_GMdiag_get_pwtwo_diag_req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_gmdiag_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 18
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 15 Aug 2012 Miguel Garcia
 * Include pits gmdiag quality
 *
 * 13 Aug 2012 Miguel Garcia
 * Include pits calls for different regions in dpid2 and dpid10
 *
 * 23 May 2012 Miguel Garcia
 * Include get pwtwo diag
 *
 * 21-Mar-2012 Darinka Lopez  Rev 13
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 27 Feb 2012 Miguel Garcia
 * Include bt diagnostics
 *
 * 27 Jan 2012 Miguel Garcia
 * Include PIDS functions
 *
 * 14-Dec-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 6
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 18 Jun 2011 Miguel Garcia
 * Include send app swid to vip function
 *
 * 15 Jun 2011 Miguel Garcia
 * Use Safe_Strncpy
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_GMDIAG_SERVICES_H */
