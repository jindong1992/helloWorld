#ifndef PITS_PROGRAMMING_SERVICES_H
#   define PITS_PROGRAMMING_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_programming_services.h
 *
 * API for PITS_programming_services.c.
 *
 * %full_filespec:pits_programming_services.h~1:incl:ctc_ec#23 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:53 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the PITS Programming Service Messages used in the project. 
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy
 *    - MSID: Message Set Identifier
 *    - MID: Message Identifier
 *    - PPS: PITS Programming Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  
#include "pits_parameter_list_cfg.h"
#include "preset_mgr_friend.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Type Declarations
 *===========================================================================*/
 /**
 * Memory Access definition
 */
typedef enum PPS_Access_Tag
{
   ACCESS_READ       = 0,
   ACCESS_READ_WRITE,
   PPS_ACCESS_NUM
} PPS_Access_T;

/**
 * Read/Write Status definition
 */
typedef enum PPS_Param_Status_Tag
{
   PARAM_SUCCESS       = 1,
   PARAM_LEN_ERROR,
   PARAM_READ,
   PARAM_UNABLE_WRITE,
   PARAM_NO_LIST_EXIST,
   PARAM_NO_ID_EXIST,   
   PARAM_MAX_NUM
} PPS_Param_Status_T;

/*===========================================================================*
 *
 * The only thing exposed by an application to the outside world is it's interface
 * This is defined in the Applications C file and is used by the Configuration 
 * and then the PITS Application Manager. This interface contains a number of
 * PITS Message Sets. This interface is of type PITS_Application_Interface_T
 *
 * An application could expose two or more interfaces if desired
 *
 * @todo make this const
 */
/*===========================================================================*/
extern PITS_Application_Interface_T PITS_PPS_Interface;
/*extern SIP_GWM_DID_SYNC_T did_sync_data;*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Download_Memory_Map_Check
 *===========================================================================*
 * @brief Check Download Memory Address is within valid range
 *
 * @param [in] address = Start Address to check
 * @param [in] length = Memory block size
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_Download_Memory_Map_Check(uint32_t start_address, size_t length);

/*===========================================================================*
 * FUNCTION: PITS_Create_PPS_Timer
 *===========================================================================*
 * @brief Create PITS Programming Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_PPS_Timer(void);
/*===========================================================================*
 * FUNCTION: PITS_Destroy_PPS_Timer
 *===========================================================================*
 * @brief Destroy PITS Programming Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_PPS_Timer(void);
/*===========================================================================*
 * FUNCTION: PITS_Check_PPS_Timer
 *===========================================================================*
 * @brief Check for PPS Session Timeout
 *
 * @returns
 *    false = If Event is a not PPS Session Timeout
 *    true = If Event is a PPS Session Timeout
 *
 * @param [in] event_id = ID of private event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_PPS_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Set_PPS_Session
 *===========================================================================*
 * @brief Setter Function for the PPS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * PREOPEN: Session State = PreOpen, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 *
 * PreOpen may be required in advance of Open() to handle cases where the device
 *  needs to jump from one piece of software supporting PITS (e.g. host application
 *  code) to another (e.g. bootloader) prior to opening the programming session
 */
/*===========================================================================*/
extern bool_t PITS_Set_PPS_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_PPS_Session_State
 *===========================================================================*
 * @brief Getter function for PPS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_PREOPEN
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_PPS_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_PPS_Send_Session_State
 *===========================================================================*
 * @brief Function to send PPS Session State
 *
 * @returns
 *    false - Request is not for PPS Session
 *    true - Request is for PPS Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PPS_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PPS_Session_State
 *===========================================================================*
 * @brief Getter functions for XSAL published PCS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_PREOPEN
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_PPS_Session_State(void);

uint16_t Pits_Get_Param_Band_Value_Mpi (uint8_t zone, uint8_t page, uint8_t preset);

void Preset_Prog_PS_Put_Preset_Data (Tuner_Info_T tuner_info,
                                    preset_mgr_zone_num_type zone_index,
                                    preset_mgr_page_num_type page_index,
                                    preset_mgr_preset_num_type preset_index);

/*===========================================================================*
 * FUNCTION: PITS_Clear_PPS_Timer
 *===========================================================================*
 * @brief Clear PITS Programming Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Clear_PPS_Timer_Session(void);

extern void Pits_Get_Random_Shuffle (const uint8_t * data, size_t length);

extern void Pits_Get_Paired_Data_Info (const uint8_t * data, size_t length);

extern uint16_t Pits_Get_Diag_Btdevices_Number (void);

extern void Pits_Get_Diag_Btconnected_Address (uint8_t *new_address);

extern void Pits_Get_Diag_Btconnected_Name (uint8_t *new_name);

extern void Pits_Get_Diag_Btconnected_Profile (uint8_t *new_profile);

extern void Pits_Get_Diag_Bt_Address_Paired (uint8_t list_data, uint8_t *new_address);

extern uint8_t Pits_Get_Reflash_Status (void);

extern void Pits_Set_Reflash_Process (void);

extern void Pits_Calculate_MD_Chksum_Value (uint8_t md_value, uint32_t md_block);
extern uint8_t Pits_Get_MD_Calc_Status (uint8_t md_value);
extern void Pits_Get_MD_Calc_Result(uint8_t md_value, uint8_t *md_result);
/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_pps_session_get_state_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_preopen_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_open_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_close_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_data_checksum_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_refresh_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_get_timeout_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_session_set_timeout_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_CarDSP_write_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_CarDSP_read_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_param_write_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_ECU_read_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_ECU_write_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PPS_Param_Write_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_partition_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_md5_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_partition_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_autentification_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_load_defaults_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_eng_menus_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_send_micdtc_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_send_usbdtc_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_send_usbtest_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_send_usbset_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_set_reflash_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_test_usbset_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_mpi_checksums_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_network_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_send_usbset9_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_receive_chksum_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_rec_chksum_last_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_jump_to_bootloader_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_get_set_FCID_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_read_partial_param_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_calc_md_five_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_get_calc_md_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pps_manifest_version_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_PPS_Param_Read_Req(const PITS_Message_T * message);

/**
 * PITS_Get_Enable_Write_Status - Enable to write.
 *
 * @param partition
 *
 * @return  enable status
 */
bool PITS_Enable_to_Write_Partition(uint8_t partition);

/*===========================================================================*/
/*!
 * @file pits_programming_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 20-Jun-2014 Tim Wang
 * Include Checksum functions
 *
 * - 11-Sep-2012  Jorge Rodriguez
 *   kok_basa#31658 - PIT 10/60 implemented to read/write manifest version.
 *
 * 10-Sep-2012 Carolina Tovar (WZRJ41) - Rev 23
 * kok_basa#30935: Implement PITS to read/write FCID PITS 10h 14h and Status 10h 15h
 *
 * 10-Sep-2012 Carolina Tovar (WZRJ41) - Rev 22
 * kok_basa#30933: Implement PITS 10 12 Request Jump to FBL and 10h 13h status.
 *
 *  06-Sep-2012 Darinka L�pez Rev 21
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 23 Aug 2012 Miguel Garcia
 * Task kok_basa#115934 - Fix Pits Timers
 *
 * 16 Aug 2012 Miguel Garcia
 * Include MD5 calc checksums
 *
 * 26 Jul 2012 Miguel Garcia
 * Include CRC32 Checksum functions
 *
 * 11 Jun 2012 Miguel Garcia
 * Includ mpi checksums and network functions
 *
 * 23 May 2012 Miguel Garcia
 * Include reflash functions
 *
 * 18 May 2012 Miguel Garcia
 * Include pit for reflash
 *
 * 11 May 2012 Miguel Garcia Rev 14
 * Include Diag_Bt_Address_Paired
 *
 * 21-Mar-2012 Darinka Lopez  Rev 13
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 07 Mar 2012 Miguel Garcia Rev 9
 * Include usbtests services
 *
 * 27 Feb 2012 Miguel Garcia Rev 8
 * Include bt diagnostics
 *
 * 24 Feb 2012 Miguel Garcia Rev 7
 * Include pits send mic dtcs
 *
 * 27 Jan 2012 Miguel Garcia Rev 6
 * Include BT functions calls
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Change code to be BASA2.0 compatible.
 *
 * - 2008-06-30  Larry Ong
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 * - 2008-06-10  Larry Ong
 *    - Moved MID definitions to pits_programming_services_cfg file.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-07-05  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_PROGRAMMING_SERVICES_H */
