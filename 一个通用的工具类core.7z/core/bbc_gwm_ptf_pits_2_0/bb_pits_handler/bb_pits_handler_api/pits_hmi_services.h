#ifndef PITS_HMI_SERVICES_H
#   define PITS_HMI_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_hmi_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_hmi_services.h~1:incl:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:58 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_hmi_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  
#include "pits_hmi_services_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_HMI_Services_Interface;
/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern bool_t PITS_HMI_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Set_HMI_Session
 *===========================================================================*
 * @brief Setter Function for the PCS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_HMI_Session(const PITS_EVG_SESSION_T session);


/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_hmi_get_band_and_freq_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_HD_audio_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_HD_available_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_number_of_fav_pages_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_current_highlighted_preset_number_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_current_fav_page_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_XM_category_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_volume_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_fade_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_balance_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_ATC_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_SCV_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_tone_settings_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_primary_src_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_CD_load_type_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_CD_media_type_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_CD_file_type_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_USB_file_type_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_clock_data_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_hmi_get_view_id_req(const PITS_Message_T * message);


/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/



/*===========================================================================*/
/*!
 * @file pits_hmi_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 5
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 17-feb-2010 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_HMI_SERVICES_H */

