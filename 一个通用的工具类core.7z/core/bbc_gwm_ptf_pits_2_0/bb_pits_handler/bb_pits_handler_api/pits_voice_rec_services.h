#ifndef PITS_VOICE_REC_SERVICES_H
#   define PITS_VOICE_REC_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_voice_rec_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_voice_rec_services.h~1:incl:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:06:12 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_RearCamera_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Voice_Services_Interface;

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_voice_start_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_start_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_end_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_end_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_timeout_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_timeout_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_confidence_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_confidence_detection_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_snr_settings_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_snr_settings_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_grammar_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_grammar_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_pause_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_pause_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_lastvr_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_lastvr_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_lastnav_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_lastnav_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_bestrate_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_bestrate_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_jumpback_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_jumpback_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_flush_jumpback_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_srdl_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_srdl_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_score_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_score_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_persistence_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_voice_set_persistence_req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_voice_rec_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 4
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_VOICE_REC_SERVICES_H */
