#ifndef PITS_BT_SERVICES_H
#   define PITS_BT_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_bt_services.h
 *
 * @pits bt_service header file
 *
 * %full_filespec:pits_bt_services.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:22 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup PITS_BT_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_BT_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/*===========================================================================*
 * FUNCTION: PITS_Set_BT_Session
 *===========================================================================*
 * Setter Function for the Bluetooth Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_BT_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_BT_Session
 *===========================================================================*
 *   Getter function for Bluetooth Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_BT_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_Create_BT_Timer
 *===========================================================================*
 *   Create PITS Bluetooth Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_BT_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_BT_Timer
 *===========================================================================*
 * Destroy PITS Bluetooth Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_BT_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_BT_Timer
 *===========================================================================*
 *   Check for Bluetooth Session Timeout
 *
 * @returns
 *    false = If Event is not a Bluetooth Session Timeout
 *    true = If Event is a Bluetooth Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_BT_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_BT_Send_Session_State
 *===========================================================================*
 *   Function to send Bluetooth Session State
 *
 * @returns
 *    false - Request is not for Bluetooth Session
 *    true - Request is for Bluetooth Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_BT_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_BT_Session_State
 *===========================================================================*
 *   Getter functions for published Bluetooth Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_BT_Session_State(void);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
#if PITS_BLUETOOTH_IS
extern Done_Or_Not_Done_T pits_bt_test_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_btaddress_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_connected_dev_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_name_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_btaddress_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_pairing_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_pairing_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_discover_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_discover_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_connectability_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_connectability_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_echo_cancel_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_echo_cancel_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_profile_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_profile_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_disconnect_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_conname_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_name_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_signal_strength_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_setup_coexistence_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_paired_num_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_ps_key_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_ps_key_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_bccmd_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_bccmd_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_reset_chip_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_align_cal_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_align_cal_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_reset_echo_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_clear_paired_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_btloop_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_set_btloop_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_clear_all_devices_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_bt_get_all_devices_req(const PITS_Message_T * message);
#endif /* BLUETOOTH_IS */

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_bt_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  
 * 30-Jun-2014 Tim Wang
 * Added Destroy PITS Bluetooth Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 12
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 17 May 2012 Miguel Garcia REV 11
 * Include clear all devices from vip
 *
 * 27 Apr 2012 Miguel Garcia Rev 10
 * Include loop get and set
 *
 * 24 Apr 2012 Miguel Garcia Rev 9
 * Include clear all paired devices from list
 *
 * 14-Mar-2012 Oscar Vega  Rev 8
 * SCR task_kok_basa#82989 : Add bluetooth services handler in SBX program
 *
 * 27 Feb 2012 Miguel Garcia Rev 7
 * Include missing bt pits functions
 *
 * 5-Jan-2012 Darinka Lopez  Rev 6
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_BT_SERVICES_H */
