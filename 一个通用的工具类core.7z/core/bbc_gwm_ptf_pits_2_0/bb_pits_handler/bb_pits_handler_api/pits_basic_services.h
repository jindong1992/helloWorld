#ifndef PITS_BASIC_SERVICES_H
#   define PITS_BASIC_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_basic_services.h
 *
 * API for PITS_basic_services.c.
 *
 * %full_filespec:pits_basic_services.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:19 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *    This module defines the PITS Basic Service Messages used in the project. 
 *
 * @section ABBR ABBREVIATIONS:
 *   - PITS - Product Integrated Test Strategy.
 *   - MSID - Message Set Identifier
 *   - MID - Message Identifier
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  
#include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 *
 * The only thing exposed by an application to the outside world is it's interface
 * This is defined in the Applications C file and is used by the Configuration 
 * and then the PITS Application Manager. This interface contains a number of
 * PITS Message Sets. This interface is of type PITS_Application_Interface_T
 *
 * An application could expose two or more interfaces if desired
 *
 * @todo make this const
 */
/*===========================================================================*/
extern PITS_Application_Interface_T PITS_PBS_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_PBS_Error_Report
 *===========================================================================*
 * @brief Receive a Request to Report PBS Status
 *
 * @returns
 *    true = Status Report transmitted successfully
 *    false = Status Report was not transmitted
 *
 * @param [in] message = Pointer to the string array for the error information
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PBS_Error_Report(const char_t * message);

/*===========================================================================*
 * FUNCTION: PITS_PBS_Error_Report
 *===========================================================================*
 * @brief Receive a Request to Report PBS Error
 *
 * @returns
 *    true = Error Report transmitted successfully
 *    false = Error Report was not transmitted
 *
 * @param [in] message = Pointer to the string array for the status information
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PBS_Status_Report(const char_t * message);

/*===========================================================================*
 * FUNCTION: PITS_Create_PBS_Timer
 *===========================================================================*
 * @brief Create PITS Diagnostic Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_PBS_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_PBS_Timer
 *===========================================================================*
 * @brief Destroy PITS Diagnostic Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_PBS_Timer (void);

/*===========================================================================*
 * FUNCTION: PITS_Check_PBS_Timer
 *===========================================================================*
 * @brief Check for PBS Session Timeout
 *
 * @returns
 *    false = If Event is a not PBS Session Timeout
 *    true = If Event is a PBS Session Timeout
 *
 * @param [in] event_id = ID of the private event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_PBS_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Set_PBS_Session
 *===========================================================================*
 * @brief Setter Function for the PCS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_PBS_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_PBS_Session_State
 *===========================================================================*
 * @brief Getter function for PCS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_PBS_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_PBS_Send_Session_State
 *===========================================================================*
 * @brief Function to send PBS Session State
 *
 * @returns
 *    false - Request is not for PBS Session
 *    true - Request is for PBS Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PBS_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_PBS_Session_State
 *===========================================================================*
 * @brief Getter functions for published PCS Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_PBS_Session_State(void);

/*===========================================================================*
 * FUNCTION: PITS_PBS_Session_Is_Closed 
 *===========================================================================*
 * @brief Getter functions for PCS Session States for Diagnostic Session
 *
 * @returns
 *    false - session is opened
 *    true - session is closed
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_PBS_Session_Is_Closed(void);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_PBS_Message_Set_Id_Supported_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_size_packet_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_size_message_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_message_set_name_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_message_id_supported_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_message_set_bit_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_pbs_message_id_bit_req(const PITS_Message_T * message);

/*===========================================================================*/
/*!
 * @file pits_basic_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Diagnostic Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 7
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 11-Apr-2012 Darinka Lopez  Rev 6
 * Task kok_basa#89011 - Implement Basic Services (MIDs 00, 02 and 08).
 * Fix basic services function to acomplish with PDD requirements.
 * Fix status report message similar to Error report message.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 11-Nov-2008 Yi Liu
 * + SCR 57706 - Clean up compile warning for mdf_pits_2_0.
 *
 * - 2008-06-30  Larry Ong
 *    - Added Diagnostic Session in PBS as a master session, and allow other
 *      services in Diagnostic Session.
 *    - Added ability to change session timeout
 *    - Used X-macro to define the Private and Gobal Event declaration and move
 *      processing of these events to the individual PITS Service block.
 *
 *
 * - 2008-05-20  Larry Ong
 *    - Moved MID definitions to pits_basic_services_cfg file.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS SOH Services, MSID = 5.
 *    - Redefined DTC as SOH Services.
 *    - Removed Session from Basic Services. 
 *
 * - 2007-12-14  Larry Ong
 *    - Added DTC Ignition Counter
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-11-26  Larry Ong
 *    - Add DTC messages
 *    - Used PITS_EVG_SESSION_T for PBS, PPS & PCS session
 *
 * - 2007-10-31  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-06-01  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_BASIC_SERVICES_H */
