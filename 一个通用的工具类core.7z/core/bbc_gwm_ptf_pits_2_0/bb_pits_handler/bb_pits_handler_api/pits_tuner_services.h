#ifndef PITS_TUNER_SERVICES_H
#   define PITS_TUNER_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_tuner_services.h
 *
 * @header file for pits tuner services.
 *
 * %full_filespec:pits_tuner_services.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:06:07 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_tuner_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Tuner_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

extern void PITS_Tuner_Clear_Overrides(void);

/*===========================================================================*
 * FUNCTION: PITS_Set_Tuner_Session
 *===========================================================================*
 * @brief Setter Function for the PCS Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_Tuner_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_Tuner_Session
 *===========================================================================*
 * @brief Getter function for Tuner Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_Tuner_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_Create_Tuner_Timer
 *===========================================================================*
 * @brief Create PITS Tuner Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_Tuner_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Tuner_Timer
 *===========================================================================*
 * @brief Destroy PITS Tuner Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_Tuner_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_Tuner_Timer
 *===========================================================================*
 * @brief Check for Tuner Session Timeout
 *
 * @returns
 *    false = If Event is not a Tuner Session Timeout
 *    true = If Event is a Tuner Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_Tuner_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Tuner_Send_Session_State
 *===========================================================================*
 * @brief Function to send Tuner Session State
 *
 * @returns
 *    false - Request is not for Tuner Session
 *    true - Request is for Tuner Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Tuner_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Tuner_Session_State
 *===========================================================================*
 * @brief Getter functions for published Tuner Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_Tuner_Session_State(void);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_tuner_get_band_and_freq_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_band_and_freq_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_scan_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_band_and_freq_diag_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_Signal_Strengh_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_User_PI_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_Received_PI_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_User_PTY_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_User_PTY_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_Received_PTY_req(const PITS_Message_T * message);

#if PITS_HD_IS
extern Done_Or_Not_Done_T pits_tuner_get_hd_radio_audio_status_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_hd_radio_get_mode_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_get_hd_radio_set_mode_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_hd_split_mode_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_hd_digital_delay_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_tuner_set_hd_audio_scale_req(const PITS_Message_T * message);
#endif /*PITS_HD_IS*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_tuner_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Tuner Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 15
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 13-Jan-2012 Darinka Lopez  Rev 14
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Fix compilation variable .
 *
 * 05-Jan-2012 Darinka Lopez  Rev 13
 * SCR kok_basa#19966: PITS:  Create new structure for PITS services
 * Move tuner specif fuctions to proccesing_tuner file .
 *
 * 14-Dec-2011 Darinka Lopez  Rev 12
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 11
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * 28 Nov 2011 Miguel Garcia
 * Include changes for tuner porting
 *
 * 07-Nov-2011 Darinka Lopez  Rev 9
 * SCR kok_basa#17610:  Implement TMC Channel in Tuner Services MSID 11
 * Add Channel input in Tuner messages.
 *
 * 03-Nov-2011 Manuel Robledo  Rev 8
 * SCR kok_basa#16238: Implement message for Set Receiver Band and Frequency.
 * SCR kok_basa#17422: Add service ID to Get/set band and frequency PIT
 *
 * 01-Nov-2011 Darinka Lopez  Rev 7
 * SCR kok_basa#17394: Create general function for pits_manager (events)
 * Add X macro for suscribe events.
 *
 * 28-Oct-2011 Manuel Robledo  Rev 6
 * SCR kok_basa#16239: Implement message for Get Receiver Band and Frequency.
 * Implement PITS_Get_Current_Station_Info, PITS_Get_Tuner_Source_Type, PITS_Get_Tuner_Frequency
 * PITS_Get_Tuner_Quality and PITS_Get_Tuner_HD_Subchannel
 *
 * 26-Oct-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#16236: Implement MSID(11h) - Tuner Services
 * Fix: Make Tuner Services common for ICR and SBX projects.
 *
 * 10-Sept-2009 David Mooar  Rev 2
 * SCR kok_aud#62396/62402: Implement PITS Tuner messages.
 *
 * - 12-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_TUNER_SERVICES_H */
