#ifndef PITS_PCS_SERVICES_H
#   define PITS_PCS_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_pcs_services.h
 *
 * API for pits_pcs_services.c.
 *
 * %full_filespec:pits_pcs_services.h~1:incl:ctc_ec#25 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:43 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *    This module defines the PITS Control Services.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy
 *    - MSID: Message Set Identifier
 *    - MID: Message Identifier
 *    - PCS: PITS Control Services.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*==========================================================================*/


/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_application_manager.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

typedef Success_Or_Fail_T(*rx_param) (const PITS_Message_T * rxdata, uint8_t * txdata);

/**
 * PITS Control Services Element ID for Parameter messages
 */
typedef struct PITS_PCS_PAR_EID_Tag
{
   uint8_t EID;                 /* Element ID */
   rx_param rx_par;             /* receive function to handle this element message */
} PITS_PCS_PAR_EID_T;

/**
 * PITS Control Services Group ID for Parameter messages
 */
typedef struct PITS_PCS_PAR_GID_Tag
{
   uint8_t GID;                 			/* Group ID */
   const PITS_PCS_PAR_EID_T *message_ids;	/* pointer to an array of Message IDs in the Message Set */
   uint8_t message_count;       			/* number of message IDs supported in the Message Set */
} PITS_PCS_PAR_GID_T;


extern const PITS_PCS_PAR_GID_T PCS_Param_Message_Sets[];

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_IIC_Read
 *===========================================================================*
 * @brief This function Read IIC data.
 *
 * @param [in] message = Pointer to the received PITS message, containing the IIC read parameters
 * @param [out] txdata = Pointer to the transmit PITS message
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 * Read IIC is accomplished by writing to the IIC device requesting data from
 * a sub-address of the device. The device responses by transmitting the data to
 * the sender.
 *
 *===========================================================================*/
extern Success_Or_Fail_T PITS_IIC_Read(const PITS_Message_T * message, uint8_t * txdata, bool_t *send_message, Done_Or_Not_Done_T *pits_status);

/*===========================================================================*
 * FUNCTION: PITS_IIC_Write
 *===========================================================================*
 * @brief This function Write IIC data.
 *
 * @param [in] message = Pointer to the received PITS message, containing the IIC read parameters
 *
 * @Return
 *    FAILURE: If start and end addresses are outside valid range
 *    SUCCESS: If start and end addresses are within valid range
 *
 * @pre
 *
 * @post
 *
 *===========================================================================*/
extern Success_Or_Fail_T PITS_IIC_Write(const PITS_Message_T * message, bool_t *send_message, Done_Or_Not_Done_T *pits_status);

/*===========================================================================*
 * FUNCTION: PITS_PCS_Clear_Device_Control
 *===========================================================================*
 * @brief This function Clear the Device control Mode.
 *
 * @param [in] 
 *
 * @Return
 *
 * @pre
 *
 * @post
 *
 *===========================================================================*/
extern void PITS_PCS_Clear_Device_Control(void);

/*===========================================================================*/
/*!
 * @file pits_pcs_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  06-Sep-2012 Darinka L�pez Rev 3
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 28-Oct-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#16494: Implement MSID(04h) - Control Services
 * Fix: Change control to use in ICR and SBX project.
 *
 * - 2008-06-10  Larry Ong
 *    - Moved GID/EID  definitions to pits_control_services_cfg file.
 *
 * - 2008-01-23  Larry Ong
 *    - Cleaned up @todo comments.
 *
 * - 2007-12-13  Jaroslaw Saferna
 *    - Group IDs for PITS Control Services Test updated.
 *    - Success_Or_Fail_T(*rx_test) typedef changed.
 *
 * - 2007-12-08  Jaroslaw Saferna
 *    - Group IDs for PITS Control Services updated.
 *
 * - 2007-11-29  Larry Ong
 *    - Re-arrange the structure of the bbc_pits for re-useability:
 *       - Move OS/XSAL related modules from bb_pits_core to bb_pits_xsal
 *       - Create bbc_pits_services to contain independent pits services re-usable blocks:
 *          - bb_pits_pbs, for basic services
 *          - bb_pits_pcs, for control services
 *          - bb_pits_pps, for programming services
 *
 * - 2007-10-09  Larry Ong
 *    - Fixed issue with MEMORY_ROM ID not defined, which returns a SUCCESS for invalid
 *      memory address.
 *
 * - 2007-09-28  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-09-27  Jaroslaw Saferna
 *    - Memory map ID for EEPROM enabled.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-08-01  Larry Ong
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_PCS_SERVICES_H */
