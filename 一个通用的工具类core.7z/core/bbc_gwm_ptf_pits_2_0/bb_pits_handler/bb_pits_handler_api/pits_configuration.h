#ifndef PITS_CONFIGURATION_H
#   define PITS_CONFIGURATION_H
/*===========================================================================*/
/**
 * @file pits_configuration.h
 *
 * PITS Configuration API.
 *
 * %full_filespec:pits_configuration.h~1:incl:ctc_ec#19 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:38 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This file contains the standard api for the pits configuration module.
 *
 * @section ABBR ABBREVIATIONS:
 *    - PITS: Product Integrated Test Strategy.
 *    - MSID: Message Set Identifier.
 *    - MID: Message Identifier.
 *    - DTC: Diagnostic Trouble Code.
 *
 * @section TRACE TRACEABILITY INFO:
 *    - Design Document(s):
 *       - AN_PITS_001.doc: Application Note for PITS Basic Services.
 *       - AN_PITS_002.doc: Application Note for PITS Programming Services.
 *       - AN_PITS_004.doc: Application Note for PITS Control Services.
 *       - AN_PITS_005.doc: Application Note for PITS Health Services.
 *       - AN_PITS_Diagnostic_Application.doc: Application Note for Embedded Software Diagnostic Applications.
 *       - MDD_PITS_Embedded_SW_Building_Block.doc: Module Design Document for Embedded Software Building Block Design.
 *       - PDD_PITS_001_04.doc: Product Design Document for Core PITS Design.
 *
 *    - Requirements Document(s):
 *       - RAD_PITS_Embedded_SW_Building_Block.doc: Requirement and Architecture Document for Embedded Software Building
 *         Block Design.
 *       - SRS_BASA_Diagnostics.doc: Software Requirement Specification for PITS.
 *
 *    - Applicable Standards (in order of precedence: highest first):
 *       - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *         SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *       - BASA Naming Convention, version 1.1
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *    - None
 *
 * @addtogroup PITS_grp
 * @{
 */
/*===========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "pits_common_types.h"
#   include "pits_configuration_acfg.h"
#   include "pits_manager.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/* *INDENT-OFF* */

/**--------------------------------------------------------------------------*
 * PITS Standard Message Set ID (MSID) X-Macro Definition
 *
 * The IDs for these Message Sets are between 0 - 16, and must not be changed.
 * 
 * The Project Specific MSID X-Macro definition can be found in pits_configuration_acfg.h.
 *
 * These IDs are unique for each Message Set and are used by the PITS Application modules.
 * Please define the Interfaces to the applications for the Standard MSIDs to be used by
 * this PITS implementation in PITS_INTERFACE_TABLE X-Macro in pits_configuration_acfg.h.
 *                 index                        msid  interface
 *---------------------------------------------------------------------------*/
#define PITS_STANDARD_MSID_TABLE \
   PITS_MSID_INDEX(MSID_BASIC_SERVICES,         1) \
   PITS_MSID_INDEX(MSID_PROGRAMMING_SERVICES,   2) \
   PITS_MSID_INDEX(MSID_NETWORK_SERVICES,       3) \
   PITS_MSID_INDEX(MSID_CONTROL_SERVICES,       4) \
   PITS_MSID_INDEX(MSID_SOH_SERVICES,           5)

/* *INDENT-ON* */

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

#   undef PITS_MSID_INDEX

/**
 * X-Macro to define the value of the Message Set IDs to be supported
 */
#   define PITS_MSID_INDEX(index, msid)   index = msid,

typedef enum
{
   PITS_STANDARD_MSID_TABLE
   PITS_APPLICATION_MSID_TABLE 
} PITS_MSID_LIST_T;

/**
 * PITS Bearing Bus X-Macro Definitions
 *
 * This macro defines the list of Bearing Busses to be supported by this PITS implementation.
 * There must be an entry of the type PITS_Bearing_Bus_T for each bus to be supported.
 *
 *                index                 interface
 */
#   define PITS_BUS_TABLE \
   PITS_BUS_INDEX(PITS_BUS_GMLAN,      &GM_Diag_Bearing_Bus)

#   undef PITS_BUS_INDEX

/**
 * X-Macro to define the index of the Bearing Busses to be supported
 */
#   define PITS_BUS_INDEX(index, interface)  index,

typedef enum
{
   PITS_BUS_TABLE
} PITS_BUS_INDEX_T;


/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Configuration_Initialize
 *===========================================================================*
 * @brief This function intitializes the structures for the bearing busses
 * and the applications
 *
 * @returns
 * 
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Configuration_Initialize(void);

/*===========================================================================*
 * FUNCTION: PITS_Get_MSID_Name
 *===========================================================================*
 * @brief This function gets the string name for a MSID supported by the system
 *
 * @returns
 *    true = MSID is found in the interface
 *    false = MSID not found in the interface
 *
 * @param [in]    msid = The Message Set ID to search
 * @param [out]   data = string name of the msid
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_Get_MSID_Name(const uint8_t msid, uint8_t * data);
/*===========================================================================*
 * FUNCTION: PITS_Get_MSID
 *===========================================================================*
 * @brief This function search for a MSID supported
 *
 * @returns
 *    true = MSID is found in the interface
 *    false = MSID not found
 *
 * @param [in]    msid = The Message Set ID to search
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_Get_MSID(const uint8_t msid);
/*===========================================================================*
 * FUNCTION: PITS_Get_MID
 *===========================================================================*
 * @brief This function search for a MSID and MID pair supported
 *
 * @returns
 *    true = MSID/MID is found in the interface
 *    false = MSID/MID not found
 *
 * @param [in]    msid = The Message Set ID to search
 * @param [in]    mid = The Message ID to search
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_Get_MID(const uint8_t msid, const uint8_t mid);

/*===========================================================================*
 * FUNCTION: PITS_Get_MSID_List
 *===========================================================================*
 * @brief This function compiles a list of all MSID supported by the system
 *
 * @returns
 *
 * @param [out]   message_id_bits[] = bit array to store MSID bits.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Get_MSID_List(uint8_t * message_id_bits);

/*===========================================================================*
 * FUNCTION: PITS_Get_MID_List
 *===========================================================================*
 * @brief This function compiles a list of all the MID supported by a given MSID
 *
 * @returns
 *    true = MSID is found in the interface and the list is built
 *    false = MSID not found and the list is left empty
 *
 * @param [in]    msid = The MSID to collect the MIDs it supports
 * @param [out]   message_id_bits[] = bit array to store MID bits_
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern Success_Or_Fail_T PITS_Get_MID_List(const uint8_t msid, uint8_t * message_id_bits);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

extern void RemRcvr_Enable_Override(void);
extern void RemRcvr_Disable_Override(void);


/*===========================================================================*/
/*!
 * @file pits_configuration.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *  06-Sep-2012 Darinka L�pez Rev 10
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 13 Jan 2011 Miguel Garcia
 * Remove unused Pits
 *
 * + 2010-07-16    lzz7kf (JICASTANON)  Rev 8
 *    - Merged: Fix parallel versions
 *
 * + 2009-06-10  Larry Ong
 *    - Decouple application interfaces from MSID definitions. 
 *    - Seperate standard MSIDs (0 - 16) from project specific MSIDs (17 - 155).
 *    - Move standard MSIDs definition to pits_configuration.h.
 *
 * - 2008-07-02  Larry Ong
 *    - Moved pits configuration parameters from pits_configuration.h to pits_configuration_acfg.h.
 *
 * - 2008-06-05  Larry Ong
 *    - Added MSID string name.
 *
 * - 2008-05-13  Larry Ong
 *    - Used X-macro to define the MSIDs and Application Interfaces.
 *    - Used X-macro to define the Bearing Busses.
 *    - Moved pits_configuration.c file into the bb_pits_core block.
 *
 * - 2008-04-28  Larry Ong
 *    - Created PITS Health Services, MSID = 5.
 *    - Redefined DTC as Health Services. 
 *    - Removed Session from Basic Services. 
 *
 * - 2008-01-24  Larry Ong
 *    - Clean up todo list.
 *
 * - 2007-10-31  Larry Ong
 *    - Add The following pits basic services:
 *       - Message Support Services
 *       - Flow Control Services
 *       - Health Services
 *       - Device ID Services
 *
 * - 2007-10-01  Larry Ong
 *    - Update to Doxygen 1.5.3.
 *
 * - 2007-08-31  Larry Ong
 *    - MISRA changes per QAC.
 *
 * - 2007-07-31  Larry Ong
 *    - Added PITS Control Services.
 *
 * - 2007-02-08  Mike Gerig/Kris Boultbee 
 *    - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* PITS_CONFIGURATION_H */

