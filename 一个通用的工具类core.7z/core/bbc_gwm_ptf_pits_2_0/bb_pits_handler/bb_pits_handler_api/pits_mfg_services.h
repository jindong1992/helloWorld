#ifndef PITS_MFG_SERVICES_H
#   define PITS_MFG_SERVICES_H
/*===========================================================================*/
/**
 * @file pits_mfg_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_mfg_services.h~1:incl:ctc_ec#7 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:26 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2014 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_mfg_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define PITS_MAX_MD5_NAME_SIZE       4

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum PITS_MAN_MD5_Req_Tag
{
   PITS_MD5_STATUS,
   PITS_MD5_CALC,
   PITS_MD5_MAX_INFO,
} PITS_MAN_MD5_Req_T;

typedef enum PITS_MD5_Checksum_Resp_Tag
{
   PITS_MAN_CHKSUM_NONE  = 0,
   PITS_MAN_CHKSUM_PROCESS,
   PITS_MAN_CHKSUM_SUCCESS,
   PITS_MAN_CHKSUM_ERROR  = 0xFF,   
}PITS_MD5_Checksum_Resp_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Mfg_Services_Interface;

extern uint8_t DG_Receive_Pit_Load_Def (void);

/**
 * PITS_Create_MD5_Timer: create timer for md5.
 *
 * @param none
 *
 * @return none
 */
extern void PITS_Create_MD5_Timer(void);

/**
 * PITS_Destroy_MD5_Timer: destroy timer for md5.
 *
 * @param none
 *
 * @return none
 */
extern void PITS_Destroy_MD5_Timer (void);

extern bool_t PITS_Check_MD5_Status (const SAL_Event_Id_T event_id);

extern Done_Or_Not_Done_T PITS_Mfg_Aux_Jack_Stat_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Mfg_Req_Md5_Calc_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Mfg_Get_Md5_Part_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Mfg_Unlock_Lock_Data_Partition_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Man_Load_Defaults_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Mfg_Set_Vss_Pwm_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Mfg_Get_Vss_Pwm_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T Pits_Man_Reflash_Status_Req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file pits_mfg_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 24-jun-2014 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* PITS_MFG_SERVICES_H */
