#ifndef PITS_DISPLAY_SERVICES_H
#   define PITS_DISPLAY_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_display_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_display_services.h~1:incl:ctc_ec#8 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:04:47 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_display_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
 
/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Display_Services_Interface;

extern void Pits_Request_Screen_Test_XY (const uint8_t * data, size_t length);

extern void Pits_Request_Screen_Error (const uint8_t * data, size_t length);
/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * FUNCTION: PITS_Set_Display_Session
 *===========================================================================*
 * @brief Setter Function for the Display Session
 *
 * @returns
 *    true = if the Session State changed
 *    false = if the Session State remained unchanged
 *
 * @param [in] session = destination state
 *
 * @pre session must be valid
 *
 * @post
 *
 * OPEN:    Session State = Open, Publish 'Session Open' message, start session timer
 * CLOSE:   Session State = Close, Publish 'Session Close' message, stop session timer
 */
/*===========================================================================*/
extern bool_t PITS_Set_Display_Session(const PITS_EVG_SESSION_T session);

/*===========================================================================*
 * FUNCTION: PITS_Get_Display_Session
 *===========================================================================*
 * @brief Getter function for Display Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_Display_Session(void);

/*===========================================================================*
 * FUNCTION: PITS_Create_Display_Timer
 *===========================================================================*
 * @brief Create PITS Display Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Create_Display_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Destroy_Display_Timer
 *===========================================================================*
 * @brief Destroy PITS Display Services Session Timer
 *
 * @returns
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern void PITS_Destroy_Display_Timer(void);

/*===========================================================================*
 * FUNCTION: PITS_Check_Display_Timer
 *===========================================================================*
 * @brief Check for Display Session Timeout
 *
 * @returns
 *    false = If Event is not a Display Session Timeout
 *    true = If Event is a Display Session Timeout
 *
 * @param [in] event_id = ID of the Private Event.
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Check_Display_Timer(const SAL_Event_Id_T event_id);

/*===========================================================================*
 * FUNCTION: PITS_Display_Send_Session_State
 *===========================================================================*
 * @brief Function to send Display Session State
 *
 * @returns
 *    false - Request is not for Display Session
 *    true - Request is for Display Session, and message sent 
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern bool_t PITS_Display_Send_Session_State(const SAL_Message_T * message);

/*===========================================================================*
 * FUNCTION: PITS_Get_SAL_Display_Session_State
 *===========================================================================*
 * @brief Getter functions for published Display Session States
 *
 * @returns
 *    SESSION_CLOSE
 *    SESSION_OPEN
 *
 * @param
 *
 * @pre
 *
 * @post
 *
 */
/*===========================================================================*/
extern PITS_EVG_SESSION_T PITS_Get_SAL_Display_Session_State(void);

extern void Pits_Display_Text_Test(const uint8_t * data, size_t length);

extern bool_t Pits_Display_Override_Status (void);

void PITS_Get_Touchscreen_Info (const uint8_t * data, size_t length);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T pits_display_session_get_state_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_display_session_open_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_display_session_close_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_display_session_refresh_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_display_session_get_timeout_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_display_session_set_timeout_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_get_time_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_time_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_test_req(const PITS_Message_T * message);
#if defined FORD_C490
extern Done_Or_Not_Done_T pits_disp_get_override_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_override_req(const PITS_Message_T * message);
#endif
extern Done_Or_Not_Done_T pits_disp_display_text_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_video_source_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_dim_req(const PITS_Message_T * message);
#if defined(GWM_CHK041_8AT) || defined(GWM_CHK011_8AT)
extern Done_Or_Not_Done_T pits_disp_select_test_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_get_faceplate_dim_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_set_faceplate_dim_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_ir_touch_cali_req(const PITS_Message_T * message);
#endif
extern Done_Or_Not_Done_T pits_disp_get_rtd_temp_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_disp_get_dim_req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T pits_ir_touch_cali_req(const PITS_Message_T * message);


/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_display_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added Destroy PITS Display Services Session Timer function.
 *
 *  06-Sep-2012 Darinka L�pez Rev11
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 22-Aug-2012 Miguel Garcia 10
 * Include pits display status
 *
 * 11 Jun 2012 Miguel Garcia Rev 8
 * Create pits disp set video source
 *
 * 21-Mar-2012 Darinka Lopez  Rev 7
 * SCR kok_basa#22458: pits_manager_j2.c is misnamed in SBX project.
 * Fix suscribe list function prototype to "size_t"
 *
 * 5-Jan-2012 Darinka Lopez  Rev 6
 * SCR kok_basa#19966 : PITS:  Create new structure for PITS services
 * Change upercases to lowercases in pits modules.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 5
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 4
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 * - 19-nov-2008 Yi Liu
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_DISPLAY_SERVICES_H */
