#ifndef PITS_NAV_SERVICES_H
#   define PITS_NAV_SERVICES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file pits_nav_services.h
 *
 * @todo Add a one line description of the header file here.
 *
 * %full_filespec:pits_nav_services.h~1:incl:ctc_ec#26 %
 * @version %version:1 %
 * @author  %derived_by:vzm576 %
 * @date    %date_modified:Mon May 23 14:05:34 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup pits_nav_services Provide API description and define/delete next line
 * @ingroup <parent_API> (OPTIONAL USE if part of another API, else delete)
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pits_application_manager.h"
#include "pits_configuration.h"  

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#define NAV_TEST_RUNNING                      (0x01)

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
typedef enum PITS_GPS_Test_Tag
{
   PITS_GPS_TEST_START_NONE              = 0x00,
   PITS_GPS_TEST_IN_PROGRESS             = 0x01,
   PITS_GPS_TEST_FINISHED                      = 0x02,
   PITS_GPS_TEST_NONE                            = 0x03,
} PITS_GPS_Test_T;


/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
extern PITS_Application_Interface_T PITS_Nav_Services_Interface;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
extern void PITS_Create_GYRO_Timer(void);
extern void PITS_Destroy_GYRO_Timer(void);
extern bool_t PITS_Check_GYRO_Timer(const SAL_Event_Id_T event_id);
extern void PITS_Get_VSS_Info(const uint8_t * data, size_t length);
extern void PITS_Create_VSS_Timer(void);
extern bool_t PITS_Check_VSS_Timer(const SAL_Event_Id_T event_id);
extern void Pits_Destroy_VSS_Timer(void);

/*===========================================================================*
 * Exported PITS MID Functions
 *===========================================================================*/
extern Done_Or_Not_Done_T PITS_Nav_Enter_Gyro_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Stop_Gyro_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Test_Gyro_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Gyro_Selftest_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Begin_Temp_Sensor_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Get_Temp_Sensor_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Enter_GPS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Enter_VSS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Stop_Tone_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Display_Map_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Set_Key_Mode_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Test_GPS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Get_GPS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Satellite_GPS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Set_Antenna_GPS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Enter_VSS_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Get_Single_Vss_Req(const PITS_Message_T * message);
extern Done_Or_Not_Done_T PITS_Nav_Ubx_Message_Req(const PITS_Message_T * message);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file pits_nav_services.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *  30-Jun-2014 Tim Wang
 *  Added PITS_Nav_Get_GPS_Req, PITS_Nav_Satellite_GPS_Req, PITS_Nav_Set_Antenna_GPS_Req
 *  function.
 *
 *  06-Sep-2012 Darinka L�pez Rev 4
 *  Task kok_basa#117362 - Pits: Fix Error Message return option.   
 *  Fix Error Message return value
 *  Fix cbk includes (Should not be cbk or cfg in a *.h api file).
 *  Fix warnings with new VM.
 *
 * 14-Dec-2011 Darinka Lopez  Rev 3
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Fix include files
 *
 * 14-Dec-2011 Darinka Lopez  Rev 2
 * SCR kok_basa#17463: Add PITS Message to set SBX Board Calibrations
 * Fix: Generate PITs MID functions as extern functions. The cfg files will call the correct function
 * when the MID is implemented, otherwise will response COMMAND NO SUPPORTED
 *
 *
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* PITS_NAV_SERVICES_H */
