#ifndef CONVERT_UNICODE_TO_GB2312_H
#   define CONVERT_UNICODE_TO_GB2312_H
/*===========================================================================*/
/**
 * @file convert_unicode_to_gb2312.h
 *
 * API for functions used to perform convert_unicode_to_gb2312.
 *
 * %full_filespec:convert_unicode_to_gb2312.h~1:incl:ctc_ec#1 %version:1 %
 * @author  %derived_by:rznbk1 %
 * @date    %date_modified:Tue Aug 21 15:12:39 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @page conversion_page convert_unicode_to_gb18032 User Manual
 *
 * @section DESC DESCRIPTION:
 *
 * The convert_unicode_to_gb2312 sub-module provides set of functions to convert unicode to GB2312
 * character and from GB2312 to unicode.
 *
 *
 * @section USAGE USAGE INSTRUCTIONS:
 *
 * -# Include bb_util in the project
 * -# Include utilities.h in your code
 *
 * @section ABBR ABBREVIATIONS:
 *   - GB2312 is  known as Chinese characters
 *
 * @section TRA TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_BASA_Utilities.doc
 *
 *   - Requirements Document(s):
 *     - SRS_BASA_Utilities.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @defgroup conversions_grp Data conversions
 * @ingroup utilities_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#   include "reuse.h"

/*===========================================================================*\
 * Exported Preprocessor #define Constants
\*===========================================================================*/

/*===========================================================================*\
 * Exported Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Exported Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Function Prototypes
\*===========================================================================*/
#   ifdef __cplusplus
extern "C"
{

#   endif                       /* __cplusplus */

/**
 * The function converts a unicode character array to a gb2312 character array.
 *
 * @param [in] dest - output buffer
 * @param [in] size   - size of the outStr buffer
 * @param [in] src  - buffer to convert
 *
 */
 void utf16_to_gb2312(wchar_t * dest, const wchar_t* src, uint8_t size);



/*===========================================================================*\
 * Exported Inline Function Definitions and #define Function-Like Macros
\*===========================================================================*/

#   ifdef __cplusplus
}
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file unicode_to_gb2312.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 26-July-2012 Jiang Tao
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* CONVERT_UNICODE_TO_GB2312_H */
