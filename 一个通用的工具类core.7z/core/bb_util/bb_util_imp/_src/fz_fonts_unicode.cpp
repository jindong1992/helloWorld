/*===========================================================================*/
/**
 * @file fz_fonts_unicode.cpp
 *
 * Main function for
 *
 * %full_filespec: fz_fonts_unicode.cpp~2:c++:ctc_ec#1 %
 * @version %version: 2 %
 * @author  %derived_by: cz1936 %
 * @date    %date_modified: Fri Oct 26 11:03:39 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Main function for Silverbox Core Process.
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/

/**
 * File: GWM Chinese Characters unicode convert
 * Edit: zheng @ 2012-10-24 15:44:09, Wed
 *
 * @良凉凉梁
 * Doulble 凉 = U+51C9, U+F979
 * @see
 * http://www.fileformat.info/info/unicode/char/51c9/index.htm
 * http://www.fileformat.info/info/unicode/char/f979/index.htm
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fstream>
#include <string>
#include <sstream>
#include <iostream>

#include <vector>
#include <algorithm>    // sort

#include "fz_fonts_unicode.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/


/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/
typedef std::vector<unsigned short> unicode_table_vector_t;

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/
static unicode_table_vector_t v_fz_fonts_table;

static unsigned int fz_fonts_unicode_init_flag = 0;   // 0 = Un-initialized by default, 1 = initialized

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/

int fz_fonts_unicode_init( void )
{

   v_fz_fonts_table.clear( );
   v_fz_fonts_table.assign( FZ_FONTS_UNICODE_TABLE,
                            FZ_FONTS_UNICODE_TABLE + FZ_FONTS_UNICODE_TABLE_SIZE );

#if 0 // for debug
   int i = 0;
   unicode_table_vector_t::iterator it;
   for ( it = v_fz_fonts_table.begin();
         it != v_fz_fonts_table.end();
         ++it )
   {
      i ++;
      cout << "0x"  << hex << *it << ", ";
      if ( ( i % 8 ) == 0 )
         cout << endl;
   }
#endif

   // flag it initialized
   fz_fonts_unicode_init_flag = 1;

   return 0;

}

int fz_fonts_unicode_fini( void )
{
   v_fz_fonts_table.clear();

   return 0;
}

/**
 * @see fz_fonts_unicode.h
 */
int fz_fonts_unicode_single_search( const unsigned short chn_unicode )
{
   int rc = 0; // Don't existed in the FZ Fonts Library by default.

   // init at first and only init one time
   if ( !fz_fonts_unicode_init_flag )
   {
      fz_fonts_unicode_init( );
   }

   // binary search
   if ( binary_search ( v_fz_fonts_table.begin( ),
                        v_fz_fonts_table.end( ),
                        chn_unicode )
      )
   {
      //cout << "found!\n";
      rc = 1;
   }
   else
   {
      //cout << "not found.\n";
      rc = 0;
   }

   return rc;
}


#if 0
template <class T>
T from_string( std::string s )
{
   T result;
   std::stringstream str;
   str << s;
   str >> result;
   return result;
}

int main ( int argc, char *argv[] )
{
   unsigned short unicode = 0x1234;
   if( argc != 2 )
   {
      cout << "Usage:" << endl;
      cout << "    " << argv[0] << " 0x1234" << endl;
      return 1;
   }
   else
   {
      unicode = from_string<unsigned short> ( argv[1] );
   }

   cout << "unicode = " << hex << unicode << endl;

   // init
   vector<unsigned short> v_fz_fonts_table;
   v_fz_fonts_table.assign( FZ_FONTS_UNICODE_TABLE,
                            FZ_FONTS_UNICODE_TABLE + FZ_FONTS_UNICODE_TABLE_SIZE );

   int i = 0;
   vector<unsigned short>::iterator it;
   for ( it = v_fz_fonts_table.begin();
         it != v_fz_fonts_table.end();
         ++it )
   {
      i ++;
      cout << "0x"  << hex << *it << ", ";
      if ( ( i % 8 ) == 0 )
         cout << endl;
      // cout << dec << i << ") "  << hex << *it << endl;
      // printf( "%d) %s\n", i, (const char*) *it );
   }

   // binary search
   if ( binary_search ( v_fz_fonts_table.begin( ),
                        v_fz_fonts_table.end( ),
                        unicode )
      )
   {
      cout << "found!\n";
   }
   else
   {
      cout << "not found.\n";
   }

   v_fz_fonts_table.clear();

   return 0;
}


#endif
/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 *
 *
\*===========================================================================*/


