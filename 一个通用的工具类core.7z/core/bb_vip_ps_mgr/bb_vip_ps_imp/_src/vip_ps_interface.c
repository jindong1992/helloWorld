/*===========================================================================*/
/**
 * @file vip_ps_interface.c
 *
 * Implements the vip_ps_interface.
 *
 * %full_filespec:vip_ps_interface.c~ctc_ec#10:csrc:kok_basa#1 %
 * @version %version:ctc_ec#10 %
 * @author  %derived_by:xzhgs6 %
 * @date    %date_modified:Tue Oct 29 16:11:15 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *  The vip_ps service module provides a translation link between vip persistent
 *  storage messages and persistent storage in the application.
 *  This module contains all of the standard communication code to store the vip information.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VIP - Vehilce Interface Processor
 *   - PS - Persistent storage
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup vip_ps_interface
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "application_manager.h"
#include "desip_msg_ids.h"
#include "desip_msg_types.h"
#include "icr_radio_process_app_defn.h"
#include "pbc_trace.h"
#include "ps_proxy.h"
#include "state_of_health.h"
#include "utilities.h"
#include "vip_desip.h"
#include "vip_ps_interface_cbk.h"
#include "vip_ps_interface.h"
#include "xsal.h"
#include <string.h>
#include <unistd.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_PS_INTERFACE_MODULE_ID, 0);     /* Identifies file for PbC/trace */

/**
 * General message timeout period mS for threads
 */
#define VIP_PS_MSG_WAIT_TIMEOUT_MS (2000)

#define VIP_PS_TASK_MSG_SIZE (sizeof(uint8_t))
/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/* If the SOH_TIMEOUT is not defined in the cfg file, then default value will be taken */
#ifndef VIP_PS_SOH_TIMEOUT_MS
#define VIP_PS_SOH_TIMEOUT_MS  SOH_DEFAULT_TIMEOUT_MS
#endif

/* If SOH_TIMEOUT_MS time is less than twice the MSG_WAIT_TIME_MS
 * time then set the SOH Timeout error */
#if ( VIP_PS_SOH_TIMEOUT_MS < (2 * VIP_PS_MSG_WAIT_TIMEOUT_MS))
#error "Invalid SOH timeout"
#endif

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

static void VIP_PS_Listener_Thread(void *arg);
void VIP_PS_Decode_COMMAND_REQ(const uint8_t * data, size_t num_bytes);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 *
 * Please refer to the detailed description in vip_desip.h.
 *
 *  Creates a receive and transmit threads
 *  A semaphore to run receive thread.
 *  A mutex to allow only one request / reply pair at a time
 *  
 *===========================================================================*/
void VIP_PS_Interface_Initialize(void)
{
   SAL_Thread_Attr_T thread_attr;
   SAL_Thread_Id_T tid;

   VIP_PS_Get_PS_Listener_Thread_Attr(&thread_attr);
   tid = SAL_Create_Thread(VIP_PS_Listener_Thread, NULL, &thread_attr);
   PBC_Ensure(VIP_PS_THREAD_ID == tid, "Error creating VIP PS Thread");

}

/*===========================================================================*
 *
 * Please refer to the detailed description in vip_desip.h.
 *
 *===========================================================================*/
/**
 * This thread processes the VIP Persistent Storage Read/Write requests, it receives
 * a XSAL message aready processed.
 */
static void VIP_PS_Listener_Thread(void *arg)
{

   bool_t ok;
   bool_t thread_alive = true;

   const SAL_Message_T *message;/*  pointer to current receive message*/

   const SAL_Event_Id_T events[]=
   {
      EVG_PS_COMMAND_REQ,
   };

   ok = SAL_Create_Queue(VIP_PS_Message_Queue_Size,
                         VIP_PS_TASK_MSG_SIZE,
                         SAL_Alloc,
                         SAL_Free );
   PBC_Ensure(ok, "SAL_Create_Queue() failed");

   ok = SAL_Subscribe(events,Num_Elems(events));
   PBC_Ensure(ok, "SAL_Subscribe() failed");

   SAL_Signal_Ready();

   APM_Activated(APM_VIP_PS);

   SOH_Register(VIP_PS_SOH_TIMEOUT_MS);
   Tr_Info_Lo("VIP PS Listener Thread: start");

   while (thread_alive)
   {
      message = SAL_Receive_Timeout(VIP_PS_MSG_WAIT_TIMEOUT_MS);
      if (NULL != message)
      {
         switch (message->event_id)
         {
            case EVG_PS_COMMAND_REQ:
               VIP_PS_Decode_COMMAND_REQ(message->data, message->data_size);
               PBC_Ensure(message->data != NULL, "Empty data error");
               break;

            default:
               Tr_Warn_1("Unknown message %d", (int)message->event_id);
               break;
         }
      }
      SOH_Alive(VIP_PS_SOH_TIMEOUT_MS);
   }
   /*Thread cleanup*/
   SOH_Dormant();

   ok = SAL_Unsubscribe(events, Num_Elems(events));
   PBC_Ensure(ok, "SAL_Unsubscribe: error");

   APM_Terminated(APM_VIP_PS);

   if(false == ok)
   {
      Tr_Warn("SAL_Unsubcribe Failed");
   }
   Tr_Info_Hi("VIP PS Listener Task Stopped");
}

/**
 * Processes PS Read/Write requests from VIP
 */
void VIP_PS_Decode_COMMAND_REQ(const uint8_t * data, size_t num_bytes)
{
   uint8_t local_index = 0;
   static SIP_PS_Command_T command;
   static Persistent_Section_ID_T section_id;
   static Persistent_Section_ID_T section_id_mfg;
   static size_t section_name_size;
   static size_t section_name_position;
   static size_t data_size;
   static ssize_t data_size_read;
   static size_t data_position;
   static size_t read_buffer_total_lenght;
   static uint8_t read_buffer[SIP_MAX_PS_SIZE];

   command = (SIP_PS_Command_T)data[local_index];
   local_index = local_index + 1;
   /** Get PS Header info */
   /**Decode Section ID and move index to next element*/
   section_id_mfg =  (Persistent_Section_ID_T) data[local_index];
   section_id = PS_SECTION_NONVOL;
   local_index = local_index + 1;
   /**Decode Section Name (size & chars)*/
      /* - Size*/
   section_name_size = ((uint32_t)(data[local_index])         & 0x000000FF) |
                       ((uint32_t)(data[local_index+1] <<  8) & 0x0000FF00) |
                       ((uint32_t)(data[local_index+2] << 16) & 0x00FF0000) |
                       ((uint32_t)(data[local_index+3] << 24) & 0xFF000000);
   local_index = local_index + 4;
      /* - Chars: No need to decode name string, just its position on buffer*/
   section_name_position = local_index;

      /* Move index to next element in buffer*/
   local_index = local_index + section_name_size + 1;

   /**Data (size & bytes & strap)*/
      /* - Size*/
   data_size = ((uint32_t)(data[local_index])         & 0x000000FF) |
               ((uint32_t)(data[local_index+1] <<  8) & 0x0000FF00) |
               ((uint32_t)(data[local_index+2] << 16) & 0x00FF0000) |
               ((uint32_t)(data[local_index+3] << 24) & 0xFF000000);
#if 0
   data_size_read = ((uint32_t)(data[local_index])         & 0x000000FF) |
                  ((uint32_t)(data[local_index+1] <<  8) & 0x0000FF00) |
                  ((uint32_t)(data[local_index+2] << 16) & 0x00FF0000) |
                  ((uint32_t)(data[local_index+3] << 24) & 0xFF000000);
#else
   data_size_read = data_size;
#endif

   local_index = local_index + 4;
      /* - Data: No need to load data, just its position on buffer*/
   data_position = local_index;
   read_buffer_total_lenght = data_size + data_position;

   Tr_Info_Lo_1("VIP_PS_Decode_COMMAND_REQ: command=%d ", command);

   switch (command)
   {
      case PS_READ_CMD:
         /*Start building response buffer
          * - Copy message header which includes the same received buffer up to current data_position*/
         memcpy(&read_buffer[0], &data[0], data_position);
         if ((section_id_mfg == PS_SECTION_PROD_ID)||(section_id_mfg == PS_SECTION_ALIGN_CAL))
         {
            if(PS_Read(section_id_mfg, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
            {
               read_buffer[0] = PS_READ_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, read_buffer_total_lenght);
            }
            else
            {
               read_buffer[0] = PS_ERROR_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, data_position);
            }
         }
         else if ((data[1] == 0x06)||(data[1] == 0x07))
         {
            if(PS_Read(PS_SECTION_MANUFACTURING, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
            {
               read_buffer[0] = PS_READ_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, read_buffer_total_lenght);
            }
            else
            {
               read_buffer[0] = PS_ERROR_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, data_position);
            }
         }
         else
         {
            if(PS_Read(section_id, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
            {
               read_buffer[0] = PS_READ_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, read_buffer_total_lenght);
            }
            else
            {
               read_buffer[0] = PS_ERROR_CMD;
               VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, data_position);
            }
         }
         break;

      case PS_WRITE_CMD:
      {
         int drop = 0;
         
         Tr_Info_Lo_4("PS_WRITE_CMD: %s, section_id_mfg=%d, data[1]=0x%x, size=%d ", 
                                 &data[section_name_position], section_id_mfg, data[1], data_size);

         /*Write Received Data*/
         if ((section_id_mfg == PS_SECTION_PROD_ID)||(section_id_mfg == PS_SECTION_ALIGN_CAL))
         {
            drop = 0;
            if(PS_Read(section_id_mfg, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
            {
               if (0 == memcmp(&read_buffer[data_position], &data[data_position], data_size_read))
               {
                  Tr_Info_Mid_1("PS_WRITE_CMD: section_id_mfg=%d, PS file same, drop!", section_id_mfg);
                  drop = 1;
               }
            }

            if (0 == drop)
            {
               PS_Write(section_id_mfg, (const char *)&data[section_name_position], &data[data_position], data_size);
               usleep (20*1000);
            }
         }

         if ((data[1] == 0x06)||(data[1] == 0x07))
         {
            drop = 0;
            if(PS_Read(PS_SECTION_MANUFACTURING, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
            {
               if (0 == memcmp(&read_buffer[data_position], &data[data_position], data_size_read))
               {
                  Tr_Info_Mid_1("PS_WRITE_CMD: data[1]=0x%x, PS file same, drop!", data[1]);
                  drop = 1;
               }
            }

            if (0 == drop)    
            {
               PS_Write(PS_SECTION_MANUFACTURING, (const char *)&data[section_name_position], &data[data_position], data_size);
               usleep (20*1000);
            }
         }


         drop = 0;
         if(PS_Read(section_id, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
         {
            if (0 == memcmp(&read_buffer[data_position], &data[data_position], data_size_read))
            {
               Tr_Info_Mid_1("PS_WRITE_CMD: section_id=%d, PS file same, drop!", section_id);
               drop = 1;
            }
         }

         if (0 == drop)  
         {
            PS_Write(section_id, (const char *)&data[section_name_position], &data[data_position], data_size);
         }
         break;
      }
      case PS_ERROR_CMD:
         break;
      case PS_LOAD_DEFAULTS_CMD:
         memcpy(&read_buffer[0], &data[0], data_position);

         if(PS_Read(section_id, (const char *)&data[section_name_position], &read_buffer[data_position], data_size_read))
         {
            read_buffer[0] = PS_LOAD_DEFAULTS_CMD;
            VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, read_buffer_total_lenght);
          }
          else
          {
             read_buffer[0] = PS_ERROR_CMD;
             VIP_Send(VIPP_EV_PS_COMMAND_REPLY, read_buffer, data_position);
           }
           break;
      default:
         break;
   }

}



/*===========================================================================*/
/*!
 * @file vip_interface.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 29-Oct-2013 Zeng Liangqian
 * when PS_WRITE_CMD, PS_Read and compare before really PS_Write
 *
 * 22-Aug-2012 Kirk Bailey
 * Eliminated use of system_threads.h
 *
 * 16 May 2012 Maheshkumar M
 * Incorporate system level SOH Timeout - bb_vip_ps_mgr
 *
 * 02 Mar 2012 Miguel Garcia
 * Include Align Cal in factory data
 *
 * 29 Dec 2011 Miguel Garcia
 * Include DPS manufacturing
 *
 * 22 Nov 2011 Miguel Garcia
 * Change to Nonvol
 *
 * 04 May 2011 Miguel Garcia
 * Make write DIDs available
 */
/*===========================================================================*/
/** @} doxygen end group */
