#ifndef VIP_PS_INTERFACE_CBK_H
#   define VIP_PS_INTERFACE_CBK_H
/*===========================================================================*/
/**
 * @file vip_ps_interface_cbk.h
 *
 *   This file defines the callouts that are used by the vip ps Interface module
 *   and which must be implemented by the program using the module.
 *
 * %full_filespec:vip_ps_interface_cbk.h~2:incl:kok_basa#1 %
 * @version %version:2 %
 * @author  %derived_by:kzvhr7 %
 * @date    %date_modified:Thu May  5 16:11:16 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   Callouts are a mechanism by which a module can be "customized" for a
 *   program without its source code being change. They represent points where
 *   the designer of the module has recognized that system-specific data or
 *   behavior must be supplied for the module. This module "owns" these
 *   callouts in the sense that it declares them and uses them according
 *   to its design. The program choses the implementation so that the module
 *   integrates properly into the system.
 *
 * @section ABBR ABBREVIATIONS:
 *   - CNTS = VIP Interface
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup vip_desip
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "xsal.h"

/* ! The inclusion of header files should NOT be inside the extern "C" block */
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/* VIP PS Listener Thread message queue size */
extern const size_t VIP_PS_Message_Queue_Size;


/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/


/**
 * Returns the thread configuration for PS VIP Listener thread.
  *
 * @param [out] attr Points to the caller-supplied thread attribute that
 *                   will be filled in with the attributes of the thread
 *                   for this system.
 *
 * @pre
 *    attr != NULL
 *
 * @post
 *    attr->id == thread ID
 */
   void VIP_PS_Get_PS_Listener_Thread_Attr(SAL_Thread_Attr_T * attr);

/*===========================================================================*/
/*!
 * @file vip_desip_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 24 Feb 2011 Miguel Garcia kzvhr7
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PS_INTERFACE_CBK_H */
