#ifndef SINGLETON_HPP
#   define SINGLETON_HPP
/*===========================================================================*/
/**
 * @file Singleton.hpp
 *
 * Implements the Template to turn a class into a singleton
 *
 * %full_filespec:Singleton.hpp~4:ascii:kok_basa#1 %
 * @version %version:4 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Fri Jan 27 09:33:06 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2011 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements the Template to turn a class into a singleton
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup Singleton Implements the required code for a Singleton design pattern
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "block_list.h"
#include "pbc_trace.h"
#include "reuse.h"
#include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#undef EM_F_ID
#define EM_F_ID EM_FILE_ID(CPP_UTIL_MODULE_ID, 1)

#define HASH_BITS    (8)
#define HASH_BUCKETS (1 << HASH_BITS)

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
using namespace std;

/**
 * Template class used for creating a Singleton. This template uses the
 * Curiously Recurring Template Pattern, where a class inherits from this
 * template class passing it's own class name as the template parameter.
 *
 * Also required as a template parameter is the name of a type that will
 * be used as the unique identifier of a client of the Singleton class.
 * This unique identifier can be anything that suits the system implementer,
 * but should be easily guaranteed to be unique. Failure to use the proper
 * unique identifier for a client will cause the destruction of the reference
 * for the wrong client and could result in inadvertent destruction of the
 * Singleton object.
 *
 * Example:
 * @verbatim
 *
 * class My_Class : public Singleton<My_Class, My_Subsystem_ID_T>
 * {
 *    public:
 *       virtual int My_Method(int);
 *
 *    private:
 *
 *       friend class Singleton<My_Class, My_Subsystem_ID_T>;
 *
 *       int m_My_Data_Member;
 *
 *       My_Class() : m_My_Data_Member(0)
 *       {
 *       }
 *
 *       My_Class(My_Class& copy) {}
 *
 *       virtual ~My_Class() {}
 *
 *       My_Class& operator=(const My_Class& rhs){return *this;}
 * }
 * @endverbatim
 *
 * There are several major items in the above example that are of note.
 *
 * 1. The class definition inherits from the Singleton with the template parameters My_Class and
 *    My_Subsystem_ID_T. My_Class is the name of the class we are turning into a Singleton.
 *    My_Subsystem_ID_T is in this case envisioned as an enumerated type that uniquely identifies each
 *    subsystem within the system.
 *
 * 2. The class must grant friendship status to the template. This allows the template to create objects
 *    of My_Class since the constructor of My_Class is private.
 *
 * 3. The constructor, copy constructor, destructor and operator= of My_Class are private to prevent
 *    creation of objects of type My_Class directly without using the Get_Instance method of the
 *    Singleton template class.
 *
 * 4. My_Class inherits the Get_Instance() and Destroy_Instance() methods of the Singleton template class.
 *    These methods take a single parameter that is a value from (in this example) the My_Subsystem_ID_T
 *    enumerated type that uniquely identifies the subsystem that is requesting and instance of the
 *    Singleton.
 *
 * In order to effectively create a Singleton, you must have items 1, 2, and 3 above and must take care
 * to use item 4 properly to avoid inadvertent destruction of the Singleton object.
 *
 * If you need to provide some sort of post-construction initialization for your Singleton, the method
 * initialize() can be overridden. It must have the following prototype:
 *
 * @verbatim
 *
 * virtual void initialize(void);
 *
 * @endverbatim
 *
 * It is recommended that this method be placed in your derived class's private section.
 *
 */

template <class T, typename Unique_Client_ID_T>
class Singleton
{
   public:
      /**
       * Method for retrieving the instance of a Singleton object. This static
       * method is the *only* way to obtain access to the object.
       *
       * @return - a pointer to an object of the Template type
       */
      static T * Get_Instance(Unique_Client_ID_T client_id);

      /**
       * Method for destroying a client's reference to the instance of
       * the Singleton object.
       */
      static void Destroy_Instance(Unique_Client_ID_T client_id);

   protected:

      /**
       * Protected constructor to prevent classes using this template to create a Singleton
       * from being instantiated in any other fashion than using the Get_Instance method.
       */
      Singleton() {}

      /**
       * Protected destructor to prevent classes using this template to create a Singleton
       * from being destroyed in any other fashion than using the Destroy_Instance method
       * @return
       */
      virtual ~Singleton(){}

   private:

      /**
       * private method that can be overridden by derived class to provide post-construction
       * initialization that is automatically executed in Get_Instance()
       */
      virtual void initialize(void){}

      /**
       * Private copy constructor to prevent copying of a singleton
       *
       * @param copy - not used
       * @return - not used
       */
      Singleton(Singleton& copy) {}

      /**
       * Private override of the = operator when dealing with a Singleton.
       * @param rhs - not used
       * @return - not used
       */
      Singleton& operator=(const Singleton& rhs);

      /**
       * Finds a record of a client in the client record.
       *
       * @param client_id - Unique Client ID of the client to search for
       *
       * @return - Reference to the found client or NULL if no record found
       */
      static int32_t find_client(Unique_Client_ID_T client_id);

      /**
       * Removes the record of the client with the matching Unique Client ID.
       *
       * @param client_id - Unique Client ID of the client to remove
       *
       */
      static void remove_client(Unique_Client_ID_T client_id);

      /**
       * Adds a record of a client with the Unique Client ID
       *
       * @param client_id - Unique Client ID to add
       */
      static void add_client(Unique_Client_ID_T client_id);

      /**
       * Creates a hash value from the Unique Client ID
       *
       * @param value - value of the Unique Client ID
       *
       * @return - hashed value
       */
      static uint32_t hasher(Unique_Client_ID_T * value);

      static T          * m_Instance;        /**< pointer to the single instance of the object */
      static SAL_Mutex_T  m_Mutex;           /**< Mutex used to guard access to m_Instance */
      static blocklist  * client_table[256 /* make this configurable*/]; /**< Storage for all of the records of all clients of the Singleton object */
      static uint32_t     client_count;
};

/*===========================================================================*
 * Static Data Member Definitions
 *============================================================================*/
template <class T, typename Unique_Client_ID_T> T           * Singleton<T, Unique_Client_ID_T>::m_Instance = NULL;
template <class T, typename Unique_Client_ID_T> SAL_Mutex_T   Singleton<T, Unique_Client_ID_T>::m_Mutex    = SAL_MUTEX_INITIALIZER;
template <class T, typename Unique_Client_ID_T> blocklist   * Singleton<T, Unique_Client_ID_T>::client_table[256];
template <class T, typename Unique_Client_ID_T> uint32_t      Singleton<T, Unique_Client_ID_T>::client_count = 0;

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Template Method Definitions
 *===========================================================================*/

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> T * Singleton<T, Unique_Client_ID_T>::Get_Instance(Unique_Client_ID_T client_id)
{
   bool_t mutex_locked = false;

   mutex_locked = SAL_Lock_Mutex_Timeout(&m_Mutex, 1000);
   PBC_Require(mutex_locked,"Singleton::Get_Instance failed to lock mutex.");

   if (NULL == m_Instance)
   {
      Tr_Info_Lo("First client of Singleton. Creating instance.");

      m_Instance = new T();

      /* Create the client list */
      for (uint32_t i = 0; i < Num_Elems(client_table); i++)
      {
         create_blocklist(&client_table[i],
                          4 /* make this configurable*/,
                          sizeof(Unique_Client_ID_T),
                          false);
      }

      m_Instance->initialize();
   }

   add_client(client_id);

   SAL_Unlock_Mutex(&m_Mutex);

   return m_Instance;
}

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> void Singleton<T, Unique_Client_ID_T>::Destroy_Instance(Unique_Client_ID_T client_id)
{
   bool_t mutex_locked = false;

   mutex_locked = SAL_Lock_Mutex_Timeout(&m_Mutex, 1000);
   PBC_Require(mutex_locked,"Singleton::Destroy_Instance failed to lock mutex.");

   remove_client(client_id);

   if (    (0 == client_count)
        && (NULL != m_Instance))
   {
      Tr_Info_Lo("No remaining clients of a Singleton. Deleting instance.");
      delete m_Instance;
      m_Instance = NULL;

      /* Erase the client list */
      for (uint32_t i = 0; i < Num_Elems(client_table); i++)
      {
         dispose_blocklist(client_table[i]);
      }
   }
   SAL_Unlock_Mutex(&m_Mutex);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> int32_t Singleton<T, Unique_Client_ID_T>::find_client(Unique_Client_ID_T client_id)
{
   int32_t found_client_id_index = -1;
   uint32_t client_id_hash = hasher(&client_id);

   for (int32_t i = 0; i < client_table[client_id_hash]->d_num_items; i++)
   {
      Unique_Client_ID_T * client_id_ptr = (Unique_Client_ID_T *)blocklist_get(client_table[client_id_hash], i);

      if (*client_id_ptr == client_id)
      {
         found_client_id_index = i;
         break;
      }
   }

   return found_client_id_index;
}

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> void Singleton<T, Unique_Client_ID_T>::remove_client(Unique_Client_ID_T client_id)
{
   uint32_t client_id_hash = hasher(&client_id);
   int32_t found_client_id_index = find_client(client_id);

   /* Is there a record of this client? */
   if (-1 != found_client_id_index)
   {
      /* Client found. Remove it */
      blocklist_remove(client_table[client_id_hash], found_client_id_index);

      client_count--;

      Tr_Info_Lo_1("Singleton removed client. Total clients: %d", client_count);
   }
   else
   {
      Tr_Info_Lo("Client record does not exist. Cannot remove record.");
   }
}

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> void Singleton<T, Unique_Client_ID_T>::add_client(Unique_Client_ID_T client_id)
{
   uint32_t client_id_hash = hasher(&client_id);

   /* Is there not already a record of this client?*/
   if (-1 == find_client(client_id))
   {
      /* Record not found, add it */
      Tr_Info_Lo("Adding client to Singleton");

      blocklist_add(client_table[client_id_hash], &client_id);

      client_count++;

      Tr_Info_Lo_1("Singleton added client. Total clients: %d", client_count);
   }
   else
   {
      Tr_Info_Lo("Client record already exists. Cannot add record");
   }
}

/*===========================================================================*
 *
 * Please refer to the detailed description in Singleton class definition above.
 *
 *===========================================================================*/
template <class T, typename Unique_Client_ID_T> uint32_t Singleton<T, Unique_Client_ID_T>::hasher(Unique_Client_ID_T * value)
{
   uint32_t hashval = 0;
   uint32_t i       = 0;
   uint8_t * value_ptr = (uint8_t *)value;

   /* Process each character in the input string */
   for(i = 0; i < sizeof(Unique_Client_ID_T); i ++)
   {
      hashval += value_ptr[i];
      hashval += (hashval << 10);
      hashval ^= (hashval >> 6);
   }

   hashval += (hashval << 3);
   hashval ^= (hashval >> 11);
   hashval += (hashval << 15);

   /* Mask off the least significant MDE_HASH_BITS */
   hashval &= (HASH_BUCKETS - 1); /* See how it masks off the least 7 bits? */

   return hashval;
}

/* Eliminate the EM_F_ID so that users of this template can define their own EM_F_ID. */
#undef EM_F_ID

/*===========================================================================*/
/*!
 * @file Singleton.hpp
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 09-dec-2011 Kris Boultbee
 *   Task kok_basa#63497 Revision 3
 *   - Added initialize() method that will be automatically executed after
 *     construction of the object and registration of the client.
 *   - Made ~Singleton() virtual
 *
 * - 09-dec-2011 Kris Boultbee
 *   Task kok_basa#63433 Revision 2
 *   - Changed the declaration of the Debug Trace File ID to allow for the removal
 *     of the symbol name at the end of the file.
 *
 * - 01-dec-2011 Kris Boultbee
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SINGLETON_HPP */
