/*===========================================================================*/
/**
 * @file printf_gate.c
 *
 *  @brief Provides a mutex to synchronize use of printf
 *
 * %full_filespec:printf_gate.c~kok_basa#8:csrc:kok_aud#1 %
 * @version %version:kok_basa#8 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Fri Jul 29 07:32:01 2011 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2007 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *
 * ABBREVIATIONS:
 *   - EM = Error Management
 *
 * TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_BASA_Error_Management.doc (version 0.7)
 *
 *   - Requirements Document(s):
 *     - BASA_SRS_Error_Management_1.2.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @addtogroup em
 * @{
 */
/*==========================================================================*/

/*===========================================================================*\
 * Header Files
\*===========================================================================*/
#include "pbc_trace.h"
#include "printf_gate.h"
#include "printf_gate_cfg.h"
#include "reuse.h"

#ifndef PRINTF_GATE_STANDALONE
#   include "xsal_util.h"
#endif /* PRINTF_GATE_STANDALONE */

/*===========================================================================*\
 * Local Preprocessor #define Constants
\*===========================================================================*/
EM_FILENUM(TEST_MODULE_ID, 12); /* define this file for assert handling */

/*===========================================================================*\
 * Local Preprocessor #define MACROS
\*===========================================================================*/

#ifndef PRINTF_GATE_TIMEOUT
/** Maximum timeout to wait for semaphore */
#define PRINTF_GATE_TIMEOUT   (1000)
#endif

/*===========================================================================*\
 * Local Type Declarations
\*===========================================================================*/

/*===========================================================================*\
 * Exported Const Object Definitions
\*===========================================================================*/

/*===========================================================================*\
 * Local Object Definitions
\*===========================================================================*/

/** mutex to control access to printf 
 */
#ifndef PRINTF_GATE_STANDALONE
static SAL_Semaphore_T printf_gate;
#endif

/*===========================================================================*\
 * Local Function Prototypes
\*===========================================================================*/
#ifndef PRINTF_GATE_STANDALONE
static void pg_initialize(void);
#endif

/*===========================================================================*\
 * Local Inline Function Definitions and Function-Like Macros
\*===========================================================================*/

/*===========================================================================*\
 * Function Definitions
\*===========================================================================*/

#ifndef PRINTF_GATE_STANDALONE
/**
 * Creates the semaphore used to serialize printf (executes one time)
 */
static void pg_initialize(void)
{
   SAL_Semaphore_Attr_T sem_attr;
   bool_t ok;

   SAL_Init_Semaphore_Attr(&sem_attr);
   sem_attr.initial_value = 1;

   ok = SAL_Create_Semaphore(&printf_gate, &sem_attr);
   
   PBC_Ensure(ok, "Failed to create semaphore");
}
#endif

void Printf_Lock(void)
{
#ifndef PRINTF_GATE_STANDALONE
   /** tracks if initialization has been performed */
   static SAL_Util_Once_T printf_initialized = SAL_UTIL_ONCE_INIT;

   SAL_Util_Once(&printf_initialized, pg_initialize);

   (void) SAL_Wait_Semaphore_Timeout(&printf_gate, PRINTF_GATE_TIMEOUT);
#endif
}

void Printf_Unlock(void)
{
#ifndef PRINTF_GATE_STANDALONE
   (void) SAL_Signal_Semaphore(&printf_gate);
#endif
}

/*===========================================================================*\
 * File Revision History (top to bottom: last revision to first revision)
 *===========================================================================
 *
 * Date        Name      (Description on following lines: SCR #, etc.)
 * ----------- --------
 * 25-Jul-2010 Kirk Bailey Rev 7
 * + Replaced "bool" with "bool_t".
 *
 * 22-aug-2008 kirk bailey
 * + Added PRINTF_GATE_STANDALONE configuration option.
 *
 * 12-sep-2007 kirk bailey
 * + Change EM_ASSERT_ERROR args. so the module will build with QNX. The
 * + previous implementation only worked if the semaphore type was not a
 * + struct.
 *
 * 16-Aug-2007 Dan Carman
 * + Used self_init for thread safety
 * + MISRA changes
 *
 * 04-apr-2007 kirk bailey
 * + Created initial file.
 *
\*===========================================================================*/
/** @} doxygen end group */
