#ifndef HSM_ENGINE_CBK_H
#   define HSM_ENGINE_CBK_H
/*===========================================================================*/
/**
 * @file hsm_engine_cbk.h
 *
 * Callout declaration for hierarchical statechart engine.
 *
 * %full_filespec:hsm_engine_cbk.h~1:incl:kok_basa#1 %
 * @version %version:1 %
 * @author  %derived_by:dzq92s %
 * @date    %date_modified:Fri Sep  3 15:42:43 2010 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Declares the functions that must be implemented by a program that uses the
 * HSM engine.
 *
 * @section ABBR ABBREVIATIONS:
 *   - HSM = hierarchical state machine
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - SDD_10016705_State_Machine_Engine.doc
 *
 *   - Requirements Document(s):
 *     - SRS_10016705_State_Machine.doc
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup hsm_engine
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "hsm_engine.h"


#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * Returns a pointer to the string for the specified event's name. This is used
 * for debug trace messages. On systems that cannot afford to allocate memory
 * for event names, this function can simply return "", which will of course
 * reduce the usefulness of the debug trace messages.
 *
 * @return A non-NULL pointer to a string to be used for the event name.
 *
 * @param [in] event The event id value.
 */
char const *HSM_Get_Event_Name(HSM_Event_T event);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file hsm_engine_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 02-sep-2010 Kirk Bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* HSM_ENGINE_CBK_H */
