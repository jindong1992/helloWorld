#ifndef STATE_OF_HEALTH_H
#   define STATE_OF_HEALTH_H
/*===========================================================================*/
/**
 * @file state_of_health.h
 *
 *   Defines the interface used by XSAL threads for interfacing with the
 *   State of Health manager.
 *
 * %full_filespec:state_of_health.h~kok_basa#6:incl:kok_aud#2 %
 * @version %version:kok_basa#6 %
 * @author  %derived_by:dzw34w %
 * @date    %date_modified:Mon Feb 27 07:40:49 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   This is the interface for a thread to show its state of health to the
 *   system. Threads are required to periodically tell the system that they
 *   are alive and healthy. Valid state of health means that all threads are
 *   alive and functional.
 *
 * @section ABBR ABBREVIATIONS:
 *   - SoH - State of Health. 
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @defgroup state_of_health_grp State of Health Monitoring of individual threads
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "state_of_health_acfg.h"
#   include "reuse.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/
#ifndef SOH_DEFAULT_TIMEOUT_MS
#   error "SOH_DEFAULT_TIMEOUT_MS must be declare the system's default SOH timeout in state_of_health_acfg.h"
#endif

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/**
 * Marks the calling thread as alive and functioning for at least the specified
 * timeout period.
 *
 * @param timeout_mS Maximum time (mS) that thread should be considered alive. 
 *        See the definition of SOH_DEFAULT_TIMEOUT_MS for recommended default
 *        usage.
 *
 * @note Every thread shall call this function periodically while active. 
 */
void SOH_Alive(uint16_t timeout_mS);

/**
 * Marks the calling thread as dormant (inactive) and stops SOH monitoring
 * of it.
 *
 * @note
 * 
 * - If a thread does not call this function, before shutting down, the system
 *   will reset.
 * - If a thread calls SOH_Alive, after calling this function it will be back
 *   under active state of health monitoring.
 */
void SOH_Dormant(void);

/**
 * Initializes the State of Health Manager. This must be called once by the
 * single application (process) in the system that owns the state-of-health
 * manager thread. This call must occur before any of the other threads in
 * the SOH manager process register with and use the SOH manager.
 */
void SOH_Initialize(void);

/**
 * Initializes the SOH proxy library for any application (process) other than
 * the one in which the SOH manager thread runs. For single process systems,
 * this call is never used since the single process also contains the SOH
 * manager thread. For multi-process systems, this call must be made by each
 * non-SOH-manager application (process) before any of its threads call any of
 * the other SOH functions.
 *
 * @note
 *
 * - Single process systems will never use this call; they will use
 *   SOH_Initialize() instead.
 *
 * - In multi-process systems, the application (process) that owns the SOH
 *   manager thread will not call this function; it will call
 *   SOH_Initialize() instead. The other processes in the system will
 *   use this call.
 */
void SOH_Proxy_Initialize(void);

/**
 * Registers the calling thread with the SOH client and initializes its SOH
 * timer
 *
 * @param timeout_mS The time (mS) that thread should be considered alive.
 *        See the definition of SOH_DEFAULT_TIMEOUT_MS for recommended default
 *        usage.
 * 
 * @note Every thread shall call this function immediately upon startup
 */
void SOH_Register(uint16_t timeout_mS);

/**
 * Report the SOH status of this application's threads to the SOH manager.
 * This function should be called by one thread in each application (process)
 * upon receipt of the SOH_EVG_STATUS_QUERY message which is broadcast by the
 * SOH manager.
 */
void SOH_Report(void);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file state_of_health.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 27-Feb-2012 Jon Knoch
 *   - SCR 21723 (Task 79142) - Added #include of "state_of_health_acfg.h"
 *      to include definition of SOH_DEFAULT_TIMEOUT_MS.
 *
 * - 05-oct-2010 kirk bailey
 *   - SCR 3438 - Fixed extern C issues.
 *
 * - 14-jul-2008 kirk bailey
 *   - Added SOH_Report.
 *   - Added SOH_Proxy_Initialize() for multi-process systems.
 *
 * - 04-jun-2008 kirk bailey
 *   -Converted to new Doxygen comment format.
 *
 * - 26-Apr-2007 Dan Carman
 *   -Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* STATE_OF_HEALTH_H */
