#ifndef SOH_EVENT_ID_H
#   define SOH_EVENT_ID_H
/*===========================================================================*/
/**
 * @file soh_event_id.h
 *
 *    Defines XSAL events for the state-of-health manager.
 *
 * %full_filespec: soh_event_id.h~ctc_ec#6:incl:kok_aud#1 %
 * @version %version: ctc_ec#6 %
 * @author  %derived_by: jzt744 %
 * @date    %date_modified: Mon Mar 17 09:43:47 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   These declarations are included into the xsal_event_id module to be
 *   assigned unique values within the systems event space.
 *
 * @section ABBR ABBREVIATIONS:
 *   - SOH = state-of-health
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

#   define SOH_PUBLISHED_EVENTS\
    SAL_PUBLISHED_EVENT(SOH_EVG_STATUS_QUERY, "SOH manager request for status from all applications")\
    SAL_PUBLISHED_EVENT(SOH_EVG_RESET_PROCESS_NOTIFY, "SOH manager reset process notify message to all applications")

#   define SOH_PUBLIC_EVENTS

#   define SOH_PRIVATE_EVENTS\
    SAL_PRIVATE_EVENT(SOH_EV_FEED_WATCHDOG, "SOH Feed Watchdog")\
    SAL_PRIVATE_EVENT(SOH_EV_REPORT,        "SOH Status Report")\
    SAL_PRIVATE_EVENT(SOH_EV_GOING_DORMANT, "An applicaton (process) is going dormant.")

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
 
/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file soh_event_id.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 14-Mar-2014 Wang Le Rev 6
 *   - Add a message to notify all application after reset certain process. 
 *
 * - 23-May-2011 kirk bailey
 *   - Task 33048 - Added SOH_EV_GOING_DORMANT.
 *
 * - 05-oct-2010 kirk bailey
 *   - SCR 3438 - Fixed extern C issues.
 *
 * - 05-jun-2009 kirk bailey
 *   - task kok_aud52012: Update names of published events to EVG.
 *
 * - 14-jul-2008 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SOH_EVENT_ID_H */
