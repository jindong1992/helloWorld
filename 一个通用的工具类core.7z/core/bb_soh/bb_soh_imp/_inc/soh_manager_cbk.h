#ifndef SOH_MANAGER_CBK_H
#   define SOH_MANAGER_CBK_H
/*===========================================================================*/
/**
 * @file soh_manager_cbk.h
 *
 * Defines the implementation-specific callouts and constants that must be
 * provided by another module in the system
 *
 * %full_filespec:soh_manager_cbk.h~kok_basa#7:incl:kok_aud#1 %
 * @version %version:kok_basa#7 %
 * @author  %derived_by:jz4fpf %
 * @date    %date_modified:Mon Jun 18 15:56:29 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Isolates the implementation-specific constants and callouts so that the
 * remainder of the module can be reused without modification.
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @addtogroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Constant Objects that Must be Provided by the Application
 *===========================================================================*/

/**
 * The maximum number of messages that the SOH manager message queue will hold.
 * This value is controlled by the application so that it can be tuned for the
 * system. The SOH manager receives a periodic SOH_EV_FEED_WATCHDOG event to
 * manage the watchdog along with an SOH_EV_REPORT from each process in the
 * system. 
 */
extern size_t const SOH_Manager_Queue_Size;

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * Called when any registered system thread fails its state-of-health check.
 * The implementation decides what to do in this situation; typically, this
 * will lead to a system reset.
 */
void SOH_Fault_Detected(void);

/**
 * Dump system information on SOH faults
 */
void SOH_Dump(void);

/**
 * Called by the state-of-health manager when it decides that the system
 * watchdog should be fed. The implementation must map this to whatever
 * functionality is required to satisfy this need.
 */
void SOH_Feed_Watchdog(void);

/**
 * Called by the state-of-health manager initialization function
 * (SOH_Initialize) to initialize the system watchdog. The implementation
 * must map this to whatever functionality is required to satisfy this need.
 */
void SOH_Initialize_Watchdog(void);

/**
 * Returns the thread configuration for State of Health Manager thread.
 *
 * @param [out] attr Points to the caller-supplied thread attribute that
 *                   will be filled in with the attributes of the thread
 *                   for this system.
 *
 * @pre
 *    attr != NULL
 *
 * @post
 *    attr->id == SOH_MANAGER_THREAD_ID
 */
void SOH_Get_Manager_Thread_Attr(SAL_Thread_Attr_T *attr);

/**
 * This function signals when the State of Health Manager is fully initialized
 * and ready to be used by other modules.
 */
void SOH_Activated(void);

/*===========================================================================*/
/*!
 * @file soh_manager_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 05-jun-2009 kirk bailey
 *   - task kok_aud52033: Made queue size a callout constant.
 *
 * - 24-Sep-2008 David Origer
 *   - Added callout for when State of Health is activated.
 *
 * - 03-jun-2008 kirk bailey
 *   - Changed thread attribute constant to callout function.
 *   - Added SOH_Failure_Detected() and SOH_Feed_Watchdog() to decouple the
 *     module from other specific modules.
 *
 * - 30-Apr-2007 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* SOH_MANAGER_CBK_H */
