/*===========================================================================*/
/**
 * @file soh_manager.c
 *
 * Implements state of health manager for XSAL threads.
 *
 * %full_filespec:soh_manager.c~ctc_ec#21.1.1:csrc:kok_aud#1 %
 * @version %version:ctc_ec#21.1.1 %
 * @author  %derived_by:jzt744 %
 * @date    %date_modified:Mon Mar 17 09:45:04 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   The logic in this file runs within a single application (process) of the
 *   system and is responsible for monitoring all of the system's threads
 *   that register with it. This manager feeds the system watchdog only if all
 *   active (and registered) threads are in good standing. This requires the
 *   threads to meet the time commitments the make for "checking in" with the
 *   SOH manager. If any thread fails to meet its commitment, then this module
 *   executes a callout that can be used by the system to take corrective action
 *   (typically a system reset).
 *
 *   Each application (process) uses the soh_proxy logic defined in a separate
 *   library to interface to the manager. Each process keeps track of its
 *   threads and reports the cumulative results to this SOH manager in
 *   response the the manager's periodic status query (the broadcast of the
 *   SOH_EVG_STATUS_QUERY message).
 *
 * @section ABBR ABBREVIATIONS:
 *   - SOH = state-of-health
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @addtogroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <string.h>
#include <time.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/resource.h>

#include "pbc_trace.h"
#include "soh_private.h"
#include "soh_manager_cbk.h"
#include "state_of_health.h"
#include "state_of_health_cfg.h"
#include "soh_reset_process_manual.h"
#include "xsal.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(SOH_MODULE_ID, 1); /**< define file for assert handling */

/**
 * Maximum times to attempt timer creation
 */
#define SOH_CREATE_TIMER_RETRIES    5

/**
 * Multiplier for delay between attempting to create timer.
 */
#define SOH_CREATE_TIMER_DELAY      2

#ifndef SOH_FEED_DOG_TIME_MS
/**
 * Default Rate to feed watchdog and check SOH timers
 */
#   define SOH_FEED_DOG_TIME_MS 800

#endif

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/**
 * Maximum number of consecutive times that an app is allowed to not report
 * its SOH (after having reported it at least once) before it is considered
 * a fault.
 */
#ifndef SOH_MAX_MISSED_REPORTS
#define SOH_MAX_MISSED_REPORTS 3
#endif

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
#undef SOH_MANUAL_TS_RESET_APP 
#define SOH_MANUAL_TS_RESET_APP(EnableReset, Filename, Argv, Envp, Pid, Running) {EnableReset, {Filename, Argv, Envp, Pid, Running}, 0, 0},
	
SOH_RESET_PROCESS_MANUAL_T Reset_Process_Table[SAL_LAST_APP_ID - 1] =
{
	SOH_MANUAL_RESET_APPS
};

/**
 * Status of last SOH report (true = "ok") for app_id; only meaningful if the
 * corresponding feeding_count_at_report is non-zero, which indicates that
 * a report was made at least once by that application (process).
 *
 * @note The index into this array is (app_id - 1) since APP_ID zero is not used.
 */
static bool_t Application_Is_Ok[SAL_LAST_APP_ID - 1];

/**
 * Used to count watchdog feedings in order to detect whether any application
 * (process) stops responding to status queries. This counter never has the
 * value zero, which is used for an application that has not ever reported its
 * status.
 */
static uint8_t Feeding_Count = 1;

/**
 * Saves the value of Feeding_Count when each applicaton (process) last
 * reported its SOH status. A value of zero means no report was ever made by
 * the application (process).
 *
 * @note The index into this array is (app_id - 1) since APP_ID zero is not used.
 */
static uint8_t Feeding_Count_At_Report[SAL_LAST_APP_ID - 1];

static time_t now_time;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

static bool_t SOH_All_Apps_Are_Okay(void);
static void SOH_Handle_Watchdog(void);
static void SOH_Manager(void *param);
static void SOH_Process_Report(SAL_Application_Id_T app_id, bool_t is_ok);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/
/**
* Start a processes.  The process_info structure contains the filename to
* execute, along with any arguments and environment variables.  The structure
* is then populated with the PID and running status.
*/
void SOH_PH_Start_Process(SOH_PH_Process_Info_T * process_info)
{
	int status;
	struct rlimit rlim;

	process_info->running = true;

	/* Get limit of open file handles */
	if (getrlimit(RLIMIT_NOFILE, &rlim) < 0)
	{
		/* Very odd this would fail... */
		rlim.rlim_cur = 128;
	}

	process_info->pid = vfork();
	
	if (-1 == process_info->pid)
	{
		PBC_Failed_2("Unable for fork for %s (%s)", process_info->filename, strerror(errno));
	}
	
	if (0 == process_info->pid)
	{
		/* Child process */
		unsigned int i;

		/* Close any open file handles inherited from parent */
		for (i = 3; i < rlim.rlim_cur; i++)
		{
			close(i);
		}

		status = execve(
			(const char   *)process_info->filename,
			(char * const *)process_info->argv,
			(char * const *)process_info->envp
			);
		/* Should not return */
		if(-1 == status)
		{
			PBC_Failed_2("Process failed: %s (%s)", process_info->filename, strerror(errno));
		}
		_exit(0);
	}
	
	Tr_Info_Hi_2("Process started: %s, PID: %d", process_info->filename, process_info->pid);
}

static void Reset_Process_Manual(SAL_Application_Id_T app_index)
{
   SAL_Application_Id_T app_id;
   
   time(&now_time);

   /* Reset process every 30 seconds to void time of starting process too long */
   if( (Reset_Process_Table[app_index].reset_time == 0) || 
      (now_time - Reset_Process_Table[app_index].reset_time >= 30) )
   {
      Tr_Warn_2("SOH application %d failed, reset it, cmd is %s.\n", (int)(app_index+1), Reset_Process_Table[app_index].process_info.filename);
      SOH_PH_Start_Process(&Reset_Process_Table[app_index].process_info);
      time(&now_time);
      time(&Reset_Process_Table[app_index].reset_time);
      Reset_Process_Table[app_index].continuous_reset_cnt++;

      /* report the reset process id to all application */
      app_id = app_index+1;
      SAL_Publish(SOH_EVG_RESET_PROCESS_NOTIFY, &app_id, sizeof(app_id));
   }
}

/**
 * Checks the status of all applications (processes) that have ever reported
 * SOH status.
 *
 * @return true if all applications are in good standing; false otherwise..
 */
static bool_t SOH_All_Apps_Are_Okay(void)
{
   SAL_Application_Id_T app_index;
   bool_t ok = true;

   for (app_index = SAL_NO_APP_ID; app_index < SAL_LAST_APP_ID - 1; app_index++)
   {
      if (Feeding_Count_At_Report[app_index] != 0)
      {
         /* App has reported status at least once. */
         if (!Application_Is_Ok[app_index])
         {
				if(Reset_Process_Table[app_index].enable_reset == false)
				{
					Tr_Fault_1("SOH application %d failed", (int)(app_index+1));
					ok = false; /* This app reported a problem. */
					/* Clear error once reported */
					Application_Is_Ok[app_index] = true;
				}
				else
				{
					/* if process is still abnormal after reset 5 times, then reset the radio completely */
					if(Reset_Process_Table[app_index].continuous_reset_cnt < 5)
					{
						Reset_Process_Manual(app_index);
					}
					else
					{
						Tr_Fault_1("Application %d is still abnormal after reset 5 times, reset radio completely.\n", (int)(app_index+1));
						ok = false; /* This app reported a problem. */
						/* Clear error once reported */
						Application_Is_Ok[app_index] = true;						
					}
				}
			}
			else
			{
				uint8_t delta_count;

				delta_count = (uint8_t) (Feeding_Count - Feeding_Count_At_Report[app_index]);

				if (delta_count > SOH_MAX_MISSED_REPORTS)
				{
					if(Reset_Process_Table[app_index].enable_reset == false)
					{
						/* App checked in at least once but has missed its deadline. */
						ok = false;
						Tr_Fault_1("SOH application %d failed to report in", (int)(app_index+1));
						/* Clear error once it has been reported */
						Feeding_Count_At_Report[app_index] = 0;
					}				
				}

				if(delta_count > 0)
				{
					if(Reset_Process_Table[app_index].enable_reset == true) 
					{
						/* if process is still abnormal after reset 5 times, then reset the radio completely */
						if(Reset_Process_Table[app_index].continuous_reset_cnt < 5)
						{
							Reset_Process_Manual(app_index);
						}
						else
						{
							/* App checked in at least once but has missed its deadline. */
							ok = false;
							Tr_Fault_1("Application %d is still abnormal after reset 5 times, reset radio completely.\n", (int)(app_index+1));
							/* Clear error once it has been reported */
							Feeding_Count_At_Report[app_index] = 0;							
						}
					}
				}

				/* it means this process is running normal */
				if(delta_count == 0)
				{
					if( (Reset_Process_Table[app_index].enable_reset == true) &&
						 (Reset_Process_Table[app_index].reset_time > 0) &&
						 (Reset_Process_Table[app_index].continuous_reset_cnt > 0) )
					{
						Tr_Warn_1("Application %d have been resumed after reset.\n", (int)(app_index+1));
						/* clear continuous reset process count */
						Reset_Process_Table[app_index].reset_time = 0;
						Reset_Process_Table[app_index].continuous_reset_cnt = 0;
					} 
				}
      	}
      }
   }

   return ok;
}

/**
 * Checks the status of all the system's registered application threads and
 * feeds the system watchdog if all are in good standing. If any are not in
 * good standing, then a separate call is made to handle the fault.
 */
static void SOH_Handle_Watchdog(void)
{

   /*
    * Now check the SOH status of all processes to determine whether to
    * feed the watchdog, or to report a fault.
    */
   if (SOH_All_Apps_Are_Okay())
   {
      SOH_Feed_Watchdog();
      Tr_Info_Mid("SOH fed watchdog");
      /*
       * Increment the Feeding_Count so that future reports can be
       * distinguished from past ones.
       */
      if (255 == Feeding_Count)
      {
         /* A count of zero is reserved to mean "never reported". */
         Feeding_Count = 1;
      }
      else
      {
         Feeding_Count++;
      }
      /*
       * Publish an event to trigger all apps to report their SOH status. These
       * reports will be checked the next time this function is run.
       */
      SAL_Publish(SOH_EVG_STATUS_QUERY, NULL, 0);
   }
   else
   {
      SOH_Dump();    /* dump any system information */
      SOH_Fault_Detected();
   }
}

/*===========================================================================*
 *
 * Please refer to the detailed description in SOH_manager.h
 *
 *===========================================================================*/
void SOH_Initialize(void)
{
   SAL_Thread_Attr_T attr;
   SAL_Thread_Id_T tid;

   SOH_Initialize_Watchdog();

   SOH_Get_Manager_Thread_Attr(&attr);
   PBC_Require_1(SOH_MANAGER_THREAD_ID == attr.id,
      "Wrong SOH tid: %d", (int)attr.id);

   tid = SAL_Create_Thread(SOH_Manager, NULL, &attr);

   PBC_Require_1(SOH_MANAGER_THREAD_ID == tid, "Wrong SOH tid: %d", (int)tid);

}

/**
 * SOH Manager Task
 *
 *  Creates a message queue
 *  Creates and start a periodic timer to feed watchdog and request SOH status
 *  from all applications (processes) in the system.
 *  Enter endless loop waiting for messages
 *    - Verify application (process status) and feed watchdog 
 */
static void SOH_Manager(void *param)
{
   bool_t ok;
   SAL_Timer_Id_T update_watchdog;

   (void) param; /* Eliminate unused variable warning */
   ok = SAL_Create_Queue(SOH_Manager_Queue_Size, sizeof(SOH_EV_REPORT_T), SAL_Alloc, SAL_Free);
   PBC_Ensure(ok, "SOH queue creation failed");

   {
      int retries = SOH_CREATE_TIMER_RETRIES;
      ok = false;

      while (!ok && retries--)
      { /* delay to allow procman to start */
         SAL_Sleep((SOH_CREATE_TIMER_RETRIES - retries) * SOH_CREATE_TIMER_DELAY);
         ok = SAL_Create_Timer(SOH_EV_FEED_WATCHDOG, &update_watchdog);
         if (!ok)
         {
            /* Failure to create timer, probably because procman is not fully initialized yet */
            Tr_Warn("Failed to create SOH Watcfhdog Timer");
         }
      }
   }
   PBC_Ensure(ok, "SOH timer creation failed");

   SAL_Start_Timer(update_watchdog, SOH_FEED_DOG_TIME_MS, true);

   SAL_Signal_Ready();

   SOH_Activated();

   while (true)
   {
      const SAL_Message_T *msg;

      msg = SAL_Receive_Timeout(2 * SOH_FEED_DOG_TIME_MS);

      if (NULL == msg)
      {
         Tr_Warn("SOH failed to receive any status or timer events");
         SOH_Dump();
         SOH_Handle_Watchdog(); /* limp along - handle as if timer message was received */
      }
      else
      {
         switch (msg->event_id)
         {
            case SOH_EV_FEED_WATCHDOG:
#if defined (XSAL)
               /*
                * For Linux, the timer sever is located in procman process
                *   so if we get the timer message, it means procman is still running
                */
               SOH_Process_Report(APP_PROCMAN, true);
#endif
               SOH_Handle_Watchdog();
               break;

            case SOH_EV_REPORT:
            {
               bool_t is_ok = *((SOH_EV_REPORT_T*) msg->data);
               SOH_Process_Report((SAL_Application_Id_T) msg->sender_app_id, is_ok);
               break;
            }

            case SOH_EV_GOING_DORMANT:
            {
               SAL_Application_Id_T app_id = (SAL_Application_Id_T) msg->sender_app_id;

               Tr_Info_Mid_1("App: %d going dormant", (int)app_id);

               app_id--; /* app_id zero is not used. */
               Feeding_Count_At_Report[app_id] = 0; /* no more reports expected */
               Application_Is_Ok[app_id] = true;
               break;
            }

            default: /* unknown event */
               Tr_Warn_3("SOH received unknown message - app:%d; tid:%d; event:%d",
                  (int)msg->sender_app_id, (int)msg->sender_thread_id,
                  (int)msg->event_id);
               break;

         } /* switch (msg->event_id) */

      } /* if (NULL == msg) */
   }
}

/**
 * Processes the SOH status reported by an application (process).
 *
 * @param [in] app_id The application (process) reporting the status of its
 *                    threads.
 * @param [in] is_ok True if all threads in the application are in good
 *                   standing as of this report; false otherwise.
 */
static void SOH_Process_Report(SAL_Application_Id_T app_id, bool_t is_ok)
{
   PBC_Require_1((app_id >= SAL_FIRST_APP_ID) && (app_id < SAL_LAST_APP_ID),
      "SOH report with illegal app_id: %d", (int)app_id);

   Tr_Info_Mid_2("Report from app: %d - %s", (int)app_id,
      (is_ok ? "OK" : "FAILED"));

   app_id--; /* app_id zero is not used. */
   Feeding_Count_At_Report[app_id] = Feeding_Count;
   Application_Is_Ok[app_id] = is_ok;
}

/*===========================================================================*/
/*!
 * @file SOH_manager.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 14-Mar-2014 Wang Le Rev 22
 *   - Reset process if it was abnormal and did not want to reset radio completely.
 *
 * 14Feb12  David Origer (hz1941)  Rev 19
 * SCR kok_basa#21723 : Increased SOH_MAX_MISSED_REPORTS and made it possible
 *    to configure it.
 *
 * - 16-Jan-2011 Dan Carman
 *    On SBX, SOH Manager was attempting to create Feed Watchdog timer before procman is ready.
 *    Added monitoring of procman / timer server 
 *
 * - 30-Nov-2011 Kirk Bailey
 *   - Added FAULT message for an application that reports a failure.
 *
 * - 14-Nov-2011 Brian Bolinger
 *   - CR 17723 - Removed feeding the watchdog at the beginning of the SOH Manager Task.  The
 *   watchdog should already be fed in the initialization, and this refeeding was causing a
 *   message to be sent to a task that had not yet been created.
 *
 * - 23-May-2011 kirk bailey
 *   - Task 33048 - Added SOH_EV_GOING_DORMANT logic.
 *
 * - 30-Nov-2010 Dan Carman
 *   - Appman is now running SOH_Proxy. No longer local link for current process.
 *
 * - 25-Jul-2010 Kirk Bailey Rev 8
 *   - Replaced "bool" with "bool_t".
 *
 * - 05-jun-2009 kirk bailey
 *   - task kok_aud52012: Update names of published events to EVG.
 *   - task kok_aud52022: Update names to use mixed case.
 *   - task kok_aud52030: Rename soh_types.h to something more appropriate.
 *   - task kok_aud52033: Made queue size a callout constant.
 *   - task kok_aud52042: Add a break at the end of the default case in thread.
 *
 * - 24-Sep-2008 David Origer
 *   - Added callout for when State of Health is activated.
 *
 * - 17-aug-2008 kirk bailey
 *   - Converted to new trace logic.
 *
 * - 03-jun-2008 kirk bailey
 *   - Moved proxy routines into a separate file.
 *   - Put SOH manager in application SOH_APP_ID.
 *   - Added support for multiple processes.
 *   - Changed names to follow guidelines.
 *   - Made unknown messages/timeouts warnings, not fatal errors.
 *
 * - 12-Sept-2007 Dan Carman
 *   - Changed constant for uninitialized SoH task detection.
 *   - Nonfunctional MISRA / QAC changes.
 *
 * - 24-May-2007 kirk bailey
 *   - Fixed spelling of "Elapsed".
 *
 * - 14-May-2007 kirk bailey
 *   -Updated to match BASA event naming conventions.
 *
 * - 11-May-2007 Dan Carman
 *   - Added a pre-condition to verify that SOH_Initialize is called only once
 *   - Added Information trace (low) of requests to update alive timers and feed
 *     dog 
 *
 * - 26-apr-2007 Dan Carman
 *   -Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
