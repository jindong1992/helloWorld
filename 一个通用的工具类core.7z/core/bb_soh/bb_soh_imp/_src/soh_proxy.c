/*===========================================================================*/
/**
 * @file soh_proxy.c 
 *
 *   Implements the functions that communicate to the SOH manager.
 *
 * %full_filespec:soh_proxy.c~ctc_ec#23.1.3:csrc:kok_aud#1 %
 * @version %version:ctc_ec#23.1.3 %
 * @author  %derived_by:jzt744 %
 * @date    %date_modified:Mon Mar 17 10:13:41 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008-2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * The functions implemented in this file run in the thread that is
 * communicating to the SOH manager. This segregation is important for multi-
 * process systems because these threads may also be in separate processes.
 * By segregating these communication functions into a separate object file,
 * this module can support both single and multiple process systems.
 *
 * @section ABBR ABBREVIATIONS:
 *   - SOH - state-of-health
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - "None".
 *
 * @addtogroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "soh_private.h"
#include "state_of_health.h"
#include "state_of_health_cfg.h"
#include <string.h>
#include "xsal_util.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(SOH_MODULE_ID, 2); /**< define file for assert handling */

/** timer valid time setting indicating that timer is not in use */
#define SOH_INACTIVE    (0)

#ifndef SOH_MULTIPLER
/**
 * Default SOH time multipler
 *    Use to systematically increase SOH timeouts  
 */
#define SOH_MULTIPLER   (1)
#endif 

#ifndef SOH_MIN_ALIVE_MS
/**
 * Default SOH minimum alive time
 */
#define SOH_MIN_ALIVE_MS   (15 * 1000)
#endif 

#ifndef SOH_MAX_ALIVE_MS
/**
 * Default SOH maximum alive time
 */
#define SOH_MAX_ALIVE_MS   (60 * 1000)
#endif 

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/** 
 * SoH timer definition
 */
typedef volatile uint32_t SOH_Alive_Timer_T;

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * Stores timers for all threads
 */
static SOH_Alive_Timer_T * volatile SOH_Timers = NULL;

/**
 * Number of SoH timers allocated 
 */
static size_t SOH_Num_Timers = 0;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static bool_t Has_Thread_Timed_Out(uint_fast16_t thread_idx, uint32_t now);
static bool_t Are_All_Threads_Okay(void);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/** 
 * Converts a thread index back into thread ID
 */
#define Index_To_Thread_Id(thread_idx)  ((SAL_Thread_Id_T)((thread_idx) + 1))

/** 
 * Converts a thread id into the appropriate index into the SOH timers
 */
#define Thread_Id_To_Index(thread_id)  ((uint_fast16_t)((thread_id) - 1))

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*
 *
 * Please refer to the detailed description in state_of_health.h
 *
 *===========================================================================*/
void SOH_Alive(uint16_t timeout_mS)
{
   SAL_Thread_Id_T tid = SAL_Get_Thread_Id();
   SAL_Application_Id_T app_id = (SAL_Application_Id_T) SAL_Get_App_Id();
   uint_fast16_t thread_index = Thread_Id_To_Index(tid);
   uint32_t now = (uint32_t) SAL_Clock();
   uint32_t alive_time_ms;

   /* Verify that SOH_Initialize was called */
   PBC_Ensure(NULL != SOH_Timers, "NULL timer array");
   PBC_Ensure(thread_index < SOH_Num_Timers, "Thread ID too large");
   /*
    * Check if thread had missed it previous deadline so that a warning will be
    * issued for threads that barely avoided missing their deadlines. This is
    * only a warning since the thread is obviously still running; however, this
    * could have been an SOH failure if the manager had run first.
    */
   Has_Thread_Timed_Out(thread_index, now);
   /*
    * NOTES:
    *   1) No thread synchronization is required as long as the target
    *      processor supports atomic 32-bit reads and writes.
    *   2) Rollover was considered an acceptable risk since the 32-bit
    *      clock only rolls over every 49.71 days and this would have
    *      to then coincide with the thread malfunctioning. 
    */
   alive_time_ms = (timeout_mS * SOH_MULTIPLER);
   if (alive_time_ms > SOH_MAX_ALIVE_MS)
   {
      alive_time_ms = SOH_MAX_ALIVE_MS;
      Tr_Info_Hi_2("Excessive Alive time. %d mS reduced to %d mS", (int) timeout_mS, SOH_MAX_ALIVE_MS);
   }
   else if (alive_time_ms < SOH_MIN_ALIVE_MS)
   {
      alive_time_ms = SOH_MIN_ALIVE_MS;
      Tr_Info_Hi_2("Use larger Alive time. %d mS increased to %d mS", (int) timeout_mS, SOH_MIN_ALIVE_MS);
   }

   SOH_Timers[thread_index] = now + alive_time_ms;

   Tr_Info_Mid_3("SOH Alive (%d/%d) for: %d mS",
      (int)app_id, (int)tid, (int)timeout_mS);
}

/**
 * Checks all thread timers in the application (process) and returns an
 * indication of their health.
 *
 * @return True if all threads in the application (process) are in good
 *         standing; false otherwise.
 */
static bool_t Are_All_Threads_Okay(void)
{
   uint_fast16_t thread_index;
   bool_t ok = true;
   uint32_t now;

   now = SAL_Clock();

   for (thread_index = 0; thread_index < SOH_Num_Timers; thread_index++)
   {
      if (Has_Thread_Timed_Out(thread_index, now))
      {
         ok = false;
      }
   }

   return ok;
}

/*===========================================================================*
 *
 * Please refer to the detailed description in state_of_health.h
 *
 *===========================================================================*/
void SOH_Dormant(void)
{
   SAL_Thread_Id_T tid = SAL_Get_Thread_Id();
   SAL_Application_Id_T app_id = (SAL_Application_Id_T) SAL_Get_App_Id();
   bool_t process_active = false;
   uint_fast16_t thread_index = Thread_Id_To_Index(tid);

   /** Verify that SOH_Initialize was called */
   PBC_Ensure(NULL != SOH_Timers, "NULL timer array");
   PBC_Ensure(thread_index < SOH_Num_Timers, "Thread ID too large");

   SOH_Timers[thread_index] = SOH_INACTIVE;
   Tr_Info_Mid_2("SOH_Dormant: %d/%d", (int)app_id, (int)tid);
   /*
    * Check to see if all the threads in the process are now dormant. If so,
    * notify the SOH manager so it doesn't require periodic reports from
    * the process. Note that the process will be required to report in
    * again if it calls SOH_Report() in the future.
    */
   for (thread_index = 0; thread_index < SOH_Num_Timers; thread_index++)
   {
      if (SOH_Timers[thread_index] != SOH_INACTIVE)
      {
         process_active = true;
         break;
      }
   }
   if (!process_active)
   {
      SAL_Send(SOH_APP_ID, SOH_MANAGER_THREAD_ID, SOH_EV_GOING_DORMANT, NULL, 0);
   }
}

/**
 * Determines if a thread had timed out
 *    Logs thread ID if time out had occurred 
 *
 * @param thread_index index to Thread's timer (one less than ID)
 * @param now Timestamp to check against
 *
 * @return true if thread's alive timer is expired
 */
static bool_t Has_Thread_Timed_Out(uint_fast16_t thread_index, uint32_t now)
{
   /*
    * NOTE: No thread synchronization is required as long as the target
    *       processor supports atomic 32-bit reads and writes.
    */
   uint32_t alive_time = SOH_Timers[thread_index];
   bool_t timed_out = false; /* assume thread id is OK */

   if (SOH_INACTIVE != alive_time)
   {
      /* Note: A delta is computed; hence, wrap-around is handled. */
      int32_t time_left = (int32_t) (alive_time - now);

      if (time_left < 0)
      {
         SAL_Application_Id_T app_id = (SAL_Application_Id_T) SAL_Get_App_Id();
         timed_out = true;
         Tr_Fault_2("SOH timeout for app/thread: %d/%d",
            (int)app_id, (int)Index_To_Thread_Id(thread_index));
      }
   }
   return timed_out;
}

/*===========================================================================*
 *
 * Please refer to the detailed description in state_of_health.h
 *
 *===========================================================================*/
void SOH_Proxy_Initialize(void)
{
   /** SOH_Initialize may be called only once */
   PBC_Require(NULL == SOH_Timers, "Multiple SOH_Proxy_Initialize() calls");

   SOH_Num_Timers = SAL_Get_Max_Number_Of_Threads();

   SOH_Timers = SAL_Alloc(SOH_Num_Timers * sizeof(*SOH_Timers));
   PBC_Ensure(NULL != SOH_Timers, "NULL timer array");
   memset((void*) SOH_Timers, SOH_INACTIVE, SOH_Num_Timers * sizeof(*SOH_Timers));
}

/*===========================================================================*
 *
 * Please refer to the detailed description in state_of_health.h
 *
 *===========================================================================*/
void SOH_Register(uint16_t timeout_mS)
{
   SOH_Alive(timeout_mS);
}

/*===========================================================================*
 *
 * Please refer to the detailed description in state_of_health.h
 *
 *===========================================================================*/
void SOH_Report(void)
{
   SOH_EV_REPORT_T ok;

   ok = Are_All_Threads_Okay();

   SAL_Send(SOH_APP_ID, SOH_MANAGER_THREAD_ID, SOH_EV_REPORT, &ok, sizeof(ok));
}

/*===========================================================================*/
/*!
 * @file SOH_proxy.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 23-May-2011 kirk bailey
 *   - Task 33048 - Added SOH_EV_GOING_DORMANT logic.
 *
 * - 25-Jul-2010 Kirk Bailey Rev 18
 *   - Replaced "bool" with "bool_t".
 *
 * - 17-Aug-2009 Dan Carman
 *   - Added a SoH Multipler to effectively increase timeouts on a global basis.
 *       High system throughput was leading to false SOH errors (tasks were starving
 *       rather than locking up).  Especially an issue during system startup.
 *
 * - 18-jun-2009 kirk bailey
 *   - task kok_aud52967: Fixed volatile on SOH_Timers..
 *
 * - 17-jun-2009 kirk bailey
 *   - task kok_aud52891: Fixed initialization of SOH timers in SOH proxy.
 *   - Eliminated second warning if timeout is detected in SOH_Alive()
 *
 * - 05-jun-2009 kirk bailey
 *   - task kok_aud52022: Update names to use mixed case.
 *   - task kok_aud52027: Add comments for timer wrap around analysis.
 *   - task kok_aud52030: Rename soh_types.h to something more appropriate.
 *
 * - 15-Oct-2008 Jaime Almeida
 *   - Updated SOH_Report tu use SAL_Send instead of SAL_Util_Send
 *
 * - 17-aug-2008 kirk bailey
 *   - Converted to new trace logic.
 *
 * - 03-jun-2008 kirk bailey
 *   - Split state_of_health.c into two files to separate manager logic from
 *     proxy logic.
 *   - Added support for multiple processes.
 *
 * - 18-Jun-2008 Dan Carman
 *   - Significant implementation change to reduce messages and throughput usage.
 *     The previous design while seeming clean was effectively doubling the XSAL
 *     message traffic and tripling the context switches.
 *   - In the new design, a thread's alive call directly updates its timer,
 *     instead of sending message to have SoH manager do it. To support this the
 *     alive timers data structure was reduce to a single 32 bit value per
 *     thread to allow atomic updates and reads. 
 *
 * - 12-Sept-2007 Dan Carman
 *   - Changed constant for uninitilazed SoH task detection.
 *   - Nonfunctional MISRA / QAC changes.
 *
 * - 24-May-2007 kirk bailey
 *   - Fixed spelling of "Elasped".
 *
 * - 14-May-2007 kirk bailey
 *   - Updated to match BASA event naming conventions.
 *
 * - 11-May-2007 Dan Carman
 *   - Added a pre-condition to verify that SOH_Initialize is called only once
 *   - Added Information trace (low) of requests to update alive timers and feed
 *     dog 
 *
 * - 26-apr-2007 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
