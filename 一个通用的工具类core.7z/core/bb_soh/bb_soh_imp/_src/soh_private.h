#ifndef SOH_TYPES_H
#   define SOH_TYPES_H
/*===========================================================================*/
/**
 * @file soh_private.h
 *
 * Declarations common to the state of health manager and proxy implementations.
 *
 * %full_filespec:soh_private.h~ctc_ec#6.1.1:incl:kok_aud#1 %
 * @version %version:ctc_ec#6.1.1 %
 * @author  %derived_by:jzt744 %
 * @date    %date_modified:Mon Mar 17 09:47:29 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008, 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   These types are private to the SOH implementation and are public only
 *   to allow the implementation to be in multiple C files.
 *
 * @section ABBR ABBREVIATIONS:
 *   - SOH = state-of-health
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - sdd_basa_state_of_health.doc
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup state_of_health_grp
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#   include <time.h>

#include "process_handler.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/**
 * Type of data associated with the SOH_EV_REPORT event; true means that the
 * SOH of the application's threads is okay.
 */
typedef bool_t SOH_EV_REPORT_T;

typedef struct
{
   char  * filename; 
   char ** argv;
   char ** envp;
   pid_t   pid;
   bool_t  running;
} SOH_PH_Process_Info_T;

typedef struct SOH_RESET_PROCESS_MANUAL_Tag
{
	bool_t                enable_reset;
	SOH_PH_Process_Info_T process_info;
	time_t                reset_time;
	uint8_t               continuous_reset_cnt;
} SOH_RESET_PROCESS_MANUAL_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file soh_private.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 14-Mar-2014 Wang Le Rev 7
 *   - Reset process if it was abnormal and did not want to reset radio completely. 
 *
 * - 30-Nov-2010 Dan Carman
 *   - Appman is now running SOH_Proxy. No longer local link for current process.
 *
 * - 25-Jul-2010 Kirk Bailey Rev 5
 *   - Replaced "bool" with "bool_t".
 *
 * - 05-jun-2009 kirk bailey
 *   - task kok_aud52030: Rename soh_types.h to something more appropriate.
 *
 * - 17-aug-2008 kirk bailey
 *   - Converted to new trace logic.
 *
 * - 03-jun-2008 kirk bailey
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* SOH_TYPES_H */
