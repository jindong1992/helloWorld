#ifndef APM_EVENT_ID_H
#   define APM_EVENT_ID_H
/*===========================================================================*/
/**
 * @file apm_event_id.h
 *
 *    Defines XSAL events for the Application Manager.
 *
 * %full_filespec:  apm_event_id.h~kok_basa#6:incl:kok_aud#1 %
 * @version %version:  kok_basa#6 %
 * @author  %derived_by:  bzt837 %
 * @date    %date_modified:  Wed Sep 26 16:21:44 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *   These declarations are included into the xsal_event_id module to be
 *   assigned unique values within the systems event space.
 *
 * @section ABBR ABBREVIATIONS:
 *   - APM = Application Manager
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - none
 *
 *   - Requirements Document(s):
 *     - none
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - none
 *
 * @ingroup application_manager
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

#   define APM_PUBLISHED_EVENTS \
    SAL_PUBLISHED_EVENT(APM_EVG_START_STOP, "APM Start/Stop") \
    SAL_PUBLISHED_EVENT(APM_EVG_READY_STATUS,"APM Ready") \

#   define APM_PUBLIC_EVENTS

#   define APM_PRIVATE_EVENTS \
    SAL_PRIVATE_EVENT(APM_EV_ACTIVATED,  "APM Activated") \
    SAL_PRIVATE_EVENT(APM_EV_TERMINATED, "APM Terminated") \

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
 
/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file apm_event_id.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * - 26-Sep-2012 Chris Edgington
 *   - Changed SAL_PRIVATE_EVENT to SAL_PUBLISHED_EVENT in APM_PUBLISHED_EVENTS
 *
 * - 15-July-2011 Dan Carman
 *   - Changed Start/Stop and Ready Status to Publish events to allow coordination
 *       between mutliple AppMans
 *
 * - 08-dec-2009 Kirk Bailey
 *   - Task kok_basa 2165: Turned on Synergy Translate ASCII file option
 *
 * - 18Sep08  David Origer Rev 2
 *   - SCR kok_aud#56890 : Generate Doxygen documentation.
 *
 * - 28Aug08 David Origer
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* SOH_EVENT_ID_H */
