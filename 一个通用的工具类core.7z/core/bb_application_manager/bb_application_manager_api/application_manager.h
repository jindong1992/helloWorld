#ifndef APPLICATION_MANAGER_H
#   define APPLICATION_MANAGER_H
/*===========================================================================*/
/**
 * @file application_manager.h
 *
 * API header file for the Application Manager.
 *
 * %full_filespec:application_manager.h~kok_basa#16:incl:kok_aud#1 %
 * @version %version:kok_basa#16 %
 * @author  %derived_by:bzt837 %
 * @date    %date_modified:Tue Oct  2 16:11:18 2012 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API header file for the Application Manager.  This header file provides the
 * functional interface for the Application Manager.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @defgroup application_manager API for Application Manager
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "application_manager_acfg.h"
#   include "reuse.h"
#   include "xsal.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

#   undef APM_AP_READY_STATUS
#   define APM_AP_READY_STATUS(status) status,
/**
 * Defines the AP readiness levels.
 */
typedef enum
{
   APM_READY_INIT,         /* Must be first element */
   
   APM_AP_READY_STATUS_LIST
   
   APM_AP_READY_UNKNOWN    /* Must be last element */
}
APM_AP_Ready_Status_T;

/**
 * Defines the AP readiness status level for APM_EVG_READY event.
 */
typedef struct APM_EVG_READY_Tag
{
   APM_AP_Ready_Status_T status;
   SAL_App_Id_T          process;
   
} APM_EVG_READY_T;

/**
 * Defines the AP readiness status level for APM_EVG_START_STOP event.
 */
typedef struct APM_EVG_START_STOP_Tag
{
   APM_AP_Ready_Status_T target_status;
   SAL_App_Id_T          process;
} APM_EVG_START_STOP_T;

/**
 * Defines the application IDs for APM_EV_ACTIVATED event.
 */
typedef uint16_t APM_EV_ACTIVATED_T;

/**
 * Defines the application IDs for APM_EV_TERMINATED event.
 */
typedef uint16_t APM_EV_TERMINATED_T;

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/**
 * The application calls this function when it is fully initialized and ready
 * to be used by other applications.
 *
 * @param [in] app_id Id of application that is now activated.
 */
void APM_Activated(uint16_t app_id);

/**
 * The application calls this function when it is done shutting down.
 *
 * @param [in] app_id Id of application that shut down.
 */
void APM_Terminated(uint16_t app_id);

/**
 * This function is called when enough other applications have been started
 * to allow Application Manager to send the initial READY NULL event.
 */
void APM_Initialize(void);

/**
 * This function is called when it is time to shut down the application
 * manager.  In order to ensure the "ready nothing" message goes out over
 * DESIP, this function will not return so the DESIP code will not be shutdown.
 */
void APM_Shutdown(void);

/**
 * The application calls this function when it wants to start or stop
 * the AP.
 *  
 * @param [in] ready_status The level of functionality desired.
 *
 */
void APM_Start_Stop(APM_AP_Ready_Status_T ready_status);

/**
 * The application calls this function when it wants to start or stop
 * the AP.
 *  
 * @param [in] ready_status The level of functionality desired.
 * @param [in] process The particular AppMan instance being controlled
 *
 */
void APM_Start_Stop_Process(APM_AP_Ready_Status_T ready_status, SAL_App_Id_T process);

/**
 * The application is the entry point from the initial startup code to the
 * Application Manager.
 */
void Application_Initialization(void);

/**
 * Dump current application status bits in table format 
 */
void APM_Dump_App_Status(void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
/*===========================================================================*/
/*!
 * @file application_manager.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 15-July-2011 Dan Carman
 *   - Add API (APM_Start_Stop_Process) to Start/Stop an AppMan in another process
 *
 * - 29-Oct-2010 Kirk Bailey Rev 14
 *   - Task 15929: Minor modifications after review feedback.
 *
 * - 27-Oct-2010 Kirk Bailey Rev 13
 *   - Task 15623: Altered app man to be usable by multiple processes.
 *
 * - 08-dec-2009 Kirk Bailey
 *   - Task kok_basa 2165: Turned on Synergy Translate ASCII file option
 *
 * - 26May09  David Origer  Rev 11
 *   - SCR kok_aud#60808 : Implement review action items.
 *
 * - 17Nov08  David Origer
 *   - SCR kok_aud#58060 : Add capability for multiple ready levels.
 *
 * - 20Oct08  David Origer Rev 9
 *   - SCR kok_aud#57256 : Make AP send "ready nothing" on shutdown.
 *
 * - 18Sep08  David Origer Rev 8
 *   - SCR kok_aud#56890 : Generate Doxygen documentation.
 *
 * - 16Sep08  David Origer  Rev 2
 *   - SCR kok_aud#56931 : Implement monitoring code using debug trace.  With this
 *                     change, it is possible to view the sequence and timing
 *                     of changes to AP Ready Status and of the initialization
 *                     shutdown of individual applications.  The AP Ready
 *                     Status information can be viewed by setting the trace
 *                     level to "info mid" while application init and shutdown
 *                     can be viewed by setting the trace level to "info low."
 *
 * - 18Aug2008 David Origer
 *   - SCR kok_aud#55337 : Added include of reuse.h.
 *
 * - 18Aug2008 David Origer
 *   - SCR kok_aud#55337 : Added prototypes for APM_Activated() and
 *                       APM_Terminated().
 *
 * - 15Aug2008 David Origer
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif                          /* APPLICATION_MANAGER_H */
