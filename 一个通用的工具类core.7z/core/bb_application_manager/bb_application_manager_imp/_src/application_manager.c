/*===========================================================================*/
/**
 * @file application_manager.c
 *
 * Source code file for the Application Manager.
 *
 * %full_filespec:application_manager.c~ctc_ec#38:csrc:kok_aud#1 %
 * @version %version:ctc_ec#38 %
 * @author  %derived_by:xzhgs6 %
 * @date    %date_modified:Wed Sep  2 09:14:01 2015 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Source code file for the Application Manager.  This file implements the core
 * functionality for initializing and shutting down applications.
 *
 * NOTE: Future implementations will allow for intermediate states besides
 *       NOTHING/ALL.  This module will not handle standby-type reduced power
 *       modes.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup application_manager
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "application_manager.h"
#include "application_manager_cbk.h"
#include "bit_array.h"
#include "pbc_trace.h"
#include "state_of_health.h"
#include <string.h>
#include <stdio.h>
#include "xsal.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(APPLICATION_MANAGER_MODULE_ID, 0); /* Identifies file for PbC/trace */

#define APM_SAL_RECEIVE_TIMEOUT_MS  (10000)

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**
 * Configuration for app man provided by the containing process. To allow
 * app man to be used in multiple processes, all of the configuration is
 * done dynamically.
 */
static APM_Configuration_T const *APM_Config;

/**
 * Keeps track of the applications that have been activated.
 */
static uint8_t *APM_Activated_Apps;

/**
 * Keeps track of the applications that have been terminated.
 */
static uint8_t *APM_Terminated_Apps;

/**
 * Keeps track of the applications whose "activate" function has been called.
 */
static uint8_t *APM_Activate_Called;

/**
 * Keeps track of the applications whose "terminate" function has been called.
 */
static uint8_t *APM_Terminate_Called;

/**
 * Target ready status to which all applications are moving.
 */
static APM_AP_Ready_Status_T APM_Ready_Status_Target = APM_AP_READY_UNKNOWN;

/**
 * Last application status achieved by all applications.
 */
static APM_AP_Ready_Status_T APM_Actual_Ready_Status = APM_READY_INIT;

#undef APM_AP_READY_STATUS
#define APM_AP_READY_STATUS(status) #status,
/**
 * Table of ready status names for debugging purposes.
 */
static const char *APM_AP_Ready_Status_Names[] =
{
  "APM_READY_INIT",
   APM_AP_READY_STATUS_LIST
   "APM_AP_READY_UNKNOWN"    /* Must be last element */
};

static bool_t APM_In_Transition = true;

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void APM_Handle_Start_Stop(APM_AP_Ready_Status_T ready_status);
static void APM_Handle_Activated(uint16_t subsystem_id);
static void APM_Handle_Terminated(uint16_t subsystem_id);
static void APM_Task(void *unused_parameter);
static bool_t APM_Activate_Apps(void);
static bool_t APM_Terminate_Apps(void);
static void APM_Check_App_Status(void);
static void Set_Ready_Status(APM_AP_Ready_Status_T ready_status, uint32_t delay_MS);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/**
 * Update current state
 *    set current state 
 *    trace message 
 *    publish new state
 *    delay if necessary
 *    call callout for project specific 
 */
static void Set_Ready_Status(APM_AP_Ready_Status_T ready_status, uint32_t delay_MS)
{
   APM_EVG_READY_T status = { 0 };
   
   APM_Actual_Ready_Status = ready_status;
   Tr_Info_Hi_1("Process ready: %s", APM_AP_Ready_Status_Names[APM_Actual_Ready_Status]);
   
   /* Delay is to allow time for debug trace messages to go out
    * (i.e., before shutting down the process)
    */
   if (delay_MS != 0)
   {
      SAL_Sleep(delay_MS);
   }

   status.process = SAL_Get_App_Id();
   status.status = ready_status;
   SAL_Publish(APM_EVG_READY_STATUS, &status, sizeof(status));
   
   APM_Set_AP_Ready_Status(APM_Actual_Ready_Status); /* process specific callout */
}   

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void Application_Initialization(void)
{
   SAL_Thread_Attr_T thread_attributes;
   SAL_Config_T      sal_configuration;
   bool_t            status_ok;
   SAL_Thread_Id_T   thread_id;

   SAL_Get_Config(&sal_configuration);
   APM_Get_SAL_Config(&sal_configuration);

   status_ok = SAL_Init(&sal_configuration);
   PBC_Ensure(status_ok, "SAL_Init() failed.");

   APM_Get_Thread_Attr(&thread_attributes);
   
   thread_id = SAL_Create_Thread(APM_Task, NULL, &thread_attributes);
   PBC_Ensure_1((thread_attributes.id == thread_id), "SAL_Create_Thread() failed: %d", (int) thread_id);

   SAL_Run();
   Tr_Info_Hi("Exited from SAL_Run()");
}

/**
 * This function handles start/stop messages from the VIP.
 *
 * @return     
 *   nothing
 *  
 * @param [in]   ready_status
 *   This is the operational ready status requested by the VIP.
 *
 */
void APM_Handle_Start_Stop(APM_AP_Ready_Status_T ready_status)
{
   PBC_Require_1((APM_AP_READY_UNKNOWN > ready_status), "Ready status out of range: %d", (int) ready_status);
   APM_Ready_Status_Target = ready_status;

   Tr_Info_Mid_1("AP start/stop received: %s", APM_AP_Ready_Status_Names[ready_status]);

   /** If already at target, report out current state */
   if (ready_status == APM_Actual_Ready_Status)
   {
      Set_Ready_Status(ready_status, 0);
      Tr_Info_Hi_1("APM_Handle_Start_Stop - already at %s", APM_AP_Ready_Status_Names[ready_status]);
   }
}

/**
 * The function records when an app is fully initialized and ready
 * to be used by other applications.
 *
 * NOTE: When this event is received, the task will fall through and
 *       see if any other subsystems can be activated now.
 *
 * @return     
 *   nothing
 *  
 * @param [in]   subsystem_id
 *   This is the ID of the app.
 *
 */
static void APM_Handle_Activated(uint16_t subsystem_id)
{
   PBC_Require_1((APM_Config->num_apps > subsystem_id), "Subsystem_id out of range: %d", (int) subsystem_id);
   Bit_Set_MSB(APM_Activated_Apps, subsystem_id, APM_Config->num_apps, 1);
   Tr_Info_Mid_1("Subsystem activated: %s", APM_Config->apps[subsystem_id].app_name);
}

/**
 * The function records when an app is finished shutting down.
 *
 * NOTE: When this event is received, the task will fall through and
 *       see if any other subsystems can be terminated now.
 *
 * @return     
 *   nothing
 *  
 * @param [in]   subsystem_id
 *   This is the ID of the app.
 *
 */
static void APM_Handle_Terminated(uint16_t subsystem_id)
{
   PBC_Require_1((APM_Config->num_apps > subsystem_id), "Subsystem_id out of range: %d", (int) subsystem_id);
   Bit_Set_MSB(APM_Terminated_Apps, subsystem_id, APM_Config->num_apps, 1);
   Tr_Info_Mid_1("Subsystem terminated: %s", APM_Config->apps[subsystem_id].app_name);
}

/**
 * This is the thread for the Application Manager.
 *
 * NOTE: This task does not use State of Health because the SOH thread has not
 *       been started yet.  This is acceptable because the Power Mode Manager
 *       on the VIP is monitoring responses from Application Manager and will
 *       reset the AP if the Application Manager is not responding.
 *
 *       In addition, if any subsystem fails to initialize and call
 *       APM_Activated() (or APM_Terminated() when shutting down), the
 *       sequence will not complete.  This will be noticed by the VIP and the
 *       J2 will be reset.
 *
 * @return     
 *   nothing
 *  
 */
void APM_Task(void *unused_parameter)
{
   const SAL_Message_T *message;
   size_t               num_bytes;
   bool_t               status_ok;
   const SAL_Event_Id_T subscribe_list[] =
   {
      /* Note: If new published messages are added to the list, then you *might*
       * need to update the SAL_Create_Queue statement a little farther down.
       * Currently, APM_EVG_START_STOP is the largest message. */
      SOH_EVG_STATUS_QUERY,
      APM_EVG_START_STOP
   };   

   APM_Get_App_Configuration(&APM_Config);
   PBC_Ensure(APM_Config != NULL, "NULL App Configuration");
   PBC_Ensure(APM_Config->num_apps > 0, "No applications declared");

   num_bytes = BIT_ARRAY_NUM_BYTES(APM_Config->num_apps);   
   APM_Activated_Apps = SAL_Alloc(num_bytes);
   PBC_Ensure(APM_Activated_Apps != NULL, "Could not allocate memory to manage applications");
   memset(APM_Activated_Apps, 0, num_bytes);
   APM_Terminated_Apps  = SAL_Alloc(num_bytes);
   PBC_Ensure(APM_Terminated_Apps != NULL, "Could not allocate memory to manage applications");
   memset(APM_Terminated_Apps, 0, num_bytes);
   APM_Activate_Called = SAL_Alloc(num_bytes);
   PBC_Ensure(APM_Activate_Called != NULL, "Could not allocate memory to manage applications");
   memset(APM_Activate_Called, 0, num_bytes);
   APM_Terminate_Called = SAL_Alloc(num_bytes);
   PBC_Ensure(APM_Terminate_Called != NULL, "Could not allocate memory to manage applications");
   memset(APM_Terminate_Called, 0, num_bytes);

   status_ok = SAL_Create_Queue(APM_Message_Queue_Size, sizeof(APM_EVG_START_STOP_T), SAL_Alloc, SAL_Free);
   PBC_Ensure(status_ok, "SAL_Create_Queue() failed.");

   SAL_Subscribe(subscribe_list, Num_Elems(subscribe_list));
   SOH_Proxy_Initialize();

   SAL_Signal_Ready();

   Set_Ready_Status(APM_READY_INIT, 0);

   Tr_Warn("APM_Task: first SOH_Report!!!");
   SOH_Report();
   
   while (true)
   {
      /*
       * Activate/terminate applications if necessary
       */
      if (APM_Ready_Status_Target > APM_Actual_Ready_Status)
      {
         if (APM_Activate_Apps())
         {
            Set_Ready_Status(APM_Ready_Status_Target, 0);
         }
      }
      else if (APM_Ready_Status_Target < APM_Actual_Ready_Status)
      {
         if (APM_Terminate_Apps())
         {
            /* Allow debug trace messages to go out before shutting down the process */
            Set_Ready_Status(APM_Ready_Status_Target, 100);
         }
      }
      else
      {
         /* Already at correct level, do nothing */
      }

      /*
       * Receive and handle any messages
       */
      message = SAL_Receive_Timeout(APM_SAL_RECEIVE_TIMEOUT_MS);
      if (NULL != message)
      {
         switch (message->event_id)
         {
            /* Note: If new private messages are added to this handler, then you *might*
             * need to update the SAL_Create_Queue statement a little farther up.
             * Currently, APM_EVG_START_STOP is the largest message. */
            case APM_EVG_START_STOP:
            {
               APM_EVG_START_STOP_T const * start_stop = (APM_EVG_START_STOP_T const *) message->data;
               if (start_stop->process == SAL_Get_App_Id())
               {
                  APM_Handle_Start_Stop(start_stop->target_status);
               }   
               break;
            }
            case APM_EV_ACTIVATED:
               APM_Handle_Activated(*((APM_EV_ACTIVATED_T *) message->data));
               break;

            case APM_EV_TERMINATED:
               APM_Handle_Terminated(*((APM_EV_TERMINATED_T *) message->data));
               break;

            case SOH_EVG_STATUS_QUERY:
               APM_Check_App_Status();
               SOH_Report();  
               break;
               
            default:
               Tr_Warn_1("Unexpected message received: %d", (int) message->event_id);
               break;
         }
      }
   } /* while (true) */
   /*
    * NOTE: If the above while loop is ever changed to allow it to exit, then
    *       code will need to be added to free memory allocated at the
    *       start of the function.
    */
}

/**
* This function looks for applications have been activated but have
* not yet reported that they have completed activation.  It has a
* similar purpose for termination.
*/
void APM_Check_App_Status(void)
{
   uint16_t subsystem_id;

   if (APM_In_Transition)
   {
      APM_In_Transition = false;
   }
   else
   {
      for (subsystem_id = 0; subsystem_id < APM_Config->num_apps; subsystem_id++)
      {
         if (Bit_Is_True_MSB(APM_Activate_Called, subsystem_id)
             && !Bit_Is_True_MSB(APM_Activated_Apps, subsystem_id))
         {
            Tr_Warn_1("App not activated: %s", APM_Config->apps[subsystem_id].app_name);
         }

         if (Bit_Is_True_MSB(APM_Terminate_Called, subsystem_id)
             && !Bit_Is_True_MSB(APM_Terminated_Apps, subsystem_id))
         {
            Tr_Warn_1("App not terminated: %s", APM_Config->apps[subsystem_id].app_name);
         }
      }
   }
}

void APM_Dump_App_Status(void)
{
   uint16_t subsystem_id;
   char info[100];

   Tr_Notify_2("APM_Dump_App_Status: APM_Ready_Status_Target=%d, APM_Actual_Ready_Status=%d", APM_Ready_Status_Target, APM_Actual_Ready_Status);
   snprintf(info, sizeof(info), "%40s:  AC  AV  TC  TD", "AppName");
   Tr_Notify_1("%s", info);

   for (subsystem_id = 0; subsystem_id < APM_Config->num_apps; subsystem_id++)
   {
      uint8_t stat_ac, stat_av, stat_tc, stat_td;

      stat_ac = stat_av = stat_tc = stat_td = 0;
      if (Bit_Is_True_MSB(APM_Activate_Called, subsystem_id))
      {
         stat_ac = 1;
      }
      if (Bit_Is_True_MSB(APM_Activated_Apps, subsystem_id))
      {
         stat_av = 1;
      }
      if (Bit_Is_True_MSB(APM_Terminate_Called, subsystem_id))
      {
         stat_tc = 1;
      }
      if (Bit_Is_True_MSB(APM_Terminated_Apps, subsystem_id))
      {
         stat_td = 1;
      }

      snprintf(info, sizeof(info), "%40s:   %d   %d   %d   %d", APM_Config->apps[subsystem_id].app_name, stat_ac, stat_av, stat_tc, stat_td);
      Tr_Notify_1("%s", info);
   }
}

/**
 * This function looks for applications that can be activated and
 * calls their initialization functions.
 *
 * @return     
 *   True if all applications have been initialized.
 *  
 */
bool_t APM_Activate_Apps(void)
{
   uint16_t subsystem_id;
   uint8_t  dependency;
   bool_t   done;
   bool_t   app_ready;

   Bit_Set_MSB(APM_Activated_Apps, 0, APM_Config->num_apps, 1);

   /*
    * Determine if we are already done
    */
   done = true;
   for (subsystem_id = 1; subsystem_id < APM_Config->num_apps; subsystem_id++)
   {
      if (!Bit_Is_True_MSB(APM_Activated_Apps, subsystem_id)
          && ((APM_Config->apps[subsystem_id].ready_level <= APM_Ready_Status_Target)
              || (APM_AP_READY_UNKNOWN == APM_Ready_Status_Target)))
      {
         done = false;
      }
   }

   /*
    * Search for any applications that can be activated
    */
   if (!done)
   {
      for (subsystem_id = 1; subsystem_id < APM_Config->num_apps; subsystem_id++)
      {
         if (!Bit_Is_True_MSB(APM_Activate_Called, subsystem_id)
             && ((APM_Config->apps[subsystem_id].ready_level <= APM_Ready_Status_Target)
                 || (APM_AP_READY_UNKNOWN == APM_Ready_Status_Target)))
         {
            app_ready = true;

            for (dependency = 0; dependency < APM_NUMBER_OF_DEPENDENCIES; dependency++)
            {
               if (!Bit_Is_True_MSB(APM_Activated_Apps, APM_Config->apps[subsystem_id].dependencies[dependency]))
               {
                  app_ready = false;
               }
            }

            if (app_ready)
            {
               if (NULL != APM_Config->apps[subsystem_id].activate)
               {
                  Tr_Info_Lo_1("Initializing: %s", APM_Config->apps[subsystem_id].app_name);
                  APM_Config->apps[subsystem_id].activate();
                  APM_In_Transition = true;

                  /* Clear terminated bits in case apps are brought up again */
                  Bit_Set_MSB(APM_Terminate_Called, subsystem_id, APM_Config->num_apps, 0);
                  Bit_Set_MSB(APM_Terminated_Apps, subsystem_id, APM_Config->num_apps, 0);
               }
               else
               {
                  APM_Activated(subsystem_id);
               }

               Bit_Set_MSB(APM_Activate_Called, subsystem_id, APM_Config->num_apps, 1);
               /* since the app was not activated, do not clear its terminated bits */
            }
         }
      }
   }

   return done;
}

/**
 * This function looks for applications that can be terminated and
 * calls their shutdown functions.
 *
 * @return     
 *   True if all applications have been terminated.
 *  
 */
bool_t APM_Terminate_Apps(void)
{
   uint16_t subsystem_id;
   uint16_t dependency_check_id;
   uint8_t  dependency;
   bool_t   done;
   bool_t   app_ready;

   Bit_Set_MSB(APM_Terminated_Apps, 0, APM_Config->num_apps, 1);

   /*
    * Determine if we are already done
    */
   done = true;
   for (subsystem_id = 1; subsystem_id < APM_Config->num_apps; subsystem_id++)
   {
      if (!Bit_Is_True_MSB(APM_Terminated_Apps, subsystem_id)
          && (APM_Config->apps[subsystem_id].ready_level > APM_Ready_Status_Target))
      {
         done = false;
      }
   }

   /*
    * Search for any applications that can be terminated
    */
   if (!done)
   {
      for (subsystem_id = 1; subsystem_id < APM_Config->num_apps; subsystem_id++)
      {
         if (!Bit_Is_True_MSB(APM_Terminate_Called, subsystem_id)
             && (APM_Config->apps[subsystem_id].ready_level > APM_Ready_Status_Target))
         {
            /* Only check apps that have have finished init (Activated) - fixes crash when shutting down quickly */
            if (Bit_Is_True_MSB(APM_Activated_Apps, subsystem_id))
            {
               app_ready = true;

               for (dependency_check_id = 1; dependency_check_id < APM_Config->num_apps; dependency_check_id++)
               {
                  for (dependency = 0; dependency < APM_NUMBER_OF_DEPENDENCIES; dependency++)
                  {
                     /* 
                      * Before we mark the current subsystem as not being ready to shutdown because another app
                      * depends on it, make sure the other app is at least in the process of initializing
                      */
                     if ((APM_Config->apps[dependency_check_id].dependencies[dependency] == subsystem_id)
                         && (!Bit_Is_True_MSB(APM_Terminated_Apps, dependency_check_id)))
                     {
                        app_ready = false;
                     }
                  }
               }

               if (app_ready)
               {
                  if (NULL != APM_Config->apps[subsystem_id].terminate)
                  {
                     Tr_Info_Lo_1("Terminating: %s", APM_Config->apps[subsystem_id].app_name);
                     APM_Config->apps[subsystem_id].terminate();
                     APM_In_Transition = true;

                     /* Clear activated bits in case apps are brought up again */
                     Bit_Set_MSB(APM_Activate_Called, subsystem_id, APM_Config->num_apps, 0);
                     Bit_Set_MSB(APM_Activated_Apps, subsystem_id, APM_Config->num_apps, 0);
                  }
                  else
                  {
                     APM_Terminated(subsystem_id);
                  }

                  Bit_Set_MSB(APM_Terminate_Called, subsystem_id, APM_Config->num_apps, 1);
                  /* since the app was not terminated, do not clear its activated bits */
               }
            }
            /* If app was not activated, and also never had its initialize method called, mark it as terminated */
            else if (!Bit_Is_True_MSB(APM_Activate_Called, subsystem_id))
            {
               Bit_Set_MSB(APM_Terminate_Called, subsystem_id, APM_Config->num_apps, 1);
               Bit_Set_MSB(APM_Terminated_Apps, subsystem_id, APM_Config->num_apps, 1);
            }
            /* 
             * The other case is when an app's initialize has been called, but it has not finshed and called activated.
             * In that case, we do nothing here in terminate - the app will eventually finish and become activated and
             * on a subsequent call to APM_Terminate_Apps it will get terminated
             */
         }
      }
   }

   return done;
}

/*===========================================================================*/
/*!
 * @file application_manager.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 *    2Sep15 zengliangqian
 *     SOH add initial stage
 * - 27Mar13  David Origer
 *   - SCR kok_basa#39894 : Moved delay in Set_Ready_Status() to right after
 *     the debug trace message.  This helps but does not fix a race condition
 *     where a process can be told to terminate and the process actually
 *     terminates before the readv() call in SAL_Sync_Send_V(), resulting
 *     in FAULT messages.
 *
 * - 15-Oct-2012 Larry Piekarski Rev 35
 *   - Task 123953: Fixed incorrect trace message that was causing confusing 
 *     debug trace.
 *
 * - 26-Sep-2012 Chris Edgington Rev 33
 *   - Task 121113: Check to make sure an app is activated before deciding that it needs terminated
 *
 * - 06-Jun-2012 Larry Piekarski Rev 32
 *   - Task 101416: Changed behavior to allow App Man to warm start (Essentially
 *     go from All READY to NOTHING READY and back to ALL READY). When a shutdown
 *     function pointer is called, clear the activated app bits. (If the shutdown
 *     function is NULL, then do not clear the bits). A similar change was made
 *     for activate.
 *
 * - 06-Jun-2012 Kirk Bailey Rev 31
 *   - Fixed Klockwork errors.
 *
 * - 06-Jan-2012 Kirk Bailey Rev 30
 *   - Removed use of signal_dbg.
 *
 * - 05-Jan-2012 Kirk Bailey Rev 28
 *   - Added support for signal debugging.
 *
 * - 29-Oct-2011 Larry Piekarski Rev 27
 *   - Task 56383: Increased the width of the App Man message queue to sizeof
 *     APM_EVG_START_STOP_T, which is currently the largest message received.
 *     Added a note to the subscription list that is new, larger messages are 
 *     added, then update the SAL_Create_Queue statement.
 *
 * - 15-July-2011 Dan Carman
 *   - Modified to support coordination of multiple AppMans
 *       - Modified for published start / stop message
 *       - Add common set routine to update actual, publish ready status, and call process specific callout
 *       - Added new state APM_READY_INIT and report of this state at AppMan startup - This represents that
 *          NO Apps have been activated and we are not even at the NOTHING READY state.
 *
 * - 8Mar11  David Origer  Rev 24
 *   SCR kok_basa#6947 : Print when apps don't start.
 *
 * - 30-Nov-2010 Dan Carman
 *   - Application Manager is now responsible for running SOH Proxy Interface
 *
 * - 30-Oct-2010 Kirk Bailey Rev 22
 *   - Task 15995: Fixed initialization of dynamically allocated memory.
 *
 * - 29-Oct-2010 Kirk Bailey Rev 21
 *   - Task 15929: Minor modifications after review feedback.
 *
 * - 27-Oct-2010 Kirk Bailey Rev 20
 *   - Task 15623: Altered app man to be usable by multiple processes.
 *
 * - 25-Jul-2010 Kirk Bailey Rev 19
 *   - Replaced "bool" with "bool_t".
 *
 * - 15-jan-2010 Kirk Bailey Rev 18
 *   - Task kok_basa 5193: Altered priority and length of trace messages to
 *     eliminate resets that occurred when all trace messages were enabled.
 *
 * - 08-dec-2009 Kirk Bailey
 *   - Task kok_basa 2165: Turned on Synergy Translate ASCII file option
 *
 * - 17Nov09  David Origer  Rev 16
 *   - SCR kok_aud#63877 : Reorder reporting on terminate and add a delay to allow
 *    reports to go out over UART before the J2 gets reset by the V850.
 *
 * - 26May09  David Origer  Rev 15
 *   - SCR kok_aud#60808 : Implement review action items.
 *
 * - 17Nov08  David Origer
 *   - SCR kok_aud#58060 : Add capability for multiple ready levels.
 *
 * - 18Sep08  David Origer Rev 8
 *   - SCR kok_aud#56890 : Generate Doxygen documentation.
 *
 * - 16Sep08  David Origer  Rev 7
 *   - SCR kok_aud#56931 : Implement monitoring code using debug trace.  With this
 *                     change, it is possible to view the sequence and timing
 *                     of changes to AP Ready Status and of the initialization
 *                     shutdown of individual applications.  The AP Ready
 *                     Status information can be viewed by setting the trace
 *                     level to "info mid" while application init and shutdown
 *                     can be viewed by setting the trace level to "info low."
 *
 * - 12Sep08  David Origer  Rev 6
 *   - SCR kok_aud#56927 : Use standard bit array utilities instead of
 *                     APM_Set/Get_Bit().
 *
 * - 15Aug08  David Origer
 *   - SCR kok_aud#56731 : Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
