/*===========================================================================*/
/**
 * @file application_manager_proxy.c
 *
 * Source code file for the Application Manager Proxy.
 *
 * %full_filespec: application_manager_proxy.c~kok_inf#9:csrc:kok_aud#1 %
 * @version %version: kok_inf#9 %
 * @author  %derived_by: czhswm %
 * @date    %date_modified: Thu Oct 31 15:12:24 2013 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Source code file for the Application Manager Proxy.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup application_manager
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "application_manager.h"
#include "application_manager_cbk.h"
#include "pbc_trace.h"
#include "reuse.h"
#include "xsal.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(APPLICATION_MANAGER_MODULE_ID, 1); /* Identifies file for PbC/trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Activated(uint16_t subsystem_id)
{
   APM_EV_ACTIVATED_T *subsystem_id_ptr = &subsystem_id;

   PBC_Require_1((APM_Num_Apps > subsystem_id), "Subsystem_id out of range: %d", (int) subsystem_id);
   SAL_Send(APM_Process, APM_Thread_Id, APM_EV_ACTIVATED, subsystem_id_ptr, sizeof(*subsystem_id_ptr));
}

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Initialize(void)
{
   APM_AP_Ready_Status_T ready_status = APM_AP_NOTHING_READY;
   
   APM_Set_AP_Ready_Status(ready_status);
   APM_Activated(APM_App_Id);
}

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Shutdown(void)
{
   APM_Set_AP_Ready_Status(APM_AP_NOTHING_READY);
   Tr_Info_Mid("AP ready: APM_AP_NOTHING_READY");

   while (true)
   {
      SAL_Sleep(10000);
   }
}

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Start_Stop(APM_AP_Ready_Status_T ready_status)
{
   APM_EVG_START_STOP_T command = { 0 };
   
   PBC_Require_1((APM_AP_READY_UNKNOWN > ready_status), "Ready status out of range: %d", (int) ready_status);
   
   command.target_status = ready_status;
   command.process = APM_Process;
   SAL_Publish(APM_EVG_START_STOP, &command, sizeof(command));
}

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Start_Stop_Process(APM_AP_Ready_Status_T ready_status, SAL_App_Id_T process)
{
   APM_EVG_START_STOP_T command = { 0 };
   
   PBC_Require_1((APM_AP_READY_UNKNOWN > ready_status), "Ready status out of range: %d", (int) ready_status);
   
   command.target_status = ready_status;
   command.process = process;
   SAL_Publish(APM_EVG_START_STOP, &command, sizeof(command));
}

/*===========================================================================*\
 *
 * Please refer to the detailed description in application_manager.h
 *
\*===========================================================================*/
void APM_Terminated(uint16_t subsystem_id)
{
   APM_EV_TERMINATED_T *subsystem_id_ptr = &subsystem_id;

   PBC_Require_1((APM_Num_Apps > subsystem_id), "Subsystem_id out of range: %d", (int) subsystem_id);
   SAL_Send(APM_Process, APM_Thread_Id, APM_EV_TERMINATED, subsystem_id_ptr, sizeof(*subsystem_id_ptr));
}

/*===========================================================================*/
/*!
 * @file application_manager.c
 *
 * @section RH REVISION HISTORY (top to bottom: first revision to last revision)
 *
 * - 10Sep2008 David Origer
 *   - Created initial file.
 *
 * - 18Sep08  David Origer Rev 2
 *   - SCR kok_aud#56890 : Generate Doxygen documentation.
 *
 * - 20Oct08  David Origer Rev 3
 *   - SCR kok_aud#57256 : Make AP send "ready nothing" on shutdown.
 *
 * - 08-dec-2009 Kirk Bailey
 *   - Task kok_basa 2165: Turned on Synergy Translate ASCII file option
 *
 * - 27-Oct-2010 Kirk Bailey Rev 5
 *   - Task 15623: Altered app man to be usable by multiple processes.
 *
 * - 29-Oct-2010 Kirk Bailey Rev 6
 *   - Task 15929: Minor modifications after review feedback.
 *
 * - 15-July-2011 Dan Carman
 *   - Add API (APM_Start_Stop_Process) to Start/Stop an AppMan in another process
 *
 * - 13 April-2012 Weston Bridgewater
 *   - Task 90072: Fix Improper use of SAL_Send()
 * 
 * - 31-Oct-2013 Larry Piekarski Rev 37
 *   - Task 2594: Fix use of uninitialized local data contained in pad bytes.
 */
/*===========================================================================*/
