#ifndef APPLICATION_MANAGER_CBK_H
#   define APPLICATION_MANAGER_CBK_H
/*===========================================================================*/
/**
 * @file application_manager_cbk.h
 *
 * Callout header file for the Application Manager.
 *
 * %full_filespec: application_manager_cbk.h~kok_basa#8:incl:kok_aud#1 %
 * @version %version: kok_basa#8 %
 * @author  %derived_by: dzq92s %
 * @date    %date_modified: Tue Nov  2 15:24:29 2010 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Callout header file for the Application Manager.  This header file provides the
 * functional interface for the Application Manager callouts.
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @ingroup application_manager
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "application_manager.h"
#   include "xsal.h"

#   ifdef __cplusplus
extern "C"
{ /* ! Inclusion of header files should NOT be inside the extern "C" block */
#   endif /* __cplusplus */
/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

#define APM_NUMBER_OF_DEPENDENCIES  (5)

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/**
 * Applications are activated by a call of this type. The call is a "request"
 * and should not block. The return of this function does not imply the
 * activation has occurred. When the request has been handled, the application
 * will call back into application manager (APM_Activated()) using the
 * application id value associated with the application.
 */
typedef void (*APM_Activation_Function_Ptr_T)(void);

/**
 * Applications are terminated by a call of this type. The call is a "request"
 * and should not block. The return of this function does not imply the
 * termination has occurred. When the request has been handled, the application
 * will call back into application manager (APM_Terminated()) using the
 * application id value associated with the application.
 */
typedef void (*APM_Termination_Function_Ptr_T)(void);

/**
 * This structure defines the interface to an application.
 */
typedef struct APM_Application_Definition_Tag
{
   /** Name of application (for debugging) */   
   char const *app_name;
   /** Function that activates the application (NULL is allowed) */
   APM_Activation_Function_Ptr_T activate;
   /** Function that terminates the application (NULL is allowed) */
   APM_Termination_Function_Ptr_T terminate;
   /** Minimum ready level for which this application is used. */
   APM_AP_Ready_Status_T ready_level;
   /** List of other applications that this one depends upon */
   uint16_t dependencies[APM_NUMBER_OF_DEPENDENCIES];
}
APM_Application_Definition_T;

/**
 * This structure defines all the applications for a process.
 */
typedef struct APM_Configuration_Tag
{
   /** Number of applications (# entries in "apps") */
   size_t num_apps;   
   /** List of application definitions (num_apps entries) */
   APM_Application_Definition_T const *apps;
}
APM_Configuration_T;


/*===========================================================================*
 * Constant Declarations for Callouts
 *===========================================================================*/

/**
 * Application id assigned to AppMan for this process; must be defined by the
 * process using AppMan.
 */
extern const uint16_t APM_App_Id;

/**
 * Number of applications in this process; must be defined by the process
 * using AppMan.
 */
extern const uint16_t APM_Num_Apps;

/**
 * XSAL application id for this process; ; must be defined by the process
 * using AppMan.
 */
extern const SAL_Application_Id_T APM_Process;

/**
 * XSAL thread id for this app man; ; must be defined by the process
 * using AppMan.
 */
extern const SAL_Thread_Id_T APM_Thread_Id;

/**
 * Size of SAL message receive queue for Application Manager.
 */
extern const size_t APM_Message_Queue_Size;

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/**
 * This function is called by application manager to obtain the information
 * for all the apps it controls. This allows the app man library to be used
 * and shared simultaneously by multiple processes in the system.
 *
 * @param [out] app_config Address of pointer that is to be written to by
 *              the function. It must point to the app man configuration for
 *              the process and the data it points to must not change during
 *              the execution of app man.
 */
void APM_Get_App_Configuration(APM_Configuration_T const **app_config);

/**
 * Callout function that must be implemented by the program using the
 * Application Manager module in order to provide the SAL Configuration for the
 * application.
 *
 * @param [out] sal_configuration pointer to location to which SAL
 *                          configuration is to be written.
 */
void APM_Get_SAL_Config(SAL_Config_T *sal_configuration);

/**
 * Callout function that must be implemented by the program using the
 * Application Manager module in order to provide the thread attribute for the
 * Application Manager's thread.
 *
 * @param [out] thread_attributes pointer to location to which thread attribute
 *                          is to be written.
 */
void APM_Get_Thread_Attr(SAL_Thread_Attr_T *thread_attributes);

/**
 * Callout function that must be implemented by the program using the
 * Application Manager module in order to set the desired AP readiness
 * level.
 *
 * @param [in] ready_status desired AP readiness level
 */
void APM_Set_AP_Ready_Status(APM_AP_Ready_Status_T ready_status);

#   ifdef __cplusplus
}         /* extern "C" */
#   endif /* __cplusplus */
/*===========================================================================*/
/*!
 * @file application_manager_CBK.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 02-nov-2010 Kirk Bailey Rev 8
 *   - Task 16084: Made APM_Thread_Id const.
 *
 * - 02-nov-2010 Kirk Bailey Rev 7
 *   - Task 16078: Made APM_Message_Queue_Size type size_t.
 *
 * - 29-Oct-2010 Kirk Bailey Rev 6
 *   - Task 15929: Minor modifications after review feedback.
 *
 * - 27-Oct-2010 Kirk Bailey Rev 5
 *   - Task 15623: Altered app man to be usable by multiple processes.
  *
 * - 08-dec-2009 Kirk Bailey
 *   - Task kok_basa 2165: Turned on Synergy Translate ASCII file option
 *
 * - 26May09  David Origer  Rev 3
 *   - SCR kok_aud#60808 : Implement review action items.
 *
 * - 18Sep08  David Origer Rev 2
 *   - SCR kok_aud#56890 : Generate Doxygen documentation.
 *
 * - 10Sep2008 David Origer
 *   - Created initial file.
 */
/*===========================================================================*/
#endif                          /* APPLICATION_MANAGER_CBK_H */
