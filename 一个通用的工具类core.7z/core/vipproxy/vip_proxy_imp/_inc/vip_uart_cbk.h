#ifndef VIP_UART_CBK_H
#   define VIP_UART_CBK_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_uart_cbk.h
 *
 * Defines VIP Interface call out for UART channel
 *
 * %full_filespec:vip_uart_cbk.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:02 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "uart.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Callouts
 *===========================================================================*/

/** Identifies UART channel used to communicate with VIP */
   extern const UA_Channel_T VIP_UART_Channel;
/*add for touch screen function by steven cheng start*/
   extern const UA_Channel_T TSI_UART_Channel;
/*add for touch screen function by steven cheng end*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Callouts
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for Callouts
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_uart_cbk.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 20-may-2008 @todo insert developer name
 *   - Created initial file.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_UART_CBK_H */

