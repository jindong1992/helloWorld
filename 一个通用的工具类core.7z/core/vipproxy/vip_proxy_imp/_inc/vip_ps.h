#ifndef VIP_PS_H
#   define VIP_PS_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*/
/**
 * @file vip_ps.h
 *
 *  Header file for the VIP Persistent Storage callouts.
 *
 * %full_filespec: vip_ps.h~1:incl:ctc_ec#18 %
 * @version %version: 1 %
 * @author  %derived_by: qzb3mh %
 * @date    %date_modified: Fri May 30 18:48:01 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API of callouts for VIP Persistent Storage.
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "reuse.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants for Persistent Storage
 *===========================================================================*/


/*===========================================================================*
 * Exported Preprocessor #define MACROS for Persistent Storage
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations for Persistent Storage
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes for persistent storage access routines
 *===========================================================================*/

/**
* Initialize VIP persistent storage.
*
* @return     
*   TRUE if operation is successful
*  
*/
   bool_t VIP_PS_Init(void);

/**
 * Get production configuration.
 *
 * @return
 *    Returns production configuration.
 *
 */
   bool_t VIP_PS_Get_Production_Configuration(void);

/**
 * Put production configuration.
 *
 * @param [in] new_configuration
 *    True if radio is configured for production, false if configured
 *    for development.
 *
 */
   void VIP_PS_Put_Production_Configuration(bool_t new_configuration);

/*===========================================================================*/
/*!
 * @file vip_ps.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * 28Feb11  David Origer  Rev 1
 * SCR kok_basa#5846 : Implement method for production vs. development code.
 */
/*===========================================================================*/
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PS_H */
