/*===========================================================================*/
/**
 * @file vip_iic.c
 *
 * This proxy implements the VIP IIC API
 *
 * %full_filespec:vip_iic.c~1:csrc:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:03 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements IIC reads from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - IIC - Analog to Digital conversion
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "vip_iic.h"
#include "vip_desip.h"
#include "desip_msg_types.h"
#include <string.h>
#include <stddef.h>

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 6);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/* write data via IIC channel on VIP
 *   See vip_iic.h for detail
 */
void VIIC_Write(uint8_t vip_channel, uint8_t device, bool no_stop, const uint8_t * wdata, size_t num_bytes)
{
   SIP_IIC_Write_T write_data;

   PBC_Require_2((num_bytes <= SIP_IIC_MAX_SIZE), "DESIP IIC Write request of %d bytes exceeds DESIP max of %d",
                 num_bytes, SIP_IIC_MAX_SIZE);

   write_data.channel = vip_channel;
   write_data.tx_data[SIP_IIC_WRITE_DEVICE_OFFSET] = device;
   write_data.no_stop = no_stop;
   write_data.num_bytes = (uint8_t) num_bytes;
   memcpy(&write_data.tx_data[SIP_IIC_WRITE_DATA_OFFSET], wdata, num_bytes);

   VIP_Send(VIPP_EV_IIC_WRITE, &write_data, num_bytes + offsetof(SIP_IIC_Write_T, tx_data) + 1);
}


/*
 * VIP IIC Receive
 *   See vip_iic.h for detail
 */
bool VIIC_Read(uint8_t vip_channel, uint8_t device, uint8_t * rdata, size_t num_bytes)
{
   SAL_Message_T const *reply_msg;
   bool success = false;
   SIP_IIC_Read_T read_data;

   read_data.channel = vip_channel;
   read_data.device_address = device;
   read_data.num_bytes = (uint16_t) num_bytes;

   reply_msg = VIP_Send_Wait_Reply(VIPP_EV_IIC_READ, &read_data, sizeof(SIP_IIC_Read_T), EVG_IIC_READ_DATA);

   if (NULL != reply_msg)
   {
      SIP_IIC_Read_Data_T *results = (SIP_IIC_Read_Data_T *) reply_msg->data;
      if (results->num_bytes > 0)
      {
         memcpy(rdata, results->rx_data, results->num_bytes);
         success = true;
      }
   }

   return success;
}

/*===========================================================================*/
/*!
 * @file vip_iic.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - rev 5 25-Mar-2009 xz152s (Huemann_Jim)
 *    SCR kok_aud#59863: fix VIIC_Write routine which was sending the incorrect 
 *                       number of bytes
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

