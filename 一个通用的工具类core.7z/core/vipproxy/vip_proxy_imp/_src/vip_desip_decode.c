/*===========================================================================*/
/**
 * @file vip_desip_decode.c
 *
 * This file handles custom decoding of incoming DESIP messages
 *
 * %full_filespec:vip_desip_decode.c~1:csrc:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:02 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * This file handles custom decoding of incoming DESIP messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - VIP - Vehicle Interface processor
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "application_manager.h"
#include "desip_msg_ids.h"
#include "desip_msg_types.h"
#include "pbc_trace.h"
#include "phone_call_mgr_decode.h"
#include "reuse.h"
#include "vip_desip.h"
#include "vip_proxy_private.h"
#include "vip_ps.h"
#include "vip_intp.h"
#include "vip_proxy_cfg.h"
#include "xsal.h"
#include "apm_event_id.h"
#include "xsal_application_id.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 4); /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/
/*#define XSAL_ID_to_TSI_DESIP_ID(event_id)  ((DESIP_Id_T) (DESIP_FIRST_AP_TO_RTD + ((event_id) - (RTDP_EV_START_DESIP + 1))))*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void Decode_Call_Status(SAL_Message_T const * msg);
bool_t RDS_Decode_VIP_Block(  RDS_Decoder_Input_T * block );
bool_t RDS_Decode_VIP_Block_BCD(  SIP_DE_Block_Msg_BCD_T * block_bcd );
bool_t RDS_Decode_VIP_Block_II(  RDS_Decoder_Input_T * block );
bool_t RDS_Decode_VIP_Block_BCD_II(  SIP_DE_Block_Msg_BCD_T * block_bcd );

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/
uint8_t gRtdBrightness = 200;
uint8_t gSetRtdBrightnessFlag = 0;/* add for resend only after already setting, by zlq */

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*
 * Do custom DESIP decode processing
 */
bool VIPP_Custom_Decode_DESIP_Message(DESIP_Id_T id, const uint8_t * rx_buf, size_t num_bytes)
{
   bool normal_process = true;

   switch (id)
   {
      case DESIP_VIP_ALIVE:
         vipp_Decode_VIP_ALIVE(*((const SIP_MSG_ID_Version_T *) rx_buf));
         normal_process = false;
         break;
      case DESIP_VIP_INTERRUPT:
         VGPIO_Decode_VIP_Interrupt(*((const SIP_Interrupt_Id_T *) rx_buf));
         normal_process = false;
         break;
      case DESIP_AP_START_STOP:
         /* VIP does not have  init as state 0) */
         APM_Start_Stop_Process((APM_AP_Ready_Status_T) ((*rx_buf) + (APM_AP_NOTHING_READY - SIP_AP_NOTHING_READY)),
            ICR_RADIO_PROCESS_ID);
         normal_process = false;
         break;

#ifdef XMODEM_IS
         case DESIP_VIP_CALS_REFLASH:
         VIP_Switch_To_Xmodem();
         VIP_RcvThrd_Wait_Flash_Cals();
         normal_process = false;
         break;
#endif /*XMODEM_IS*/

      case DESIP_PRODUCTION_CONFIGURATION:
         VIP_PS_Put_Production_Configuration((bool_t) (*((const SIP_Bool_T *) rx_buf)));
         normal_process = true;
         break;
    /*--------------------------------------------------------*/
	case DESIP_RDS_DATA_BLOCK:
	 if(RDS_Decode_VIP_Block((  RDS_Decoder_Input_T *)rx_buf))
	 {
         	normal_process = false;
	 }		
	break;	
	case DESIP_RDS_DATA_BLOCK_BCD:
	 if(RDS_Decode_VIP_Block_BCD((  SIP_DE_Block_Msg_BCD_T *)rx_buf))
	 {
         	normal_process = false;
	 }		
	break;

	case DESIP_RDS_DATA_BLOCK_II:
	 if(RDS_Decode_VIP_Block_II((  RDS_Decoder_Input_T *)rx_buf))
	 {
         	normal_process = false;
	 }		
	break;	
	case DESIP_RDS_DATA_BLOCK_BCD_II:
	 if(RDS_Decode_VIP_Block_BCD_II((  SIP_DE_Block_Msg_BCD_T *)rx_buf))
	 {
         	normal_process = false;
	 }		
	break;

      case DESIP_GMLAN_REPROGRAMMING:
      {
         Tr_Info_Hi("GMLAN REPROGRAMMING IN PROCESS");
         SAL_Send(FBL_LINKER_APP_ID, FBL_GMLAN_HANDLER_THREAD_ID, (SAL_Event_Id_T) FBL_LINKER_EV_ENTER_TO_SAFE_MODE,
            (const uint8_t *) rx_buf, sizeof(uint8_t));
         break;
      }

      case DESIP_VIP_DEBUG_TRACE:
         Tr_Notify_1("VIP trace: %s", ((const VIP_Debug_Trace_T *) rx_buf)->text);
         normal_process = false;
         break;
#ifndef GWM_CHB031
      case DESIP_POWE_ON_RTD_REPLY:    
         normal_process = false;
         break;
#endif
      default: /* use standard decoding */
         break;
   }

   return normal_process;
}
#if 0
/*add for touch screen function by steven cheng start*/
bool TSIP_Custom_Decode_DESIP_Message(DESIP_Id_T id, const uint8_t * rx_buf, size_t num_bytes)
{
   bool normal_process = true;

   switch (id)
   {
      case DESIP_RTD_AUDIO_ALIVE:
         tsip_Decode_TSI_ALIVE(*((const SIP_MSG_ID_Version_T *) rx_buf));
         normal_process = false;
         break;
         
      case DESIP_RTD_BACKLIGHT_PWM_REPORT: /* add by zlq, handle RTD report, resend when different */
      {
         uint8_t brightness = *rx_buf;

         if (brightness != gRtdBrightness)
         {
            Tr_Warn_2(" RTD BACKLIGHT to %d != %d !", brightness, gRtdBrightness);
            if (gSetRtdBrightnessFlag)
            {
            	if (gSetRtdBrightnessFlag++ >= 2) /* delay, wait for RTD setting */
            	{
            		Tr_Warn_2("ReSet RTD BACKLIGHT to %d -> %d !", brightness, gRtdBrightness);
            		TSI_Transmit(XSAL_ID_to_TSI_DESIP_ID(RTDP_EV_BACKLIGHT_PWM_SET), &gRtdBrightness, 1);     
            	}
            }
         }
         else
         {
            Tr_Info_Hi_1("DESIP_RTD_BACKLIGHT_PWM_REPORT same with AP %d ", brightness);
         }
         break;
      }  
      default:                 /* use standard decoding */
         break;
   }

   return normal_process;
}
/*add for touch screen function by steven cheng end*/
#endif
/**
 * Handle special cases - primarily published data
 */
bool VIPP_Custom_Decode_XSAL_Message(SAL_Message_T const *msg) /* check for special cases */
{
   bool normal_process = true;

   if (NULL != msg)
   {
      switch (msg->event_id)
      {

         /* Phone call status message handling */
         case PHMGR_EVG_PHONE_CALL_REPORT:
         {
            Decode_Call_Status(msg);

            normal_process = false;
            break;
         }

         default:
            /* Message does not have a custom decoder */
            normal_process = true;
            break;
      }
   }
   return normal_process;
}
#if 0
bool TSIP_Custom_Decode_XSAL_Message(SAL_Message_T const *msg) /* check for special cases */
{
   bool normal_process = true;

   if (NULL != msg)
   {
      switch (msg->event_id)
      {

         default:
            /* Message does not have a custom decoder */
            normal_process = true;
            break;
      }
   }
   return normal_process;
}
#endif
/**
 * Decodes the incoming Phone Manager event and transmits the appropriate
 * call status to the VIP.
 *
 * @param event [in] Event received from the Phone Manager
 */
static void Decode_Call_Status(SAL_Message_T const * msg)
{
   SIP_BT_call_status_T call_status = SIP_BT_CALL_FAILED;

   PBC_Internal((msg != NULL), "Decode_Call_Status cannot decode a NULL message.");
   PBC_Internal((PHMGR_EVG_PHONE_CALL_REPORT == msg->event_id), "Decode_Call_Status can only decode a PHMGR_EVG_PHONE_CALL_REPORT message");

   /* Are any HF calls being reported? */
   if (0 == PhMgr_Get_Call_Count(msg->event_id, msg->data, msg->data_size))
   {Tr_Info_Hi("Decode_Call_Status-------------SIP_BT_CALL_ENDED");
      /* No HF calls are being reported */
      call_status = SIP_BT_CALL_ENDED;
   }
   else
   {
      if ((PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_ACTIVE))
         || (PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_HELD)))
      {
         if (PHMGR_AUDIO_HANDSFREE == PhMgr_Get_Phone_Audio_Location(msg->event_id, msg->data, msg->data_size))
         {Tr_Info_Hi("Decode_Call_Status-------------SIP_BT_CALL_ACTIVE");
            call_status = SIP_BT_CALL_ACTIVE;
         }
         else /* call is active in private (handset) mode */
         {Tr_Info_Hi("Decode_Call_Status-------------SIP_BT_CALL_ENDED");
            call_status = SIP_BT_CALL_ENDED;
         }
      }
      else if ((PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_INCOMING))
         || (PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_WAITING)))
      {Tr_Info_Hi("Decode_Call_Status-------------SIP_BT_INCOMING_CALL");
         call_status = SIP_BT_INCOMING_CALL;
      }
      else if ((PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_DIALING))
         || (PhMgr_Call_With_State_Is_Present(msg->event_id, msg->data, msg->data_size, PHMGR_CALL_OUTGOING_ALERTING)))
      {Tr_Info_Hi("Decode_Call_Status-------------SIP_BT_OUTGOING_CALL");
         call_status = SIP_BT_OUTGOING_CALL;
      }
      else
      {Tr_Info_Hi("Decode_Call_Status-------------NULL");
         /* This is an invalid call status */
      }
   }

   VIP_Transmit(DESIP_BT_CALL_STATUS, &call_status, sizeof(call_status));
}

/*add for RDS filter  start*/
bool_t RDS_Decode_VIP_Block(  RDS_Decoder_Input_T * block )
{
  
   bool_t discard = false;
   static uint8_t nosync_cnt = 5;	
   /*Invliad channel or invalid data*/
   Tr_Info_Hi_3("PI    block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x",  block->deocder_id, block->sync_channel, block->block_data);
   if((block->sync_channel == 206) ||((block->block_type == 1)&& (block->block_data == 0xffff)) )
   {
       if(0 ==( --nosync_cnt))
       {
		discard = false;
		nosync_cnt = 5;
		
       }
	else
	{
		discard = true;
		
	}

   }
   else
   {
	nosync_cnt =1;
   }
   Tr_Info_Hi_3("PI    block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block->block_type,  block->is_good_quality,  block->is_strong_sync);
   return  discard;

}


bool_t RDS_Decode_VIP_Block_BCD(  SIP_DE_Block_Msg_BCD_T * block_bcd )
{
	Tr_Info_Mid_3(" BCD ONE  block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[0].deocder_id, block_bcd->sync_data[0].sync_channel, block_bcd->sync_data[0].block_data);
	Tr_Info_Mid_3(" BCD ONE block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[0].block_type,  block_bcd->sync_data[0].is_good_quality,  block_bcd->sync_data[0].is_strong_sync);
	
	Tr_Info_Mid_3(" BCD TWO  block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[1].deocder_id, block_bcd->sync_data[1].sync_channel, block_bcd->sync_data[1].block_data);
	Tr_Info_Mid_3(" BCD TWO  block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[1].block_type,  block_bcd->sync_data[1].is_good_quality,  block_bcd->sync_data[1].is_strong_sync);
	
	Tr_Info_Mid_3(" BCD III   block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[2].deocder_id, block_bcd->sync_data[2].sync_channel, block_bcd->sync_data[2].block_data);
	Tr_Info_Mid_3(" BCD III  block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[2].block_type,  block_bcd->sync_data[2].is_good_quality,  block_bcd->sync_data[2].is_strong_sync);

	return false;
}


/*add for RDS filter  start*/
bool_t RDS_Decode_VIP_Block_II(  RDS_Decoder_Input_T * block )
{
  
   bool_t discard = false;
   static uint8_t nosync_cnt = 5;	
   /*Invliad channel or invalid data*/
   Tr_Info_Hi_3("PI II block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x",  block->deocder_id, block->sync_channel, block->block_data);
   if((block->sync_channel == 206) ||((block->block_type == 1)&& (block->block_data == 0xffff)) )
   {
       if(0 ==( --nosync_cnt))
       {
		discard = false;
		nosync_cnt = 5;
		
       }
	else
	{
		discard = true;
		
	}

   }
   else
   {
	nosync_cnt =1;
   }
   Tr_Info_Hi_3("PI II block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block->block_type,  block->is_good_quality,  block->is_strong_sync);
   return  discard;

}


bool_t RDS_Decode_VIP_Block_BCD_II(  SIP_DE_Block_Msg_BCD_T * block_bcd )
{
	Tr_Info_Mid_3(" BCD II ONE  block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[0].deocder_id, block_bcd->sync_data[0].sync_channel, block_bcd->sync_data[0].block_data);
	Tr_Info_Mid_3(" BCD II ONE block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[0].block_type,  block_bcd->sync_data[0].is_good_quality,  block_bcd->sync_data[0].is_strong_sync);
	
	Tr_Info_Mid_3(" BCD II TWO  block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[1].deocder_id, block_bcd->sync_data[1].sync_channel, block_bcd->sync_data[1].block_data);
	Tr_Info_Mid_3(" BCD II TWO  block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[1].block_type,  block_bcd->sync_data[1].is_good_quality,  block_bcd->sync_data[1].is_strong_sync);
	
	Tr_Info_Mid_3(" BCD II III   block->deocder_id=%d  block->sync_channel=%d  block->block_data=0x%x", block_bcd->sync_data[2].deocder_id, block_bcd->sync_data[2].sync_channel, block_bcd->sync_data[2].block_data);
	Tr_Info_Mid_3(" BCD II III  block->block_type=%d  block->is_good_quality =%d block->is_strong_sync=%d ",block_bcd->sync_data[2].block_type,  block_bcd->sync_data[2].is_good_quality,  block_bcd->sync_data[2].is_strong_sync);

	return false;
}
/*===========================================================================*/
/*!
 * @file vip_desip_decode.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 5-Mar-2013 Jiang Tao
 * + Add a customer DESIP message DESIP_POWE_ON_RTD_REPLY for GWM CHK041 project
 *
 * June 1, 2012 Dan Carman
 * Report BT Call status as ended when call goes private.
 *
 *  May 11, 2012  WZRJ41  (Carolina Tovar)
 *  kok_basa#26535: GMLAN programming - Radio incorrectly times out of programming mode after 1 minute
 *  Modify GMLAN message to support data
 *
 *  March 28, 2012  Pramod N K (bzfpq6) Rev 139
 *  SCR 23736
 *  Changes made related to BT call status.
 *
 *  March 26, 2012  WZRJ41  (Carolina Tovar)
 *  kok_basa#23885: Fix screen issue related to GMLAN and HOME button events
 *  GMLAN event now calls to new thread
 *
 * - 13-feb-2012 Kris Boultbee
 *   Task kok_basa#75877 Revision 21
 *   - Moved the function Any_Call_With_State into the Phone Call Manager decode
 *     library as PhMgr_Call_With_State_Is_Present because it has wider use than
 *     just in the VIP Proxy.
 *
 * 26Jan12  David Origer (hz1941)  Rev 20
 * SCR kok_basa#20981 : Show debug trace messages from VIP on AP trace output.
 *
 * - 16-jan-2012 Kris Boultbee
 *   Task kok_basa#69827 Revision 19
 *   - Refactored Decode_Call_Status to use PHMGR_EVG_PHONE_CALL_REPORT
 *   - Added helper function Any_Call_With_State()
 *
 *  04-Nov-2011 Vijayalakshmi
 *  Added custom decoder function for the Phone Manager outgoing call status events.
 *
 *  30-Sep-2011 Jorge Rodriguez
 *  Add decoding for new DESIP message that reports GMLAN reprogramming event.
 *
 * 12Aug11  David Origer (hz1941)  Rev 15
 * SCR kok_basa#13133 : Send APM_EV_START_STOP directly to ICR_RADIO_PROCESS_ID
 *    since this is the only process that needs the event (not icr_core_1).
 *
 * - 22-jun-2011 Kris Boultbee
 *   Task kok_basa#37014 Revision 14
 *   - Added custom decoder function for the Phone Manager call status events.
 *
 * Aug 31th 2010  lzz7kf (JICASTANON) Rev 12
 * Task kok_basa#14105: Fix Task for kok_basa#13676: Implement PS VIP on vip_proxy
 *  - Remove change from vip_desip_decode.c go back to previous version
 *
 * Aug 19th 2010  lzz7kf (JICASTANON) Rev 11
 * Task kok_basa#13676/SCR kok_basa#2446: [VIP PS] Integrate PS_VIP module add AP support
 *
 * - 03-May-2010 Octavio Rocha rev. 10
 *   SCR kok_basa#1509 VIP_Proxy Update to support 4 GMLAN calibrations
 *   via Xmodem.
 *
 * - 24-Feb-2010 Jorge Rodriguez
 *    Add compilation switch to remove Xmodem related functionality.
 *
 * - rev 6 25-Mar-2009 xz152s (Huemann_Jim)
 *    SCR kok_aud#59863: fix task kok_aud#47241 which did not include updates to this file properly
 *
 *  - 24-Mar-2009 Luis E Hernandez
 *   - Add functionality for sharing UART port with xmodem
 *
 * - 16-Oct-2008 Dan Carman
 *    - Fixed offset error with AP Start/Stop that resulted when general offset of received data was fixed
 *
 * 29Sep08     hz1941 (David Origer) Rev 3
 * SCR kok_aud#56731 : Integrate AP with VIP.
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

