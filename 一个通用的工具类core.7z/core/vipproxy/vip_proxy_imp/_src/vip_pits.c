/*===========================================================================*/
/**
 * @file vip_pits.c
 *
 * This proxy transmit a PITs reply message via the VIP
 *
 * %full_filespec:vip_pits.c~1:csrc:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:03 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements PITs transmit via the VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - IIC - Analog to Digital conversion
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "vip_pits.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 3);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/
typedef struct SIP_PITS_GM_DTC_Tag
{
   uint8_t dtc_code;
   uint8_t dtc_value;
   uint8_t did_value[76];
   uint8_t did_hours;
   uint8_t did_set_audio;
   uint8_t did_cd_errors[7];
}SIP_PITS_GM_DTC_T;

static uint8_t pits_did_value[76]= {0};
static uint8_t pits_did_source_hours= 0;
static uint8_t pits_did_set_audio= 0x01;
static uint8_t pits_did_errors[7]= {0};
/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/* 
 * Transmit a PITs Message
 */
void PITs_Send(const uint8_t * pits_msg, size_t num_bytes)
{
   VIP_Send(VIPP_EV_PITS_REPLY, pits_msg, num_bytes);
}

extern void PITs_GM_DTC_Set (SIP_DTC_Code_T pits_dtc_code, bool_t pits_dtc_value, bool_t pits_did_status)
{
   SIP_PITS_GM_DTC_T set_dtc_msg;
   uint8_t did_index;
   if (!pits_did_status)
   {
      set_dtc_msg.dtc_code = (uint8_t) pits_dtc_code;
      set_dtc_msg.dtc_value = (uint8_t) pits_dtc_value;
      set_dtc_msg.did_value[0] = 0;
      set_dtc_msg.did_hours = 0;
      set_dtc_msg.did_set_audio = 0x01;
   }
   else
   {
      set_dtc_msg.dtc_code = 0;
      set_dtc_msg.dtc_value = 0;
      for (did_index = 0; did_index < 76;did_index++)
      {
         set_dtc_msg.did_value[did_index]= pits_did_value[did_index];
      }
      set_dtc_msg.did_hours = pits_did_source_hours;
      set_dtc_msg.did_set_audio = pits_did_set_audio;

      for (did_index = 0; did_index < 7;did_index++)
      {
         set_dtc_msg.did_cd_errors[did_index]= pits_did_errors[did_index];
      }

   }

   VIP_Send(VIPP_EV_GM_DTC_SET_REQ, &set_dtc_msg, 87);
}

extern void PITs_GM_Set_DID (uint8_t did_position, uint8_t did_value)
{
   pits_did_value[did_position] = did_value;
}

extern void PITs_GM_Set_DID_Source (uint8_t source_value, uint8_t audio_value)
{
   pits_did_source_hours = source_value;
   pits_did_set_audio = audio_value;
}

extern void PITs_GM_Set_DID_Errors (uint8_t error_position, uint8_t error_value)
{
   pits_did_errors[error_position] = error_value;
}

void PITs_Send_Server(const uint8_t * pits_msg, size_t num_bytes)
{
   VIP_Send(VIPP_EV_PITS_SERVER_COMMAND, pits_msg, num_bytes);
}
/*===========================================================================*/
/*!
 * @file vip_pits.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 27-Dec-2011 Miguel Garcia (kzvhr7)
 *  Add new Desip messages to support pits server commands
 *
 * 27-April-2011 Miguel Garcia
 * Update SIP_GM_DTC_T for desip dtc messages
 *
 * Nov 19 2010 kzvhr7 (Miguel Garcia) Rev 2
 * SCR kok_basa#4358 Implement Set_DTC in APP
 *
 * - 15-Oct-2008 Dan Carman
 *   - Fix extra dereference of PITs message
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

