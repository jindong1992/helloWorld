/*===========================================================================*/
/**
 * @file vip_proxy.c
 *
 * Miscellaneous VIP proxy functions
 *
 * %full_filespec:vip_proxy.c~14.1.2:csrc:ctc_ec#23 %
 * @version %version:14.1.2 %
 * @author  %derived_by:hzs8nb %
 * @date    %date_modified:Tue Jul  5 12:30:19 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2010 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Miscellaneous VIP proxy functions
 *
 * @section ABBR ABBREVIATIONS:
 *   - None
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - None
 *
 *   - Requirements Document(s):
 *     - None
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "desip_msg_ids.h"
#include "desip_msg_types.h"
#include "pbc_trace.h"
#include <string.h>
#include "utilities.h"
#include "vip_desip.h"
#include "vip_proxy.h"
#include "vip_proxy_private.h"
#include "vip_ps.h"
#include "xsal.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 3);     /* Identifies file for PbC trace */

/** timeout limit to declare VIP dead */
#define VIPP_VIP_ALIVE_TIMEOUT_MS  (2000)
/** timeout limit to declare RTD dead */
#define VIPP_TSI_ALIVE_TIMEOUT_MS  (15000) /* RTD alive timer is 5s, so 5*3= 15 */


/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/**  List of published XSAL messages to forward to VIP */
static const SAL_Event_Id_T vipp_sub_list[] = {
   EVG_BATTERY_VOLTAGE,
/* Phone call status messages */
   PHMGR_EVG_PHONE_CALL_REPORT,
};

/** timestamp of last VIP Alive message */
static SAL_Clock_T vipp_vip_alive_time;

/** timestamp of last TSI Alive message */
SAL_Clock_T tsip_tsi_alive_time;/* del static by zlq */

#if defined(GWM_CHK041_8AT)
static uint32_t key_vibrate_timestamp;
#endif
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*\
 * Implement VIP Proxy functions
\*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*\
 * Implement VIP DESIP to XSAL mapping callouts
\*---------------------------------------------------------------------------*/

/*
 *  Subscribes to all XSAL published data that should be forward to the VIP.
 */
void VIPP_Custom_Initialize(void)
{
   bool_t ok;

   ok = SAL_Subscribe(vipp_sub_list, Num_Elems(vipp_sub_list));
   PBC_Ensure(ok, "SAL_Subscribe() failed");

   VIP_PS_Init();
}

bool_t VIP_Is_Alive(void)
{
   return (SAL_Elapsed_Time(vipp_vip_alive_time) < VIPP_VIP_ALIVE_TIMEOUT_MS);
}

/*---------------------------------------------------------------------------*
 * Decode Function Definitions
 *---------------------------------------------------------------------------*/

/** update VIP Alive timer, check on periodic AP alive timer  */
void vipp_Decode_VIP_ALIVE(SIP_MSG_ID_Version_T version)
{
   char msg_id[SIP_MSG_ID_LEN + 1];
   char msg_types[SIP_MSG_ID_LEN + 1];
   char const *start_of_digits;
   size_t prefix_len;
   size_t src_len;

   prefix_len = strlen("%""version"":");
   /*
    * Copy just the digit portion of the version string for the messages
    * to msg_id.
    */
   src_len = strlen(DESIP_MSG_IDS_VERSION);
   start_of_digits = strrchr(DESIP_MSG_IDS_VERSION, '#');

   if (start_of_digits != NULL)
   {
      start_of_digits++; /* Move ptr. from '#' to first digit */
   }
   else if (src_len > prefix_len)
   {
      start_of_digits = DESIP_MSG_IDS_VERSION + prefix_len;
   }
   else
   {
      start_of_digits = DESIP_MSG_IDS_VERSION;
   }

   Safe_Strncpy(msg_id, start_of_digits, SIP_MSG_ID_LEN+1);
   /*
    * Copy just the digit portion of the version string for the types
    * to msg_id.
    */
   src_len = strlen(DESIP_MSG_TYPES_VERSION);
   start_of_digits = strrchr(DESIP_MSG_TYPES_VERSION, '#');

   if (start_of_digits != NULL)
   {
      start_of_digits++; /* Move ptr. from '#' to first digit */
   }
   else if (src_len > prefix_len)
   {
      start_of_digits = DESIP_MSG_TYPES_VERSION + prefix_len;
   }
   else
   {
      start_of_digits = DESIP_MSG_TYPES_VERSION;
   }

   Safe_Strncpy(msg_types, start_of_digits, SIP_MSG_ID_LEN+1);

   version.desip_msg_id_version[SIP_MSG_ID_LEN] = 0;     /* Null terminate string */
   version.desip_msg_types_version[SIP_MSG_ID_LEN] = 0;  /* Null terminate string */

   vipp_vip_alive_time = SAL_Clock();

   if (VIP_ALIVE_KEY == version.vip_alive_key)
   {
      if(strncmp(version.desip_msg_id_version,msg_id,SIP_MSG_ID_LEN))
      {
         Tr_Fault_2("VIP and AP desip_msg_ids.h do not match. VIP ver = %s, AP ver = %s",version.desip_msg_id_version,msg_id);
      }
      if(strncmp(version.desip_msg_types_version,msg_types,SIP_MSG_ID_LEN))
      {
         Tr_Fault_2("VIP and AP desip_msg_types.h do not match. VIP ver = %s, AP ver = %s",version.desip_msg_types_version,msg_types);
      }
   }
   else
   {
      Tr_Fault_1("VIP and AP desip_msg_ids.h do not match. VIP ver = UNKNOWN, AP ver = %s",msg_id);
      Tr_Fault_1("VIP and AP desip_msg_types.h do not match. VIP ver = UNKNOWN, AP ver = %s",msg_types);
   }
}

/*add for touch screen function by steven cheng start*/
#if 0
bool_t TSI_Is_Alive(void)
{
   /*return (SAL_Elapsed_Time(tsip_tsi_alive_time) < VIPP_TSI_ALIVE_TIMEOUT_MS);*/
   return (SAL_Clock() < (tsip_tsi_alive_time + VIPP_TSI_ALIVE_TIMEOUT_MS));/* modify from "-" to "+" by zlq */
}


/** update TSI Alive timer, check on periodic AP alive timer  */
void tsip_Decode_TSI_ALIVE(SIP_MSG_ID_Version_T version)
{
   char msg_id[SIP_MSG_ID_LEN + 1];
   char msg_types[SIP_MSG_ID_LEN + 1];
   char const *start_of_digits;
   size_t prefix_len;
   size_t src_len;

   prefix_len = strlen("%""version"":");
   /*
    * Copy just the digit portion of the version string for the messages
    * to msg_id.
    */
   src_len = strlen(DESIP_TSI_MSG_IDS_VERSION);
   start_of_digits = strrchr(DESIP_TSI_MSG_IDS_VERSION, '#');

   if (start_of_digits != NULL)
   {
      start_of_digits++; /* Move ptr. from '#' to first digit */
   }
   else if (src_len > prefix_len)
   {
      start_of_digits = DESIP_TSI_MSG_IDS_VERSION + prefix_len;
   }
   else
   {
      start_of_digits = DESIP_TSI_MSG_IDS_VERSION;
   }

   Safe_Strncpy(msg_id, start_of_digits, SIP_MSG_ID_LEN+1);
   /*
    * Copy just the digit portion of the version string for the types
    * to msg_id.
    */
   src_len = strlen(DESIP_TSI_MSG_TYPES_VERSION);
   start_of_digits = strrchr(DESIP_TSI_MSG_TYPES_VERSION, '#');

   if (start_of_digits != NULL)
   {
      start_of_digits++; /* Move ptr. from '#' to first digit */
   }
   else if (src_len > prefix_len)
   {
      start_of_digits = DESIP_TSI_MSG_TYPES_VERSION + prefix_len;
   }
   else
   {
      start_of_digits = DESIP_TSI_MSG_TYPES_VERSION;
   }

   Safe_Strncpy(msg_types, start_of_digits, SIP_MSG_ID_LEN+1);

   version.desip_msg_id_version[SIP_MSG_ID_LEN] = 0;     /* Null terminate string */
   version.desip_msg_types_version[SIP_MSG_ID_LEN] = 0;  /* Null terminate string */

   tsip_tsi_alive_time = SAL_Clock();

   if (VIP_ALIVE_KEY == version.vip_alive_key)
   {
      if(strncmp(version.desip_msg_id_version,msg_id,SIP_MSG_ID_LEN))
      {
         Tr_Fault_2("TSI and AP desip_msg_ids.h do not match. VIP ver = %s, AP ver = %s",version.desip_msg_id_version,msg_id);
      }
      if(strncmp(version.desip_msg_types_version,msg_types,SIP_MSG_ID_LEN))
      {
         Tr_Fault_2("TSI and AP desip_msg_types.h do not match. VIP ver = %s, AP ver = %s",version.desip_msg_types_version,msg_types);
      }
   }
   else
   {
      Tr_Fault_1("TSI and AP desip_msg_ids.h do not match. VIP ver = UNKNOWN, AP ver = %s",msg_id);
      Tr_Fault_1("TSI and AP desip_msg_types.h do not match. VIP ver = UNKNOWN, AP ver = %s",msg_types);
   }
}
/*add for touch screen function by steven cheng end*/
#endif
void VIP_AP_Shutdown_Initiate(void)
{
   VIP_Send(VIPP_EV_AP_SHUTDOWN_INITIATED, NULL, 0);
}

void VIP_Power_Mode_Status(SIP_Power_Mode_Status_T status)
{
   VIP_Send(VIPP_EV_POWER_MODE_STATUS, &status, sizeof(status));
}
void VIP_AP_Immediate_Shutdown(void)
{
   VIP_Send(VIPP_EV_IMMEDIATE_SHUTDOWN, NULL, 0);
}

void VIP_Request_Aux_Jack_Phy_State(void)
{
   VIP_Send(VIPP_EV_AUX_JACK_REQUEST, NULL, 0);
}

void VIP_GYRO_Selftest_Request(SIP_PITS_GYRO_TEST_ENUM_T Request)
{
   VIP_Send(VIPP_EV_PITS_GYRO_TEST_REQ, &Request, sizeof(uint8_t));
}
void VIP_Get_K0R_Chksum(SIP_Cheksum_Request_T section)
{
   VIP_Send(VIPP_EV_CHECKSUM16_K0R_REQUEST, &section, sizeof(section));
}
void VIP_Get_FACEPLATE_K0R_Chksum(SIP_Cheksum_Request_T section)
{
   VIP_Send(VIPP_EV_FACEPLATE_K0R_CHECKSUM_REQUEST, &section, sizeof(section));
}
void VIP_Get_Misc_Microphone_Status(void)
{
   VIP_Send(VIPP_EV_MICROPHONE_FAILURE_STATUS_REQ, NULL, 0);
}

void VIP_PITS_Sent_VSS_Config_To_VIP(SIP_PITS_VSS_INPUT_CONFIG_T Config_input)
{
   VIP_Send(VIPP_EV_PITS_VSS_INPUT_CONFIG_REQ, &Config_input, sizeof(Config_input));
}

void VIP_PITS_VSS_PWM_Get_Req(void)
{
   VIP_Send(VIPP_EV_PITS_VSS_INPUT_GET_REQ, NULL, 0);
}

void VIP_RTC_Set_Req(SIP_Date_Time_T input)
{
   VIP_Send(VIPP_EV_SET_DATE_TIME, &input, sizeof(input));
}
/*===========================================================================*
 * Please refer to the detailed description in vip_proxy.h.
 *===========================================================================*/
void VIP_Get_Power_Antenna(void)
{
    VIP_Send(VIPP_EV_AP_PWR_ANTENA_CURRENT_STATUS_REQ, NULL, 0);
}

/*===========================================================================*
 * Please refer to the detailed description in vip_proxy.h.
 *===========================================================================*/
void VIP_Set_Power_Antenna(SIP_Power_Antenna_Status_T new_power_ANT_status)
{
   VIP_Send(VIPP_EV_ANTENNA_POWER_STATUS, &new_power_ANT_status, sizeof(new_power_ANT_status));
}
/*===========================================================================*
 * get the voltage from VIP
 *===========================================================================*/
void VIP_Get_Battery_Voltage(void)
{
   VIP_Send(VIPP_EV_VOLTAGE_VALUE_REQ, NULL, 0);
}

/*===========================================================================*
 * Please refer to the detailed description in vip_proxy.h.
 *===========================================================================*/
void VIP_Get_GPIO_Port_Status(SIP_VIP_Ports_T port)
{
   VIP_Send(VIPP_EV_READ_VIP_GPIO_PORT, &port, sizeof(SIP_VIP_Ports_T));
}

/*===========================================================================*
 * Set K0R PIN status.
 *===========================================================================*/
void VIP_Set_GPIO_Port_Status(SIP_Set_VIP_Port_T port_status)
{
   VIP_Send(VIPP_EV_SET_VIP_GPIO_PORT, &port_status, sizeof(SIP_Set_VIP_Port_T));
}

/*===========================================================================*
 * Get AD port value.
 *===========================================================================*/
void VIP_Get_AD_Port_Value(SIP_AD_Channel_T channel)
{
   VIP_Send(VIPP_EV_PITS_READ_AD_PORTS_REQ, &channel, sizeof(SIP_AD_Channel_T));
}

/* power on or off the display board.
	value, ture  power on, false power off
	add by zengliangqian */
void VIP_Power_On_RTD_Request(bool_t value)
{
#if defined(GWM_CHK041_8AT)
    static uint8_t rtd_poweron = 0xFF;

    if (value != rtd_poweron)
    {
      rtd_poweron = value;
      key_vibrate_timestamp = SAL_Clock(); 
    }
#endif
   Tr_Notify_1("VIP_Power_On_RTD_Request %s!!!", value ? "on" : "off");
    /*request to power on RTD from vip*/
   VIP_Send(VIPP_EV_POWE_ON_RTD, &value, sizeof(bool_t));
}

#if defined(GWM_CHK041_8AT)
void VIP_Vibrate_Timestamp_Get(uint32_t *timestamp)
{
	*timestamp = key_vibrate_timestamp;
}
#endif

/* select RSE spdif
	value, ture  select RSE spdif
	          false  select CD/DVD spdif
	add by zengliangqian */
void VIP_Select_RSE_SPDIF_Request(bool_t value)
{
   Tr_Notify_1("VIP_Select_RSE_SPDIF_Request %s!!!", value ? "on" : "off");

   VIP_Send(VIPP_EV_SELECT_RSE_SPDIF, &value, sizeof(bool_t));
}



/*===========================================================================*
 * Please refer to the detailed description in vip_proxy.h.
 *===========================================================================*/
void VIP_Tuner_Send_Status(uint8_t band, uint32_t frequency)
{

   TUNNER_STATUS_T tuner_status;
   tuner_status.tuner_band = band;
   tuner_status.tuner_frequency   = frequency;
   
   Tr_Notify_2("VIP_Tuner_Send_Status band=%d frequency=%d", band, frequency);
   
   VIP_Send(VIPP_EV_TUNNER_STAUS, &tuner_status, sizeof(TUNNER_STATUS_T));
}

void VIP_Request_Power_Antenna_Status(void)
{
    VIP_Send(VIPP_EV_AP_GET_ANTENNA_STATUS, NULL, 0);
}

/*
* Please refer to the detailed description in vip_proxy.h.
*/
void VIP_Request_GPS_Antenna_Status(void)
{
   VIP_Send(VIPP_EV_AP_GET_GPS_ANT_STATUS, NULL, 0); 
}

/*
* Please refer to the detailed description in vip_proxy.h.
*/
void VIP_Request_Mic_Failure_Status(void)
{
    VIP_Send(VIPP_EV_MICROPHONE_FAILURE_STATUS_REQ, NULL, 0); 
}

/*
* Please refer to the detailed description in vip_proxy.h.
*/
void VIP_Request_SWC_Failure_Status(void)
{
   VIP_Send(VIPP_EV_AP_GET_SWC_FAILURE_STATUS, NULL, 0); 
}


/*
* Please refer to the detailed description in vip_proxy.h.
*/
void VIP_Set_GPS_Antenna_Power_Status(SIP_GPS_Power_Antenna_Req_T status)
{
    VIP_Send(VIPP_EV_AP_SET_GPS_ANT_POWER, &status, sizeof(SIP_GPS_Power_Antenna_Req_T));
}



/*===========================================================================*/
/*!
 * @file vip_proxy.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 16-jan-2011 Kris Boultbee
 *   Task kok_basa#69827 Revision 13
 *   - Removed subsription to individual call status messages reported by the
 *     Phone Call Manager and replaced them with the single
 *     PHMGR_EVG_PHONE_CALL_REPORT.
 *
 * - 04-Nov-2011 Vijayalakshmi
 *   - Added Phone Manager call status events to the list of subscribed events
 *
 * - 22-jun-2011 Kris Boultbee
 *   Task kok_basa#37014 Revision 11
 *   - Added Phone Manager call status events to the list of subscribed events
 *
 * - 14-April-2011 Dan Carman
 *   - Moved VIP_PS_Init to custom init from desip block
 *
 * - 17-feb-2010 Kirk Bailey
 *   - Tasks 6549: Fixed logic that extracts version number to work whether or
 *     not the number is preceded by the database id.
 *
 * - 14Apr09     xz152s (Jim Huemann) Rev 6
 *   - Modified the code to receive the VIP_Alive message as a string of just the
 *     version number without the "version:".
 *
 * - 18Mar09     xz152s (Jim Huemann) Rev 4
 *   - Added code to the vipp_Decode_VIP_ALIVE routine to throw a fault when the
 *     AP and VIP msg ids and types do not match
 *
 * - 29Sep08     hz1941 (David Origer) Rev 3
 *   - SCR kok_aud#56731 : Integrate AP with VIP.
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

