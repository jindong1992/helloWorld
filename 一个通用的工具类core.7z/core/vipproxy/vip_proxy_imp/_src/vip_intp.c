/*===========================================================================*/
/**
 * @file vip_intp.c
 *
 * This proxy implements the VIP Edge Interrupt API
 *
 * %full_filespec:vip_intp.c~1:csrc:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:03 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements intp reads from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - intp - Discrete I/O (GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "vip_desip.h"
#include "vip_intp.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 5);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/** hold list of callbacks for VIP edge interrupts */
static Interrupt_Callback_T VGPIO_Int_Callbacks[VIP_NUM_INTERRUPTS];

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

void VGPIO_Interrupt_Configure(VGPIO_Int_Id_T vip_int_id, VGPIO_Int_Edge_T edge, Interrupt_Callback_T callback)
{
   SIP_Set_Interrupt_T int_settings;

   PBC_Require_1(vip_int_id < VIP_NUM_INTERRUPTS, "Invalid interrupt ID %d", (int)vip_int_id);
   PBC_Require_1(edge <= VIP_INT_EDGE_BOTH, "Invalid edge specifier %d", (int)edge);

   if (VIP_INT_DISABLE == edge)
   {
      VGPIO_Int_Callbacks[vip_int_id] = NULL;
   }
   else
   {
      PBC_Require(NULL != callback, "No callback specified");
      VGPIO_Int_Callbacks[vip_int_id] = callback;
   }

   int_settings.intp_id = (SIP_Interrupt_Id_T) vip_int_id;
   int_settings.edge = (uint8_t) edge;

   VIP_Send(VIPP_EV_SET_VIP_GPIO_INTERRUPT, &int_settings, sizeof(int_settings));
}


void VGPIO_Decode_VIP_Interrupt(SIP_Interrupt_Id_T int_id)
{
   if (int_id < VIP_NUM_INTERRUPTS)
   {
      if (NULL != VGPIO_Int_Callbacks[int_id])
      {
         VGPIO_Int_Callbacks[int_id] ();
      }
      else
      {
        /* Tr_Warn_1("No callback definied for VIP interrupt ID %d", (int)int_id);*/
      }
   }
   else
   {
      Tr_Warn_1("Received Invalid interrupt ID %d from VIP", (int)int_id);
   }
}

/*===========================================================================*/
/*!
 * @file vip_intp.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

