#ifndef VIP_PROXY_PRIVATE_H
#   define VIP_PROXY_PRIVATE_H
/*===========================================================================*/
/**
 * @file vip_proxy_private.h
 *
 * Defines the local interface betwee vip_proxy implementation files.
 *
 * %full_filespec:vip_proxy_private.h~1:incl:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:04 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Defines the local interface betwee vip_proxy implementation files.
 *
 * @section ABBR ABBREVIATIONS:
 *   - HSM = hierarchical state machine
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None
 *
 * @defgroup vip_proxy_internal Custom DESIP Message handling functions
 * @ingroup vip_services
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "xsal.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * Custom decode routines
 *---------------------------------------------------------------------------*/

/** update VIP Alive timer, check on periodic AP alive timer  */
void vipp_Decode_VIP_ALIVE(SIP_MSG_ID_Version_T version);


/*add for touch screen function by steven cheng start*/
/** update TSI Alive timer, check on periodic AP alive timer  */
void tsip_Decode_TSI_ALIVE(SIP_MSG_ID_Version_T version);
/*add for touch screen function by steven cheng end*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_proxy_private.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
  * 18Mar09     xz152s (Jim Huemann) Rev 4
 *  - Added code to the vipp_Decode_VIP_ALIVE routine to throw a fault when the 
 *    AP and VIP msg ids and types do not match
 *
 * - 04-Sept-2008 Dan Carman
 *   -Created file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#endif /* vip_proxy_private_H */

