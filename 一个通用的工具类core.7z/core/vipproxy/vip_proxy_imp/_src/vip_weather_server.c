/*===========================================================================*/
/**
 * @file vip_weather.c
 *
 * This proxy implements the WEATHER API via the VIP
 *
 * %full_filespec:vip_weather_server.c~1:csrc:ctc_ec#5 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:05 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements WEATHER reads/writes from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include "pbc_trace.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 10);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/
static void wtr_convert_location_to_sexagesimal(int32_t latitude, int32_t longitude, uint8_t * location);
/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/* 
 *  WTR_Vehicle_Position
 *    This function will send the current vehicle position
 */
void WTR_Vehicle_Position(int32_t latitude, int32_t longitude)
{
   uint8_t location[VEH_POS_DATA_LEN];

   wtr_convert_location_to_sexagesimal(latitude,longitude,&location[0]);

   VIP_Send(VIPP_EV_VEHICLE_POSITION, &location[0], sizeof(SIP_Vehicle_Position_T));
}

/* 
 *  WTR_Weather_Awake
 *    This function will send the weather awake signal
 */
void WTR_Weather_Awake(void)
{
   VIP_Send(VIPP_EV_WEATHER_AWAKE, NULL, 0);
}

/* 
 *  WTR_Weather_Feature_Status
 *    This function will send the weather feature status signal
 */
void WTR_Weather_Feature_Status(void)
{
   VIP_Send(VIPP_EV_WEATHER_FEATURE_STATUS, NULL, 0);
}

/* 
 *  WTR_City_Forecast
 *    This function will send the City Forecast request
 */
void WTR_City_Forecast(uint8_t city_code)
{
   SIP_City_Forecast_T city_forecast = city_code;

   VIP_Send(VIPP_EV_CITY_FORECAST, &city_forecast, sizeof(SIP_City_Forecast_T));
}

/* 
 *  WTR_Warning_Current_Location
 *    This function will send the Warning Current Location enable request
 */
void WTR_Warning_Current_Location(bool_t enable)
{
   bool_t warning_current_location = enable;

   VIP_Send(VIPP_EV_WARNING_CURRENT, &warning_current_location, sizeof(SIP_Bool_T));
}

/* 
 *  WTR_Forecast_Metar_Warning_Current_Location
 *    This function will send the Forecast/Metar/Warning Current Location request
 */
void WTR_Forecast_Metar_Warning_Current_Location(void)
{
   VIP_Send(VIPP_EV_WEATHER_CURRENT, NULL, 0);
}

/* 
 *  WTR_Forecast_Metar_Other_City
 *    This function will send the Forecast/Metar Other City request
 */
void WTR_Forecast_Metar_Other_City(uint8_t city_code)
{
   SIP_Weather_Other_City_T other_city = city_code;

   VIP_Send(VIPP_EV_WEATHER_OTHER_CITY, &other_city, sizeof(SIP_Weather_Other_City_T));
}

/* 
 *  WTR_Metar_From_Location
 *    This function will send the Metar From Location request
 */
void WTR_Metar_From_Location(int32_t latitude, int32_t longitude)
{
   uint8_t location[OTHER_POS_DATA_LEN];

   wtr_convert_location_to_sexagesimal(latitude,longitude,&location[0]);

   VIP_Send(VIPP_EV_METAR_FROM_LOCATION, &location[0], sizeof(SIP_Metar_From_Loc_T));
}

/* 
 *  WTR_Metar_From_Location
 *    This function will send the Metar From Location request
 */
void WTR_Forecast_Metar_Other_Location(int32_t latitude, int32_t longitude)
{
   uint8_t location[OTHER_POS_DATA_LEN];

   wtr_convert_location_to_sexagesimal(latitude,longitude,&location[0]);

   VIP_Send(VIPP_EV_WEATHER_OTHER_LOCATION, &location[0], sizeof(SIP_Weather_Other_Loc_T));
}

/* 
 *  WTR_Weather_Alerts_Popup
 *    This function will send the Weather Alerts Popup enabled request
 */
void WTR_Weather_Alerts_Popup(bool_t alerts_popup)
{
   bool_t weather_alerts_popup = alerts_popup;

   VIP_Send(VIPP_EV_ALERT_NOTIFICATION, &weather_alerts_popup, sizeof(SIP_Bool_T));
}

/* 
 *  wtr_convert_location_to_sexagesimal
 *    This function will convert latitude/longitude units to sexagesimal
 */
static void wtr_convert_location_to_sexagesimal(int32_t latitude, int32_t longitude, uint8_t * location)
{
   location[0] = (0 < latitude) ? 0x00 : 0x80;
   location[1] = (uint8_t)(abs(latitude)/100000);
   location[2] = (uint8_t)(((abs(latitude)%100000)*60)/100000);

   location[3] = (0 < longitude) ? 0x00 : 0x80;
   location[4] = (uint8_t)(abs(longitude)/100000);
   location[5] = (uint8_t)(((abs(longitude)%100000)*60)/100000);
}

/*===========================================================================*/
/*!
 * @file vip_weather.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 09-Apr-2012 Ernesto Beltran (zzgqx5) Rev 3
 *   - SCR kok_basa#24141: NAV Weather: XM Subscription and Audio present
 *
 * - 20-Feb-2012 Ernesto Beltran (zzgqx5) Rev 2
 *   - SCR kok_basa#22340: NAV Weather - Alerts Pop Up Categories Update
 *
 * - 14-Oct-2011 zzgqx5
 *   - Created initial file.
 */
/*===========================================================================*/

