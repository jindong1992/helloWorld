/*===========================================================================*/
/**
 * @file vip_remote_receiver.c
 *
 * VIP Proxy fucntions for controlling Remote Receiver (XM)
 *
 * %full_filespec:vip_remote_receiver.c~1:csrc:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:04 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API for controlling Remote Receiver (XM). Status and station information available
 *    via published messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "reuse.h"
#include "pbc_trace.h"
#include "vip_desip.h"
#include "desip_msg_types.h"
#include "remote_receiver.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 9);     /* Identifies file for PbC trace */

/* The following 3 define's come from
   "INFOTAINMENT GMLAN MESSAGES REV 2", section 4.5.8(3)  */
#define CATEGORY_LIST                     1
#define CHANNELS_IN_CURRENT_CATEGORY_LIST 2
#define FULL_CHANNEL_LIST                 3

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

static void rr_send_command(SIP_Rem_Rcvr_Commands_ENUM_T cmd, int16_t tune_value);
static void rr_set_source(SIP_Rem_Src_ID_ENUM_T src, SIP_Rem_Src_Command_ENUM_T src_command);

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/**
 * send request remote receiver command to VIP  
 */
static void rr_send_command(SIP_Rem_Rcvr_Commands_ENUM_T cmd, int16_t tune_value)
{
   SIP_Rem_Rcvr_Command_T rr_cmd;

   rr_cmd.commmand = (uint8_t) cmd;
   rr_cmd.tune_value = tune_value;

   VIP_Send(VIPP_EV_REM_RECEIVER_COMMAND, &rr_cmd, sizeof(SIP_Rem_Rcvr_Command_T));
}

/**
 * send remote audio source command to VIP  
 */
static void rr_set_source(SIP_Rem_Src_ID_ENUM_T src, SIP_Rem_Src_Command_ENUM_T src_command)
{
   SIP_rem_src_command_T rr_src;

   rr_src.remote_source_index = (uint8_t) src;
   rr_src.remote_source_command = (uint8_t) src_command;

   VIP_Send(VIPP_EV_REM_AUD_SRC_COMMAND, &rr_src, sizeof(SIP_rem_src_command_T));
}

/*---------------------------------------------------------------------------*
 * Connect / Disconnect Remote Receiver
 *---------------------------------------------------------------------------*/

/*
 * Connect Remote Receiver as external source tuned to SID
 */
void RR_Connect(void)
{
   rr_set_source(SIP_REM_SDAR_SRC, SIP_REM_SRC_CONNECT);
}

/*
 * Disconnect Remote Receiver as external source
 */
void RR_Disconnect(void)
{
   rr_set_source(SIP_REM_SDAR_SRC, SIP_REM_SRC_DISCONNECT);
}

/*---------------------------------------------------------------------------*
 * Standard Tuning
 *---------------------------------------------------------------------------*/

/*
 * Remote Receiver Tune to Station ID (SID)
 * @param sid - desired SID
 */
void RR_Tune_Station_Id(uint16_t sid)
{
   rr_send_command(RR_SID_TUNE, (int16_t) sid);
}

/*
 * Remote Receiver Set Preset (preset)
 * @param preset - Set Preset
 */
void RR_Recall_Preset_Id(uint16_t preset_value)
{
   rr_send_command(RR_RECALL_PRESET_TUNE, (int16_t) preset_value);
}

/*
 * Remote Receiver Recall Preset (preset)
 * @param preset - Recall Preset
 */
void RR_Set_Preset_Id(uint16_t preset_value)
{
   rr_send_command(RR_SET_PRESET, (int16_t) preset_value);
}
/*
 * Remote Receiver Tune to Channel 
 * @param channel - desired channel 
 */
void RR_Tune_Channel(uint16_t channel)
{
   rr_send_command(RR_STATION_TUNE, (int16_t) channel);
}

/*
 * Remote Receiver Tune to Channel 
 * @param channel - desired channel 
 */
void RR_Tune_Delta(int16_t channel_delta)
{
   rr_send_command(RR_STATION_DELTA_TUNE, channel_delta);
}

/*
 * Remote Receiver Scan Up 
 */
void RR_Scan_Up(void)
{
   rr_send_command(RR_SCAN_UP, 0);
}

/*
 * Remote Receiver Scan Down
 */
void RR_Scan_Down(void)
{
   rr_send_command(RR_SCAN_DOWN, 0);
}

/*---------------------------------------------------------------------------*
 * Category Tuning
 *---------------------------------------------------------------------------*/

/*
 * Remote Receiver Set Current Category 
 *    Automatically Tunes to first station in selected category
 * @param cat_id - desired category
 */
void RR_Set_Category(uint16_t cat_id)
{
   rr_send_command(RR_CATEGORY_TUNE, (int16_t) cat_id);
}

/*
 * Remote Receiver Set Category by Delta
 *    Automatically Tunes to first station in selected category
 * @param cat_delta - change of category ID
 */
void RR_Change_Category(int16_t cat_delta)
{
   rr_send_command(RR_CATAGORY_DELTA_TUNE, cat_delta);
}

/*
 * Remote Receiver Scan Up within current Category
 */
void RR_Scan_Up_In_Cat(void)
{
   rr_send_command(RR_SCAN_CAT_UP, 0);
}

/*
 * Remote Receiver Scan Down within current Category
 */
void RR_Scan_Down_In_Cat(void)
{
   rr_send_command(RR_SCAN_CAT_DOWN, 0);
}

/*
 * Remote Receiver Delta Tune within current Category
 * @param channel - desired channel 
 */
void RR_Tune_Delta_In_Cat(int16_t channel_delta)
{
   rr_send_command(RR_STATION_DELTA_IN_CAT, channel_delta);
}

/*---------------------------------------------------------------------------*
 * List Requests
 *---------------------------------------------------------------------------*/

/*
 * Remote Receiver Request Station List
 */
void RR_Request_Station_List(void)
{
   rr_send_command(RR_LIST_REQUEST, FULL_CHANNEL_LIST);
}

/*
 * Remote Receiver Request Category List
 */
void RR_Request_Category_List(void)
{
   rr_send_command(RR_LIST_REQUEST, CATEGORY_LIST);
}

/*
 * Remote Receiver Request Station List for current Category
 */
void RR_Request_Station_List_In_Cat(void)
{
   rr_send_command(RR_LIST_REQUEST, CHANNELS_IN_CURRENT_CATEGORY_LIST);
}

/*---------------------------------------------------------------------------*
 * Redundant Commands
 *---------------------------------------------------------------------------*/

void RR_Seek_Up(void)
{
   rr_send_command(RR_SEEK_UP, 0);
}

void RR_Seek_Down(void)
{
   rr_send_command(RR_SEEK_DOWN, 0);
}

void RR_Seek_Cat_Up(void)
{
   rr_send_command(RR_SEEK_CAT_UP, 0);
}

void RR_Seek_Cat_Down(void)
{
   rr_send_command(RR_SEEK_CAT_DOWN, 0);
}

/*---------------------------------------------------------------------------*
 * Tune Select
 *---------------------------------------------------------------------------*/
/*===========================================================================*
 *
 * Please refer to the detailed description in remote_receiver_tun_sel.h
 *
 *===========================================================================*/

extern void RR_Tune_Sel_Send_Command(SIP_Rem_Rcvr_Commands_ENUM_T cmd, int16_t tune_value)
{
   rr_send_command(cmd, tune_value);
}

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_remote_receiver.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * -04-April-2012 Gustavo M Guzman Ver 8
 *    - kok_basa#23806 XM Diagnostics is not implemented.
 *      Update the XM Recall and Preset functionality
 *
 * 22-Mar-2012 Ever P Cortes (sz68t3)      Rev 7
 * kok_basa#23634: VIP code, audio arbitration needs to be updated and cleaned up.
 * Send DESIP message having source ID and command: connect, disconnect, no action.
 *
 * 15-Feb-2012 Antonio C. Arriaga (bzrth8) Rev 6
 * CR kok_basa#15216: Add logic to support the XM box connection and disconnection process 
 *
 *  19-Oct-2011 Antonio C. Arriaga (bzrth8)
 *  Add new Remote Receiver function to send through 
 *  DESIP protocol a Tune Select command.
 *
 * - 27-April-2009 David Mooar - Rev 3
 *   - SCR 59684 - Fix list request functions.
 *
 * - 18-March-2009 Dan Carman
 *   - SCR 59427 - Add redundant commands because GM requirement
 *
 * - 23-Jan-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

