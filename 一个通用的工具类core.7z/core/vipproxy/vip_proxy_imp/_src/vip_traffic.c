/*===========================================================================*/
/**
 * @file vip_traffic.c
 *
 * This proxy implements the TRAFFIC API via the VIP
 *
 * %full_filespec: vip_traffic.c~1:csrc:ctc_ec#5 %
 * @version %version: 1 %
 * @author  %derived_by: qzb3mh %
 * @date    %date_modified: Fri May 30 18:48:05 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements TRAFFIC reads/writes from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include "pbc_trace.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 11);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*
 *  TRF_TMC_Filter
 *    This function will send a TMC filter set request
 */
void TRF_TMC_Filter(uint8_t index, uint8_t table_id, uint16_t broadcast_service_id, uint8_t traffic_usage)
{
   SIP_TMC_Filter_T filter;
   uint16_t service_id_swap;

   filter.index = index;
   filter.table_id = table_id;
   service_id_swap = broadcast_service_id << 8;
   filter.broadcast_service_id = (broadcast_service_id >> 8) | service_id_swap; /* LSB first, MSB after */
   filter.traffic_usage = traffic_usage;

   VIP_Send(VIPP_EV_TMC_FILTER, &filter, sizeof(SIP_TMC_Filter_T));
}

/*
 *  TRF_Traffic_Status
 *    This function will send the traffic status signal
 */
void TRF_Traffic_Status(void)
{
   VIP_Send(VIPP_EV_TRAFFIC_STATUS, NULL, 0);
}

/*===========================================================================*/
/*!
 * @file vip_traffic.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 14-Oct-2011 zzgqx5
 *   - Created initial file.
 */
/*===========================================================================*/
