/*===========================================================================*/
/**
 * @file vip_uart.c
 *
 * Implements the communication channel interface for VIP DESIP
 *
 * %full_filespec:vip_uart.c~1:csrc:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:05 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements VIP DESIP calls for communciation channel (open, getc, putc)
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "reuse.h"
#include "pbc_trace.h"
#include "uart.h"
#include "vip_desip_acbk.h"
#include "vip_uart_cbk.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 8);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/**
 * Define end of message to trigger actual transmit 
 */
#define END_OF_MSG  (0x1C)

/**
 * Define size of local buffer to match UART HARDWARE FIFO
 */
#define TX_BUF_SIZE  (16)

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*\
 * Implement VIP Interface communications callouts
\*---------------------------------------------------------------------------*/

/* This function initializes the underlying communications (UART, etc) channel
 * used by the VIP interface
 */
void VIPP_Open_Comm_Channel(void)
{
   const UA_Attribute_T uart_attr = {
      UA_8_DATA_BITS,
      UA_1_STOP_BIT,
      UA_NO_PARITY,
      57600,
      UA_HANDSHAKE_NONE,
      256,
      256
   };

   if (VIP_UART_Channel != UA_Open(VIP_UART_Channel, &uart_attr))
   {
      PBC_Failed("UART did not open\n");
   }
}

/*add for touch screen function by steven cheng start*/
/* This function initializes the underlying communications (UART, etc) channel
 * used by the touch screen interface
 */
void TSIP_Open_Comm_Channel(void)
{
   const UA_Attribute_T uart_attr = {
      UA_8_DATA_BITS,
      UA_1_STOP_BIT,
      UA_NO_PARITY,
      115200,
      UA_HANDSHAKE_NONE,
      256,
      256
   };

   if (TSI_UART_Channel != UA_Open(TSI_UART_Channel, &uart_attr))
   {
      Tr_Warn("UART4 did not open\n");
   }
}
/*add for touch screen function by steven cheng end*/

/* 
 * VIP DESIP serial byte receive function
 *
 * @return next incoming byte value (0-0xFF) or EOF (-1) if no data is available
 */
int16_t VIPP_Get_Byte(void)
{
   int32_t rx_byte;

   rx_byte = UA_Getc(VIP_UART_Channel);

   return (int16_t) rx_byte;
}

/*add for touch screen function by steven cheng start*/
/* 
 * TSI DESIP serial byte receive function
 *
 * @return next incoming byte value (0-0xFF) or EOF (-1) if no data is available
 */
int16_t TSIP_Get_Byte(void)
{
   int32_t rx_byte;

   rx_byte = UA_Getc(TSI_UART_Channel);

   Tr_Info_Lo_1(" %02X ", rx_byte);

   return (int16_t) rx_byte;
}
/*add for touch screen function by steven cheng end*/

/* 
 * VIP DESIP serial byte transmit function
 *
 * @param byte to transmit on serial link 
 *
 * @return byte sent or EOF (-1) if byte was not sent (tx buffer full)
 */
int16_t VIPP_Put_Byte(uint8_t tx_byte)
{
   static uint8_t vip_tx_buf[TX_BUF_SIZE];
   static uint_fast8_t vip_tx_idx = 0;

   vip_tx_buf[vip_tx_idx++] = tx_byte;

   if ((END_OF_MSG == tx_byte) || (vip_tx_idx >= sizeof(vip_tx_buf)))
   {
      int32_t bytes_sent = 0;

      while (bytes_sent < vip_tx_idx)
      {
         bytes_sent += UA_Puts(VIP_UART_Channel, &vip_tx_buf[bytes_sent], vip_tx_idx - bytes_sent);

         if (bytes_sent < vip_tx_idx)
         {
            SAL_Sleep(1);
         }
      }
      vip_tx_idx = 0;
   }

   return 0;
}

/*add for touch screen function by steven cheng start*/
/* 
 * TSI DESIP serial byte transmit function
 *
 * @param byte to transmit on serial link 
 *
 * @return byte sent or EOF (-1) if byte was not sent (tx buffer full)
 */
int16_t TSIP_Put_Byte(uint8_t tx_byte)
{
   static uint8_t vip_tx_buf[TX_BUF_SIZE];
   static uint_fast8_t vip_tx_idx = 0;

   vip_tx_buf[vip_tx_idx++] = tx_byte;

   Tr_Info_Lo_1(" => %02X ", tx_byte);
   if ((END_OF_MSG == tx_byte) || (vip_tx_idx >= sizeof(vip_tx_buf)))
   {
      int32_t bytes_sent = 0;

      while (bytes_sent < vip_tx_idx)
      {
         bytes_sent += UA_Puts(TSI_UART_Channel, &vip_tx_buf[bytes_sent], vip_tx_idx - bytes_sent);

         if (bytes_sent < vip_tx_idx)
         {
            SAL_Sleep(1);
         }
      }
      vip_tx_idx = 0;
   }

   return 0;
}

/*add for touch screen function by steven cheng end*/

/*===========================================================================*/
/*!
 * @file vip_uart.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 18-Jan-2014 Li Hui 
 *   ctc_ec#59294 Update uart baud rate to adapt to k0R for chk041 and ford project. 
 *
 * - 03-May-2010 Octavio Rocha rev. 5
 *   SCR kok_basa#1509 VIP_Proxy Update to support 4 GMLAN calibrations
 *   via Xmodem. 
 *
 * - 15-July-2009 Dan Carman
 *   - J2's UART driver is more efficient with fewer large request.  Each new
 *    tx request does a busy wait for the previous request to complete. Therefore
 *    byte by byte transmit basically tying up the CPU for the entire transmit time.
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

