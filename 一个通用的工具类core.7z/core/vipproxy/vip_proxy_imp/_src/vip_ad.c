/*===========================================================================*/
/**
 * @file vip_ad.c
 *
 * This proxy implements the A/D API as a proxy for VIP services
 *
 * %full_filespec:vip_ad.c~1:csrc:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:02 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements A/D reads from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - A/D - Analog to Digital conversion
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "reuse.h"
#include "pbc_trace.h"
#include "ad.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 2);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*---------------------------------------------------------------------------*\
 * Implement A/D API functions s
\*---------------------------------------------------------------------------*/

/*
 * Reads an single A/D channel
 *
 * See ad.h for details 
 */
bool AD_Read_Channel(AD_Channel_T channel, uint16_t * counts)
{
   SAL_Message_T const *reply_msg;
   bool success = false;
   SIP_AD_Channel_T chan = (SIP_AD_Channel_T) channel;

   reply_msg = VIP_Send_Wait_Reply(VIPP_EV_AD_READ, &chan, sizeof(SIP_AD_Channel_T), EVG_AD_DATA);

   if (NULL != reply_msg)
   {
      SIP_AD_Results_T *results = (SIP_AD_Results_T *) reply_msg->data;
      if (results->counts_valid)
      {
         *counts = results->counts;
         success = true;
      }
   }

   return success;
}

/*
 * Reads an A/D Channel relative to another A/D channel
 *
 * See ad.h for details 
 */
bool AD_Read_Ratio(AD_Channel_T chan, AD_Channel_T ref_chan, uint16_t * ratio)
{
   SIP_AD_Ratiometeric_Request_T request;
   SAL_Message_T const *reply_msg;
   bool success = false;

   request.chan = (SIP_AD_Channel_T) chan;
   request.ref_chan = (SIP_AD_Channel_T) ref_chan;

   reply_msg =
      VIP_Send_Wait_Reply(VIPP_EV_AD_READ_RATIOMETERIC, &request, sizeof(SIP_AD_Ratiometeric_Request_T), EVG_AD_DATA);

   if (NULL != reply_msg)
   {
      SIP_AD_Results_T *results = (SIP_AD_Results_T *) reply_msg->data;
      if (results->counts_valid)
      {
         *ratio = results->counts;
         success = true;
      }
   }

   return success;
}

/**
 * Shuts down A/D module
 */
void AD_Shutdown(void)
{
   /* Nothing to do */
}

/*===========================================================================*/
/*!
 * @file vip_ad.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

