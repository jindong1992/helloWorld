/*===========================================================================*/
/**
 * @file vip_dio.c
 *
 * This proxy implements the VIP DIO API
 *
 * %full_filespec:vip_dio.c~1:csrc:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:02 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements DIO reads from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "vip_desip.h"
#include "vip_dio.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 5);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/*
 * Reads DIO input from VIP
 * @return true if pin is high
 */
bool VDIO_Is_High(SIP_VIP_Ports_Enum_T port, uint8_t pin)
{
   SAL_Message_T const *reply_msg;
   bool pin_high = false;

   PBC_Require_2((port < VIP_NUM_PORTS) && (pin < 8), "Invalid VIP port / pin index %u-%u", port, pin);

   reply_msg = VIP_Send_Wait_Reply(VIPP_EV_READ_VIP_GPIO_PORT, &port, sizeof(SIP_VIP_Ports_T), EVG_VIP_GPIO_PORT);

   if (NULL != reply_msg)
   {
      SIP_VIP_Port_State_T *results = (SIP_VIP_Port_State_T *) reply_msg->data;

      if (port == results->port)
      {
         pin_high = 0 != (results->pins & (1U << pin));
      }
      else
      {
         Tr_Warn("Wrong VIP port value returned");
      }
   }
   else
   {
      Tr_Warn("Unable to read VIP port");
   }
   return pin_high;
}

/*
 * Sets DIO output state on VIP without waiting for reply
 */
void VDIO_Set_High_No_Wait(SIP_VIP_Ports_Enum_T port, uint8_t pin, bool high)
{
   SIP_Set_VIP_Port_T port_settings;
   uint8_t pin_mask = (uint8_t) (1U << pin);

   PBC_Require_2((port < VIP_NUM_PORTS) && (pin < 8), "Invalid VIP port / pin index %u-%u", port, pin);
   port_settings.port = (SIP_VIP_Ports_T) port;

   if (high)
   {
      port_settings.pin_set = pin_mask;
      port_settings.pin_clear = 0;
   }
   else
   {
      port_settings.pin_set = 0;
      port_settings.pin_clear = pin_mask;
   }

   VIP_Send(VIPP_EV_SET_VIP_GPIO_PORT, &port_settings, sizeof(port_settings));
}


/*
 * Sets DIO output state on VIP
 */
void VDIO_Set_High(SIP_VIP_Ports_Enum_T port, uint8_t pin, bool high)
{
   SIP_Set_VIP_Port_T port_settings;
   uint8_t pin_mask = (uint8_t) (1U << pin);
   SAL_Message_T const *reply_msg;

   PBC_Require_2((port < VIP_NUM_PORTS) && (pin < 8), "Invalid VIP port / pin index %u-%u", port, pin);
   port_settings.port = (SIP_VIP_Ports_T) port;

   if (high)
   {
      port_settings.pin_set = pin_mask;
      port_settings.pin_clear = 0;
   }
   else
   {
      port_settings.pin_set = 0;
      port_settings.pin_clear = pin_mask;
   }

   reply_msg = VIP_Send_Wait_Reply(VIPP_EV_SET_VIP_GPIO_PORT, &port_settings, sizeof(port_settings), EVG_VIP_GPIO_PORT);
   
   if (NULL != reply_msg)
   {
      SIP_VIP_Port_State_T *results = (SIP_VIP_Port_State_T *) reply_msg->data;

      if (port == results->port)
      {
         bool pin_state = (0 != (results->pins & pin_mask));
         if (high != pin_state)
         {
            Tr_Warn_3("Wrong VIP pin value returned %d %d 0x%X", (int) pin, (int) high, (int) results->pins);
         }
      }
      else
      {
         Tr_Warn_2("Wrong VIP port value returned %d %d", port, results->port);
      }
   }
   else
   {
      Tr_Warn("No reply to set VIP port");
   }
}

/*
 * Set Direction for DIO pin on VIP
 */
void VDIO_Set_Direction(SIP_VIP_Ports_Enum_T port, uint8_t pin, DIO_Direction_T direction)
{
   SIP_Set_VIP_Port_Direction_T port_settings;
   uint8_t pin_mask = (uint8_t) (1U << pin);

   PBC_Require_2((port < VIP_NUM_PORTS) && (pin < 8), "Invalid VIP port / pin index %u-%u", port, pin);
   port_settings.port = (SIP_VIP_Ports_T) port;

   if (DIO_INPUT == direction)
   {
      port_settings.pin_input = pin_mask;
      port_settings.pin_output = 0;

   }
   else                         /* DIO_OUTPUT */
   {
      port_settings.pin_input = 0;
      port_settings.pin_output = pin_mask;
   }

   VIP_Send(VIPP_EV_SET_VIP_GPIO_PORT_DIRECTION, &port_settings, sizeof(port_settings));
}

/*===========================================================================*/
/*!
 * @file vip_dio.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 01-Dec-2008 Dan Carman
 *   - Added non-blocking VDIO set Pin function.
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

