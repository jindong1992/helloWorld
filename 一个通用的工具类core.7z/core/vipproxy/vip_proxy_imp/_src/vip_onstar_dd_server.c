/*===========================================================================*/
/**
 * @file vip_onstar_dd_server.c
 *
 * This proxy implements the ONSTAR DD API via the VIP
 *
 * %full_filespec:  vip_onstar_dd_server.c~1:csrc:ctc_ec#5 %
 * @version %version:  1 %
 * @author  %derived_by:  qzb3mh %
 * @date    %date_modified:   Fri May 30 18:48:03 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements ONSTAR DD reads/writes from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include "pbc_trace.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 10);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/

/* 
 *  Nav_Onstar_DD_Resolution_Report
 *    This function will send the Onstar Destination Download Resolution
 */
void Nav_Onstar_DD_Resolution_Report(SIP_Onstar_DD_Address_Resolution_T onstar_dd_resolution)
{
   VIP_Send(VIPP_EV_ONSTAR_DD_RESOLUTION, &onstar_dd_resolution, sizeof(SIP_Onstar_DD_Address_Resolution_T));
}

/*===========================================================================*/
/*!
 * @file vip_onstar_dd_server.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 29-Jan-2012 Ever P Cortes (sz68t3)
 *   - Created initial file.
 */
/*===========================================================================*/

