/*===========================================================================*/
/**
 * @file vip_pwm.c
 *
 * This proxy implements the PWM API via the VIP
 *
 * %full_filespec:vip_pwm.c~1:csrc:ctc_ec#16 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:04 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Implements IIC reads from VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - IIC - Analog to Digital conversion
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "pbc_trace.h"
#include "pwm.h"
#include "vip_desip.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Local Preprocessor #define Constants
 *===========================================================================*/
EM_FILENUM(VIP_DESIP_MODULE_ID, 9);     /* Identifies file for PbC trace */

/*===========================================================================*
 * Local Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Local Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Object Definitions
 *===========================================================================*/

/*===========================================================================*
 * Local Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Local Inline Function Definitions and Function-Like Macros
 *===========================================================================*/

/*===========================================================================*
 * Function Definitions
 *===========================================================================*/


/* 
 *  Generate a PWM output 
 *    This function will configure the necessary I/O and timer to generate the 
 *    requested output signal
 * See pwm.h for details
 */
void PWM_Set_Output(PWM_Channel_T channel_num, uint32_t freq_hz, uint16_t duty_cycle)
{
   SIP_PWM_T pwm_data;

   pwm_data.vip_channel = (uint8_t) channel_num;
   pwm_data.frequency_Hz = freq_hz;
   pwm_data.duty_cycle = duty_cycle;

   VIP_Send(VIPP_EV_SET_PWM, &pwm_data, sizeof(SIP_PWM_T));
}

/*===========================================================================*/
/*!
 * @file vip_pwm.c
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 05-sep-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/

