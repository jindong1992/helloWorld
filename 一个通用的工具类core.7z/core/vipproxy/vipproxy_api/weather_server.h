#ifndef WEATHER_SERVER_H
#   define WEATHER_SERVER_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file weather_server.h
 *
 * API for Weather Server (XM Data Services)
 *
 * %full_filespec:weather_server.h~1:incl:ctc_ec#4 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:08 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API for controlling  Weather Server (XM Data Services).
 *    via published messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup weather_server VIP Weather Server (XM Data Services) Command Interface
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/* 
 *  WTR_Vehicle_Position
 *    This function will send the currect vehicle position
 */
void WTR_Vehicle_Position(int32_t latitude, int32_t longitude);

/* 
 *  WTR_Weather_Awake
 *    This function will send the weather awake signal
 */
void WTR_Weather_Awake(void);

/* 
 *  WTR_Weather_Feature_Status
 *    This function will send the weather feature status signal
 */
void WTR_Weather_Feature_Status(void);

/* 
 *  WTR_City_Forecast
 *    This function will send the City Forecast request
 */
void WTR_City_Forecast(uint8_t city_code);

/* 
 *  WTR_Warning_Current_Location
 *    This function will send the Warning Current Location enable request
 */
void WTR_Warning_Current_Location(bool_t enable);

/* 
 *  WTR_Forecast_Metar_Warning_Current_Location
 *    This function will send the Forecast/Metar/Warning Current Location request
 */
void WTR_Forecast_Metar_Warning_Current_Location(void);

/* 
 *  WTR_Forecast_Metar_Other_City
 *    This function will send the Forecast/Metar Other City request
 */
void WTR_Forecast_Metar_Other_City(uint8_t city_code);

/* 
 *  WTR_Metar_From_Location
 *    This function will send the Metar From Location request
 */
void WTR_Metar_From_Location(int32_t latitude, int32_t longitude);

/* 
 *  WTR_Metar_From_Location
 *    This function will send the Metar From Location request
 */
void WTR_Forecast_Metar_Other_Location(int32_t latitude, int32_t longitude);

/* 
 *  WTR_Weather_Alerts_Popup
 *    This function will send the Weather Alerts Popup enabled request
 */
void WTR_Weather_Alerts_Popup(bool_t alerts_popup);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file weather_server.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 09-Apr-2012 Ernesto Beltran (zzgqx5) Rev 4
 *   - SCR kok_basa#24141: NAV Weather: XM Subscription and Audio present
 *
 * - 20-Feb-2012 Ernesto Beltran (zzgqx5) Rev 3
 *   - SCR kok_basa#22340: NAV Weather - Alerts Pop Up Categories Update
 *
 * - 08-Dec-2011 Dan Kiel (gzhs41) Rev 2
 *   - Task 61332, Integrate weather functionality 
 *   - fix eols 
 *
 * - 28-Sep-2011 zzgqx5
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* WEATHER_SERVER_H */

