#ifndef VIP_INTP_H
#   define VIP_INTP_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_intp.h
 *
 * API for control of Edge Interrupts on VIP
 *
 * %full_filespec:vip_intp.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:06 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Supports interrupt detection on VIP.  The use of this API will result in long latency 
 * until the interrupt is served.  Use only for infrequent interrupts.  Anything that requires
 * a quick or frequent response should  be handle by VIP specific code (for example RDS decode).
 *
 * @section ABBR ABBREVIATIONS:
 *   - INTP - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup vip_intp VIP Edge Interrupt APIs
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "reuse.h"
#   include "desip_msg_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/** List of possible edge interrupts on VIP */

   typedef enum VGPIO_Int_Id_Tag
   {
      VIP_INTP0,
      VIP_INTP1,
      VIP_INTP2,
      VIP_INTP3,
      VIP_INTP4,
      VIP_INTP5,
      VIP_INTP6,
      VIP_INTP7,
      VIP_NUM_INTERRUPTS
   } VGPIO_Int_Id_T;

/** Interrupt configuration  */
   typedef enum VGPIO_Int_Edge_Tag
   {
      VIP_INT_DISABLE,
      VIP_INT_EDGE_FALL,
      VIP_INT_EDGE_RISE,
      VIP_INT_EDGE_BOTH,
   } VGPIO_Int_Edge_T;

/** call back routine for interrupt */
   typedef void (*Interrupt_Callback_T) (void);


/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/** 
 * Enable / Disable Edge Interrupt on VIP 
 *
 * @param vip_int_id - Interrupt to configure
 * @param edge - Desired configuration disable or which edges 
 * @param callback - function to be called when VIP reports interrupt occurrance
 */
   void VGPIO_Interrupt_Configure(VGPIO_Int_Id_T vip_int_id, VGPIO_Int_Edge_T edge, Interrupt_Callback_T callback);

/**
 * Custom decode routine for VIP report interrupt DESIP Message
 *
 * @param int_id - ID of interrupt (INTPn) on VIP
 */
   void VGPIO_Decode_VIP_Interrupt(SIP_Interrupt_Id_T int_id);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_intp.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 15-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_INTP_H */

