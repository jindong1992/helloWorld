#ifndef DESIP_MSG_IDS_H
#   define DESIP_MSG_IDS_H
/*===========================================================================*/
/**
 * @file desip_msg_ids.h
 *
 * Defintion of all DESIP messages IDs between VIP and AP
 *
 * %full_filespec:desip_msg_ids.h~20.1.5:incl:ctc_ec#31 %
 * @version %version:20.1.5 %
 * @author  %derived_by:fzpr6s %
 * @date    %date_modified:Mon May  8 15:01:40 2017 %
 */
#   define DESIP_MSG_IDS_VERSION      "%version:20.1.5 %"

/*
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Header and data type definition for all DESIP messages. All message data types
 *    are assume to be dependent upon just this file with the exception of standard 
 *    C types.
 *
 * @section ABBR ABBREVIATIONS:
 *   - DESIP - Delco Electronics Serial Interface Protocol
 *   - VIP - Vehicle Interface Processor 
 *   - AP - Application Processor 
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo What about functional error handling (i.e., IIC write or A/D read fails) ?
 *
 * @defgroup desip_msg DESIP message ID definitions
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/
/* 
 * DESIP_Msg is for DESIP message with fixed data length
 * DESIP_Msg_ND is for DESIP message with no data
 * DESIP_Msg _VL is for DESIP message with variable length data 
 */


typedef short DESIP_Header_T;
/**
 * XMacro to define all DESIP messages from AP to VIP
 *    Data types are defined in desip_msg_types.h
 */
                            


#define DESIP_VIP_CAN_Msg()    DESIP_VIP_Msg(CAN_SystemPowerMode,      SIP_VIP_CAN8_T,                       "")\
                               DESIP_VIP_Msg(CAN_TrailerSts,      SIP_VIP_CAN8_T,                       "")\
                               DESIP_VIP_Msg(CAN_PowerModeBackup,      SIP_VIP_CAN8_T,                       "")\
                               DESIP_VIP_Msg(CAN_PowerModeBackEnable,      SIP_VIP_CAN8_T,                "")\
                               DESIP_VIP_Msg(CAN_PASWorkCmd,      SIP_VIP_CAN8_T,                       "")\
                               DESIP_VIP_Msg(CAN_ACCDBackgroundLightCmd,      SIP_VIP_CAN8_T,                       "")\
                               DESIP_VIP_Msg(CAN_BackgroundLightLvl,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_BattVolt,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_TrunkSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_PosLmpSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_DoorLockSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_BattSaveDelaySts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_DomeLampDelaySts,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_FollowMeDelaySts,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_RLS_Sts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_AntitheftSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_PASActiveSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_PitchAngle,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_PitchAngleSign,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FPADetectionFOL,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FPADetectionFML,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FPADetectionFMR,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FPADetectionFOR,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FOLErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FMLErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FMRErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FORErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RollAngle,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_RollAngleSign,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RPADetectionROL,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RPADetectionRML,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RPADetectionRMR,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RPADetectionROR,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_ROLErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RMLErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RMRErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RORErrorFlag,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_SteeringWheelAngle,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_SteeringWheelAngleSign,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_TQI_ACOR,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_ShiftLeverPos,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_TransOilTemp,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_VehicleSpd,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_BRAKE_SW,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_BRAKE_SW_Qualification,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_ENG_COOLANT,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_BARO_PRESSURE,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_EstimatedTorque,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_FeedbackAFSDrivingSide,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RvcOperationState,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RvcButtonGroup,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_GuideVoiceReq,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FrtBlwFnSpSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrBlwFnSpSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_DrStTmpDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_PassStTmpDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FrtOutletMdDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FrtInletMdDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_ZoneDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_ACDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_HvacAutoDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_HvacOffSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrContrlDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrOutletMdDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrAutoDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrOffSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrPassStTmpDspSts,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrOutletMdIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrAutoIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrPassStTmpIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_FrHVACDspIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrHVACDspIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_RrBlwFnSpIO,      SIP_VIP_CAN8_T,            "")\
                               DESIP_VIP_Msg(CAN_PEPS_UnlockModSts,      SIP_VIP_CAN8_T,      "")\
                               DESIP_VIP_Msg(EX_DTC_Res,           SIP_EX_DTC_Res_T,      "")\
                               DESIP_VIP_Msg(CAN_Surroundstate,           SIP_VIP_CAN8_T,      "")\
                               DESIP_VIP_Msg(POWE_ON_RTD_REPLY,       SIP_Bool_T,        "Reply message POWE_ON_RTD")\
                               DESIP_VIP_Msg(VSS_VEHICLE_SPEED,        SIP_VSS_Vehicle_Speed_T,   "VSS Vehicle Speed") \
                               DESIP_VIP_Msg(RVC_FAULT,                SIP_RVC_Fault_T,   "") \
                               DESIP_VIP_Msg(RDS_DATA_BLOCK_II,  SIP_DE_Block_Msg_T, "Report RDS Data Block") \
                               DESIP_VIP_Msg(RDS_DATA_BLOCK_BCD_II, SIP_DE_Block_Msg_BCD_T,"Report RDS Data Block for Blocks B, C & D") \
                               DESIP_VIP_Msg(CAN_AMP_SWVersion,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_AMP_HWVersion,      SIP_VIP_CAN16_T,            "")\
                               DESIP_VIP_Msg(CAN_AMP_TempValue,      SIP_VIP_CAN8_T,             "")\
                               DESIP_VIP_Msg(CAN_AMP_VolValue,       SIP_VIP_CAN8_T,             "")\
                               DESIP_VIP_Msg(CAN_DriverSeatHeatSts,   SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_PassSeatHeatSts,     SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_DriverSeatVentSts,   SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_PassSeatVentSts,     SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_DriverSeatMassageSts,SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_PassSeatMassageSts,  SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_DriverSeatSupportSts,SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_PassSeatSupportSts,  SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_DrStHtngSwActn,      SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_PassStHtngSwActn,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_RVMFoldModSts_DDCM,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_RVMFoldModSts_PDCM,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_KeyMemoPosEnableSts,    SIP_VIP_CAN8_T,   "")\
                               DESIP_VIP_Msg(CAN_DrStHtngSwSts,          SIP_VIP_CAN8_T,  "")\
                               DESIP_VIP_Msg(CAN_PassStHtngSwSts,        SIP_VIP_CAN8_T,  "")\
                               DESIP_VIP_Msg(CAN_VehTotalMileage,        SIP_VIP_CAN8_T,  "")\
                               DESIP_VIP_Msg(CAN_VehTotalMileageValid,   SIP_VIP_CAN8_T,  "")\


#   define DESIP_AP_to_VIP_Msgs \
   DESIP_AP_Msg   (GEN_ECL_PULSE,                    SIP_ECL_Pulse_T,            "#01 Generate ECL Pulse"                       ) \
   DESIP_AP_Msg_ND (AP_GET_SWC_FAILURE_STATUS,                                   "#REQURST THE SWC FAILURE STATUTS"                         ) \
   DESIP_AP_Msg   (AP_READY,                         SIP_AP_Ready_T,             "#03 AP Ready Status"                          ) \
   DESIP_AP_Msg_ND(AP_ALIVE,                                                     "#04 AP is alive"                              ) \
   DESIP_AP_Msg_ND(GET_SPEED_SIGNAL_FAILURE_STAUS,                                   "#05 Request   Speed signal failure" ) \
   DESIP_AP_Msg_ND(IMMEDIATE_SHUTDOWN,                                           "#06 Request Shutdown"                         ) \
   DESIP_AP_Msg   (DE_RESET,                         SIP_Sync_T,                 "#07 Resync RDS"                               ) \
   DESIP_AP_Msg_ND(AUX_JACK_REQUEST,                                             "#08 Request Physical AUX Jack Status"         ) \
   DESIP_AP_Msg_ND(BUC_REQUEST,                                                  "#09 Buc Request ACC and Reverse Status"                        ) \
   DESIP_AP_Msg_ND(LIGHT_MODE_REQUEST,                                                "#0A request light mode"                        ) \
   DESIP_AP_Msg   (QBA_DIAGNOSTICS,                  SIP_QBA_Diagnostics_T,      "#0B QBA Diagnostics"                          ) \
   DESIP_AP_Msg_VL(IIC_WRITE,                        SIP_IIC_Write_T,            "#0C IIC Write"                                ) \
   DESIP_AP_Msg   (SET_DATE_TIME,                    SIP_Date_Time_T,            "#0D Set Date / Time"                          ) \
   DESIP_AP_Msg   (RMT_ENABLE,                       SIP_Rmt_Enable_T,           "#0E SIP Rmt Enable/Disable"                   ) \
   DESIP_AP_Msg   (RMT_MUTE,                         SIP_Rmt_Mute_T,             "#0F SIP Rmt Mute/Unmute"                      ) \
   DESIP_AP_Msg   (IIC_READ,                         SIP_IIC_Read_T,             "#10 IIC Read Request"                         ) \
   DESIP_AP_Msg   (SYSTEM_COMMAND,                   SIP_System_Command_T,       "#11 ILIN System Command"                      ) \
   DESIP_AP_Msg_ND(LIN_COMM_STATUS_REQ,                                          "#12 Request LIN communication status"         ) \
   DESIP_AP_Msg   (VIP_APP_REFLASH,                  SIP_VIP_TX_Reflash_Files_T, "#13 Enter VIP app. code reflash"              ) \
   DESIP_AP_Msg_ND(AP_REMOVED_05,                                                   "#14 Most is Ready"                            ) \
   DESIP_AP_Msg_ND(COLD_START,                                                   "#15 Request Cold Start"                       ) \
   DESIP_AP_Msg   (CAMERA_ENABLE,                    SIP_Camera_Enable_T,        "#16 Camera Enable Output"                     ) \
   DESIP_AP_Msg   (POWER_MODE_STATUS,                SIP_Power_Mode_Status_T,    "#17 Power mode status"                        ) \
   DESIP_AP_Msg_ND(APP_SWID_REQ,                                                 "#18 Request Application SWID"                 ) \
   DESIP_AP_Msg_ND(BOOT_SWID_REQ,                                                "#19 Request Boot SWID"                        ) \
   DESIP_AP_Msg   (PITS_GYRO_TEST_REQ,               SIP_PITS_GYRO_TEST_T,       "#1A Request begin/stop a GYRO selftest"       ) \
   DESIP_AP_Msg   (MICROPHONE_ENABLE_STATE,          SIP_Mic_Ena_Request_T,      "#1B Enable or Disable Microphone State"       ) \
   DESIP_AP_Msg_ND(VOLTAGE_VALUE_REQ,                                            "#1C Request Battery Voltage Level"            ) \
   DESIP_AP_Msg_ND(DIAG_RUNNING,                                                 "#1D Diagnostics is Running"                   ) \
   DESIP_AP_Msg_ND(AP_SHUTDOWN_INITIATED,                                        "#1E AP is preparing for shutdown"             ) \
   DESIP_AP_Msg_ND(AP_RESET_REQUEST,                                             "#1F AP requests to be reset"                  ) \
   DESIP_AP_Msg   (AP_SOH_MONITOR_STATUS,            SIP_SOH_Monitor_Status_T,   "#20 AP enables/disables SOH monitoring by VIP") \
   DESIP_AP_Msg_ND(LIN_CONFIGURATION_REQ,                                        "#21 LIN Configuration"                        ) \
   DESIP_AP_Msg   (DSLR_PWR_SUPPLY_FREQ,             SIP_DSLR_PWR_SUPPLY_FREQ_T, "#22 DSLR power supply frequency"              ) \
   DESIP_AP_Msg   (ANTENNA_POWER_STATUS,             SIP_Power_Antenna_Status_T, "#23 Antenna power mode status"                ) \
   DESIP_AP_Msg_ND(AP_REMOVED_06,                                               "#24 ECL Configuration"                        )\
   DESIP_AP_Msg_ND(AP_PWR_ANTENA_CURRENT_STATUS_REQ,                             "#25 Request Power antenna enable/disable"     ) \
   DESIP_AP_Msg_ND(AP_RMT_CURRENT_STATUS_REQ,                                    "#26 Request Remote enable/disable and mute/unmute" ) \
   DESIP_AP_Msg   (PITS_VSS_INPUT_CONFIG_REQ,        SIP_PITS_VSS_INPUT_CONFIG_T,"#27 PITS, VSS input type change request"      ) \
   DESIP_AP_Msg_ND(PITS_VSS_INPUT_GET_REQ,                                       "#28 PITS, VSS input get information Request"  ) \
   DESIP_AP_Msg   (CHECKSUM16_K0R_REQUEST,           SIP_Cheksum_Request_T,      "#29 K0R Checksum Request"                     ) \
   DESIP_AP_Msg_ND(MICROPHONE_FAILURE_STATUS_REQ,                                "#2A Microphone Failure Status Request"        ) \
   DESIP_AP_Msg_ND(MICROPHONE_AD_VALUE_REQ,                                      "#2B Microphone AD Value Request"              ) \
   DESIP_AP_Msg_ND(FACEPLATE_BOOT_SWID_REQ,                                         "facelate boot swid request"                    )\
   DESIP_AP_Msg   (PITS_READ_AD_PORTS_REQ,           SIP_READ_AD_PORTS_REQ_T,    "#2D PITS read AD value from VIP"              ) \
   DESIP_AP_Msg_ND(ANTENNA_CURRENT_DRAW_REQ,                                     "#2E Request Antenna Current Draw"             ) \
   DESIP_AP_Msg_ND(FACEPLATE_APP_SWID_REQ,                                        "faceplate app swid request"               )\
   DESIP_AP_Msg_ND(WAKEUP_SOURCE_REQUEST,                                        "#30 AP is requesting the wakeup source"       ) \
   DESIP_AP_Msg   (VSS_FACTOR_INFO_RPT,              SIP_VSS_FACTOR_T,           "#31 Report VSS factor to VIP, unit:pulse/mile") \
   DESIP_AP_Msg_ND(AP_REMOVED_09,                              "Request logical ignition state") \
   DESIP_AP_Msg_ND(GET_POWER_SUPPLY_STATUS,                          "Request Power Supply Status") \
   DESIP_AP_Msg(SET_POWER_SUPPLY,         SIP_Set_Power_Supply_T,    "Set Power Supply State") \
   DESIP_AP_Msg(READ_VIP_GPIO_PORT,       SIP_VIP_Ports_T,           "Read VIP GPIO Port value") \
   DESIP_AP_Msg(SET_VIP_GPIO_PORT,        SIP_Set_VIP_Port_T,        "Set / Clear VIP GPIO Port Pins") \
   DESIP_AP_Msg(SET_VIP_GPIO_PORT_DIRECTION, SIP_Set_VIP_Port_Direction_T,  "Set VIP GPIO Port direction") \
   DESIP_AP_Msg(SET_VIP_GPIO_INTERRUPT,   SIP_Set_Interrupt_T,       "Configure VIP edge Interrupt") \
   DESIP_AP_Msg(AD_READ,                  SIP_AD_Channel_T,          "A/D Read Request") \
   DESIP_AP_Msg(AD_READ_RATIOMETERIC,     SIP_AD_Ratiometeric_Request_T,  "A/D Ratiometeric Read Request") \
   DESIP_AP_Msg(SET_PWM,                  SIP_PWM_T,                 "PWM Output Request") \
   DESIP_AP_Msg_VL(PITS_REPLY,            SIP_PITs_Msg_T,            "Pits Diagnostic Reply") \
   DESIP_AP_Msg(REM_AUD_SRC_COMMAND,      SIP_rem_src_command_T,     "Remote Audio Source Command") \
   DESIP_AP_Msg(REM_RECEIVER_COMMAND,     SIP_Rem_Rcvr_Command_T,    "Remote Receiver Command") \
   DESIP_AP_Msg(ARB_TXT_REQ_COMMAND,      SIP_Arb_Txt_Req_Command_T, "Arbitration Text Request Command") \
   DESIP_AP_Msg(FACEPLATE_K0R_CHECKSUM_REQUEST,              SIP_Cheksum_Request_T,     "Faceplate checksum request") \
   DESIP_AP_Msg(CD_READY_FOR_IDLE,        SIP_Bool_T,                "CD ready to go idle") \
   DESIP_AP_Msg(QUEUE_RSA_STATUS_CONNECTED, SIP_RSA_Active_Source_T, "Queue_RSA_Status_Connected") \
   DESIP_AP_Msg(TUNNER_STAUS,           TUNNER_STATUS_T,      "TUNNER Band and frequence") \
   DESIP_AP_Msg(READ_VIP_FLASH_BLOCK,     SIP_VIP_Flash_Read_T,      "Read a block of VIP Flash") \
   DESIP_AP_Msg(MODULE_SUBSTITUTION,      SIP_MODULE_SUB_T,          "SET AD Limits") \
   DESIP_AP_Msg(ARB_TXT_ICON_REQ_COMMAND, SIP_Arb_Txt_Icon_Req_Com_T,"request to HUD for icon and text") \
   DESIP_AP_Msg_VL(PS_COMMAND_REPLY,      SIP_PS_Msg_T,              "Reply Persistent Storage Command")\
   DESIP_AP_Msg_VL(GM_DTC_SET_REQ,        SIP_GM_DTC_T,              "Set DTC Value Request")\
   DESIP_AP_Msg_VL(AUD_DRV_MGR_CMD,       SIP_Aud_Drv_Mgr_Cmd_T,     "Command to Audio Driver Manager") \
   DESIP_AP_Msg_VL(CHI_GEN_BEEP_CMD,      SIP_Chi_Gen_Beep_Cmd_T,     "Command to Generate Beep") \
   DESIP_AP_Msg_VL(TUNER_DRV_CMD,         SIP_Tuner_Drv_Cmd_T,       "Command to Tuner Driver") \
   DESIP_AP_Msg(DIM_DISP_STATUS,          SIP_DIM_Display_State_Lvl_T,  "Set Backlight State") \
   DESIP_AP_Msg(BOARD_TYPE_VALUE,         SIP_Board_Type_T,            "transmit board type to VIP") \
   DESIP_AP_Msg(ARB_TXT_NAV_MENU_ACTION,  SIP_Arb_Txt_Nav_Menu_Action_T,"display menu action to Onstar")\
   DESIP_AP_Msg(AUDIO_MASTER_ARBITRATION_COMMAND,  SIP_Audio_Master_Arbitration_Command_T ,"Audio Master Arbitration Command")\
   DESIP_AP_Msg(ICR_ENG_CALS_INFO,        SIP_Icr_Eng_Cals_Info_T ,     "ICR eng cals info")\
   DESIP_AP_Msg_ND(REQUEST_INIT_LIST,                                "Request init. messages") \
   DESIP_AP_Msg_ND(NAV_RESET_REQUEST,                                "Request GPS Receiver Reset") \
   DESIP_AP_Msg(BT_CALL_STATUS,           SIP_BT_call_status_T,      "BT Call status") \
   DESIP_AP_Msg(RSA_ON_STAT_TO_AUDMGR,    SIP_Bool_T,                "Send RSA On Status to Audio Manager") \
   DESIP_AP_Msg_ND(CALS_CHECKSUMS,                                "Request Cals Checksums")\
   DESIP_AP_Msg(REQUEST_CALS_DATA,  SIP_Cals_Section_Name_T,  "Request Date / Time")\
   DESIP_AP_Msg(RSE_EN_CTRL,        SIP_Bool_T,      "Notify VIP to Power On/Off RSE")\
   DESIP_AP_Msg(VOICEREC_STATE,    SIP_VoiceRec_State_T,                "Voice Rec State") \
   DESIP_AP_Msg(VOICEREC_REM_ONSTAR_CMD, SIP_VoiceRec_Rem_Onstar_Cmd_T, "SWC VR Start Stop") \
   DESIP_AP_Msg(VEHICLE_POSITION,         SIP_Vehicle_Position_T,       "Vehicle Position Status") \
   DESIP_AP_Msg_ND(WEATHER_AWAKE,                                       "NAV Weather Awake Command") \
   DESIP_AP_Msg(CITY_FORECAST,            SIP_City_Forecast_T,          "Decode City For Forecast") \
   DESIP_AP_Msg_ND(WEATHER_CURRENT,                                     "Current Forecast/Metar Weather") \
   DESIP_AP_Msg(WEATHER_OTHER_CITY,       SIP_Weather_Other_City_T,     "Other City Forecast/Metar Weather") \
   DESIP_AP_Msg(METAR_FROM_LOCATION,      SIP_Metar_From_Loc_T,         "Metar From Location") \
   DESIP_AP_Msg(WEATHER_OTHER_LOCATION,   SIP_Weather_Other_Loc_T,      "Other Location Forecast/Metar Weather") \
   DESIP_AP_Msg_ND(TRAFFIC_STATUS,                                      "Traffic Status") \
   DESIP_AP_Msg(TMC_FILTER,               SIP_TMC_Filter_T,             "Traffic TMC Filter") \
   DESIP_AP_Msg(ARB_TXT_NAV_DISTANCE_HUD,   SIP_Arb_Txt_Nav_Distance_HUD_T, "Sends Navigation distance info to HUD")\
   DESIP_AP_Msg(ARB_TXT_NAV_STREET_ICON_HUD,   SIP_Arb_Txt_Nav_Street_Icon_HUD_T, "Sends Navigation street and icon info to HUD")\
   DESIP_AP_Msg_VL(PITS_SERVER_COMMAND,    SIP_PITs_Msg_T,              "Pits Server Diagnostic Request") \
   DESIP_AP_Msg_ND(REQUEST_BOOT_CAL_DATA,                               "request small set of cals required in icr_core_1 process")\
   DESIP_AP_Msg(BENCH_MODE_CALIB_TIMER_VALUE, SIP_Bench_Mode_Timer_Value,"bench mode calibration timer value")\
   DESIP_AP_Msg_VL(CHI_GEN_BEEP_FOR_PRESS_HOLD, SIP_Chi_Gen_Beep_Cmd_T,  "Command to Generate Beep") \
   DESIP_AP_Msg_ND(RESET_REQUEST,                                        "AP request for reset") \
   DESIP_AP_Msg(ONSTAR_DD_RESOLUTION,         SIP_Onstar_DD_Address_Resolution_T, "Onstar Destination Download resolution")\
   DESIP_AP_Msg_ND(REQUEST_CLEAR_VIN,                                    "Request VIP to clear VIN")\
   DESIP_AP_Msg(ALERT_NOTIFICATION,       SIP_Bool_T,                   "Alert Notification Setting") \
   DESIP_AP_Msg_ND(AP_REMOVED_14,                                  "Avoid GMLAN reflash while USB reflashing")\
   DESIP_AP_Msg_ND(WEATHER_FEATURE_STATUS,                              "NAV Weather Feature Status Request") \
   DESIP_AP_Msg(WARNING_CURRENT,          SIP_Bool_T,                   "Current Warning Alerts") \
   DESIP_AP_Msg(CAN_DomeLampDelayTSet,        SIP_CAN_DomeLampDelayTSet_T,         "")\
   DESIP_AP_Msg(CAN_FollowMeDelayTSet,        SIP_CAN_FollowMeDelayTSet_T,         "")\
   DESIP_AP_Msg(CAN_BattSaveDelaySet,         SIP_CAN_BattSaveDelaySet_T,         "")\
   DESIP_AP_Msg(CAN_AFSDrivingSideSet,        SIP_CAN_AFSDrivingSideSet_T, "")\
   DESIP_AP_Msg(CAN_RLSSet,                   SIP_CAN_RLSSet_T, "")\
   DESIP_AP_Msg(CAN_AntiTheftSetting,         SIP_CAN_AntiTheftSetting_T, "S")\
   DESIP_AP_Msg(CAN_PASActiveSet,             SIP_CAN_PASActiveSet_T, "")\
   DESIP_AP_Msg(CAN_RearViewMirrorSet,        SIP_CAN_RearViewMirrorSet_T, "")\
   DESIP_AP_Msg(CAN_UnlockModSts,             SIP_CAN_UnlockModSts_T, "")\
   DESIP_AP_Msg(CAN_FrtHMIClmCtrlSwActn,      SIP_CAN_FrtHMIClmCtrlSwActn_T, "")\
   DESIP_AP_Msg(CAN_RrHMIClmCtrlSwActn,       SIP_CAN_RrHMIClmCtrlSwActn_T,  "")\
   DESIP_AP_Msg(AP_REMOVED_15,                   SIP_EX_DTC_Req_T,"Request ex DTC from AP")\
   DESIP_AP_Msg(CAN_User_Input_Cmd,           SIP_CAN_User_Input_Cmd_T,"")\
   DESIP_AP_Msg(AP_REMOVED_16,             SIP_CAN_Surround_Cmd_T,"")\
   DESIP_AP_Msg(AP_REMOVED_17,              SIP_Time_Format_T,            "Time Format (12hr or 24hr)") \
   DESIP_AP_Msg(AP_REMOVED_18,       SIP_Disp_Language_Selection_T,"Display Language Selection") \
   DESIP_AP_Msg(AP_REMOVED_19,SIP_Onstar_Call_Status_Action_T,"HMI action on onstar call") \
   DESIP_AP_Msg_ND(AP_REMOVED_20,                                   "HMI request retrieval of in-vehicle alerts") \
   DESIP_AP_Msg(SET_FACEPLATE_GPIO_PORT,       SIP_Set_VIP_Port_T,   "set the  facepate GPIO port output") \
   DESIP_AP_Msg(READ_FACEPLATE_GPIO_PORT,     SIP_VIP_Port_State_T,"read the faceplate GPIO Port value") \
   DESIP_AP_Msg(AP_REMOVED_23,  SIP_Radio_Menu_List_Action_T, "HMI reports menu list field select action") \
   DESIP_AP_Msg_ND(CAN_TRANSCEIVER_SHUTDOWN,         "Send CAN Transceiver shutdown status to K0R") \
   DESIP_AP_Msg(FACEPLATE_FLASH,        SIP_Faceplate_Data_T,      "xmodem  data for reflash faceplate") \
   DESIP_AP_Msg(RSE_COMMAND,        SIP_RSE_Status_T,      "Send Command to RSE") \
   DESIP_AP_Msg(GWM_DID_SYNC,        SIP_GWM_DID_SYNC_T,      "Sync GWM DID information from AP to VIP at power on") \
   DESIP_AP_Msg_ND(VIP_SW_Version_REQ,                                     "Request Vip SW Version") \
   DESIP_AP_Msg(POWE_ON_RTD,        SIP_Bool_T,      "Notify VIP to Power On/Off RTD") \
   DESIP_AP_Msg(CAN_LanguageSet,        SIP_CAN_LanguageSet_T,      "") \
   DESIP_AP_Msg(CAN_TimeSet_Hour,       SIP_VIP_CAN8_T,      "") \
   DESIP_AP_Msg(CAN_TimeSet_Minutes,    SIP_VIP_CAN8_T,      "") \
   DESIP_AP_Msg_ND(AMP_Info_REQ,                                  "") \
   DESIP_AP_Msg(GPS_ALTITUDE,        SIP_Altitude_T,      "Notify VIP to Altitude") \
   DESIP_AP_Msg(GPS_DIRECTION,        SIP_Direction_T,      "Notify VIP to Direction") \
   DESIP_AP_Msg(ALTITUDE_DIRECTION,    SIP_Altitude_Direction_T,"")/*Notify VIP to Altitude Direction*/ \
   DESIP_AP_Msg(CHI_GEN_RING_TONE,     SIP_Chi_Gen_Ring_Tone_T, "")/*Command to Generate Ring Tone*/ \
   DESIP_AP_Msg(AP_REMOVED_26,         CD_Current_Temperature_T,"")/*Notify VIP to CD temperature */ \
   DESIP_AP_Msg(GPS_LAT_LON,           SIP_LAT_LON_T,       "") /*Notify VIP to LAT and LON Direction*/\
   DESIP_AP_Msg(KeyMemoPosEnable,      SIP_VIP_CAN8_T,      "") /*Key memory position enable*/\
   DESIP_AP_Msg(DriverSeatSupportSet,  SIP_VIP_CAN8_T,      "") /*Driver Seat supporting Setting*/\
   DESIP_AP_Msg(DriverSeatHeatSet,     SIP_VIP_CAN8_T,      "") /*Driver Seat Heating Setting*/\
   DESIP_AP_Msg(PassSeatHeatSet,       SIP_VIP_CAN8_T,      "") /*Passenger Seat Heating Setting*/\
   DESIP_AP_Msg(DriverSeatVentSet,     SIP_VIP_CAN8_T,      "") /*Driver Seat ventilation Setting*/\
   DESIP_AP_Msg(PassSeatVentSet,       SIP_VIP_CAN8_T,      "") /*Passenger Seat supporting Setting*/\
   DESIP_AP_Msg(PassSeatSupportSet,    SIP_VIP_CAN8_T,      "") /*Passenger Seat supporting Setting*/\
   DESIP_AP_Msg(DriverSeatMassageSet,  SIP_VIP_CAN8_T,      "") /*Driver Seat massage Setting*/\
   DESIP_AP_Msg(PassSeatMassageSet,    SIP_VIP_CAN8_T,      "") /*Passenger Seat massage Setting*/\
   DESIP_AP_Msg(SELECT_RSE_SPDIF, SIP_Bool_T, "Notify VIP to select RSE SPDIF ") \
   DESIP_AP_Msg_ND (AP_GET_ANTENNA_STATUS,   "#REQURST THE AM/FM ANTENNA STATUTS"                         ) \
   DESIP_AP_Msg_ND(AP_GET_GPS_ANT_STATUS,   "#REQUEST THE GPS ANTENNA STATUS"		)/*query GPS status */ \
   DESIP_AP_Msg(AP_SET_GPS_ANT_POWER,  SIP_GPS_Power_Antenna_Req_T, "#SET THE GPS ANTENNA POWER"		)/* set gps antenna power */ \
   DESIP_AP_Msg   (TOD_CAL,                          SIP_TOD_Calibration_T,      "TOD Calibration value"                    ) \
   
/**
 * @todo Add additional AP messages
 * - Display remote text
 * - Connect arbitrary audio source 
 * - Remote XM commands
 * - etc.
 */

/**
 * XMacro to define all DESIP messages from VIP to AP
 */
#   define DESIP_VIP_to_AP_Msgs \
   DESIP_VIP_Msg   (SWC_FAILURE_STATUS,           SIP_SWC_Failure_Status_T,          "swc failure status"              ) \
   DESIP_VIP_Msg   (VIP_ALIVE,                     SIP_MSG_ID_Version_T,            "#42 VIP is alive"                           ) \
   DESIP_VIP_Msg   (VIP_REMOVED_01,  SIP_Face_St_Msg_T,               "#43 Faceplate Status Message"               ) \
   DESIP_VIP_Msg_ND(VIP_REMOVED_021,                                                 "#44 Unused message #1"                      ) \
   DESIP_VIP_Msg   (VIP_WAKEUP_SOURCE,             SIP_Wake_Event_T,                "#45 Wakeup Source"                          ) \
   DESIP_VIP_Msg   (AUX_JACK_STATUS,               SIP_AUX_Jack_Msg_T,              "#46 Aux Jack Status"                        ) \
   DESIP_VIP_Msg   (DATE_TIME,                     SIP_Date_Time_T,                 "#47 Report Date and Time"                   ) \
   DESIP_VIP_Msg_ND(VIP_REMOVED_02,                                            "#48 Notify Most Reset Complete"             ) \
   DESIP_VIP_Msg   (DTC_BATTERY_VOLTAGE_STATUS,    SIP_DTC_Battery_Voltage_Status_T,"#49 DTC Baterry Voltage Status"             ) \
   DESIP_VIP_Msg   (QBA_CHANNEL_DIAG_STATUS,       SIP_QBA_Channel_Diag_Status_T,   "#4A QBA Channel Diagnostic Status"          ) \
   DESIP_VIP_Msg_VL(IIC_READ_DATA,                 SIP_IIC_Read_Data_T,             "#4B Report Data from IIC Read"              ) \
   DESIP_VIP_Msg   (VIP_SWID,                      SIP_VIP_Swid_T,                  "#4C Report VIP swid"                        ) \
   DESIP_VIP_Msg   (VIP_REMOVED_03,           SIP_LVM_Display_Req_T,           "#4D Request LVM Display"                    ) \
   DESIP_VIP_Msg   (VIP_REMOVED_04,             SIP_LVM_Audio_Req_T,             "#4E Request LVM Audio"                      ) \
   DESIP_VIP_Msg_ND(VIP_REMOVED_05,                                                   "#4F RBD initialized - pulse started"        ) \
   DESIP_VIP_Msg_ND(VIP_REMOVED_06,                                                  "#50 Start RBD - pulse complete"             ) \
   DESIP_VIP_Msg   (AUDIO_REPORT_DDL,              SIP_Audio_Report_DDL_Status_T,   "#51 Report DDL indication"                  ) \
   DESIP_VIP_Msg   (BATTERY_VOLTAGE_STATUS,        SIP_Battery_Voltage_Status_T,    "#52 Report Battery Voltage Status"          ) \
   DESIP_VIP_Msg   (ANTENNA_STATUS,                SIP_Antenna_Status_T,            "#53 Report Antenna Status"                  ) \
   DESIP_VIP_Msg   (VIP_BOOT_SWID,                 SIP_VIP_Swid_T,                  "#54 Report K0R Boot Swid"                   ) \
   DESIP_VIP_Msg   (VIP_REMOVED_07,                   SIP_ILIN_Status_T,               "#55 Report ILIN Status"                     ) \
   DESIP_VIP_Msg   (VIP_REMOVED_08,          SIP_LIN_Comm_Lost_Status_T,      "#56 LIN Communication Lost Status"          ) \
   DESIP_VIP_Msg_ND(VIP_VSS_FACTOR_REQUEST,                                         "#57 Reqest VSS pulse to calculate speed"    ) \
   DESIP_VIP_Msg   (BATTERY_VOLTAGE_VALUE,         SIP_Battery_Voltage_T,           "#58 Report Voltage battery value"           ) \
   DESIP_VIP_Msg   (PITS_GYRO_TEST_STATUS,         SIP_PITS_GYRO_TEST_STATUS_T,     "#59 Report GYRO selftest reslut"            ) \
   DESIP_VIP_Msg   (PITS_VSS_INPUT_REPORT,         PITS_VSS_INPUT_CONFIG_REP_T,     "#5A Report PITS VSS input info "            ) \
   DESIP_VIP_Msg_ND(AP_SHUTDOWN_INITIATED_RECEIVED,                                 "#5B Received AP is preparing for shutdown"  ) \
   DESIP_VIP_Msg   (VIP_REMOVED_09,      SIP_LIN_Config_Status_T,         "#5C LIN Configuration Status"               ) \
   DESIP_VIP_Msg   (VIP_REMOVED_10,             SIP_RMT_En_Status_T,             "#5D Report Remote Enable Status"            ) \
   DESIP_VIP_Msg   (REPORT_FACEPLAET_CHECKSUM,                SIP_Cheksum_Report_T,   "#Faceplate K0R Checksum Report"                      ) \
   DESIP_VIP_Msg   (VIP_PWR_ANTENA_CURRENT_STATUS, SIP_Power_Antenna_Status_T,      "#5F Antenna power mode status"              ) \
   DESIP_VIP_Msg   (VIP_REMOVED_12,        SIP_Rmt_Status_T,                "#60 Remote Enable and mute status"          ) \
   DESIP_VIP_Msg   (CHECKSUM16_K0R_REPORT,         SIP_Cheksum_Report_T,            "#61 K0R Checksum Report"                    ) \
   DESIP_VIP_Msg   (MICROPHONE_FAILURE_STATUS,     SIP_Microphone_Failure_Status_T, "#62 Microphone Failure Status Report"       ) \
   DESIP_VIP_Msg   (MICROPHONE_AD_VALUE,           SIP_Microphone_AD_Value_T,       "#63 Microphone AD Value Report"             ) \
   DESIP_VIP_Msg   (VIP_REMOVED_13,             SIP_Camera_Enable_T,             "#64 Camera status"                          ) \
   DESIP_VIP_Msg   (VIP_REMOVED_14,           SIP_MOST_ECL_DTC_Status_T,       "#65 MOST  ECL DTC Status"                   ) \
   DESIP_VIP_Msg   (VIP_REMOVED_15,        SIP_Antenna_Status_T,            "#66 DAB Antenna Status"                     ) \
   DESIP_VIP_Msg   (TEMPERATURE_STATUS,            SIP_Temper_Status_T,             "#67 report temperature Status"              ) \
   DESIP_VIP_Msg   (VSS_INFO,                      SIP_VSS_INFO_T,                  "#68 report vehicle speed info"              ) \
   DESIP_VIP_Msg   (VIP_REMOVED_16,        SIP_Hscan_ComLine_Status_T,      "#69 report HSCAN Comm Enable line status"   ) \
   DESIP_VIP_Msg   (VIP_AD_PORTS_REPORT,           SIP_READ_AD_VALUE_RPT_T,         "#6A report AD Value of specified AD Port"   ) \
   DESIP_VIP_Msg   (ANTENNA_CURRENT_DRAW,          SIP_Antenna_Current_Draw_T,      "#6B Report Antenna Current Draw"            ) \
   DESIP_VIP_Msg   (K0R_STATUS,                    SIP_K0R_Status_T,                "#6C K0R boot an app status"                 ) \
   DESIP_VIP_Msg   (VIP_REMOVED_17,     SIP_Non_Touch_Display_Status_T,  "#6D Non-Touch Display Status"               ) \
   DESIP_VIP_Msg(POWER_MODE_STATE,         SIP_Power_Mode_T,          "Report Power Mode") \
   DESIP_VIP_Msg(SPEED_SIGNAL_FAILURE,      SPEED_SIGNAL_Failure_Status_T,                "Report    speed signal failure") \
   DESIP_VIP_Msg(VIP_REMOVED_19,       SIP_Power_Supply_T,        "Report Power Supply State") \
   DESIP_VIP_Msg(VEHICLE_POWER_MODE,       SIP_Vehicle_Power_Mode_T,  "Vehicle Power Mode")\
   DESIP_VIP_Msg(VIP_GPIO_PORT,            SIP_VIP_Port_State_T,      "Report VIP GPIO Port value") \
   DESIP_VIP_Msg(VIP_INTERRUPT,            SIP_Interrupt_Id_T,        "Report Edge Interrupt Occurred") \
   DESIP_VIP_Msg(KNOB_VOL_DELTA,           SIP_Knob_Delta_T,          "Report Volume Knob Change") \
   DESIP_VIP_Msg(KNOB_SELECT_DELTA,        SIP_Knob_Delta_T,          "Report Select / Tune Knob Change") \
   DESIP_VIP_Msg(KEY_MSG_ID,               SIP_Key_Msgs_IDs_T,        "Report Logical Key ID") \
   DESIP_VIP_Msg(AD_DATA,                  SIP_AD_Results_T,          "Report A/D Read Results") \
   DESIP_VIP_Msg(BATTERY_VOLTAGE,          SIP_Battery_Voltage_T,     "Report Battery Voltage") \
   DESIP_VIP_Msg(RDS_DATA_BLOCK,           SIP_DE_Block_Msg_T,        "Report RDS Data Block") \
   DESIP_VIP_Msg(AP_START_STOP,            SIP_AP_Ready_T,            "AP start/stop") \
   DESIP_VIP_Msg_VL(PITS_COMMAND,          SIP_PITs_Msg_T,            "Pits Diagnostic Request") \
   DESIP_VIP_Msg(REM_AUD_SRC_STATUS,       SIP_rem_src_status_T,      "Remote Audio Source Status") \
   DESIP_VIP_Msg(REM_RECEIVER_STATUS,      SIP_Rem_Rcvr_Status_T,     "Remote Receiver Status") \
   DESIP_VIP_Msg_VL(SD_CHANNEL_LABEL,      SIP_SD_Channel_Label_T,    "SDAR Channel Label") \
   DESIP_VIP_Msg_VL(SD_ARTIST_LABEL,       SIP_SD_Artist_Label_T,     "SDAR Artist Label") \
   DESIP_VIP_Msg_VL(SD_SONG_LABEL,         SIP_SD_Song_Label_T,       "SDAR Song Label") \
   DESIP_VIP_Msg_VL(SD_CAT_LABEL,          SIP_SD_Cat_Label_T,        "SDAR Channel Label") \
   DESIP_VIP_Msg_VL(SD_CAT_LIST,           SIP_SD_Cat_List_T,         "SDAR Channel Label") \
   DESIP_VIP_Msg_VL(SD_CHANNEL_LIST,       SIP_SD_Channel_List_T,     "SDAR Channel Label") \
   DESIP_VIP_Msg_ND(VIP_REMOVED_20,                                 "Enter calibrations reflash")\
   DESIP_VIP_Msg(PRNDL,                    SIP_PRNDL_T,               "PRNDL Information") \
   DESIP_VIP_Msg(RDS_DATA_BLOCK_BCD,       SIP_DE_Block_Msg_BCD_T,    "Report RDS Data Block for Blocks B, C & D") \
   DESIP_VIP_Msg(ARB_TXT_REQ,              SIP_Arb_Txt_Req_Msg_T,     "Arbitration Text Requestor") \
   DESIP_VIP_Msg(LIN_Display_APP_SW_INFO,         SIP_VIP_Swid_T,      "faceplate_app_sw_id") \
   DESIP_VIP_Msg(LIN_NDP_Display_Boot_SW_INFO,    SIP_VIP_Swid_T,       "faceplate_boot_sw_id") \
   DESIP_VIP_Msg(SCV_VEHICLE_SPEED,        SIP_SCV_Vehicle_Speed_T,   "SCV Vehicle Speed") \
   DESIP_VIP_Msg(RSA_OFF_STATUS,           SIP_Bool_T,                "Report RSA Off status") \
   DESIP_VIP_Msg(ACC_DEVICE_ON_STATUS,     SIP_Acc_Device_On_T,       "Report Acc Device On status") \
   DESIP_VIP_Msg_ND(VIP_REMOVED_23,                                         "UNUSED - need to be removed")\
   DESIP_VIP_Msg(PAR,                      SIP_PAR_T,                 "Report Parking Assistance Rear Object Status") \
   DESIP_VIP_Msg_VL(SEND_VIP_FLASH_BLOCK,  SIP_VIP_Flash_Block_T,     "Send a block of VIP Flash") \
   DESIP_VIP_Msg(VIN_2_17,                 SIP_VIN_2_17_T,            "Report VIN") \
   DESIP_VIP_Msg(CLEAR_VIN,                SIP_Bool_T,                "Report Clear VIN")\
   DESIP_VIP_Msg(NAV_TBT,                  SIP_NAV_TBT_T,             "NAV turn by turn") \
   DESIP_VIP_Msg(NAV_TBT_URGENT,           SIP_NAV_TBT_URGENT_T,      "NAV turn by turn urgent") \
   DESIP_VIP_Msg(NAV_TBT_DISTANCE,         SIP_Nav_Data_T,            "NAV turn by turn distance") \
   DESIP_VIP_Msg_VL(PS_COMMAND_REQ,        SIP_PS_Msg_T,              "Request Persistent Storage Command")\
   DESIP_VIP_Msg(AUD_DRV_MGR_RESP,         SIP_Aud_Drv_Mgr_Resp_T,    "Audio Driver Manager Result") \
   DESIP_VIP_Msg(TUNER_DRV_ACK,            SIP_Tuner_Drv_Mgr_Resp_T,  "Report tuner command results") \
   DESIP_VIP_Msg(TUNER_DRV_REPORT_QUALITY, SIP_Tuner_Drv_Quality_Resp_T,"Report signal quality indicators") \
   DESIP_VIP_Msg(TUNER_DRV_SEEK_FREQ,      SIP_Tuner_Frequency,       "Report updated frequency while seeking") \
   DESIP_VIP_Msg(TUNER_DRV_SEEK_RESULT,    SIP_Bool_T,                "Report tuner seek result") \
   DESIP_VIP_Msg(STR_WH_ANG,               SIP_Str_Wh_Ang_T,          "Report Steering Wheel Angle Information") \
   DESIP_VIP_Msg(ARB_TXT_REQ_COMMAND_EXT,  SIP_AT_Disp_Str_T,         "Display req. from External device telematics") \
   DESIP_VIP_Msg(INTERIOR_DIM_DISP_LEVEL,  SIP_Interior_Dim_Display_Level_T,"GMLAN Dimming value")\
   DESIP_VIP_Msg_ND(AUDIO_DDL_REPORT,                                 "Report DDL indication") \
   DESIP_VIP_Msg(AIRBAG_DEPLOYED,          SIP_Airbag_Deployed_T,     "Air Bag Deployment indication") \
   DESIP_VIP_Msg(VIP_REMOVED_24,         SIP_Onstar_Connected_T,    "Onstar Connected")\
   DESIP_VIP_Msg(PRODUCTION_CONFIGURATION, SIP_Bool_T,                "Production configuration") \
   DESIP_VIP_Msg(AUD_DDL_ENABLE,           SIP_AuDM_DDL_State_T,      "Enable/disable DDL") \
   DESIP_VIP_Msg(VIP_REMOVED_25,                     SIP_RCTA_Info_T,           "rear cross traffic alert") \
   DESIP_VIP_Msg(VIP_WAKEUP,               SIP_Wakeup_T,              "VIP has experienced a wakeup") \
   DESIP_VIP_Msg(GMLAN_LANGUAGE_SELECTION, SIP_Disp_Language_Selection_T,"Display Language Selection") \
   DESIP_VIP_Msg(DISP_MEASUREMENT_SYSTEM,  SIP_Disp_Measurement_Sys_T, "Display Measurement System") \
   DESIP_VIP_Msg(PHONE_STATUS,             SIP_Phone_Status_T,        "Onstar Phone status") \
   DESIP_VIP_Msg(VOICE_RECOGNITION_STATUS, SIP_Voice_Recognition_Status_T, "Voice Recognition Status ") \
   DESIP_VIP_Msg(NAV_TBT_STATUS,           SIP_Nav_TBT_Status_T,      "Nav TBT Status ") \
   DESIP_VIP_Msg(RCTA_LEFT_INDICATION,     SIP_RCTA_Info_T,           "rear cross traffic alert") \
   DESIP_VIP_Msg(RCTA_RIGHT_INDICATION,    SIP_RCTA_Info_T,           "rear cross traffic alert") \
   DESIP_VIP_Msg(OAT_AIR_TEMP_CR,          SIP_Out_Side_Air_TempCr_T, "Outside Air Temprature")\
   DESIP_VIP_Msg(VIP_REMOVED_26,SIP_Bool_T,                "GMLAN Chimes Notification") \
   DESIP_VIP_Msg(SEND_CALS_CHECKSUMS,           SIP_Cals_Checksums_T,      "Cals Checksums") \
   DESIP_VIP_Msg_VL(SEND_CALS_DATA,           SIP_Cals_Data_T,      "Cals Data") \
   DESIP_VIP_Msg(ICR_SWID_HWID,            SIP_ICR_SW_HW_T           ,"ICR Software Hardware version")\
   DESIP_VIP_Msg(VIP_REMOVED_27,  SIP_Onstar_TBT_Voice_Prmpt_Muted_T,  "Onstar TBT Voice Prompts Muted")\
   DESIP_VIP_Msg(ONSTAR_PHONE_SWITCH_ACTIVE,  SIP_Onstar_Phone_Switch_Active_T,  "Onstar Phone Switch Active")\
   DESIP_VIP_Msg(DOOR_OPEN_STATE,          SIP_Bool_T     ,"Comes if Door is OPEN or AJAR")\
   DESIP_VIP_Msg(BATTERY_STATE_CHARGE_LOW_INDICATION, SIP_Battery_State_Charge_Low_Indication_T     ,"Battery State Charge Low Indication")\
   DESIP_VIP_Msg(VEHICLE_FUEL_LEVEL_LOW_INDICATION, SIP_Vehicle_Fuel_Level_Low_Indication_T     ,"Vehicle Fuel Level  Low Indication")\
   DESIP_VIP_Msg_ND(RVS_FAIL_SPEED,                            "RVS Speed Failed or not") \
   DESIP_VIP_Msg_ND(RVS_FAIL_STR_WH,                        "RVS Steering Wheel Angle Failed or not") \
   DESIP_VIP_Msg_ND(RVS_FAIL_TRANSMISSION,               "RVS Speed transmission Failed or not") \
   DESIP_VIP_Msg(GMLAN_REPROGRAMMING,        SIP_Diag_Service_T,         "Report if GMLAN reprogramming is in process")\
   DESIP_VIP_Msg_VL(SD_TUNE_SEL_LIST,        SIP_SD_Tune_Select_Item_T,  "Report SDAR Tune Select  List") \
   DESIP_VIP_Msg_VL(SD_TUNE_SEL_COINCIDENCE, SIP_SD_Tune_Select_Item_T,  "Report SDAR Tune Select  Coincedence") \
   DESIP_VIP_Msg_ND(VEHICLE_POSITION_REQ,                   "Vehicle Position Request") \
   DESIP_VIP_Msg(FORECAST_DAY,          SIP_Forecast_Day_Data_T       ,"XM Weather - 5 Day Forecast")\
   DESIP_VIP_Msg(METAR_DATA,            SIP_Metar_Data_T              ,"XM Weather - Metar")\
   DESIP_VIP_Msg(WEATHER_WARNING,       SIP_Weather_Warning_Data_T    ,"XM Weather - Alert")\
   DESIP_VIP_Msg(FEATURE_STATUS,        SIP_Weather_Feature_Status_T  ,"XM Weather - Feature Status")\
   DESIP_VIP_Msg(ALERTS_POPUP,          SIP_Weather_Alerts_Popup_T    ,"XM Weather - Alert Popup")\
   DESIP_VIP_Msg(ALERTS_POPUP_SETTING,  SIP_Alerts_Popup_Settings_T   ,"XM Weather - Alert Notification")\
   DESIP_VIP_Msg_ND(VIP_REMOVED_28,                                   "XM Weather - Forecast Update Notification")\
   DESIP_VIP_Msg_ND(METAR_UPDATE,                                      "XM Weather - Metar Update Notification")\
   DESIP_VIP_Msg(TMC_FILTER_STATUS,     SIP_TMC_Filter_Status_T       ,"XM Traffic - TMC Filter Status")\
   DESIP_VIP_Msg(TMC_EVENT_DATA,        SIP_TMC_Event_Data_T          ,"XM Traffic - TMC Event Data")\
   DESIP_VIP_Msg(BENCH_MODE,            SIP_Bench_State_T             ,"Bench mode")\
   DESIP_VIP_Msg_ND(RAP_TIMER_EXPIRY_EV,                         "RAP timer expiry event")\
   DESIP_VIP_Msg_VL(PITS_SERVER_REPLAY,    SIP_PITs_Msg_T,            "Pits Server Diagnostic Replay") \
   DESIP_VIP_Msg(RSP_BOOT_CAL_DATA,     SIP_Cal_Boot_T                ,"cals needed for bootup")\
   DESIP_VIP_Msg(ACCESSORY_MODE,       SIP_Bool_T,               "Accessory mode or not")\
   DESIP_VIP_Msg(VIP_DEBUG_TRACE,               VIP_Debug_Trace_T,                  "VIP debug trace message")\
   DESIP_VIP_Msg(VIP_REMOVED_29, SIP_Onstar_DD_Process_Status_T,     "Onstar Destination Download status")\
   DESIP_VIP_Msg_VL(VIP_REMOVED_30,        SIP_ONSTAR_DESTINATION_DOWNLOAD_T,  "Onstar destination download data")\
   DESIP_VIP_Msg(IGNITION_COUNTER,      SIP_Ignition_Count_T,                       "Ignition Counter")\
   DESIP_VIP_Msg(METAR_LIST_STATUS,     SIP_Bool_T                    ,"XM Weather - Metar List Status")\
   DESIP_VIP_CAN_Msg()\
   DESIP_VIP_Msg(VIP_RESET,                SIP_VIP_Reset_T,             "VIP Coldstart reason")\
   DESIP_VIP_Msg(PARK_GEAR_STATUS,         SIP_PARK_Gear_Msg_T, "park gear status")\
   DESIP_VIP_Msg(REV_IN_STATUS,            SIP_REV_Gear_Msg_T,           "reverse gear status")\
   DESIP_VIP_Msg(IGNITION_IN_STATUS,       SIP_IGN_In_Msg_T,   "ignition status")\
   DESIP_VIP_Msg(FACEPLATE_GPIO_PORT_STATE,SIP_VIP_Port_State_T, "Report FACEAPLTE GPIO PORT STATE")\
   DESIP_VIP_Msg(LIN_FACEPLATE_STATUS_MESSAGE,     SIP_Face_St_Msg_T,           "")\
   DESIP_VIP_Msg(BackgroundLightLvl,SIP_Bool_T,   "contrl Backgroundlightlvl")\
   DESIP_VIP_Msg(KEY_RSA,                  SIP_Key_Msgs_IDs_T,          "send RSA keys")\
   DESIP_VIP_Msg(ODI_CUSTOM_RPT,           SIP_ODI_Custom_Rpt_T,        "Report available ODI Customizations")\
   DESIP_VIP_Msg(RSE_STATUS,           SIP_RSE_Status_T,        "Report RSE status")\
   DESIP_VIP_Msg(VIP_SW_Version_RPT,       SIP_VIP_SW_Version_T,        "Report VIP SW Version")\
   DESIP_VIP_Msg(GPS_ANTENNA_STATUS,       SIP_GPS_Antenna_Status_T,        "Report GPS Antenna Status")\
   DESIP_VIP_Msg_ND(VIP_TOD_CAL_REQUEST,                                              "Request TOD calibration"                ) \

/**
 *  @todo Add additional VIP messages
 * - Display arbitrary text
 * - Request arbitrary audio source to be connect
 * - Remote XM data
 * - etc.
 */
/*---------------------------------------------------------------------------*/

#   undef DESIP_AP_Msg
#   undef DESIP_AP_Msg_ND
#   undef DESIP_AP_Msg_VL
#   undef DESIP_VIP_Msg
#   undef DESIP_VIP_Msg_ND
#   undef DESIP_VIP_Msg_VL

#   define DESIP_AP_Msg(id, type, desc)      DESIP_##id,
#   define DESIP_AP_Msg_ND(id, desc)         DESIP_##id,
#   define DESIP_AP_Msg_VL(id, type, desc)   DESIP_##id,
#   define DESIP_VIP_Msg(id, type, desc)     DESIP_##id,
#   define DESIP_VIP_Msg_ND(id, desc)        DESIP_##id,
#   define DESIP_VIP_Msg_VL(id, type, desc)  DESIP_##id,

/** enumeration of all DESIP message IDs */
   typedef enum DESIP_Id_Tag
   {
      DESIP_START_AP_TO_VIP = 0,

      DESIP_AP_to_VIP_Msgs

      DESIP_END_AP_TO_VIP,     
      
      DESIP_START_VIP_TO_AP = ((unsigned short)1 << (8 * sizeof(DESIP_Header_T)-1)) / 4,
      
      DESIP_VIP_to_AP_Msgs

      DESIP_END_VIP_TO_AP
   } DESIP_Id_T;

/** Set to first message in DESIP_AP_to_VIP_Msgs */
#   define DESIP_FIRST_AP_TO_VIP (DESIP_START_AP_TO_VIP + 1)

/** Number of AP msgs */
#   define DESIP_NUM_AP_TO_VIP (DESIP_END_AP_TO_VIP - DESIP_START_AP_TO_VIP - 1)

/** Set to first message in DESIP_VIP_to_AP_Msgs */
#   define DESIP_FIRST_VIP_TO_AP (DESIP_START_VIP_TO_AP + 1)

/** Number of VIP msgs */
#   define DESIP_NUM_VIP_TO_AP (DESIP_END_VIP_TO_AP - DESIP_START_VIP_TO_AP - 1)


/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/


/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* DESIP_MSG_IDS_H */
/*===========================================================================*\
 * File Revision History (top to bottom: first revision to last revision)
 *===========================================================================
 *
 * Date          Rev      userid    (Description on following lines: SCR #, etc)
 * ----------- --------  ---------  --------------------------------------------
 *
 * 02-21-2014     2.0     jz82gw      Task: ctc_basa#59608
 * - update int16_t to be short for compile.
 *
 * 02-18-2014     1.0     jz82gw      Task: ctc_basa#59290
 * - Create initial version of desip message for chb041 and ford project.
 *
 
 *
 *===========================================================================*/

