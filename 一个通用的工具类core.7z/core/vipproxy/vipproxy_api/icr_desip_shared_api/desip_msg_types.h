#ifndef DESIP_MSG_TYPES_H
#   define DESIP_MSG_TYPES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file desip_msg_types.h
 *
 * Defintion of all DESIP message types (i.e., data fields)
 *
 * %full_filespec:desip_msg_types.h~18.1.8:incl:ctc_ec#32 %
 * @version %version:18.1.8 %
 * @author  %derived_by:fzpr6s %
 * @date    %date_modified:Mon May  8 15:01:42 2017 %
 */
#   define DESIP_MSG_TYPES_VERSION      "%version:18.1.8 %"

/*
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Header and data type definition for all DESIP messages. All message data types
 *    are assume to be dependent upon just this file with the exception of standard 
 *    C types.
 *
 * @section ABBR ABBREVIATIONS:
 *   - DESIP - Delco Electronics Serial Interface Protocol
 *   - VIP - Vehicle Interface Processor 
 *   - AP - Application Processor 
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo What about functional error handling (i.e., IIC write or A/D read fails) ?
 *
 * @defgroup desip_msg_type DESIP message data / type definitions
 * @ingroup desip_msg
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#include "reuse.h"


/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/
/*---------------------------------------------------------------------------*/
#   define VIP_ALIVE_KEY    (0x55)
#   define SIP_MSG_ID_LEN   (3)

#   define NUM_QBA_CHANNELS (4)

typedef uint32_t RTC_Trim_Value_T;


/** VIP Version check  */
   typedef struct SIP_MSG_ID_Version_Tag
   {
      uint8_t vip_alive_key;
      char desip_msg_id_version[SIP_MSG_ID_LEN + 1];
      char desip_msg_types_version[SIP_MSG_ID_LEN + 1];
   } SIP_MSG_ID_Version_T;

/*---------------------------------------------------------------------------*/

/** Standard 1 byte bool for DESIP messages */
   typedef uint8_t SIP_Bool_T;

/*---------------------------------------------------------------------------*/

   /* NOTE: This must match APM_AP_Status_T */
   typedef enum
   {
      SIP_AP_NOTHING_READY,
      SIP_AP_SYSTEM_STATE_SERVER_READY,
      SIP_AP_PROGRAMMING_SAFE_MODE_READY,
      SIP_AP_ALL_READY
   } SIP_AP_Ready_Enum_T;

   typedef uint8_t SIP_AP_Ready_T;

/*---------------------------------------------------------------------------*/

/** Time of Day sub-field */
   typedef struct SIP_Time_Of_Day_Tag
   {
      uint8_t hour;
      uint8_t minute;
      uint8_t second;
   } SIP_Time_Of_Day_T;

/** Date sub-field */
   typedef struct SIP_Date_Tag
   {
      uint16_t year;
      uint8_t month;
      uint8_t day;
   } SIP_Date_T;

/** Date / Time Message data definition */
   typedef struct SIP_Date_Time_Tag
   {
      SIP_Date_T date;
      SIP_Time_Of_Day_T time;
   } SIP_Date_Time_T;

/*---------------------------------------------------------------------------
 *   DTC Structs
 *---------------------------------------------------------------------------*/

/* Antenna 1 or 2 */
typedef enum
{
   SIP_ANT1 = 1,
   SIP_ANT2,
   SIP_DAB_ANT,
} SIP_Antenna_Enum_T;

/* DTC status connection of any   */
typedef enum
{
   SIP_NORMAL_OPERATION = 0,
   SIP_SHRT_TO_VBAT,
   SIP_SHRT_TO_GND,
   SIP_OPEN_CIRCUIT,
   SIP_SHORTED_LOAD,
} SIP_DTC_Status_Conection_Enum_T;

typedef uint8_t SIP_DTC_Status_Connection_T;   /* refer SIP_DTC_Status_Conection_Enum_T */

/*Status of the ILIN BUS*/
typedef enum
{
   SIP_NORMAL_COMMUNICATION = 0,
   SIP_ERROR_COMMUNICATION,
}SIP_DTC_ILIN_Bus_Status_T;

/* GPS DTC status connection */
typedef enum
{
    SIP_GPS_ANT_STATUS_INIT = 0,
   SIP_GPS_ANT_STATUS_UNKNOWN,
   SIP_GPS_ANT_STATUS_NORMAL,	
   SIP_GPS_ANT_STATUS_TO_GND,
   SIP_GPS_ANT_STATUS_OPEN,
} SIP_GPS_Ant_Status_T;

typedef enum
{
	SIP_GPS_POWER_STATUS_OFF = 0,
	SIP_GPS_POWER_STATUS_ON,
	SIP_GPS_POWER_STATUS_UNKNOWN,
} SIP_GPS_Power_Status_T;
typedef struct SIP_Antenna_Status_Tag
{
   uint8_t  antenna;          /* refer SIP_Antenna_Enum_T */
   uint8_t  antenna_status;   /* refer SIP_DTC_Status_Conection_Enum_T */
} SIP_Antenna_Status_T;

#if 0
typedef struct SIP_GPS_Antenna_Status_Tag
{
   uint8_t  gps_antenna_status;   /* refer SIP_GPS_DTC_Status_Conection_Enum_T */
} SIP_GPS_Antenna_Status_T;
#else
typedef struct SIP_GPS_Antenna_Status_Tag
{
   uint8_t antenna_status;
   uint8_t power_status;
}SIP_GPS_Antenna_Status_T;
#endif
/*definition to report RMT_en_status*/
typedef uint8_t SIP_RMT_En_Status_T;   /* refer SIP_DTC_Status_Conection_Enum_T */


typedef struct SIP_ILIN_Status_Tag
{
  uint8_t  ILIN_status;            /* refer SIP_DTC_ILIN_Bus_Status_T*/
} SIP_ILIN_Status_T;

 /*-------------------------------------------------------------------------------*/
/** Identifies Edge interrupt on VIP (INTP0-INTP7) */
   typedef uint8_t SIP_Interrupt_Id_T;

#   define SIP_INTR_EDGE_DISABLE (0x00)
#   define SIP_INTR_EDGE_FALL    (0x01)
#   define SIP_INTR_EDGE_RISE    (0x02)
#   define SIP_INTR_EDGE_BOTH    (0x03)
#   define SIP_INTR_REFRESH_FALL (0x81)
#   define SIP_INTR_REFRESH_RISE (0x82)
#   define SIP_INTR_REFRESH_BOTH (0x83)
#   define SIP_INTR_REFRESH_BIT  (0x80)

typedef struct SIP_QBA_Channel_Diag_Status_Tag
{
  uint8_t  channel[NUM_QBA_CHANNELS];          /* refer SIP_DTC_Status_Conection_Enum_T*/
} SIP_QBA_Channel_Diag_Status_T;
/*---------------------------------------------------------------------------*/

/** Define largest allowable IIC write size */
#   define SIP_IIC_MAX_SIZE (32)

/** 
 * Define offset for device addreess 
 *    device address left shifted
 */
#   define SIP_IIC_WRITE_DEVICE_OFFSET (0)

/** Define offset ot start of data buffer */
#   define SIP_IIC_WRITE_DATA_OFFSET (1)

/** IIC Write Request Message data definition */
   typedef struct SIP_IIC_Write_Tag
   {
      uint8_t channel;        /**< VIP IIC channel 0-2 */
      SIP_Bool_T no_stop;     /**< don't generate stop condition and keep bus locked */
      uint8_t num_bytes;      /**< number of data bytes to write */
      uint8_t tx_data[SIP_IIC_MAX_SIZE + 1];  /**< device address + data to write */
   } SIP_IIC_Write_T;

/** IIC Read Request Message data definition */
   typedef struct SIP_IIC_Read_Tag
   {
      uint8_t channel;        /**< VIP IIC channel 0-2 */
      uint8_t device_address; /**< device address left shifted (bit 0 should be cleared) */
      uint16_t num_bytes;     /**< number of data bytes to read */
   } SIP_IIC_Read_T;

/** Report IIC Read Data Message data definition */
   typedef struct SIP_IIC_Read_Data_Tag
   {
      uint8_t channel;        /**< VIP IIC channel 0-2 */
      uint8_t device_address; /**< device address left shifted (bit 0 should be cleared) */
      uint16_t num_bytes;     /**< number of bytes read (0 if read failed) */
      uint8_t rx_data[SIP_IIC_MAX_SIZE];  /**< data read */
   } SIP_IIC_Read_Data_T;

/*---------------------------------------------------------------------------*/
/** Aux Jack States */
   typedef enum SIP_Aux_Jack_Tag
   {
      SIP_AUX_JACK_UNKNOWN,
      SIP_AUX_JACK_DETECT_OPEN,
      SIP_AUX_JACK_DETECT_SHORTED,
	  SIP_AUX_JACK_NOT_PRESENT,
      SIP_AUX_JACK_PRESENT
   } SIP_Aux_Jack_ENUM_T;

/** Aux Jack message data definition  */
   typedef uint8_t SIP_AUX_Jack_Msg_T;

/*---------------------------------------------------------------------------*/
	typedef enum Park_States_Tag
	{
		PARK_GEAR_UNKNOWN,
		PARK_GEAR_ON,
		PARK_GEAR_OFF
	} Park_States_T;

	typedef enum Rev_States_Tag
	{
		REV_IN_UNKNOWN,
		REV_IN_ON,
		REV_IN_OFF
	} Reverse_States_T;

	typedef enum Ignition_States_Tag
	{
		IGNITION_IN_UNKNOWN,
		IGNITION_IN_ON,
		IGNITION_IN_OFF
	} Ignition_States_T;


	typedef enum Acc_States_Tag
	{
		ACC_IN_UNKNOWN,
		ACC_IN_ON,
		ACC_IN_OFF
	} Acc_States_T;

/** Park gear message data definition  */
   typedef uint8_t SIP_PARK_Gear_Msg_T;

/** Reverse gear message data definition  */
   typedef uint8_t SIP_REV_Gear_Msg_T;

/** Ignition in message data definition  */
   typedef uint8_t SIP_IGN_In_Msg_T;

#pragma pack(push)
#pragma pack(1)

/** VIP files to reflash struct */
   typedef struct VIP_file_Tag
   {
      uint8_t  file_id;
      uint32_t file_size;
   } VIP_file_T;
  
   typedef struct SIP_VIP_TX_Reflash_Files_Tag
   {
      uint8_t     cmd;                 /** command to select specific functions as SIP_VIP_Reflash_Cmd_T*/
      uint8_t     num_tx_files;        /** Number of files to transmit to VIP*/
      VIP_file_T  vip_file[8];         /** This value must be the same of higher than NUM_OF_VIP_REFLASH_FILES*/
   } SIP_VIP_TX_Reflash_Files_T;
#pragma pack(pop)

   typedef enum SIP_VIP_Reflash_Cmd_Tag
   {
      RESET_ONLY_IMX,
      FLASH_CALS,
      FLASH_VIPAPP,
      FLASH_CAPSENSE,
      FLASH_ALL,
      JUMP_TO_FBL,
      FLASH_VIP,
#ifdef FORD_C490
      JUMP_TO_FBL_FACEPLATE,
      FLASH_VIPAPP_FACEPLATE,
#endif
   } SIP_VIP_Reflash_Cmd_T;

typedef enum SIP_K0R_Status_Enum_Tag
{
   K0R_CORRECT = 0,
   K0R_APP_CORRUPT
} SIP_K0R_Status_Enum_T;

typedef uint8_t SIP_K0R_Status_T; /* refer to SIP_K0R_Status_Enum_T */

/*---------------------------------------------------------------------------*/
/**
 * data used by HMI to send brightness level set by user
 * via DESIP
 */
typedef uint8_t SIP_DIM_Brightness_Lvl_T;

/**
 * Structure data used by VIP  to report 
 * Faceplate Status Message via DESIP
 */
typedef struct SIP_Face_St_Msg_Tag
{
    uint8_t  faceplate_status[7];  /**< faceplate status message */
} SIP_Face_St_Msg_T;

/**
 * Structure data used by VIP to report 
 * System Command Message over ILIN
 */
#pragma pack(push)
#pragma pack(1)
typedef struct SIP_System_Command_Tag
{
    uint8_t   misc1;
    uint16_t  backlight_brightness;
    uint16_t  display_brightness;
    uint16_t  auxilliary_brightness;
} SIP_System_Command_T;
#pragma pack(pop)

/*---------------------------------------------------------------------------*/

/*VIP Wakeup Source */
typedef enum
{
   SIP_WAKEUP_NOT_EVENT = 0,
   SIP_WAKEUP_BATTERY_CONNECT,
   SIP_WAKEUP_HCAN,
   SIP_WAKEUP_HW_ACC_IN,
   SIP_WAKEUP_POWERON_KEY,
   SIP_WAKEUP_AP_RESET_REQUEST,
   SIP_WAKEUP_K0R_SOH_RESET,
   SIP_WAKEUP_BATTERY_VOLTAGE_NORMAL,
   SIP_WAKEUP_ILIN
} SIP_Wake_Event_Enum_T;

typedef struct SIP_Wake_Event_Tag
{
    uint8_t  wakeup_event; /* refer SIP_Wake_Event_Enum_T*/
} SIP_Wake_Event_T;

/*ILIN Faceplate Wakeup Button */
typedef enum
{
   SIP_ILIN_NONE = 0,
   SIP_ILIN_POWER_BUTTON,
   SIP_ILIN_EJECT_BUTTON,
   SIP_ILIN_STORAGE_UNLOCK
} SIP_ILIN_Wake_Button_Enum_T;

typedef struct SIP_ILIN_Wake_Button_Tag
{
    uint8_t  ilin_wakeup_button; /* refer SIP_ILIN_Wake_Button_Enum_T*/
} SIP_ILIN_Wake_Button_T;

typedef uint8_t SIP_Most_Reset_T;

/*DESIP message for VIP software version */
#pragma pack(push)
#pragma pack(1)
typedef struct SIP_VIP_Swid_Tag
{
  uint32_t sw_id;
  uint16_t sw_version;
  uint8_t  sw_subversion;
}SIP_VIP_Swid_T;
#pragma pack(pop)

typedef enum SIP_Rmt_Enable_Enum_Tag
{
   RMT_ENABLE_OFF,     
   RMT_ENABLE_ON,      
}SIP_Rmt_Enable_Enum_T;

typedef uint8_t SIP_Rmt_Enable_T;  /* refer SIP_Rmt_Enable_Enum_T */

typedef enum SIP_Rmt_Mute_Enum_Tag
{
   RMT_AMP_MUTE,     
   RMT_AMP_UNMUTE,      
}SIP_Rmt_Mute_Enum_T;

typedef uint8_t SIP_Rmt_Mute_T;    /* refer SIP_Rmt_Mute_Enum_T */

typedef struct SIP_Rmt_Status_Tag
{
   SIP_Rmt_Enable_T Rmt_Enable;    
   SIP_Rmt_Mute_T Rmt_Mute;       
}SIP_Rmt_Status_T;

/*  False if DisplayRqst line is Open or < Vbatt/3      */
/*  True if DisplayRqst > Vbatt*2/3                     */
typedef bool_t SIP_LVM_Display_Req_T;

typedef enum SIP_LVM_Audio_Req_Enum_Tag
{
   LVM_AUDIO_REQ_OFF,         /*AudioRqst line: Open or < Vbatt/3         */
   LVM_AUDIO_REQ_MIX_MONO,    /*AudioRqst line: > Vbatt/2  & < Vbatt*2/3  */
   LVM_AUDIO_REQ_STEREO       /*AudioRqst line: > Vbatt*3/4               */
}  SIP_LVM_Audio_Req_Enum_T;

typedef uint8_t SIP_LVM_Audio_Req_T; /* refer SIP_LVM_Audio_Req_Enum_T*/

/*ECL Pulse Type*/
typedef enum
{
   SIP_ECL_PULSE_WAKEUP = 0,
   SIP_ECL_PULSE_RBD,
   SIP_ECL_ASSERT,
   SIP_ECL_RELEASE
} SIP_ECL_Pulse_T;

/*ECL Status*/
typedef enum
{
   SIP_ECL_OFF = 0,
   SIP_ECL_ON
} SIP_ECL_Status_Enum_T;

typedef struct SIP_ECL_Status_Tag
{
uint8_t ECL_status;    /* refer SIP_ECL_Status_Enum_T  */
} SIP_ECL_Status_T;

/*Battery Status */
typedef enum 
{
   SIP_NORMAL_VOLTAGE_STATUS = 0,
   SIP_OVER_VOLTAGE_STATUS,
   SIP_OVER_CAN_VOLTAGE_STATUS,
   SIP_CRITICAL_VOLTAGE_STATUS,
   SIP_LOW_VOLTAGE_STATUS,
   SIP_INVALID_VOLTAGE_STATUS
} SIP_Battery_Voltage_Status_Enum_T;

typedef struct SIP_Battery_Voltage_Status_Tag
{
    uint8_t  voltage_status; /* refer SIP_Battery_Voltage_Status_Enum_T*/
} SIP_Battery_Voltage_Status_T;

/*Type definition for battery voltage coming from K0R to IMX*/
typedef uint8_t SIP_Battery_Voltage_T;

/*Set Camera Enable Output*/
typedef enum 
{
   SIP_CAMERA_DISABLE = 0,
   SIP_CAMERA_ENABLE,
} SIP_Camera_Enable_Enum_T;

typedef struct SIP_Camera_Enable_Tag
{
    uint8_t  camera_enable; /* refer SIP_Camera_Enable_Enum_T*/
} SIP_Camera_Enable_T;

/*Power Mode Status*/
typedef enum 
{
   SIP_POWER_MODE_OFF = 0,
   SIP_POWER_MODE_ACC,
   SIP_POWER_MODE_RUN,
   SIP_POWER_MODE_CRANK,
} SIP_Power_Mode_Status_Enum_T;

typedef struct SIP_Power_Mode_Status_Tag
{
    uint8_t  status; /* refer SIP_Power_Mode_Status_Enum_T*/
} SIP_Power_Mode_Status_T;

typedef uint8_t SIP_Antenna_Current_Draw_T;

/*---------------------------------------------------------------------------*/

/* AP SOH Monitor Enable or Disable to prevent undesired SOH resets 
 * during AP reprogramming modes.  VIP only monitors SOH when this 
 * message is enabled
 */
typedef enum SIP_SOH_Monitor_Status_Enum_Tag
{
   SIP_AP_SOH_MONITOR_DISABLED = 0,
   SIP_AP_SOH_MONITOR_ENABLED
} SIP_SOH_Monitor_Status_Enum_T;

typedef uint8_t SIP_SOH_Monitor_Status_T;  /* refer to SIP_SOH_Monitor_Status_Enum_T */

typedef struct LIN_NODES_BITS_Tag
{
   bool_t node_id_60: 1,
          node_id_61: 1,
          node_id_62: 1,
          node_id_63: 1,
          node_id_64: 1,
          node_id_65: 1,
          node_id_66: 1,
          node_id_67: 1,
          node_id_68: 1,
          node_id_69: 1,
          node_id_6A: 1,
          node_id_6B: 1,
          node_id_6C: 1,
          node_id_6D: 1,
          node_id_6E: 1,
          node_configured: 1;
}LIN_NODES_BITS_T;

typedef union SIP_LIN_Config_Status_Tag
{
   uint16_t nodes_active;
   LIN_NODES_BITS_T lin_nodes;
}SIP_LIN_Config_Status_T;

/*
 * ILIN slaves connection statuses
 * */
typedef struct LIN_DEVICES_BITS_Tag
{
   bool_t device_0: 1,
          device_1: 1,
          device_2: 1,
          device_3: 1,
          device_4: 1,
          device_5: 1,
          device_6: 1,
          device_7: 1;
}LIN_DEVICES_BITS_T;


typedef union SIP_LIN_Comm_Lost_Status_Tag
{
   uint8_t devices_comm_lost;
   LIN_DEVICES_BITS_T lin_devices;
}SIP_LIN_Comm_Lost_Status_T;


typedef enum SIP_DSLR_PWR_SUPPLY_FREQ_Enum_Tag
{
   FREQUENCY_250kHz = 1,
   FREQUENCY_260kHz
} SIP_DSLR_PWR_SUPPLY_FREQ_Enum_T;

typedef uint8_t SIP_DSLR_PWR_SUPPLY_FREQ_T;  /* refer to SIP_DSLR_PWR_SUPPLY_FREQ_Enum_T */

typedef enum SIP_Audio_Report_DDL_Enum_Tag
{
   AUDIO_DDL_DISTORTED = 0,
   AUDIO_DDL_NORMAL
}SIP_Audio_Report_DDL_Enum_T;

typedef uint8_t SIP_Audio_Report_DDL_Status_T;

/*---------------------------------------------------------------------------
 *   CPID Structs
 *---------------------------------------------------------------------------*/
typedef enum
{
   ANTENNA_OFF = 0,
   ANTENNA_ON,
} SIP_Power_Antenna_Status_Enum_T;

typedef struct SIP_Power_Antenna_Status_Tag
{
    uint8_t  Antenna_1;    /* refer SIP_Power_Antenna_Status_Enum_T*/
    uint8_t  Antenna_2;    /* refer SIP_Power_Antenna_Status_Enum_T*/
} SIP_Power_Antenna_Status_T;

typedef struct SIP_GPS_Power_Antenna_Req_Tag
{
    /*
     * 00: Get GPS Antenna Status
     * 01: GPS Antenna Power ON
     * 02: GPS Antenna Power OFF 
     */	
    uint8_t  power_req;
} SIP_GPS_Power_Antenna_Req_T;

/* PIT Microphone status msg->1A90/1A91 */
typedef enum SIP_Microphone_Failure_Status_Enum_Tag
{
   SIP_MIC_NORMAL_OPERATION = 0,
   SIP_MIC_TERMINAL_SHRT_TO_GND,
   SIP_MIC_TERMINAL_SHRT_TO_BATT,
   SIP_MIC_TERMINAL_OPEN_CIRCUIT,
   SIP_MIC_SHORT_TERMINALS,
   SIP_MIC_MAX,
} SIP_Microphone_Failure_Status_Enum_T;
#ifdef FORD_C490
typedef struct SIP_Microphone_Failure_Status_Tag
{
   uint8_t negative_mic;
   uint8_t positive_mic;
}SIP_Microphone_Failure_Status_T; /* refer SIP_Microphone_Failure_Status_Enum_T*/

/* PIT Microphone A/D Value msg->1A92/1A93 */
typedef struct SIP_Microphone_AD_Value_Tag
{
   uint16_t mic_pterminal_value;
   uint16_t mic_nterminal_value;
}SIP_Microphone_AD_Value_T;
#endif
typedef struct SIP_Microphone_Failure_Status_Tag
{
   uint8_t mic_r;
   uint8_t mic_l;
}SIP_Microphone_Failure_Status_T; /* refer SIP_Microphone_Failure_Status_Enum_T*/

/* PIT Microphone A/D Value msg->1A92/1A93 */
typedef struct SIP_Microphone_AD_Value_Tag
{
   uint16_t mic_r_pterminal_value;
   uint16_t mic_r_nterminal_value;
   uint16_t mic_l_pterminal_value;
   uint16_t mic_l_nterminal_value;
}SIP_Microphone_AD_Value_T;

/*definition to report MOST ECL DTC Status_en_status*/
typedef uint8_t SIP_MOST_ECL_DTC_Status_T;   /* refer SIP_DTC_Status_Conection_Enum_T */

/* TOD Calibration */
typedef struct SIP_TOD_Calibration_Tag
{
   uint16_t tod_cal_value;
} SIP_TOD_Calibration_T;

/* add by dzyfvd */
/* QBA Diagnostics */
typedef enum QBA_Diagnostics_Enum_Tag
{
   DISABLE_QBA = 0,
   ENABLE_QBA
}QBA_Diagnostics_Enum_T;

typedef struct SIP_QBA_Diagnostics_Tag
{
   uint8_t diagnostics;  /* refer to QBA_Diagnostics_Enum_T */
}SIP_QBA_Diagnostics_T;

/*
 * desip msg structure for for Phone status.
 */

typedef enum SIP_Phone_Call_status_Tag
{
   SIP_NO_CALL_ACTIVE,
   SIP_IN_COMMING_CALL,
   SIP_VOICE_CALL_ACTIVE,
   SIP_DATA_CALL_ACTIVE
}SIP_Phone_Call_status_T;

typedef enum Phone_Call_Type_Tag
{
   SIP_ONSTAR_ADVISOR_CALL,
   SIP_VIRTUAL_ADVISOR_CALL,
   SIP_PERSONAL_CALL,
   SIP_ONSTAR_EMERGENCY_CALL,
   SIP_NAVIGATION_POI_CALL
}Phone_Call_Type_T;

typedef struct SIP_Phone_Status_Tag
{
   bool_t TmatcsSysPresnt;
   bool_t PrsnlCallingEnbld;
   bool_t  PhnActvlyRming;
   SIP_Phone_Call_status_T PhnCallStat;
   Phone_Call_Type_T PhnCallType;
   bool_t ScndryCellSrvcPrsnt;
   bool_t TrtryCellSrvcPrsnt;
   bool_t TrnscvrLckAct;
   bool_t PrimCellSrvcPrsnt;
   uint16_t PersCallUnts;
}SIP_Phone_Status_T;

#pragma pack(push)
#pragma pack(1)
#if 0
typedef struct SIP_VSS_info_Tag
{
   uint32_t VSS_speed;
   int32_t GYRO_axis_x_mdps;
   int32_t GYRO_axis_y_mdps;
   int32_t GYRO_axis_z_mdps;
}SIP_VSS_INFO_T;
#endif
typedef struct SIP_VSS_info_Tag
{
   int32_t VSS_speed;
   int32_t GYRO_axis_x_mdps;
   int32_t GYRO_axis_y_mdps;
   int32_t GYRO_axis_z_mdps;
}SIP_VSS_INFO_T;

#pragma pack(pop)

typedef enum 
{
    TEMP_DEFAULT_LEVEL = 0,
    TEMP_LOW_40 ,
    TEMP_LOW_30,
    TEMP_LOW_20,
    TEMP_NORMAL,
    TEMP_HIGH_70,
    TEMP_HIGH_85
}SIP_TEMP_LEVEL_ENUM_T;

/* for temperature control */
typedef struct SIP_Temper_Status_Tag
{
   uint8_t temper_level; /* refer SIP_TEMP_LEVEL_ENUM_T */
   int8_t   temper_value;
}SIP_Temper_Status_T;

typedef enum 
{
   HSCAN_COMM_LINE_LOW,
   HSCAN_COMM_LINE_HIGH,
}SIP_HSCAN_COMM_LINE_STATUS_ENUM_T;

typedef struct SIP_Hscan_ComLine_Status_Tag
{
   uint8_t hscan_comline_status;  /* refer SIP_HSCAN_COMM_LINE_STATUS_ENUM_T */ 
}SIP_Hscan_ComLine_Status_T;

typedef uint16_t SIP_AD_Ports_Rpt_T;

typedef uint8_t SIP_AD_Ports_Req_T;

typedef struct SIP_Non_Touch_Display_Status_Tag
{
    uint8_t  Non_Touch_Display_Status;
} SIP_Non_Touch_Display_Status_T;

/* 
 * Battery Status only for DTC purposes 
*/
typedef enum SIP_DTC_Battery_Voltage_Status_Enum_Tag
{
   SIP_DIAG_NORMAL_VOLTAGE = 0,                       /* 9 <= voltage < 16   */
   SIP_DIAG_OVER_VOLTAGE,                             /* voltage >= 16 volts */
   SIP_DIAG_LOW_VOLTAGE,                              /* voltage < 9 volts   */
   SIP_DIAG_INVALID_VOLTAGE
} SIP_DTC_Battery_Voltage_Status_Enum_T;

typedef uint8_t SIP_DTC_Battery_Voltage_Status_T;     /* refer SIP_DTC_Battery_Voltage_Status_Enum_Tag */

/* 
 * Desip message to request and report checksum from K0R application and boot
*/
typedef enum SIP_K0R_ID_Chksum_Req_Enum_Tag
{
   SIP_K0R_BOOT1_CHKSUM = 0,                          /* application checksum   */
   SIP_K0R_APPLICATION_CHKSUM,                        /* boot1 checksum */
   SIP_K0R_BOOT2_CHKSUM,                              /* boot2 checksum */
   SIP_K0R_ALL_CHKSUM,                                /* all memory checksum */
   SIP_K0R_MAX
}SIP_K0R_ID_Chksum_Req_Enum_T;

typedef uint8_t SIP_Cheksum_Request_T;                /* refer SIP_K0R_ID_Chksum_Req_Enum_T*/

typedef uint16_t SIP_Cheksum_Report_T;                /* Checksum request */

typedef enum SIP_Mic_Ena_State_Tag
{
   SIP_MIC_DISABLE,
   SIP_MIC_ENABLE,
   SIP_MIC_MAX_STATE
}SIP_Mic_Ena_State_T;

typedef uint8_t SIP_Mic_Ena_Request_T;                /* refer SIP_Mic_Ena_State_T*/

typedef enum
{
   PITS_INPUT_CONFIG_VSS,
   PITS_INPUT_CONFIG_DIAG,
}SIP_PITS_VSS_INPUT_CONFIG_ENUM_T;

typedef uint8_t SIP_PITS_VSS_INPUT_CONFIG_T; /* refer SIP_PITS_VSS_INPUT_CONFIG_ENUM_T */ 

typedef struct
{
   SIP_PITS_VSS_INPUT_CONFIG_T VSS_Config_type;
   uint8_t Duty_Cycle;
   uint16_t PWM_Freq;
}PITS_VSS_INPUT_CONFIG_REP_T;

typedef uint8_t SIP_READ_AD_PORTS_REQ_T;   

typedef uint16_t SIP_READ_AD_VALUE_RPT_T;   

typedef enum
{
   PITS_GYRO_TEST_QUERY,
   PITS_GYRO_TEST_ON,
   PITS_GYRO_TEST_OFF,
}SIP_PITS_GYRO_TEST_ENUM_T;

typedef uint8_t SIP_PITS_GYRO_TEST_T; /* refer SIP_PITS_GYRO_TEST_ENUM_T */ 

typedef enum
{
   PITS_GYRO_TEST_SUCCESS,
   PITS_GYRO_TEST_FAIL,
   PITS_GYRO_TEST_IN_PROCESSING,
}SIP_PITS_GYRO_TEST_STATUS_ENUM_T;

typedef uint8_t SIP_PITS_GYRO_TEST_STATUS_T; /* refer SIP_PITS_GYRO_TEST_STATUS_ENUM_T */ 

typedef uint16_t SIP_VSS_FACTOR_T;   


typedef char char_t;
/*---------------------------------------------------------------------------*/

   /* NOTE: This must match Power_Mode_T */
   typedef enum
   {
      SIP_IGNITION_OFF,
      SIP_IGNITION_ON
   } SIP_Power_Mode_Enum_T;

   typedef uint8_t SIP_Power_Mode_T;
   typedef uint8_t CD_Current_Temperature_T;

/*---------------------------------------------------------------------------*/
/* The following defines apply to the pizza and EV hardware configurations,
   see comments for details
 */
#   define   PSM_NO_SUPPLY    0
#   define   PSM_3_3VSW       0x00000001    /* 3.3v switcher   */
#   define   PSM_1_8VSW       0x00000002    /* Pizza N/A    , EV DSLR linear  */
#   define   PSM_3_3VSW2      0x00000004    /* 3.3v #2         */
#   define   PSM_5VSW         0x00000008    /* 5v switcher     */
#   define   PSM_8VSW         0x00000010    /* 8v              */
#   define   PSM_8V5SW        0x00000020    /* Pizza 9v Linear  , EV BPS 8.5V  */
#   define   PSM_Remote_EN    0x00000040    /* Remote Enable   */
#   define   PSM_HSD1         0x00000080    /* Pizza N/A      , EV N/A    */
#   define   V_IN_MAX1531     0x00000100    /* CCR HW */
#   define   MAX1531_EN       0x00000200    /* CCR HW */
#   define   VCDC1_TPS        0x00000400    /* CCR HW */
#   define   VCDC2_TPS        0x00000800    /* CCR HW */
#   define   VCDC3_TPS        0x00001000    /* CCR HW */
#   define   LDO1_TPS         0x00002000    /* CCR HW */
/*IMX regulator supplies*/
#   define   PSM_3V3_IMX_EN   0x00004000    /* CCR HW */
#  define    PSM_1_3VSW2      0x00008000
#  define    PSM_1_25VSW2     0x00010000
#  define    PSM_2_5VSW       0x00020000
#  define    PSM_0_75VSW      0x00040000
#   define   PSM_ALL_SUPPLIES 0xFFFFFFFF
#   define   SIP_MAX_SIZE  (16)

/** Controllable Power Supply Outputs */
   typedef uint32_t SIP_Power_Supply_T;

/** Type to control states of power supply outputs */
   typedef struct SIP_Set_Power_Supply_Tag
   {
      SIP_Power_Supply_T on;  /**< Turn set bits ON */
      SIP_Power_Supply_T off; /**< Turn set bits OFF */
   }
   SIP_Set_Power_Supply_T;



/** Time format message */
typedef enum SIP_Time_Format_Tag
{
   SIP_Time_Format_12Hr=0,
   SIP_Time_Format_24Hr
}SIP_Time_Format_T;

typedef struct SIP_EX_DTC_Res_Tag
{

    uint8_t GROUP;
    uint8_t ID;
    uint8_t DTC;
}SIP_EX_DTC_Res_T;

typedef uint8_t SIP_EX_DTC_Req_T;

/*---------------------------------------------------------------------------*/

/** DIO / GPIO ports availabe on VIP */
   typedef enum SIP_VIP_Ports_Tag
   {
      #if 0
      VIP_P0,
      VIP_P1,
      VIP_P3L,
      VIP_P3H,
      VIP_P4,
      VIP_P5,
      VIP_P7L,
      VIP_P7H,
      VIP_P9L,
      VIP_P9H,
      VIP_PCM,
      VIP_PCT,
      VIP_PDH,
      VIP_PDLL,
      VIP_PDLH,
      #else
      VIP_P0,
      VIP_P1,
      VIP_P2,
      VIP_P3,
      VIP_P4,
      VIP_P5,
      VIP_P6,
      VIP_P7,
      VIP_P8,
      VIP_P9,
      VIP_P10,
      VIP_P11,
      VIP_P12,
      VIP_P13,
      VIP_P14,
      VIP_P15,
      #endif
      VIP_NUM_PORTS
   } SIP_VIP_Ports_Enum_T;

/** use only byte size enum value in messages */
   typedef uint8_t SIP_VIP_Ports_T;

/** Report VIP Port Data Message data definition */
   typedef struct SIP_VIP_Port_State_Tag
   {
      SIP_VIP_Ports_T port;      /**< Port ID */
      uint8_t pins;              /**< port state */
   }
   SIP_VIP_Port_State_T;

/** Set VIP Port Message data definition */
   typedef struct SIP_Set_VIP_Port_Tag
   {
      SIP_VIP_Ports_T port;      /**< Port ID */
      uint8_t pin_set;           /**< Pins to set to high */
      uint8_t pin_clear;         /**< Pins to set to low */
   }
   SIP_Set_VIP_Port_T;

/** Set VIP Port Data Direction Message data definition */
   typedef struct SIP_Set_VIP_Port_Direction_Tag
   {
      SIP_VIP_Ports_T port;      /**< Port ID */
      uint8_t pin_input;         /**< Pins to set to input */
      uint8_t pin_output;        /**< Pins to set to output */
   }
   SIP_Set_VIP_Port_Direction_T;

   typedef struct SIP_Out_Side_Air_TempCr_Tag
   {
      uint8_t OtsAirTmpCrVal;
      uint8_t OtsAirTmpCrValV;
   }
   SIP_Out_Side_Air_TempCr_T;


/*---------------------------------------------------------------------------*/


#   define SIP_INTR_EDGE_DISABLE (0x00)
#   define SIP_INTR_EDGE_FALL    (0x01)
#   define SIP_INTR_EDGE_RISE    (0x02)
#   define SIP_INTR_EDGE_BOTH    (0x03)
#   define SIP_INTR_REFRESH_FALL (0x81)
#   define SIP_INTR_REFRESH_RISE (0x82)
#   define SIP_INTR_REFRESH_BOTH (0x83)
#   define SIP_INTR_REFRESH_BIT  (0x80)

/** Set up edge interrupt */
   typedef struct SIP_Set_Interrupt_Tag
   {
      SIP_Interrupt_Id_T intp_id;  /**< Identifies which edge interrupt (0-7) to enable / disable */
      uint8_t edge;     /**< which edge (if any) to interrupt on */
   }
   SIP_Set_Interrupt_T;

/*---------------------------------------------------------------------------*/

#define KB_MSG_MASK        0x1000
#define RSA_KB_MSG_MASK    0x2000
#define RSE_KB_MSG_MASK    0x4000

#ifdef PIZZA_GMB_HW       /*To avoid complies from capsense module*/
   #define   KB_PH_02         0
   #define   KB_PH_12         0
   #define   KB_PH_22         0
#endif

/** Key definitions */
typedef enum SIP_Key_Msgs_IDs_Tag
{
   KB_NO_KEY = 0,         /*Value from keyboard drivers*/
   KB_INVALID_KEY = 1,

   KB_OPEN = KB_MSG_MASK, /*Main keyboard input messages*/

   KB_PH_START,
   KB_PH_00 = KB_PH_START,
   KB_PH_01,
   KB_PH_02,
   KB_PH_03,
   KB_PH_10,
   KB_PH_11,
   KB_PH_12,
   KB_PH_13,
   KB_PH_20,
   KB_PH_21,
   KB_PH_22,
   KB_PH_23,
   KB_PH_30,
   KB_PH_31,
   KB_PH_32,
   KB_PH_33,
   
   KB_PH_BENCH,
   KB_PH_REFLASH,
   KB_PH_ENG_DIAG,
   KB_PH_TEST,
   KB_PH_SAVE_LOG,
   KB_PH_PRINT_SCREEN,
   KB_PH_LAST = KB_PH_PRINT_SCREEN,

   KB_POWER_BTN,
   KB_SELECT_BTN,
   KB_BENCH_BTN,

   KB_EJECT_BTN,
   KB_HOME_BTN,
   KB_BACK_BTN,
   KB_SRCE_BTN,
   KB_SEEK_UP_BTN,
   KB_SEEK_DN_BTN, 

   /** Non-Nav Version keys */
   KB_FAV_BTN,

   /** Nav Version keys */
   KB_DEST_BTN,
   KB_NAV_BTN,
   KB_RPT_BTN,
   KB_ENG_DIAG_BTN,           /* PHONE + MENU */

   /** SWC Specific Keys */
   KB_SWC_MUTE,               /**< SWC MUTE        */
   KB_SWC_VOLUME_UP,          /**< SWC VOL +       */
   KB_SWC_VOLUME_DOWN,        /**< SWC VOL -       */
   KB_SWC_SOURCE,             /**< SWC SOURCE      */
   KB_SWC_NEXT,               /**< SWC NEXT        */
   KB_SWC_PREV,               /**< SWC PREV        */
   KB_SWC_SEEK_UP,            /**< SWC SEEK UP     */
   KB_SWC_SEEK_DOWN,          /**< SWC SEEK DOWN   */
   KB_SWC_PHONE_ON_OFF,            /**< SWC PHONE ON OFF     */
   KB_SWC_INFO,               /**< SWC INFO        */
   KB_SWC_PICK_UP_PHONE,      /**< SWC PICK UP PHONE */
   KB_SWC_HANG_UP_PHONE,      /**< SWC HANG UP PHONE */
   KB_SWC_CAMERA_MODE,        /**< SWC CAMERA MODE, only used in GWM CHB031 */
   KB_SWC_VR,                 /**< SWC VR MODE, Uue for CHK041 and CHB031 VR */
   KB_SWC_SVC,                 /**< SWC SVC MODE, Use for NPT */
   /** TAIL GATE Specific Keys */
   KB_TAIL_GATE_MUTE,         /**< TAIL GATE MUTE        */
   KB_TAIL_GATE_VOLUME_UP,    /**< TAIL GATE VOL +       */
   KB_TAIL_GATE_VOLUME_DOWN,  /**< TAIL GATE VOL -       */
   KB_TAIL_GATE_SOURCE,       /**< TAIL GATE SOURCE      */
   KB_TAIL_GATE_NEXT,         /**< TAIL GATE NEXT        */
   KB_TAIL_GATE_PREV,         /**< TAIL GATE PREV        */
   KB_TAIL_GATE_SEEK_UP,      /**< TAIL GATE SEEK UP     */
   KB_TAIL_GATE_SEEK_DOWN,    /**< TAIL GATE SEEK DOWN   */
   KB_TAIL_GATE_INVALID,      /**< TAIL GATE INVALID     */
   KB_TAIL_GATE_INFO,         /**< TAIL GATE INFO        */

   /** OLD KEY Definitions */
   KB_BAND_BTN,
   KB_MEDIA_BTN,
   KB_AUDIO_BTN,
   KB_MENU_BTN,

   /** Phone keys */
   KB_PHONE_BTN,

   /** User definition key */
   KB_USER_DEF_BTN,

   /** Diagnostic Test */
   KB_REFLASH_BTN,            /* PHONE + DEST */
   KB_TEST_BTN,
   KB_SAVE_LOG_BTN,           /* MENU + DEST + SRCE */
   KB_PRINT_SCREEN_BTN,       /* MENU + DEST + SEEK_DN */

   RSA_OPEN          = RSA_KB_MSG_MASK, /* RSA keyboard input messages */
   RSA_PROG          = RSA_KB_MSG_MASK + 0x03,
   RSA_TUNE_UP       = RSA_KB_MSG_MASK + 0x07,
   RSA_TUNE_DOWN     = RSA_KB_MSG_MASK + 0x08,
   RSA_SOURCE        = RSA_KB_MSG_MASK + 0x09,
   RSA_BAND          = RSA_KB_MSG_MASK + 0x0A,
   RSA_SEEKUP        = RSA_KB_MSG_MASK + 0x12,
   RSA_SEEKDN        = RSA_KB_MSG_MASK + 0x13,
   RSA_POWER         = RSA_KB_MSG_MASK + 0x16,

   IR_POWER          = RSE_KB_MSG_MASK + 0x48, /* RSE keyboard input messages */
   IR_UP             = RSE_KB_MSG_MASK + 0x01,
   IR_DOWN           = RSE_KB_MSG_MASK + 0x81,
   IR_LEFT           = RSE_KB_MSG_MASK + 0x8a,
   IR_RIGHT          = RSE_KB_MSG_MASK + 0xb2,
   IR_ENTER          = RSE_KB_MSG_MASK + 0x84,
   IR_TOGGLE         = RSE_KB_MSG_MASK + 0x7b,
   IR_TITLE_MENU     = RSE_KB_MSG_MASK + 0x21,
   IR_DISPLAY        = RSE_KB_MSG_MASK + 0x68,
   IR_RETURN         = RSE_KB_MSG_MASK + 0x44,
   IR_AUDIO          = RSE_KB_MSG_MASK + 0xe4,
   IR_SUBTITLE       = RSE_KB_MSG_MASK + 0x14,
   IR_ANGLE          = RSE_KB_MSG_MASK + 0x94,
   IR_REW            = RSE_KB_MSG_MASK + 0x98,
   IR_AUX            = RSE_KB_MSG_MASK + 0xc2,
   IR_FWD            = RSE_KB_MSG_MASK + 0xc8,
   IR_STOP           = RSE_KB_MSG_MASK + 0x28,
   IR_PLAY_PAUSE     = RSE_KB_MSG_MASK + 0xa8,
   IR_NEXT           = RSE_KB_MSG_MASK + 0x24,
   IR_PREV           = RSE_KB_MSG_MASK + 0xc4,
   IR_ONE            = RSE_KB_MSG_MASK + 0x80,
   IR_TWO            = RSE_KB_MSG_MASK + 0x40,
   IR_THREE          = RSE_KB_MSG_MASK + 0xc0,
   IR_FOUR           = RSE_KB_MSG_MASK + 0x20,
   IR_FIVE           = RSE_KB_MSG_MASK + 0xa0,
   IR_SIX            = RSE_KB_MSG_MASK + 0x60,
   IR_SEVEN          = RSE_KB_MSG_MASK + 0xe0,
   IR_EIGHT          = RSE_KB_MSG_MASK + 0x10,
   IR_NINE           = RSE_KB_MSG_MASK + 0x90,
   IR_CLEAR          = RSE_KB_MSG_MASK + 0xf7,
   IR_ZERO           = RSE_KB_MSG_MASK + 0x50,
   IR_MORE_TEN       = RSE_KB_MSG_MASK + 0xa4,

} SIP_Key_Msgs_IDs_T_1;
#define  SIP_Key_Msgs_IDs_T int16_t
#define  KB_Msgs_IDs_T  SIP_Key_Msgs_IDs_T
#define  RSA_Msgs_IDs_T SIP_Key_Msgs_IDs_T
#define  RSE_Msgs_IDs_T SIP_Key_Msgs_IDs_T


/*---------------------------------------------------------------------------*/

/** knob change positive is clockwise */
   typedef int8_t SIP_Knob_Delta_T;

/*---------------------------------------------------------------------------*/


/** identifies which A/D input to read */
   typedef uint8_t SIP_AD_Channel_T;

/** Data results from an A/D read */
   typedef struct SIP_AD_Results_Tag
   {
      uint16_t counts;   /**< A/D counts left justified (range 0 - 0xFFFF) */
      SIP_Bool_T counts_valid;
   }
   SIP_AD_Results_T;

/** Request ratiometeric A/D read */
   typedef struct SIP_AD_Ratiometeric_Request_Tag
   {
      SIP_AD_Channel_T chan; /**<A/D channel to read */
      SIP_AD_Channel_T ref_chan; /**<reference A/D channel */
   }
   SIP_AD_Ratiometeric_Request_T;

/*---------------------------------------------------------------------------*/
/**
 * RDS Decoder Input Structure Type
 */
typedef struct RDS_Decoder_Input_Tag
{
   uint16_t    block_data;
   uint8_t     sync_channel;
   bitfield8_t deocder_id:2;
   bitfield8_t block_type:3;             /* A_BLOCK, B_BLOCK, C_BLOCK, CP_BLOCK, or D_BLOCK */
   bitfield8_t is_good_quality:1;
   bitfield8_t is_uncorrected_error:1;
   bitfield8_t is_strong_sync:1;
}
RDS_Decoder_Input_T;
/*---------------------------------------------------------------------------*/

/** RDS PI */
   typedef uint16_t SIP_PI_T;

/** RDS PI */
   typedef struct SIP_Sync_Tag
   {
      SIP_PI_T fast_PI;
      uint8_t channel;
      uint8_t sync_id;
   } SIP_Sync_T;

/** RDS Block Data */

   typedef RDS_Decoder_Input_T SIP_DE_Block_Msg_T;

/** RDS Syncronyzer Data */
   typedef struct RDS_Decoder_Input_BCD_Tag
   {
      RDS_Decoder_Input_T sync_data[3];
   } SIP_DE_Block_Msg_BCD_T;

   typedef enum block_index_tag
   {
      BLOCK_B_INDEX = 0,
      BLOCK_C_INDEX,
      BLOCK_D_INDEX,
      BLOCK_UNKNOWN_INDEX,
   } block_index_t;

/*---------------------------------------------------------------------------*/

/** Touch screen input */
   typedef struct SIP_Touch_Screen_Tag
   {
      uint16_t move_counter;
                          /**< The move counter information from the touch screen.
       When the user just presses the Touch screen the count will be 0x0000. Actually when we receive the data in the VIP proxy
         layer and if we find that move counter is 0x0000, this means that a PRESS EVENT has happened. And if this data is
         0xFFFF this means that a RELEASE EVENT has happened.
         After the PRESS EVENT and before the RELEASE EVENT move counter will contain the actual move counter value.
         If the move counter has reached 0xFFFF, and the user is still pressing the touch panel, then a RELEASE EVENT will be send.
         */
      uint16_t x;    /**< current X co-ordinate */
      uint16_t y;    /**< current Y co-ordinate */
      uint16_t previous_x;
                         /**< Previous X co-ordinate */
      uint16_t previous_y;
                         /**< Previous Y co-ordinate */

   } SIP_Touch_Screen_T;


/*---------------------------------------------------------------------------*/

/** PWM output request */
   typedef struct SPI_PWM_Tag
   {
      uint32_t frequency_Hz;
                           /**< output frequency */
      uint16_t duty_cycle; /**< duty cycle 0 - 100 % low, 0xFFFF - 100 % high, otherwise (x)/0x10000  high */
      uint8_t vip_channel; /**< channel id */
   } SIP_PWM_T;

/*---------------------------------------------------------------------------*/

/** Maximum length of PITs message */
#   define SIP_MAX_PITS_SIZE  (128)

/** PITs message holder */
   typedef uint8_t SIP_PITs_Msg_T[SIP_MAX_PITS_SIZE];

/*---------------------------------------------------------------------------*/

/** Remote Audio Source Identifier */
   typedef enum SIP_REM_Src_Id_Tag
   {
      SIP_REM_SRC_NONE,
      SIP_REM_SDAR_SRC,
      SIP_REM_ASYNC_SRC,
      SIP_REM_NUM_SRC,
   } SIP_Rem_Src_ID_ENUM_T;

/** Remote Audio Source Status */
   typedef enum SIP_Rem_Src_Status_Tag
   {
      SIP_REM_SRC_NOT_PRESENT,
      SIP_REM_SRC_PRESENT,
      SIP_REM_SRC_AUDIO_NOT_AVAILABLE,
      SIP_REM_SRC_AUDIO_AVAILABLE,
      SIP_REM_SRC_CONNECTING,
      SIP_REM_SRC_CONNECTED,
      SIP_REM_SRC_DISCONNECTING
   } SIP_Rem_Src_Status_ENUM_T;

/** Remote Audio Source Command */
   typedef enum SIP_Rem_Src_Command_Enum_Tag
   {
      SIP_REM_SRC_NO_ACTION,
      SIP_REM_SRC_CONNECT,
      SIP_REM_SRC_DISCONNECT
   } SIP_Rem_Src_Command_ENUM_T;

/** Remote Audio Source command structure */
   typedef struct SIP_rem_src_command_Tag
   {
      uint8_t remote_source_index;
      uint8_t remote_source_command;
   } SIP_rem_src_command_T;


/** Remote Audio Source status */
   typedef struct SIP_rem_src_status_Tag
   {
      uint8_t remote_source_index;
      uint8_t status;
   } SIP_rem_src_status_T;

/*---------------------------------------------------------------------------*/

/** Remote Receiver Command */
   typedef struct SIP_Rem_Rcvr_Com_Tag
   {
      int16_t tune_value;
      uint8_t commmand;
   } SIP_Rem_Rcvr_Command_T;

/** Remote Receiver Command values, RR = Remote Receiver  */
   typedef enum SIP_Rem_Rcvr_Commands_Tag
   {
      RR_NO_ACTION = 0x00,
      RR_STATION_TUNE,          /**< tune_value = Channel number */
      RR_STATION_DELTA_TUNE,    /**< tune_value = Channel delta  */
      RR_CATEGORY_TUNE,         /**< tune_value = Category number */
      RR_CATAGORY_DELTA_TUNE,   /**< tune_value = Delta */
      RR_RECALL_PRESET_TUNE,    /**< tune_value = Preset */
      RR_SET_PRESET,            /**< tune_value = Preset */
      RR_SEEK_UP,               /**< tune_value = N/A */
      RR_SEEK_DOWN,             /**< tune_value = N/A */
      RR_SEEK_CAT_UP,           /**< tune_value = N/A */
      RR_SEEK_CAT_DOWN,         /**< tune_value = N/A */
      RR_SEEK_PRESET_UP,        /**< tune_value = N/A */
      RR_SEEK_PRESET_DOWN,      /**< tune_value = N/A */
      RR_SCAN_UP,               /**< tune_value = N/A */
      RR_SCAN_DOWN,             /**< tune_value = N/A */
      RR_SCAN_PRESET_UP,        /**< tune_value = N/A */
      RR_SCAN_PRESET_DOWN,      /**< tune_value = N/A */
      RR_SCAN_CAT_UP,           /**< tune_value = N/A */
      RR_SCAN_CAT_DOWN,         /**< tune_value = N/A */
      RR_STATION_DELTA_IN_CAT,  /**< tune_value = Delta */
      RR_AUTO_STORE,            /**< tune_value = N/A */
      RR_SID_TUNE,              /**< tune_value = SID */
      RR_LIST_REQUEST,          /**< tune_value = 1=Category, 2=Station by current Cat, 3= station list 4= Tune Select list */
     RR_TUNE_SEL_CMND,        /**< tune_value = Tune Select Command */
      RR_COINCIDENCE_STATUS_RPT  /**< tune_value = N/A */

   } SIP_Rem_Rcvr_Commands_ENUM_T;

/** Remote Receiver Status */
   typedef struct SIP_Rem_Rcvr_Status_Tag
   {
      uint16_t current_station;
      uint8_t sid;
      uint8_t status_1;
      uint8_t status_2;
      uint8_t status_3;
      uint8_t status_4;
      uint8_t status_5;
   } SIP_Rem_Rcvr_Status_T;

/** status_1
   bits 7-4 = Current Station Preset number, 0 = not a preset
   bits 3-1 = Current Station Service:  0=No Data, 1=General Subscription,
              2=Pay per use, 3=Promotion, 4=Unsubscribed, 5=Other
   bit  0   = Current Station Quality 0 = Poor signal, 1 = good signal
*/
/** status_2
   bits 7-5 = Remote Receiver Data Type 0=No Update, 1=Audio, 2=Data, 3=Video, 7=Unknown
   bits 4-2 = Remote Receiver Command Status, 0=No Update, 1=Valid Command,
              2=Not Supported, 3=Command out of range
   bit  1   = Remote Receiver Init Active 0=not initializing, 1=initializing
   bit  0   = Remote Receiver Info Avail Active
*/
/** status_3
   bits 7-4 = Remote Receiver Scanning Status 0=No Action, 1=Scanning by Station,
              2=Scanning by Program Type, 3=Scanning by Presets.
   bits 3-1 = Remote Receiver Emergency Interrupt Status 0=No Action, 1=Enabled,
              2=Coming, 3=Ended, 4=Supported
   bit  0   = Remote Receiver Tuning Status  0=Tuned, 1=Tuning
*/
/** status_4
   bit  7   = not used
   bits 6-3 = Remote Receiver Seeking Status  0=No Action, 1=Seeking by Station,
              2=Seeking by Program Type, 3=Seeking by Presets.
   bits 2-0 = Remote Receiver Traffic Interrupt Status 0=No Action, 1=Enabled,
              2=Coming, 3=Ended, 4=Supported
*/
/** status_5
   bit  7   = not used
   bits 6-3 = Remote Receiver Type 0=SDARS, 1=DAB, 2=Remote AM/FM Tuner
   bits 2-0 = Service Provider 0=Not Available, 1=XM, 2=Sirius
*/

/*---------------------------------------------------------------------------*/

/** Remote Receiver Label types */
/** Remote Receiver Stadndard Label size */
#   define SD_STD_LABEL_SIZE 16

/** Remote ReceiverExtended Label size */
#   define SD_EXT_LABEL_SIZE 80

/** Remote Receiver Channel Label type */
   typedef uint8_t SIP_SD_Channel_Label_T[SD_STD_LABEL_SIZE + 1];

/** Remote Receiver Artist Label type */
   typedef uint8_t SIP_SD_Artist_Label_T[SD_EXT_LABEL_SIZE + 1];

/** Remote Receiver Song Label type */
   typedef uint8_t SIP_SD_Song_Label_T[SD_EXT_LABEL_SIZE + 1];

/** Remote Receiver Category Label type */
   typedef uint8_t SIP_SD_Cat_Label_T[SD_STD_LABEL_SIZE + 1];

/** Remote Receiver Category List type Note: End of list is indicated by category = 0 */
   typedef struct SIP_SD_Cat_List_Tag
   {
      uint8_t category;
      uint8_t label[SD_STD_LABEL_SIZE + 1];
   } SIP_SD_Cat_List_T;

/** Remote Receiver Channel List type, Note: End of list is indicated by channel = 0 */
   typedef struct SIP_SD_Channel_List_Tag
   {
      uint8_t channel;
      uint8_t sid;
      uint8_t category;
      uint8_t label[SD_STD_LABEL_SIZE + 1];
   } SIP_SD_Channel_List_T;

/** Remote Receiver Tun Select Item type, Note: End of list is indicated by LF(0x0A) == string_name */
typedef struct SIP_SD_Tune_Select_Item_Type_Tag
{
   uint8_t item;
   uint8_t channel;
   uint8_t sid;
   uint8_t label[SD_STD_LABEL_SIZE+1];
} SIP_SD_Tune_Select_Item_T;

/*--------------------------------------------------------------------------*/
/** Nav turn by turn */
#   define NAV_TBT_SIZE 80
/**
 * icon_page_id: 0=no icon; FF= downloaded icon; other=icon page#
 * request_icon=icon_offset:  which icon
**/
typedef struct SIP_NAV_TBT_Tag
{
   char    buf[NAV_TBT_SIZE+1];
   uint8_t icon_page_id;
   uint8_t requested_icon;
   uint8_t caret_line_id;
} SIP_NAV_TBT_T;

typedef SIP_NAV_TBT_T SIP_NAV_TBT_URGENT_T;
/*---------------------------------------------------------------------------*/

/** Transmition Gear information from vehicle bus message */
   typedef enum SIP_PRNDL_ENUM_Tag
   {
      #if 0
      NOT_SUPPORTED_1 = 0,
      FIRST_GEAR,
      SECOND_GEAR,
      THIRD_GEAR,
      FOURTH_GEAR,
      FIFTH_GEAR,
      SIXTH_GEAR,
      SEVENTH_GEAR,
      EIGHTH_GEAR,
      NOT_SUPPORTED_2,
      EVT_MODE_1,
      EVT_MODE_2,
      CVT_FORWARD_GEAR,
      NEUTRAL_GEAR,
      REVERSE_GEAR,
      PARK_GEAR
      #endif
      /* This is for GWM definition */
      PARK_GEAR,
      FORWARD_DRIVE_GEAR,
      NEUTRAL_GEAR,
      REVERSE_GEAR,
      MANUAL_GEAR,
      RESERVER1_GEAE,
      RESERVER2_GEAR,
      NOT_SUPPORTED_1
   } SIP_PRNDL_ENUM_T;

  typedef struct SIP_PRNDL_Tag
   {
      uint8_t gear_status;
      uint8_t gear_validity;
   } SIP_PRNDL_T;

typedef enum SIP_Str_Whl_Ang_Sensor_Cal_Status_Tag
{
   STR_WHL_ANG_UNKNOWN = 0,
   STR_WHL_ANG_ESTIMAGED,
   STR_WHL_ANG_CALIBRATED
}SIP_Str_Whl_Ang_Sensor_Cal_Status_T;

typedef struct SIP_Steering_Wheel_Angle_Tag
 {
   uint16_t  strWhAng;
   uint8_t   strWhAng_validity;
   uint8_t   strWhAng_Sensor_Cal_Status;  /*SIP_Str_Whl_Ang_Sensor_Cal_Status_T*/
 } SIP_Str_Wh_Ang_T;

/*---------------------------------------------------------------------------*/

/** Vehicle bus Dimming information */
   typedef uint8_t SIP_Interior_Dim_Display_Level_T;

/** Vehicle bus Airbag Deployment information */
   typedef bool_t SIP_Airbag_Deployed_T;

/** Vehicle bus Airbag Deployment information just a dummy for resolve the AP integration issue*/
   typedef bool_t SIP_Airbag_Deploy_Msg_T;

/** Vehicle Onstar Connected information */
   typedef bool_t SIP_Onstar_Connected_T;

/** Arbitrary Text Send Command */
   typedef struct SIP_Arb_Txt_Req_Com_Tag
   {
     uint8_t mode;
     uint8_t dev_id;
     char display_string[128];
   } SIP_Arb_Txt_Req_Command_T;

   typedef uint8_t SIP_AT_State_T;

/** Arbitrary Text Remote device status */
   typedef struct Arb_Txt_Req_Tag
   {
      uint8_t dev_id;
      SIP_AT_State_T state;
   } SIP_Arb_Txt_Req_Msg_T;
/*---------------------------------------------------------------------------*/

/** iPod CP Communications */

   #define CP_COMM_TX_BUF_SIZE ( 128 )
   #define CP_COMM_RX_BUF_SIZE ( CP_COMM_TX_BUF_SIZE )
   /* Add three for SIP ID, sub ID and message sync ( read/write streams of
    *  bytes that require multiple SIP messages */

/** Authentication IC VIP Send data */
   typedef struct SIP_CP_Tx_Comm_Buff_Tag
   {
     uint8_t sub_id;
     uint8_t options;
     uint8_t address;
     uint8_t msg_size;
     char data[CP_COMM_TX_BUF_SIZE];
   } SIP_CP_Tx_Comm_Buff_T;

/** Authentication IC VIP Recieve data */
   typedef struct SIP_CP_Rx_Comm_Buff_Tag
   {
     uint8_t sip_id;
     uint8_t sub_id;
     uint8_t options;
     uint8_t address;
     uint8_t msg_size;
     char data[CP_COMM_RX_BUF_SIZE];
   } SIP_CP_Rx_Comm_Buff_T;

   typedef enum CP_COMM_SIP_SUB_MSG_Tag
   {
      /* AP to VIP */
      CP_COMM_READ_BYTES = 0x10,
      CP_COMM_WRITE_BYTES = 0x11,
      CP_COMM_CHECK_READY = 0x12,
      CP_COMM_RESET = 0x13,
      CP_COMM_INIT = 0x14,
      CP_COMM_SHUTDOWN = 0x15,
      /* VIP back to AP */
      CP_COMM_BYTES_READ = 0x20,
      CP_COMM_BYTES_WRITTEN = 0x21,
      CP_COMM_READY_CHECKED = 0x22,
      CP_COMM_RESET_COMPLETE = 0x23,
      CP_COMM_INIT_COMPLETE = 0x24,
      CP_COMM_SHUTDOWN_COMPLETE = 0x25,
      /* Special Ones */
      CP_COMM_MESSAGE_NONE = 0x00,
   }   CP_COMM_SIP_SUB_MSG_T;

/*---------------------------------------------------------------------------*/

/** Chime Command Data */
   typedef struct SIP_Chime_Command_Tag
   {
      uint8_t location_tone;
      uint8_t cadence;
      uint8_t reps;
      uint8_t duty_cycle;
      uint8_t priority;
   } SIP_Chime_Command_T;

/*---------------------------------------------------------------------------*/

/** SCV Vehicle Speed Data */
   typedef struct SIP_SCV_Vehicle_Speed_Tag
   {
      uint16_t vehicle_speed;
      bool_t  vehicle_speed_valid;
   }SIP_SCV_Vehicle_Speed_T;

/*---------------------------------------------------------------------------*/

/**VSS Vehicle Speed Data */
   typedef struct SIP_VSS_Vehicle_Speed_Tag
   {
      uint16_t vehicle_speed;
      bool_t  vehicle_speed_valid;
   }SIP_VSS_Vehicle_Speed_T;

/*---------------------------------------------------------------------------*/

/** RSA Active Source data */
 typedef uint8_t SIP_RSA_Active_Source_T;

/*---------------------------------------------------------------------------*/

/** ACC Device On */

 typedef enum SIP_Acc_Device_On_Tag
 {
    DEVICE_MONO_ON,
    DEVICE_MIXED_ON,
    DEVICE_OFF
 } SIP_Acc_Device_On_T;

/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/

/** Set AD Limits*/

   typedef struct SIP_Set_AD_Compare_Tag
   {
      uint8_t          channel;
      uint16_t         low_limit;
      uint16_t         high_limit;
   } SIP_Set_AD_Compare_T;

/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/


/** VIP Application & Boot Loader Header Struct */
   typedef struct ROM_Hdr_Tag
   {
      uint16_t CHECKSUM;          /**< Module checksum */
      uint16_t MID;               /**< Module ID stored MSB first */
      uint8_t SWMI[4];            /**< Software Part Number stored MSB first */
      char DLS[2];                /**< version information */
      uint32_t PMA;               /**< Product Memory Address */
      uint32_t NOB;               /**< Number of Bytes */
      uint16_t NOAM;              /**< Number of additional modules */
   } ROM_Hdr_T;

/** VIP Application and Boot Loader Headers*/

   typedef struct SIP_VIP_AP_and_BL_Hdrs_Tag
   {
      ROM_Hdr_T  AP_Hdr;
      ROM_Hdr_T  BL_Hdr;
   } SIP_VIP_AP_and_BL_Hdrs_T;

/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/

/** Parking Assistance Rear Object Status*/

   typedef struct SIP_PAR_Tag
   {
     uint8_t    System_Status;
     uint8_t    ExtdDist_msb;
     uint8_t    ExtdDist_lsb;
     uint8_t    region_1_2;
     uint8_t    region_3_4;
   } SIP_PAR_T;

/*---------------------------------------------------------------------------*/
/* The following data is used to send Arb_Text_distance_data
   to AP */

typedef struct SIP_NAV_Dist_Data_Tag{
   uint8_t     NavDstncDsplyMdReq;
   uint8_t     NavBarGphDsp;
   uint8_t     NavDistUnt;
   uint16_t NavDistMan;
}SIP_Nav_Data_T;
/*---------------------------------------------------------------------------*/

/*VIN required for theft validation*/

typedef struct SIP_VIN_Tag
{
   uint8_t    vin_number[16];
} SIP_VIN_2_17_T;

/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
typedef enum SIP_MODULE_SUB_Tag
{
   MODULE_SUBSTITUTION_UNKNOWN,
   NO_MODULE_AUBSTITUTION,
   MODULE_SUBSTITUTION_DETECTED,
} SIP_MODULE_SUB_T;
/*---------------------------------------------------------------------------*/


/*Arbitrary Text Icon Support structure */
typedef struct SIP_Arb_Txt_Icon_Req_Com_Tag{
   uint8_t mode;
   uint8_t dev_id;
   uint8_t icon_page_no;
   uint8_t icon_offset_no;
   char display_string[128];
}SIP_Arb_Txt_Icon_Req_Com_T;

/*Arbitrary Text NAV Distance Support structure */
typedef struct SIP_Arb_Txt_Nav_Distance_HUD_Tag{
   uint8_t mode;
   uint8_t dev_id;
   uint8_t distance_mode;
   uint8_t distance_unit;
   uint32_t distance_value;
   uint8_t bar_graph_value;
}SIP_Arb_Txt_Nav_Distance_HUD_T;

/*Arbitrary Text NAV Street and Icon Support structure */
typedef struct SIP_Arb_Txt_Nav_Street_Icon_HUD_Tag{
   uint8_t mode;
   uint8_t dev_id;
   uint8_t page_number;
   uint8_t icon_number;
   uint8_t functional_code;
   char next_street_str[100];
}SIP_Arb_Txt_Nav_Street_Icon_HUD_T;

/*---------------------------------------------------------------------------*/
/** Maximum length of PITs message */
#   define SIP_MAX_PS_SIZE  (256) /**NACHOC Modify to a more accurate value*/

/** PITs message holder */
   typedef uint8_t SIP_PS_Msg_T[SIP_MAX_PS_SIZE];

/**
 * Type for command to be transmitted through DESIP
 */
typedef enum SIP_PS_Command_Tag
   {
      PS_READ_CMD,
      PS_WRITE_CMD,
      PS_LOAD_DEFAULTS_CMD, /*NACHOC: Define if necessary*/
      PS_ERROR_CMD,         /*NACHOC: Define if necessary*/
   }SIP_PS_Command_T;

/*---------------------------------------------------------------------------*/
/**
 * DTC Enumeration at AP side ONLY
 */
   typedef enum SIP_DTC_Code_Tag
   {
      AP_DTC_DUMMY,
      AP_CD_Deck_Malfunction,
      AP_RTD_UART_Malfunctionl, 
      /* Make sure to update any DTC added here into
       * VIP gm_diag and corresponding persistent storage handler*/
      NUM_AP_FIXED_DTCS,
   }SIP_DTC_Code_T;

/**
 * GM DTC SET REQ message holder
 */
   typedef struct SIP_GM_DTC_Tag
   {
      SIP_DTC_Code_T dtc_code;
      bool           dtc_value;
      uint8_t        did_value[85];
   }SIP_GM_DTC_T;

typedef struct SIP_Aud_Drv_Mgr_Cmd_Tag
{
    uint32_t cmd_id;            /**< Audio Driver Manager API ID */
    uint8_t  cmd_data[32];      /**< Audio Driver Manager API specific data */
} SIP_Aud_Drv_Mgr_Cmd_T;

typedef struct SIP_Chi_Gen_Beep_Cmd_Tag
{
    uint32_t cmd_id;            /**< Audio Driver Manager API ID */
    uint8_t  cmd_data[32];      /**< Audio Driver Manager API specific data */
} SIP_Chi_Gen_Beep_Cmd_T;

typedef struct SIP_Aud_Drv_Mgr_Resp_Tag
{
    uint32_t cmd_id;            /**< Audio Driver Manager API ID */
    uint32_t cmd_result;        /**< Audio Driver Manager return value */
} SIP_Aud_Drv_Mgr_Resp_T;


/*---------------------------------------------------------------------------*/
/**
 * data used by AP to send Board type via DESIP
 */
typedef        uint8_t        SIP_Board_Type_T;
 
typedef enum SIP_Board_Types_Tag{
   SIP_BOARD_TYPE_LOW = 0,
   SIP_BOARD_TYPE_LOW_NEW,
   SIP_BOARD_TYPE_QBA_MID,
   SIP_BOARD_TYPE_MID,
   SIP_BOARD_TYPE_HIGH,
   SIP_BOARD_TYPE_HIGHeAD,
   SIP_BOARD_TYPE_UNKNOWN
}SIP_BOARD_TYPE_T;


/**
 * Structure data used by Tuner driver proxy client to send commands to
 * server via DESIP
 */
typedef struct SIP_Tuner_Drv_Cmd_Tag
{
    uint32_t cmd_id;            /**< Tuner Driver API ID */
    uint8_t  cmd_data[32];      /**< Tuner Driver API specific data */
} SIP_Tuner_Drv_Cmd_T;


/**
 * data used by HMI to send Display ON/OFF via DESIP
 */
typedef uint8_t SIP_DIM_Display_State_Lvl_T;
/**
 * data used by HMI to send Dome lamp Delay time set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_DomeLampDelayTSet_T;

/**
 * data used by HMI to send Follow me Delay time set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_FollowMeDelayTSet_T;

/**
 * data used by HMI to send Battery save Delay time set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_BattSaveDelaySet_T;

/**
 * data used by HMI to send AFS temporary mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_AFSDrivingSideSet_T;

/**
 * data used by HMI to send Rainfall light sensor mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_RLSSet_T;

/**
 * data used by HMI to send Anti-theft mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_AntiTheftSetting_T;

/**
 * data used by HMI to send PAS active  mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_PASActiveSet_T;

/**
 * data used by HMI to send Rearview mirror fold mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_RearViewMirrorSet_T;

/**
 * data used by HMI to send Door unlock  mode set by user
 * via DESIP
 */
typedef uint8_t SIP_CAN_UnlockModSts_T;

/**
 *data used by HMI to send Front seat air condition control value by user
 *via DESIP
 */
typedef uint8_t SIP_CAN_FrtHMIClmCtrlSwActn_T;

/**
 *data used by HMI to send Rear seat air condition control value by user
 *via DESIP
 */
typedef uint8_t SIP_CAN_RrHMIClmCtrlSwActn_T;

typedef uint8_t SIP_CAN_User_Input_Cmd_T;
typedef uint8_t SIP_CAN_Surround_Cmd_T;
/**
* data used by VR to send control value via DESIP
**/
typedef uint8_t SIP_CAN_Voice_Control_Cmd_T;
/*   0: no action
      1: Face
      2: Face/Foot
      3: Foot
      4: Foot/Defrost
      5:Face/Defrost
      6:Face/Foot/Defrost
      7: Defrost",*/
typedef enum SIP_CAN_FrntAirDistriModeReq_VR_Tag
{
   SIP_ADMODE_NO_ACTION,
   SIP_ADMODE_FACE,
   SIP_ADMODE_FACE_FOOT,
   SIP_ADMODE_FOOT,
   SIP_ADMODE_FOOT_DEFROST,
   SIP_ADMODE_FACE_DEFROST,
   SIP_ADMODE_FACE_FOOT_DEFROST,
   SIP_ADMODE_DEFROST   
}SIP_CAN_FrntAirDistriModeReq_VR_T;
typedef enum SIP_CAN_LanguageSet_Tag
{
   SIP_CAN_CHINESE,
   SIP_CAN_ENGLISH,
   SIP_CAN_RUSSIAN,
   SIP_CAN_GERMAN,
   SIP_CAN_FRENCH,
   SIP_CAN_ITALIAN,
   SIP_CAN_SPANISH,
   SIP_CAN_PORTUGUESE
}SIP_CAN_LanguageSet_T;
/**
 * Structure data used by Tuner driver proxy server to provide
 * generic response to client via DESIP
 */
typedef struct SIP_Tuner_Drv_Mgr_Resp_Tag
{
    uint32_t cmd_id;            /**< Tuner Driver API ID */
    uint32_t cmd_result;        /**< Tuner Driver return value */
} SIP_Tuner_Drv_Mgr_Resp_T;

/**
 * Structure data used by Tuner driver proxy server to report
 * quality values to client via DESIP
 */
typedef struct SIP_Tuner_Drv_Quality_Resp_Tag
{
    uint32_t cmd_id;            /**< Tuner Driver API ID */
    uint8_t  quality_data[32];  /**< Tuner Driver return value */
} SIP_Tuner_Drv_Quality_Resp_T;

/**
 * Data type used by AMFM driver to report frequency updates
 */
typedef uint16_t SIP_Tuner_Frequency;

/*---------------------------------------------------------------------------*/

/* NOTE: This must match Menu_Action_Command_T */
typedef enum
{
   SIP_MOVE_UP_W_DATA = 0,
   SIP_MOVE_DOWN_W_DATA,
   SIP_MOVE_UP,
   SIP_MOVE_DOWN,
   SIP_ESC,
   SIP_ENTER
} SIP_Menu_Action_Command_Enum_T;

/*Arbitrary Text case2 Navigation Support structure */
typedef struct SIP_Arb_Txt_Nav_Menu_Action_Tag{
   uint8_t  dev_id;
   uint8_t  caret_line_id;       /* option field 1/2/3          */
   uint8_t  command_action;      /* refer SIP_Menu_Action_Command_Enum_T*/
}SIP_Arb_Txt_Nav_Menu_Action_T;


/*Arbitrary Text Phone digit dial support information to radio HMI*/
#define AT_MAX_RADIO_DISP_STR_SIZE  53 /* 52 for actual char. + 1 for NULL ;includes space for NULL termination*/
typedef uint8_t SIP_AT_Disp_Str_T[AT_MAX_RADIO_DISP_STR_SIZE];

typedef enum
 {
   DDL_OFF,
   DDL_ON
 }SIP_AuDM_DDL_State_T;

/*---------------------------------------------------------------------------*/
/*
 * structures for rear cross traffic alert typed
 * */
typedef enum SIP_RCTA_Type_Tag
{
   SIP_RCTA_LETF_INDICATIOR = 0,
   SIP_RCTA_RIGHT_INDICATOR
}SIP_RCTA_Type_T;

/*
 * rcta for the indication type
 * */
typedef enum SIP_RCTA_Indication_Request_Tag
{
   SIP_RCTA_OFF = 0,
   SIP_RCTA_CONTINUOUS_INDICATION,
   SIP_RCTA_FLASHING_INDICATION,
}SIP_RCTA_Indication_Request_T;

/*
 * rcta indicator 1 data
 */
typedef enum SIP_RCTA_Indicator_1_Status_Tag
{
   SIP_RCTA_IND_1_OFF = 0,
   SIP_RCTA_IND_1_ON,
}SIP_RCTA_Indicatior_1_Status_T;

/*
 * desip msg structure for rcta
 */
typedef struct SIP_RCTA_Info_Tag
{
   uint8_t rcta_type;            /*SIP_RCTA_Type_T*/
   uint8_t indication_request;   /*SIP_RCTA_Indication_Request_T*/
   uint8_t indicator_1;          /*SIP_RCTA_Indicatior_1_Status_T*/
}SIP_RCTA_Info_T;
/*
 * desip msg structure for VIP wakeup
 */
typedef enum SIP_Wakeup_Tag
{
   SIP_GMLAN_WAKEUP = 0,   /*GMLAN wakeup occurred*/
   SIP_EJECT_WAKEUP,       /*Eject key pressed during OFF ASLEEP*/
   SIP_COLDSTART           /*Cold start occurred*/
}SIP_Wakeup_T_1;
typedef int8_t SIP_Wakeup_T;

/*
 * desip msg's signal data for Display Measurement System.
 */
typedef enum SIP_Disp_Measurement_Sys_Tag
{
  SIP_DISP_MEASUREMENT_METRIC = 0,
  SIP_DISP_MEASUREMENT_ENGLISH
}SIP_Disp_Measurement_Sys_T;
/*
 * desip msg's signal data for Display Measurement System.
 */
typedef enum SIP_Disp_Language_Selection_Tag
{
   SIP_DISP_ENGLISH,
   SIP_DISP_GERMAN,
   SIP_DISP_ITALIAN,
   SIP_DISP_SWEDISH,
   SIP_DISP_FRENCH,
   SIP_DISP_SPANISH,
   SIP_DISP_DUTCH,
   SIP_DISP_PORTUGUESE,
   SIP_DISP_NORWEGIAN,
   SIP_DISP_FINNISH,
   SIP_DISP_DANISH,
   SIP_DISP_GREEK,
   SIP_DISP_JAPANESE,
   SIP_DISP_ARABIC,
   SIP_DISP_CHINESE,
   SIP_DISP_POLISH,
   SIP_DISP_TURKISH,
   SIP_DISP_KOREAN,
   SIP_DISP_TRADITIONAL_CHINESE,
   SIP_DISP_UK_ENGLISH,
   SIP_DISP_HUNGARIAN,
   SIP_DISP_CZECH,
   SIP_DISP_SLOVAK,
   SIP_DISP_RUSSIAN,
   SIP_DISP_BRAZILIAN_PORTUGESE,
   SIP_DISP_THAI,
   SIP_DISP_BULGARIAN,
   SIP_DISP_ROMANIAN,
   SIP_DISP_SLOVENIAN,
   SIP_DISP_CROATIAN,
   SIP_DISP_UKRANIAN,
   SIP_DISP_NA_FRENCH,
   SIP_DISP_NA_SPANISH,
   SIP_DISP_CANTONESE
}SIP_Disp_Language_Selection_T;

/*
 * Audio Arbitration command information from Audio Master Arbitration message.
 */

typedef enum SIP_Audio_Arb_Command_Type_Tag
{
   SIP_NO_ACTION = 0,
   SIP_DO_NOT_CONNECT,
   SIP_CONNECT,
   SIP_DISCONNECT,
   SIP_CONNECTION_COMPLETE
} SIP_Audio_Arb_Command_Type_T;

/*
 * Audio Channel type information from Audio Master Arbitration message.
 */

typedef enum SIP_Audio_Channel_Type_Tag
{
   SIP_NO_CHANNEL   = 0,
   SIP_MONO,
   SIP_STEREO,
   SIP_MIXED
} SIP_Audio_Channel_Type_T;

/*
 * Audio Source type information from Audio Master Arbitration message.
 */

typedef enum SIP_Audio_Source_Type_Tag
{
   SIP_AUDIO_SUPERVISOR                   = 0x00,
   SIP_TELEVISION_TUNER                   = 0x01,
   SIP_AUXILIARY_DEVICE                   = 0x08,
   SIP_REMOTE_DIGITAL_VIDEO_DISK          = 0x0C,
   SIP_REMOTE_CD_CHARGER                  = 0x10,
   SIP_DIGITAL_AUDIO_BROADCAST            = 0x14,
   SIP_SAT_DIGITAL_AUDIO_RECEIVER_SYSTEM  = 0x18,
   SIP_PHONE                              = 0x1C
} SIP_Audio_Source_Type_T;

/*
 * desip msg structure for for Audio Master Arbitration Command.
 */

typedef struct SIP_Audio_Master_Arbitration_Command_Tag
{
   SIP_Audio_Arb_Command_Type_T aud_arb_cmd;
   SIP_Audio_Channel_Type_T audsrc_chnl_type;
   SIP_Audio_Source_Type_T audsrc_type;
}SIP_Audio_Master_Arbitration_Command_T;



/*
 * desip msg structure for for Voice Recognition Status .
 */

typedef enum SIP_Remote_Onstar_Command_Tag
{
   SIP_NO_ACTION_CMND,
   SIP_REPORT_PERSONAL_CALLING_NUMBER_CMND,
   SIP_VERIFY_PERSONAL_CALLING_UNITS_CMND,
   SIP_ADD_PERSONAL_CALLING_UNITS_CMND,
   SIP_VIRTUAL_ADVISOR_CALL_CMND,
   SIP_ONSTAR_ADVISOR_CALL_CMND,
   SIP_ONSTAR_EMERGENCY_CALL_CMND,
   SIP_POINT_OF_INTEREST_CALL_CMND,
   SIP_START_MEMO_RECORD_CMND,
   SIP_END_MEMO_RECORD_CMND,
   SIP_PLAY_MEMO_RECORD_CMND,
   SIP_PAUSE_MEMO_RECORD_CMND,
   SIP_RESUME_MEMO_RECORD_CMND,
   SIP_START_TELEMATICS_VOICE_RECOGNITION_CMND,
   SIP_END_TELEMATICS_VOICE_RECOGNITION_CMND
}SIP_Remote_Onstar_Command_T;

typedef struct SIP_Voice_Recognition_Status_Tag
{
   bool_t voice_rec_active;
   SIP_Remote_Onstar_Command_T remote_onstar_cmd;
}SIP_Voice_Recognition_Status_T;

typedef enum SIP_Icr_Eng_Cals_Info_Tag
{
   SIP_NAV_CHINA = 0,
   SIP_NAV_EUROPE,
   SIP_NAV_SOUTH_AMERICA,
   SIP_NAV_SOUTH_AFRICA,
   SIP_NAV_AUSTRALIA,
   SIP_NAV_EU_NONNAV
}SIP_Icr_Eng_Cals_Info_T;

/*
 * desip msg data for Nav TBT status .
 */

typedef bool_t SIP_Nav_TBT_Status_T;


/** BT_Phone call status */
typedef enum SIP_BT_call_status_Tag
{
   SIP_BT_INCOMING_CALL = 0,
   SIP_BT_CALL_ENDED,
   SIP_BT_CALL_FAILED,
   SIP_BT_CALL_ACTIVE,
   SIP_BT_OUTGOING_CALL,
   SIP_BT_NUM_STATUS
}SIP_BT_call_status_T;
/* DESIP message data type for Cals checksums request
  * This is enum for Cals section names
  *
  * IMPORTANT NOTE: Please do not add any cal section before CALS_BT or after CALS_NUMBER_OF_HEADERS
  */
typedef enum SIP_Cals_Section_Name_Tag
{
   CALS_FIRST_HEADER = 0,
   CALS_BT,
   CALS_EQ,
   CALS_INFO,
   CALS_REARCAM,
   CALS_TUNER,
   CALS_GMB,
   CALS_NUMBER_OF_HEADERS
} SIP_Cals_Section_Name_T;

/* DESIP message data type for sending Cals checksums from VIP to AP. Checksums are 2-byte 2's complement checksums.
  */
/*#define CALS_NUMBER_OF_HEADERS  (5)*/
typedef struct SIP_Cals_Checksums_Tag
{
    uint16_t chck_sums[CALS_NUMBER_OF_HEADERS];
}SIP_Cals_Checksums_T;

/* DESIP message data type for sending Cals Data from VIP to AP.
     The data is transmitted in following order:
     1. Requested Cal section name
     2. Requested Cal section's data length
     3. Requested Cal section data
  */
#define CALS_SECTION_NAME_LEN           (1) /*number of bytes transmitted */
#define CALS_SECTION_DATA_SIZE_LEN     (2) /*number of bytes transmitted */
#define CALS_MAX_DATA_LENGTH            (1000) /*number of bytes transmitted */

typedef uint8_t SIP_Cals_Data_T[CALS_SECTION_NAME_LEN + CALS_SECTION_DATA_SIZE_LEN + CALS_MAX_DATA_LENGTH];
#if 0
typedef struct SIP_Cals_Data_Tag
{
      uint8_t cals_data [CALS_MAX_DATA_LENGTH];
   uint16_t cals_actual_tx_data_len;
} SIP_Cals_Data_T;
#endif
   typedef struct SIP_ICR_SW_HW_Tag
   {
      char_t VIP_SWID[SIP_MAX_SIZE];
      char_t AP_SWID[SIP_MAX_SIZE];
      char_t ICR_HWID[SIP_MAX_SIZE];
   } SIP_ICR_SW_HW_T;


/* DESIP message data type for sending Onstar Data from VIP to AP */

typedef bool_t SIP_Onstar_TBT_Voice_Prmpt_Muted_T;


/* DESIP message data type for sending Onstar Data from VIP to AP */

typedef bool_t SIP_Onstar_Phone_Switch_Active_T;


/* DESIP message data type for sending Onstar Data from AP to VIP */


typedef bool_t SIP_Onstar_TBTVc_Prmpt_Mute_Request_T;


/* DESIP message data type for sending Onstar Data from AP to VIP */

typedef bool_t SIP_VoiceRec_State_T;


/** Battery State Charge Low Indication*/
   typedef bool_t SIP_Battery_State_Charge_Low_Indication_T;

/** Vehicle Fuel level  Low Indication*/
 typedef bool_t  SIP_Vehicle_Fuel_Level_Low_Indication_T;

 /*Voice rec state*/
 typedef bool_t  SIP_VoiceRec_Rem_Onstar_Cmd_T;

#define VEH_POS_DATA_LEN             (6)  /*number of bytes received */
#define OTHER_POS_DATA_LEN           (6)  /*number of bytes received */

typedef struct SIP_Vehicle_Position_Tag
{
    uint8_t veh_pos[VEH_POS_DATA_LEN];
} SIP_Vehicle_Position_T;

typedef SIP_Vehicle_Position_T SIP_Metar_From_Loc_T;

typedef SIP_Vehicle_Position_T SIP_Weather_Other_Loc_T;

typedef uint8_t SIP_City_Forecast_T;

typedef uint8_t SIP_Weather_Other_City_T;

#define WEATHER_MESSAGE_TYPE_IDENTITY           (0x01)

#define FORECAST_DAY_MAX_NUM_UART_BYTES            (33)   /*number of data bytes to transmit */
#define METAR_MAX_NUM_UART_BYTES                   (62)   /*number of data bytes to transmit */
#define WEATHER_WARNING_MAX_NUM_UART_BYTES         (100)  /*number of data bytes to transmit */
#define WEATHER_FEATURE_MAX_NUM_UART_BYTES         (1)    /*number of data bytes to transmit */
#define ALERTS_POPUP_SETTING_MAX_NUM_UART_BYTES    (1)    /*number of data bytes to transmit */
#define ALERTS_POPUP_MAX_NUM_UART_BYTES            (1)    /*number of data bytes to transmit */

#define FORECAST_DAY_MAX_NUM_HEADER_BYTES          (3)    /*number of header data bytes to transmit */
#define METAR_MAX_NUM_HEADER_BYTES                 (3)    /*number of header data bytes to transmit */
#define WEATHER_WARNING_MAX_NUM_HEADER_BYTES       (2)    /*number of header data bytes to transmit */
#define WEATHER_FEATURE_MAX_NUM_HEADER_BYTES       (2)    /*number of header data bytes to transmit */
#define ALERTS_POPUP_SETTING_MAX_NUM_HEADER_BYTES  (2)    /*number of header data bytes to transmit */
#define ALERTS_POPUP_MAX_NUM_HEADER_BYTES          (2)    /*number of header data bytes to transmit */

typedef enum SIP_Weather_Msg_Id_Tag
{
   WTR_MSG_FEATURE_STATUS = 0,
   WTR_MSG_CURRENT_CONDITIONS,
   WTR_MSG_5_DAY_FORECAST,
   WTR_MSG_COUNTY_ALERTS,
   WTR_MSG_ALERTS_POPUP_SETTING,
   WTR_MSG_CITY_CODE_REQUEST,
   WTR_MSG_CITY_CODE_RESPONSE,
   WTR_MSG_ALERTS_POPUP,
} SIP_Weather_Msg_Id;

typedef enum SIP_Weather_Mode_Id_Tag
{
   WTR_MSG_MODE_CURRENT,
   WTR_MSG_MODE_OTHER_CITY,
   WTR_MSG_MODE_METAR_FROM_LOCATION,
   WTR_MSG_MODE_OTHER_LOCATION
} SIP_Weather_Mode_Id;

typedef struct SIP_Forecast_Day_Data_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  msg_mode;
  uint8_t  data[FORECAST_DAY_MAX_NUM_UART_BYTES];
} SIP_Forecast_Day_Data_T;

typedef struct SIP_Metar_Data_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  msg_mode;
  uint8_t  data[METAR_MAX_NUM_UART_BYTES];
} SIP_Metar_Data_T;

typedef struct SIP_Weather_Warning_Data_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  data[WEATHER_WARNING_MAX_NUM_UART_BYTES];
} SIP_Weather_Warning_Data_T;

typedef struct SIP_Weather_Feature_Status_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  status;
} SIP_Weather_Feature_Status_T;

typedef struct SIP_Weather_Alerts_Popup_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  warning;
} SIP_Weather_Alerts_Popup_T;

typedef struct SIP_Alerts_Popup_Settings_Tag
{
  uint8_t  msg_type;
  uint8_t  msg_id;
  uint8_t  settings;
} SIP_Alerts_Popup_Settings_T;

#define TMC_EVENT_DATA_MAX_NUM_UART_BYTES       (6) /*number of bytes received */

typedef struct SIP_TMC_Filter_Tag
{
  uint8_t  index;
  uint8_t  table_id;
  uint16_t broadcast_service_id;
  uint8_t  traffic_usage;
} SIP_TMC_Filter_T;

typedef struct SIP_TMC_Filter_Status_Tag
{
  uint8_t  msg_type;
  uint8_t  status_lo;
  uint8_t  status_hi;
  uint8_t  traffic_status;
} SIP_TMC_Filter_Status_T;

typedef uint8_t SIP_TMC_Event_Data_T[TMC_EVENT_DATA_MAX_NUM_UART_BYTES];

typedef bool_t SIP_Bench_State_T;

/*
* cals required by icr_core_1 process
*/
typedef struct SIP_Cal_Boot_Tag
{
   bool_t avail_video;/*rvs present calibration*/
   uint8_t Cal_RVS_On_Hysteresis;
   uint8_t Cal_RVS_Off_Hysteresis;
   uint8_t Cal_Splash_Screen;
}SIP_Cal_Boot_T;

typedef uint32_t SIP_Bench_Mode_Timer_Value;

/* All the below length field size should be same as AT_Onstar_Destination_Data_Length_T given in adv_arb_gl.hu */
typedef enum SIP_AT_Onstar_Destination_Data_Length_Tag
{
   SIP_ONSTAR_DEST_NAME_LENGTH           = 0x24,
   SIP_ONSTAR_DEST_ADDRESS_NUMBER_LENGTH = 0x0B,
   SIP_ONSTAR_DEST_STREET_PREFIX_LENGTH  = 0x0B,
   SIP_ONSTAR_DEST_STREET_NAME_LENGTH    = 0x24,
   SIP_ONSTAR_DEST_STREET_TYPE_LENGTH    = 0x05,
   SIP_ONSTAR_DEST_STREET_SUFFIX_LENGTH  = 0x0B,
   SIP_ONSTAR_DEST_CITY_LENGTH           = 0x15,
   SIP_ONSTAR_DEST_STATE_LENGTH          = 0x03,
   SIP_ONSTAR_DEST_LATITUDE_LENGTH       = 0x0B,
   SIP_ONSTAR_DEST_LONGITUDE_LENGTH      = 0x0B,
   SIP_ONSTAR_DEST_PHONE_NUMBER_LENGTH   = 0x11

}SIP_AT_Onstar_Destination_Data_Length_T;


typedef struct SIP_ONSTAR_DESTINATION_DOWNLOAD_Tag
{
   char  destination_name[SIP_ONSTAR_DEST_NAME_LENGTH];
   char address_number[SIP_ONSTAR_DEST_ADDRESS_NUMBER_LENGTH];
   char street_prefix[SIP_ONSTAR_DEST_STREET_PREFIX_LENGTH];
   char street_name[SIP_ONSTAR_DEST_STREET_NAME_LENGTH];
   char street_type[SIP_ONSTAR_DEST_STREET_TYPE_LENGTH];
   char street_suffix[SIP_ONSTAR_DEST_STREET_SUFFIX_LENGTH];
   char city[SIP_ONSTAR_DEST_CITY_LENGTH];
   char state[SIP_ONSTAR_DEST_STATE_LENGTH];
   char latitude[SIP_ONSTAR_DEST_LATITUDE_LENGTH];
   char longitude[SIP_ONSTAR_DEST_LONGITUDE_LENGTH];
   char phone_number[SIP_ONSTAR_DEST_PHONE_NUMBER_LENGTH];
}SIP_ONSTAR_DESTINATION_DOWNLOAD_T;

typedef enum SIP_Onstar_DD_Process_Status_Tag
{
   SIP_DOWNLOAD_NOT_ACTIVE,
   SIP_DOWNLOAD_STARTED,
   SIP_DOWNLOAD_COMPLETE,
   SIP_DOWNLOAD_FAILED,
   SIP_DOWNLOAD_MAX_ENUM
}SIP_Onstar_DD_Process_Status_T;

typedef enum SIP_Onstar_DD_Address_Resolution_Status_Tag
{
   SIP_RESOLUTION_NOT_ACTIVE,
   SIP_RESOLUTION_STARTED,
   SIP_RESOLUTION_COMPLETED,
   SIP_RESOLUTION_CANCELLED,
   SIP_RESOLUTION_FAILED
}SIP_Onstar_DD_Address_Resolution_T;

/*
 * Structure for debug trace text received from VIP
 */
#define VIP_MAX_TRACE_SIZE (256)

typedef struct
{
   char text[VIP_MAX_TRACE_SIZE];
} VIP_Debug_Trace_T;


/*DESIP message data type for sending Reflash Calibrations*/
#define MAX_BLCK_SIZE    (128)

typedef struct SIP_VIP_Flash_Block_Tag
{
  uint8_t    vip_flash_block_size[MAX_BLCK_SIZE];
}SIP_VIP_Flash_Block_T;


/*DESIP message for sending Reflash Cals address and block size*/
typedef struct SIP_VIP_Flash_Read_Tag
{
  uint32_t   block_start_addr;
  uint8_t    block_size;
}SIP_VIP_Flash_Read_T;

typedef uint32_t SIP_Ignition_Count_T;

typedef enum SIP_Vehicle_Power_Mode_Tag
{
   SIP_INVALID_MODE = -1,
   SIP_OFF_MODE = 0,
   SIP_ACCESSORY_MODE,
   SIP_RUN_MODE,
   SIP_CRANK_MODE
}SIP_Vehicle_Power_Mode_T_1;
typedef int8_t SIP_Vehicle_Power_Mode_T;
typedef enum SIP_Diag_Service_Tag
{
   SIP_DIAG_SERVICE_A5 = 0,
   SIP_DIAG_SERVICE_34
}SIP_Diag_Service_T;

typedef enum SIP_CAN_RvcOperationState_Tag
{
   RVC_STANDBY,
   RVC_OPERATION,
   RVC_SYS_NOT_AVAILABLE,
   RVC_CALIBRATION,
   RVC_UNKNOWN
}SIP_CAN_RvcOperationState_T;

typedef uint8_t SIP_VIP_CAN8_T;
typedef uint16_t SIP_VIP_CAN16_T;

typedef struct SIP_RVC_Fault_Tag
{
   uint16_t RVC_INTERNAL_FAULT:1;
   uint16_t VIDEO_SIG_FAULT:1;
   uint16_t EOL_FAULT:1;
   uint16_t SAS1_TIMEOUT:1;
   uint16_t BCM1_TIMEOUT:1;
   uint16_t BCM3_TIMEOUT:1;
   uint16_t ABS2_TIMEOUT:1;
   uint16_t VEHICLE_SPD_INVALID:1;
   uint16_t SWA_INVALID:1;
   uint16_t SAS1_LIVECOUNTER_ERROR:1;
   uint16_t SAS_STATUS_INVALID:1;
   uint16_t SAS1_CHECKSUM_ERROR:1;
   uint16_t VOLTAGE_FAULT:1;
}SIP_RVC_Fault_T;

typedef struct SIP_AMP_Info_Tag
{
   uint16_t AMP_SW_Version;
   uint16_t AMP_HW_Version;
   uint8_t AMP_Temp_Value;
   uint8_t AMP_Vol_Value;
}SIP_AMP_Info_T;
/* VIP Reset causes that get logged */
typedef enum SIP_VIP_Reset_Reasons_Tag
{
   SIP_NO_RESET                     = 0x00000000,
   SIP_BATTERY_POWER_RESTART        = 0x00000001,
   SIP_WATCHDOG_TIMEOUT             = 0x00000002,
   SIP_UNKNOWN_COLD_START           = 0x00000004,
   SIP_STACK_OVERFLOW               = 0x00000008,
   SIP_XM_STACK_FATAL_ERROR         = 0x00000010,
   SIP_SLOW_WATCHDOG_TIMEOUT        = 0x00000020,
   SIP_RESET_AP_REQUEST             = 0x00000040,
   SIP_RESET_DIAG_REQUEST           = 0x00000080,
   SIP_RESET_REFLASH                = 0x00000100,
   SIP_RESET_AP_ALIVE_TIMEOUT       = 0x00000200,
   SIP_RESET_AP_FAILED_START        = 0x00000400,
   SIP_V850_CLM_RESTART             = 0x00000800,
   SIP_V850_LVI_RESTART             = 0x00001000,
   SIP_V850_RESET_PIN_RESTART       = 0x00002000,
   SIP_DSP_774x_RESET               = 0x00004000,
   SIP_CAN_TIMER_EXPIRY_RESET       = 0x00008000,
   SIP_ROLL_OVER_PROTECTION_RESET   = 0x00010000,
   SIP_NORMAL_SLEEP_WAKEUP_RESET    = 0x00020000,
   SIP_BATTERY_WARN_EXIT_RESET      = 0x00040000
} SIP_VIP_Reset_Reasons_T;

typedef uint32_t SIP_VIP_Reset_T;

/* This is used for configuring the AP software as ICR or GMB */
typedef enum SIP_Set_Software_Project_Tag
{
   SIP_SW_ICR = 0,
   SIP_SW_GMB = 1
} SIP_Set_Software_Project_T;

/* Various states of onstar call is send to AP to bring pop-up with call staus on HMI*/
typedef enum SIP_Onstar_Call_Status_Rpt_Tag
{
   SIP_UNKNOWN_CALLSTATE = 0,
   SIP_ONSTAR_CALLCONNECTING,
   SIP_ONSTAR_CALLCONNECTED,
   SIP_ONSTAR_CALLENDED,
   SIP_ERROR_CALLCONNECTION_FAILED,
   SIP_INCOMING_ONSTARCALL_COLLISION,   
   SIP_INCOMING_ONSTARCALL_EMERGENCY,
   SIP_INCOMING_ONSTARCALL_RA,
   SIP_INCOMING_ONSTARCALL_VA,
   SIP_INCOMING_ONSTARCALL_UNIT_ADD,
   SIP_INCOMING_ONSTARCALL_VDU,
   SIP_INCOMING_ONSTARCALL_ENROLLMENT,
   SIP_INCOMING_ONSTARCALL_OCC_INITIATED,
}SIP_Onstar_Call_Status_Rpt_T;

/* user action on incoming onstar call is reported to VIP using the below list of valueaction*/
typedef enum SIP_Onstar_Call_Status_Action_Tag
{
   SIP_NOACTION = 0,
   SIP_ACCEPT_INCOMING_CALL,
   SIP_DECLINE_INCOMING_CALL,
   SIP_HANGUP_ACTIVE_CALL,
   SIP_PLACE_ONSTARCALL_EMERGENCY,
   SIP_PLACE_ONSTARCALL_ROADSIDEASSISTANCE,
   SIP_PLACE_ONSTARCALL_VIRTUALADVISOR,
   SIP_PLACE_ONSTARCALL_UNITADD,
   SIP_PLACE_ONSTARCALL_ENROLLMENT
}SIP_Onstar_Call_Status_Action_T;

/*Phone dial commands*/
typedef enum SIP_Phone_Dial_Command_Tag
{
   SIP_NO_CALLACTION = 0,
   SIP_REQUEST_PHONE_STATUS,
   SIP_DIAL_COMMAND_2_PENDING,
   SIP_SEND_VOICE_CALL,
   SIP_SEND_DATA_CALL,
   SIP_END_CALL,
   SIP_CLEAR,
   SIP_GENERATE_DTMF,
   SIP_LOCK_TRANSCEIVER,
   SIP_UNLOCK_TRANSCEIVER
}SIP_Phone_Dial_Command_T;

#define DIAL_STRG_LENGTH 16 /*string length of 15 chars + NULL*/

/*Phone dial command_1*/
typedef struct SIP_Phone_Dial_Command_1_Tag
{
   SIP_Phone_Dial_Command_T phone_dial_command;
   char dial_string[DIAL_STRG_LENGTH];
}SIP_Phone_Dial_Command_1_T;

typedef enum SIP_Onstar_Reason_For_Cancel_Tag
{
   /*End the display associated with IVA*/
   SIP_END_INVEHICLE_ALERT_DISPLAY,
   /* End the display of audiomessagetext,onstarwelcometext,xmdeactivated,onstarminutes*/
   SIP_END_ONSTAR_MESSAGE_TEXT,
   /* End display of MIN,ACQ and language*/
   SIP_UAC_DISPLAY,
   /*End radio navigation route*/
   SIP_CANCEL_NAVIGATION_ROUTE,
    /* End display of TBT screen*/
   SIP_END_TBT_NAVIGATION_DISPLAY,
   /* End activate message dialog*/
   SIP_DEACTIVATE_MENU,
   /*End center stack text*/
   SIP_CANCEL_CENTER_STACK_TEXT

}SIP_Onstar_Reason_For_Cancel_T;

typedef enum SIP_Radio_Reason_For_Pop_Up_Closure_Tag
{
   /*
   user presses the BACK button or a selectable
   display input to cancel the onstar message display
   */
   SIP_CANCEL_ONSTAR_MESSAGE_TEXT,
   SIP_POP_UP_TIME_OUT,
   SIP_POP_UP_CLOSE_ICON_PRESSED,
   SIP_BACK_KEY_PRESSED,
   SIP_BUTTON1_SELECTED_ACTION,
   SIP_BUTTON2_SELECTED_ACTION,
   SIP_CENTER_STACK_DISP_ACK


}SIP_Radio_Reason_For_Pop_Up_Closure_T;

typedef enum SIP_ONSTAR_Text_Screen_Type_Tag
{
   /* FU-6 */
   SIP_IVA_DISASTER,
   SIP_IVA_AMBER,
   SIP_IVA_TRAFFIC,
   SIP_IVA_WEATHER,
   SIP_IVA_GENERIC,
   SIP_IVA_CAMPAIGN,
   SIP_IVA_REMINDER,

   SIP_AUDIO_MESSAGE_TEXT,
   SIP_ONSTAR_WELCOME_TEXT,
   SIP_XM_DEACTIVATE_TEXT,
   SIP_ONSTAR_MINUTES_TEXT,   
   SIP_ONSTAR_LANGUAGE_CHANGE_EN,
   SIP_ONSTAR_LANGUAGE_CHANGE_FR,
   SIP_ONSTAR_LANGUAGE_CHANGE_SP,
   SIP_MIN_DIGITS_TEXT,
   SIP_ACQ_SETTINGS_TEXT,      
   SIP_MESSAGE_TEXT,
   SIP_TTY_FUNCTION_RESTRICTION_RAVM,

   SIP_ACTIVATE_1BUTTON_MESSAGE_DIALOG,
   SIP_ACTIVATE_2BUTTON_MESSAGE_DIALOG,

   /* FU-2 */
   SIP_CENTER_STACK_TEXT,
}SIP_ONSTAR_Text_Screen_Type_T;

#define AT_ONSTAR_BUTTON_TEXT_SIZE 20

typedef struct SIP_ONSTAR_Display_Request_Tag
{
   char text_info[AT_MAX_RADIO_DISP_STR_SIZE];
   SIP_ONSTAR_Text_Screen_Type_T screen_type;

}SIP_ONSTAR_Display_Request_T;

typedef struct SIP_Onstar_Dialog_Disp_Req_Tag
{

   char text_info[AT_MAX_RADIO_DISP_STR_SIZE];
   char button1[AT_ONSTAR_BUTTON_TEXT_SIZE];
   char button2[AT_ONSTAR_BUTTON_TEXT_SIZE];
   SIP_ONSTAR_Text_Screen_Type_T screen_type;

}SIP_Onstar_Dialog_Disp_Req_T;

/* Enum for Sub Menu Indicator */
typedef enum SIP_Sub_Menu_Indicator_Tag
{
   /* This state should be sent if the SubmenuIndicator column should be blank
    * or hidden on the display.
    */
   NO_SUB_MENU = 0,
   /* This value should be rendered as a > or -> on the display to indicate that
    * there is a submenu below this item.
    */
   SUB_MENU,
   /* This value indicates that the current list item is one of N selections but
    * this item is not currently selected. The display should generally render
    * this as an open circle. This is different from the check box in that only
    * one item should be selected at a time. With the check box, multiple items
    * may be selected at a time.
    */
   UNSELECTED_ITEM,
   /* This value indicates that the current list item is one of N selections and
    * this item is selected. The display should generally render this as a filled
    * circle or dot within an open circle.
    */
   SELECTED_ITEM,
   /* This value indicates that the current list item is one of N selections but
    * this item is not currently selected. The display should generally render
    * this as an open box. This is different from the open circle in that multiple
    * items could be selected at one time. With the circle, only one item should
    * be selected at a time.
    */
   UNCHECKED_BOX,
   /* This value indicates that the current list item is one of N selections and
    * it is currently selected. The display should generally render this as a box
    * with a check mark in it. This is different from the open circle in that
    * multiple items could be selected at one time. With the circle, only one
    * item should be selected at a time.
    */
   CHECKED_BOX
} SIP_Sub_Menu_Indicator_T;

#define MENU_LIST_ITEM_MAX_CHARS (32)

/* Structure for sending Menu List Item. This is send from VIP to AP one at a time. */
typedef struct SIP_Menu_List_Item_Tag
{
   uint8_t CurrentItemIndex; /* current index of the menu item */
   char_t MenuList [MENU_LIST_ITEM_MAX_CHARS]; /* Menu List Item string */
   char_t StringSetting [MENU_LIST_ITEM_MAX_CHARS]; /* Menu List Item String Setting */
   SIP_Sub_Menu_Indicator_T subMenuIndicator; /* Menu List Item Sub-Menu Indicator */
} SIP_Menu_List_Item_T;

/* Structure for sending Menu Title and number of Menu Items */
typedef struct SIP_Menu_Title_Tag
{
   uint8_t ListSize; /* Number of Menu List Items */
   char_t MenuTitle [MENU_LIST_ITEM_MAX_CHARS]; /* Menu Title */
} SIP_Menu_Title_T;

/* Enum for type of button press for menu response. It could CANCEL, BACK or Item selected */
typedef enum SIP_Menu_List_Resp_Tag
{
   /* This indicates that the CANCEL button has been pressed. */
   CANCEL_BUTTON_PRESSED = 0,
   /* This indicates that the BACK button has been pressed. */
   BACK_BUTTON_PRESSED,
   /* This indicates that a Menu List Item has been pressed. */
   MENU_ITEM_PRESSED
} SIP_Menu_List_Resp_T;

/* Structure for Menu List response:
 * - Type of button press
 * - If Menu Item is selected, then item selected is sent (ListFieldSelectAction)
 */
typedef struct SIP_Radio_Menu_List_Action_Tag
{
   SIP_Menu_List_Resp_T menu_list_response;
   uint8_t SelectedItemIndex;
} SIP_Radio_Menu_List_Action_T;

/* ODI customization sub-field */
typedef enum SIP_ODI_Custom_Tag
{
   CUSTOM_BCM_RESTORE_FACTORY_DEF = 0,
   CUSTOM_BCM_APPROACH_LIGHTING,
   CUSTOM_BCM_AUTO_REVERSE_GEAR_REAR_WIPER,
   CUSTOM_BCM_DRIVER_PERSONALIZATION,
   CUSTOM_BCM_EXIT_LIGHT_TIME,
   CUSTOM_BCM_REMOTE_START,
   CUSTOM_BCM_REMOTE_START_COOLED_SEAT,
   CUSTOM_BCM_REMOTE_START_HEATED_SEAT,
   CUSTOM_BCM_POWERTRAIN_PERFORMANCE,
   CUSTOM_BCM_DAYTIME_TAILLIGHTS,
   CUSTOM_BCM_REMOTE_START_COOLED_DR_PAS_SEAT,
   CUSTOM_BCM_REMOTE_START_HEATED_DR_PAS_SEAT,
   CUSTOM_BCM_RAIN_SENSE_WIPERS,
   CUSTOM_BCM_REMOTE_WINDOW_OPERATION,

   CUSTOM_DOORLOCKS_RESTORE_FACTORY_DEF,
   CUSTOM_DOORLOCKS_AUTO_LOCKING,
   CUSTOM_DOORLOCKS_AUTO_UNLOCKING,
   CUSTOM_DOORLOCKS_LAST_DOOR_CLOSED_LOCKING,
   CUSTOM_DOORLOCKS_MANUAL_TRANS_AUTO_UNLOCKING,
   CUSTOM_DOORLOCKS_PASSIVE_LOCKING,
   CUSTOM_DOORLOCKS_PASSIVE_UNLOCKING,
   CUSTOM_DOORLOCKS_RELOCK_REMOTE_DOOR,
   CUSTOM_DOORLOCKS_RELOCK_REMOTE_UNLOCKED_DOOR,
   CUSTOM_DOORLOCKS_REMOTE_IN_VEHICLE_REMINDER,
   CUSTOM_DOORLOCKS_REMOTE_LOCKING_FEEDBACK,
   CUSTOM_DOORLOCKS_REMOTE_SLIDING_DOOR,
   CUSTOM_DOORLOCKS_REMOTE_UNLOCK_LIGHTING_FEEDBACK,
   CUSTOM_DOORLOCKS_SELECTIVE_UNLOCKING,
   CUSTOM_DOORLOCKS_OPEN_DOOR_ANTI_LOCK_OUT,

   CUSTOM_PA_RESTORE_FACTORY_DEF,
   CUSTOM_PA_PARK_ASSIST,
   CUSTOM_PA_PARK_ASSIST_WITH_TOWBAR

} SIP_ODI_Custom_T;

/* ODI customization sub-field for item */
typedef struct SIP_ODI_Custom_Item_Tag
{
   SIP_ODI_Custom_T id;
   uint8_t value;
} SIP_ODI_Custom_Item_T;

/* Max number of customization items */
#define MAX_CUSTOM_ITEMS_PER_PKT (14)

/* ODI customization Request structure */
typedef struct SIP_ODI_Custom_Req_Tag
{
   uint8_t total_count;
   SIP_ODI_Custom_T items [MAX_CUSTOM_ITEMS_PER_PKT];
} SIP_ODI_Custom_Req_T;

/* ODI customization Action structure */
typedef struct SIP_ODI_Custom_Action_Tag
{
   uint8_t total_count;
   SIP_ODI_Custom_Item_T items [MAX_CUSTOM_ITEMS_PER_PKT];
} SIP_ODI_Custom_Action_T;

/* ODI customization Report */
typedef struct SIP_ODI_Custom_Rpt_Tag
{
   uint8_t total_count;
   SIP_ODI_Custom_Item_T items [MAX_CUSTOM_ITEMS_PER_PKT];
} SIP_ODI_Custom_Rpt_T;


/* RSE Status Report */
typedef struct SIP_RSE_Status_Tag
{
   uint8_t data[6];
} SIP_RSE_Status_T;


typedef struct SIP_GWM_DID_SYNC_Tag
{
   uint16_t ID;
   uint8_t data[20];
} SIP_GWM_DID_SYNC_T;


typedef struct SIP_GWM_DID_SYNC_REQ_Tag
{
   uint16_t ID;
   uint8_t data[20];
} SIP_GWM_DID_SYNC_REQ_T;


typedef struct SIP_VIP_SW_Version_Tag
{
   uint8_t version1[8];
   uint8_t version2[8];
} SIP_VIP_SW_Version_T;

/** Samuel add for GPS direction  and  atitude*/
   typedef uint8_t SIP_Direction_T;    
   typedef uint16_t   SIP_Altitude_T;
   typedef uint8_t SIP_Altitude_Direction_T; 

typedef struct SIP_Chi_Gen_Ring_Tone_Tag
{
   uint8_t location_tone;
   uint8_t cadence;
   uint8_t reps;
   uint8_t duty_cycle;
   uint8_t priority;
} SIP_Chi_Gen_Ring_Tone_T;

typedef struct SIP_LAT_LON_Tag
{
   int32_t LAT;
   int32_t LON;
} SIP_LAT_LON_T;

typedef enum 
{
 SWC_NORMAL,
 SWC_SHORT_GND,
 SWC_OPEN_CIRCUIT,
 SWC_UNDEFINED,
}SIP_SWC_Failure_Status;


typedef uint8_t SIP_SWC_Failure_Status_T;

typedef struct SIP_Faceplate_Data_Tag
{
   uint8_t soh;
   uint8_t blknum;
   uint8_t _blknum;
   uint8_t data[128];
   uint8_t checksum;
} SIP_Faceplate_Data_T;


typedef enum 
{
 SPEED_SIGNAL_DIAGNOSTIC_NORMAL,
 SPEED_SIGNAL_DIAGNOSTIC_OPEN_CIRCUIT,
 SPEED_SIGNAL_DIAGNOSTIC_INVALID
}SPEED_SIGNAL_FAILURE_STAUS;

typedef uint8_t SPEED_SIGNAL_Failure_Status_T;


#pragma pack(push)
#pragma pack(1)

typedef struct TUNNER_STATUS_TAG
{
  uint8_t tuner_band;
  uint32_t tuner_frequency;
}TUNNER_STATUS_T;

#pragma pack(pop)


/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/



/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* DESIP_MSG_TYPES_H */
/*===========================================================================*\
 * File Revision History (top to bottom: first revision to last revision)
 *===========================================================================

 *
 * 2-18-2013   1.0       jz82gw      Task: ctc_basa#59290
 * - Create initial version of desip for chb041 and ford project
 *
 *===========================================================================*/

