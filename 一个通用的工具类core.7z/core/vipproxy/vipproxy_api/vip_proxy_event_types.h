#ifndef VIP_PROXY_EVENT_TYPES_H
#   define VIP_PROXY_EVENT_TYPES_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_proxy_event_types.h
 *
 * Defines all events data types required by the VIP Proxy
 *
 * %full_filespec:vip_proxy_event_types.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:07 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *  All of the XSAL event types for the VIP Proxy module are defined in this
 *  file. These are re-types of the DESIP message types in the XSAL message type format
 *    VIP_EV_XXXXX_T for data going to VIP and 
 *    EVG_XXXX_T for data from VIP. 
 *
 * @section ABBR ABBREVIATIONS:
 *   - VIPP - VIP Proxy. Provides proxy interface to VIP micro 
 *   - VIP - Vehicle Interface Processor.  
 *   - AP - Application Processor.  This micro.
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @defgroup vip_proxy_xsal XSAL event IDs for DESIP Messages
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/** definition of all desip messages */
#   include "desip_msg_ids.h"
#   include "desip_msg_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
/**
 * All of the DESIP messages going to the VIP are declared here as private 
 * XSAL messages. The VIP Proxy simply converts the header and forwards the 
 * message data over DESIP.
 */
#   undef DESIP_AP_Msg
#   undef DESIP_AP_Msg_ND
#   undef DESIP_AP_Msg_VL

/* Add an XSAL event type for every AP to VIP DESIP message with data */
#   define DESIP_AP_Msg(id, type, desc)      typedef type VIPP_EV_##id##_T;
#   define DESIP_AP_Msg_ND(id, desc)
#   define DESIP_AP_Msg_VL(id, type, desc)   typedef type VIPP_EV_##id##_T;

DESIP_AP_to_VIP_Msgs

/**
 * By default all DESIP message coming from the VIP are declared as published
 * events. Although, some (e.g., AD_DATA) will really be treated as a private 
 * message back to the requestor.
 */

#   undef DESIP_VIP_Msg
#   undef DESIP_VIP_Msg_ND
#   undef DESIP_VIP_Msg_VL

/* Add an XSAL publish event type for every VIP to AP DESIP message with data */
#   define DESIP_VIP_Msg(id, type, desc)      typedef type EVG_##id##_T;
#   define DESIP_VIP_Msg_ND(id, desc)
#   define DESIP_VIP_Msg_VL(id, type, desc)   typedef type EVG_##id##_T;

DESIP_VIP_to_AP_Msgs

/*===========================================================================*
 * Exported Type Declarations
 *============================================================= ==============*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_proxy_event_types.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 18-Jan-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PROXY_EVENT_TYPES_H */

