#ifndef ONSTAR_DD_SERVER_H
#   define ONSTAR_DD_SERVER_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file onstar_dd_server.h
 *
 * API for Onstar DD Server (Onstar Destination Download Data Services)
 *
 * %full_filespec:  onstar_dd_server.h~1:incl:ctc_ec#4 %
 * @version %version:  1 %
 * @author  %derived_by:  qzb3mh %
 * @date    %date_modified:  Fri May 30 18:48:05 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API for controlling Onstar DD Server (Onstar Destination Download Data Services).
 *    via published messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup onstar_dd_server VIP Onstar DD Server (Onstar DD Data Services) Command Interface
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/* 
 *  Nav_Onstar_DD_Resolution_Report
 *    This function will send the currect Onstar Destination Download resolution
 */
void Nav_Onstar_DD_Resolution_Report(SIP_Onstar_DD_Address_Resolution_T onstar_dd_resolution);


/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file onstar_dd_server.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 29-Jan-2012 Ever P Cortes (sz68t3) rev 1
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}             /* extern "C" */
#   endif     /* __cplusplus */
#endif        /* ONSTAR_DD_SERVER_H */

