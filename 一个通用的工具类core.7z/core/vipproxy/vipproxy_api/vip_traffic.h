#ifndef VIP_TRAFFIC_H
#   define VIP_TRAFFIC_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_traffic.h
 *
 * API for Traffic Server (XM Data Services)
 *
 * %full_filespec: vip_traffic.h~1:incl:ctc_ec#4 %
 * @version %version: 1 %
 * @author  %derived_by: qzb3mh %
 * @date    %date_modified: Fri May 30 18:48:07 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2012 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API for controlling  Weather Server (XM Data Services).
 *    via published messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup traffic_server VIP Traffic Server (XM Data Services) Command Interface
 * @ingroup vip_traffic
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

void TRF_TMC_Filter(uint8_t index, uint8_t table_id, uint16_t broadcast_service_id, uint8_t traffic_usage);

void TRF_Traffic_Status(void);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_traffic.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 14-Oct-2011 zzgqx5
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_TRAFFIC_H */
