#ifndef VIP_PROXY_EVENT_ID_H
#   define VIP_PROXY_EVENT_ID_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_proxy_event_id.h
 *
 * Defines all events required by the VIP Proxy
 *
 * %full_filespec:vip_proxy_event_id.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:07 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 *  All of the XSAL event ids for the VIP Proxy module are defined in this
 *  file. This primarily consists of the DESIP message.
 *
 * @section ABBR ABBREVIATIONS:
 *   - VIPP - VIP Proxy. Provides proxy interface to VIP micro
 *   - VIP - Vehicle Interface Processor.
 *   - AP - Application Processor.  This micro.
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *
 *   - Requirements Document(s):
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - None.
 *
 * @defgroup vip_proxy_xsal XSAL event IDs for DESIP Messages
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

/** definition of all desip messages */
#   include "desip_msg_ids.h"


/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/
#   undef DESIP_AP_Msg
#   undef DESIP_AP_Msg_ND
#   undef DESIP_AP_Msg_VL

/* add an XSAL event ID for every AP to VIP DESIP message */
#   define DESIP_AP_Msg(id, type, desc)      SAL_PRIVATE_EVENT(VIPP_EV_##id, desc)
#   define DESIP_AP_Msg_ND(id, desc)         SAL_PRIVATE_EVENT(VIPP_EV_##id, desc)
#   define DESIP_AP_Msg_VL(id, type, desc)   SAL_PRIVATE_EVENT(VIPP_EV_##id, desc)

/**
 * All of the DESIP messages going to the VIP are declared here as private
 * XSAL messages. The VIP Proxy simply converts the header and forwards the
 * message data over DESIP.
 */
#   define VIP_PROXY_PRIVATE_EVENTS\
      SAL_PRIVATE_EVENT(VIPP_EV_START_DESIP,  "Marker ID of start of DESIP TX msgs")\
      DESIP_AP_to_VIP_Msgs



/**
 * The following events are defined and used by the VIP Proxy module and
 * are made visible to other modules; however, they are not events available
 * for subscription. The types associated with the events' data are declared
 * elsewhere in the VIP Proxy API. The types are not declared within this
 * file since doing so would expose the API to any module that used
 * xsal_event_id.h, even if it had no interest in the VIP Proxy.
 */
#   define VIP_PROXY_PUBLIC_EVENTS

/**
 * By default all DESIP message coming from the VIP are declared as published
 * events. Although, some (e.g., AD_DATA) will really be treated as a private
 * message back to the requestor.
 */

#   undef DESIP_VIP_Msg
#   undef DESIP_VIP_Msg_ND
#   undef DESIP_VIP_Msg_VL

/* add an XSAL publish event ID for every VIP to AP DESIP message */
#   define DESIP_VIP_Msg(id, type, desc)      SAL_PUBLISHED_EVENT(EVG_##id, desc)
#   define DESIP_VIP_Msg_ND(id, desc)         SAL_PUBLISHED_EVENT(EVG_##id, desc)
#   define DESIP_VIP_Msg_VL(id, type, desc)   SAL_PUBLISHED_EVENT(EVG_##id, desc)

#   define VIP_PROXY_PUBLISHED_EVENTS\
   SAL_PUBLISHED_EVENT(VIPP_EVG_START_RX_DESIP,  "Marker ID of start of DESIP Rx msgs")\
   DESIP_VIP_to_AP_Msgs \


/*===========================================================================*
 * Exported Type Declarations
 *============================================================= ==============*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_proxy_event_id.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 4-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PROXY_EVENT_ID_H */

