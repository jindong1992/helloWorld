#ifndef VIP_PITS_H
#   define VIP_PITS_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_pits.h
 *
 * API for sending PITS data via VIP
 *
 * %full_filespec:vip_pits.h~1:incl:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:07 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API to transmit a PITs reply. PITs command can be received by
 *    subscribing to EVG_PITS_COMMAND
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup vip_pits VIP PITS APIs
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "reuse.h"
#   include "desip_msg_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/** 
 * Transmit a PITs Message
 *
 * @param [in] pits_msg - pointer to pits message to transmit
 * @param [in] num_bytes - number of bytes in pits message
 *
 */
   void PITs_Send(const uint8_t * pits_msg, size_t num_bytes);

/**
 * Transmit a PITs Message
 *
 * @param [in] pits_dtc_msg - pointer to pits dtc message to transmit
 * @param [in] num_bytes - number of bytes in pits message
 *
 */
   extern void PITs_GM_DTC_Set (SIP_DTC_Code_T pits_dtc_code, bool_t pits_dtc_value, bool_t pits_did_status);

   extern void PITs_GM_Set_DID (uint8_t did_position, uint8_t did_value);

   extern void PITs_GM_Set_DID_Source (uint8_t source_value, uint8_t audio_value);

   extern void PITs_GM_Set_DID_Errors (uint8_t error_position, uint8_t error_value);

   void PITs_Send_Server(const uint8_t * pits_msg, size_t num_bytes);
/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_pits.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 * 27-Dec-2011 Miguel Garcia (kzvhr7)
 *  Add new Desip messages to support pits server commands
 *
 * 27-April-2011 Miguel Garcia
 * Update SIP_GM_DTC_T for desip dtc messages
 *
 * Nov 19 2010 kzvhr7 (Miguel Garcia) Rev 2
 * SCR kok_basa#4358 Implement Set_DTC in APP
 *
 * - 15-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PITS_H */

