#ifndef VIP_PROXY_H
#   define VIP_PROXY_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_proxy.h
 *
 * Miscellaneous VIP Proxy functions
 *
 * %full_filespec:vip_proxy.h~13.1.2:incl:ctc_ec#27 %
 * @version %version:13.1.2 %
 * @author  %derived_by:hzs8nb %
 * @date    %date_modified:Tue Jul  5 12:30:21 2016 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Grouping of VIP proxy functions that are not defined by their own sub-system proxy header
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup vip_proxy API functions to talk to VIP
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "xsal.h"
#include "desip_msg_types.h"
/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/
/**
 * Return if VIP is alive
 *
 * @return true - VIP has recently sent an alive messge
 */
   bool VIP_Is_Alive(void);


/**
 * Return if RTD is alive
 *
 * @return true - RTD has recently sent an alive messge
 */
bool RTD_Is_Alive(void);


/*
 * Reset RTD.
 */
void RTD_Reset(void);


/*
 * Release  RTD Reset.
 */

void RTD_Release(void);


/*
 * Initialize RTD persistent storage.
 */
bool_t RTD_PS_Init(void);

void VIP_AP_Shutdown_Initiate(void);
void VIP_Power_Mode_Status(SIP_Power_Mode_Status_T status);
void VIP_AP_Immediate_Shutdown(void);
void VIP_Request_Aux_Jack_Phy_State(void);
void VIP_GYRO_Selftest_Request(SIP_PITS_GYRO_TEST_ENUM_T Request);
void VIP_Get_K0R_Chksum(SIP_Cheksum_Request_T section);
void VIP_Get_FACEPLATE_K0R_Chksum(SIP_Cheksum_Request_T section);
void VIP_Get_Misc_Microphone_Status(void);
void VIP_PITS_Sent_VSS_Config_To_VIP(SIP_PITS_VSS_INPUT_CONFIG_T Config_input);
void VIP_PITS_VSS_PWM_Get_Req(void);
void VIP_Get_Power_Antenna(void);
void VIP_Set_Power_Antenna(SIP_Power_Antenna_Status_T new_power_ANT_status);
void VIP_Get_Battery_Voltage(void);
void VIP_Get_GPIO_Port_Status(SIP_VIP_Ports_T port);
void VIP_Set_GPIO_Port_Status(SIP_Set_VIP_Port_T port_status);
void VIP_Get_AD_Port_Value(SIP_AD_Channel_T channel);
void VIP_RTC_Set_Req(SIP_Date_Time_T input);
void Power_On_RTD_Request(bool_t value); /* add by zengliangqian, for PCAN use to power the display */
void VIP_Power_On_RTD_Request(bool_t value); /* add by zengliangqian, for PowerModing use to power the display */
void VIP_Select_RSE_SPDIF_Request(bool_t value); /* add by zengliangqian */
void VIP_Tuner_Send_Status(uint8_t band, uint32_t frequency);/*pzr37t send current frequency to vip for EMI*/
#if defined(GWM_CHK041_8AT)
void VIP_Vibrate_Timestamp_Get(uint32_t *timestamp);
#endif
void VIP_Request_Power_Antenna_Status(void);
void VIP_Request_GPS_Antenna_Status(void);
void VIP_Request_Mic_Failure_Status(void);
void VIP_Request_SWC_Failure_Status(void);
void VIP_Set_GPS_Antenna_Power_Status(SIP_GPS_Power_Antenna_Req_T status);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_proxy.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 15-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_PROXY_H */

