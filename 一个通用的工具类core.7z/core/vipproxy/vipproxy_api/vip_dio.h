#ifndef VIP_DIO_H
#   define VIP_DIO_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_dio.h
 *
 * API for control DIO on VIP
 *
 * %full_filespec:vip_dio.h~1:incl:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:06 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * Mirrors standard DIO routines to control discrete I/O on VIP
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup vip_dio VIP Digitial I/O APIs
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "reuse.h"
#   include "dio.h"
#   include "desip_msg_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/**
 * Reads DIO input from VIP
 *
 * @param [in] port - Identifies which port to read 
 *
 * @param [in] pin - Identifies pin within port range [0..15]
 *
 * @return true if pin is high
 */
   bool VDIO_Is_High(SIP_VIP_Ports_Enum_T port, uint8_t pin);

/**
 * Sets DIO output state on VIP
 *
 * @param [in] port - Identifies which port to set
 *
 * @param [in] pin - Identifies pin within port range [0..15]
 *
 * @param [in] high - true if desired output state of pin is high
 */
   void VDIO_Set_High(SIP_VIP_Ports_Enum_T port, uint8_t pin, bool high);
   
/**
 * Sets DIO output state on VIP without waiting for feedback
 *
 * @param [in] port - Identifies which port to set 
 *
 * @param [in] pin - Identifies pin within port range [0..15]
 *
 * @param [in] high - true if desired output state of pin is high
 */
   void VDIO_Set_High_No_Wait(SIP_VIP_Ports_Enum_T port, uint8_t pin, bool high);

/**
 * Set Direction for DIO pin on VIP
 *
 * @param [in] port - Identifies which port 
 *
 * @param [in] pin - Identifies pin within port range [0..15]
 *
 * @param [in] direction - Desired state of pin direction
 */
   void VDIO_Set_Direction(SIP_VIP_Ports_Enum_T port, uint8_t pin, DIO_Direction_T direction);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_dio.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 01-Dec-2008 Dan Carman
 *   - Added non-blocking VDIO set Pin function.
 *
 * - 15-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_DIO_H */

