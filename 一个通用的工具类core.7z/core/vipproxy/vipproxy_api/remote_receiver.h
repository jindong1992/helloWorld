#ifndef REMOTE_RECEIVER_H
#   define REMOTE_RECEIVER_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file remote_receiver.h
 *
 * API for controlling Remote Receiver (XM)
 *
 * %full_filespec:remote_receiver.h~1:incl:ctc_ec#6 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:06 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2009 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * API for controlling Remote Receiver (XM). Status and station information available
 *    via published messages
 *
 * @section ABBR ABBREVIATIONS:
 *   - DIO - Discrete I/O (also know as GPIO)
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup remote_receiver VIP Remote Receiver (XM) Command Interface
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/
#   include "reuse.h"
#include "desip_msg_types.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * Connect / Disconnect Remote Receiver
 *---------------------------------------------------------------------------*/

/**
 * Connect Remote Receiver as external source tuned to SID
 */
   void RR_Connect(void);

/**
 * Disconnect Remote Receiver as external source
 */
   void RR_Disconnect(void);

/*---------------------------------------------------------------------------*
 * Standard Tuning
 *---------------------------------------------------------------------------*/

/**
 * Remote Receiver Tune to Station ID (SID)
 * @param sid - desired SID
 */
   void RR_Tune_Station_Id(uint16_t sid);

/**
 * Remote Receiver Set Preset (preset)
 * @param preset - Set Preset
 */
   void RR_Set_Preset_Id(uint16_t preset);

/**
 * Remote Receiver Recall Preset (preset)
 * @param preset - Recall Preset
 */
   void RR_Recall_Preset_Id(uint16_t preset);

/**
 * Remote Receiver Tune to Channel 
 * @param channel - desired channel 
 */
   void RR_Tune_Channel(uint16_t channel);

/**
 * Remote Receiver Tune to Channel 
 * @param channel_delta - desired channel 
 */
   void RR_Tune_Delta(int16_t channel_delta);

/**
 * Remote Receiver Scan Up 
 */
   void RR_Scan_Up(void);

/**
 * Remote Receiver Scan Down
 */
   void RR_Scan_Down(void);

/*---------------------------------------------------------------------------*
 * Category Tuning
 *---------------------------------------------------------------------------*/

/**
 * Remote Receiver Set Current Category 
 *    Automatically Tunes to first station in selected category
 * @param cat_id - desired category
 */
   void RR_Set_Category(uint16_t cat_id);

/**
 * Remote Receiver Set Category by Delta
 *    Automatically Tunes to first station in selected category
 * @param cat_delta - change of category ID
 */
   void RR_Change_Category(int16_t cat_delta);

/**
 * Remote Receiver Scan Up within current Category
 */
   void RR_Scan_Up_In_Cat(void);

/**
 * Remote Receiver Scan Down within current Category
 */
   void RR_Scan_Down_In_Cat(void);

/**
 * Remote Receiver Delta Tune within current Category
 * @param channel_delta - number of channels to tune by within category
 */
   void RR_Tune_Delta_In_Cat(int16_t channel_delta);

/*---------------------------------------------------------------------------*
 * List Requests
 *---------------------------------------------------------------------------*/

/**
 * Remote Receiver Request Station List
 */
   void RR_Request_Station_List(void);

/**
 * Remote Receiver Request Category List
 */
   void RR_Request_Category_List(void);

/**
 * Remote Receiver Request Station List for current Category
 */
   void RR_Request_Station_List_In_Cat(void);


/*---------------------------------------------------------------------------*
 * Redundant Commands
 *---------------------------------------------------------------------------*/

/**
 * Remote Receiver Seek Up (same as tune delta 1)
 */
void RR_Seek_Up(void);

/**
 * Remote Receiver Seek Down (same as tune delta -1)
 */
void RR_Seek_Down(void);

/**
 * Remote Receiver Seek Cat Down  (same as tune delta in cat 1)
 */
void RR_Seek_Cat_Up(void);

/**
 * Remote Receiver Seek Cat Down (same as tune delta in cat -1)
 */
void RR_Seek_Cat_Down(void);
/*---------------------------------------------------------------------------*
 * Tune Select
 *---------------------------------------------------------------------------*/

/*
 * Send through DESIP protocol a Tune Select command 
 * @param ts_cmnd - Tune Select Commnand 
 */
extern void RR_Tune_Sel_Send_Command(SIP_Rem_Rcvr_Commands_ENUM_T cmd, int16_t tune_value);


/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file remote_receiver.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * -04-April-2012 Gustavo M Guzman Ver 6
 *    - kok_basa#23806 XM Diagnostics is not implemented.
 *      Update the XM Recall and Preset functionality
 *
 * 14-Feb-2012 Antonio C. Arriaga (bzrth8) Rev 5
 * CR kok_basa#15216: Add logic to support the XM box connection and disconnection process 
 *
 *  19-Oct-2011 Antonio C. Arriaga (bzrth8)
 *  Add new Remote Receiver function to send through 
 *  DESIP protocol a Tune Select command 
 *
 * - 18-March-2009 Dan Carman
 *   - SCR 59427 - Add redundant commands because GM requirement
 *
 * - 23-Jan-2009 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* REMOTE_RECEIVER_H */

