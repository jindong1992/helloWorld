#ifndef VIP_IIC_H
#   define VIP_IIC_H
#   ifdef __cplusplus
extern "C"
{
#   endif                       /* __cplusplus */
/*===========================================================================*/
/**
 * @file vip_iic.h
 *
 * API for sending / receiving IIC data via VIP
 *
 * %full_filespec:vip_iic.h~1:incl:ctc_ec#20 %
 * @version %version:1 %
 * @author  %derived_by:qzb3mh %
 * @date    %date_modified:Fri May 30 18:48:06 2014 %
 *
 *------------------------------------------------------------------------------
 *
 * Copyright 2008 Delphi Technologies, Inc., All Rights Reserved.
 * Delphi Confidential
 *
 *------------------------------------------------------------------------------
 *
 * @section DESC DESCRIPTION:
 *
 * @todo Add full description here
 *
 * @section ABBR ABBREVIATIONS:
 *   - @todo List any abbreviations, precede each with a dash ('-').
 *
 * @section TRACE TRACEABILITY INFO:
 *   - Design Document(s):
 *     - @todo Update list of design document(s).
 *
 *   - Requirements Document(s):
 *     - @todo Update list of requirements document(s)
 *
 *   - Applicable Standards (in order of precedence: highest first):
 *     - <a href="http://kogespw1.delcoelect.com:8508/passthru/consumer?name=SW%20REF%20264.15D&doctype=K8DBSDoc">
 *       SW REF 264.15D "Delphi C Coding Standards" [12-Mar-2006]</a>
 *     - @todo Update list of other applicable standards
 *
 * @section DFS DEVIATIONS FROM STANDARDS:
 *   - @todo List of deviations from standards in this file, or "None".
 *
 * @defgroup vip_iic VIP IIC APIs
 * @ingroup vip_proxy
 * @{
 */
/*==========================================================================*/

/*===========================================================================*
 * Header Files
 *===========================================================================*/

#   include "reuse.h"

/*===========================================================================*
 * Exported Preprocessor #define Constants
 *===========================================================================*/

/*===========================================================================*
 * Exported Preprocessor #define MACROS
 *===========================================================================*/

/*===========================================================================*
 * Exported Type Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Const Object Declarations
 *===========================================================================*/

/*===========================================================================*
 * Exported Function Prototypes
 *===========================================================================*/

/** 
 * Write data via IIC channel on VIP
 *
 * @param [in] vip_channel - Identifies IIC channel 
 * @param [in] device - Device address (left shifted)
 * @param [in] no_stop - true if stop is to be suppressed
 * @param [in] wdata - pointer to bytes to transmit
 * @param [in] num_bytes - number of data bytes
 *
 */

   void VIIC_Write(uint8_t vip_channel, uint8_t device, bool no_stop, const uint8_t * wdata, size_t num_bytes);

/**
 * VIP IIC Recieve
 *
 * @param [in] vip_channel - Identifies IIC channel 
 * @param [in] device - Device address (left shifted)
 * @param [out] rdata - Pointer to buffer to store data bytes
 * @param [in] num_bytes - Number of data bytes
 *
 * @return true if read is successful
 */
   bool VIIC_Read(uint8_t vip_channel, uint8_t device, uint8_t * rdata, size_t num_bytes);

/*===========================================================================*
 * Exported Inline Function Definitions and #define Function-Like Macros
 *===========================================================================*/

/*===========================================================================*/
/*!
 * @file vip_iic.h
 *
 * @section RH REVISION HISTORY (top to bottom: last revision to first revision)
 *
 * - 15-Sept-2008 Dan Carman
 *   - Created initial file.
 */
/*===========================================================================*/
/** @} doxygen end group */
#   ifdef __cplusplus
}                               /* extern "C" */
#   endif                       /* __cplusplus */
#endif                          /* VIP_IIC_H */

